/**
 * WebTerm ← Folia 绘光 接口层
 *
 * 全量照搬 Folia lumiere 源码（lumiere-src/），此处只做 re-export + 全局挂载，
 * 让 WebTerm 的普通 <script> 能通过 window.LumiereFolia 访问编译产物。
 *
 * 注意：必须用 `import ... + export {...}` 而非 `export {...} from ...`——
 * re-export 不建立本地绑定，挂载对象（window.LumiereFolia）里的简写属性
 * 会引用未定义标识符（浏览器实测报 compileLumiereProgram is not defined）。
 */
import { MotionValue } from 'framer-motion';
import {
    compileLumiereProgram,
    findLumiereParagraphIndexAtTime,
} from './lumiere-src/components/visualizer/lumiere/lumiereProgram';
import { LumierePixiRuntime } from './lumiere-src/components/visualizer/lumiere/createLumierePixiRuntime';
import { DEFAULT_LUMIERE_PARAMS } from './lumiere-src/components/visualizer/lumiere/program';
import { segmentTextWords } from './lumiere-src/utils/lyrics/wordSegmentation';
import { BASE_DUAL_THEME, DEFAULT_THEME, DAYLIGHT_THEME } from './lumiere-src/services/baseThemes';

export {
    MotionValue,
    compileLumiereProgram,
    findLumiereParagraphIndexAtTime,
    LumierePixiRuntime,
    DEFAULT_LUMIERE_PARAMS,
    segmentTextWords,
    /* 原版 Folia 的两套内置主题（services/baseThemes.ts 原样移植）：
       午夜墨染（深） / 日光素白（浅）。WebTerm 里由【设置】→【外观】的黑 / 白决定用哪套。 */
    BASE_DUAL_THEME,
    DEFAULT_THEME,
    DAYLIGHT_THEME,
};

export type { LumiereProgram } from './lumiere-src/components/visualizer/lumiere/lumiereProgram';
export type {
    Line,
    Theme,
    LumiereTuning,
    AudioBands,
} from './lumiere-src/types';
export type {
    LumiereSongContext,
    LumiereSongMetadata,
    LumiereRuntimeOptions,
} from './lumiere-src/components/visualizer/lumiere/createLumierePixiRuntime';

declare global {
    interface Window {
        LumiereFolia?: {
            MotionValue: typeof MotionValue;
            compileLumiereProgram: typeof compileLumiereProgram;
            findLumiereParagraphIndexAtTime: typeof findLumiereParagraphIndexAtTime;
            LumierePixiRuntime: typeof LumierePixiRuntime;
            DEFAULT_LUMIERE_PARAMS: typeof DEFAULT_LUMIERE_PARAMS;
            segmentTextWords: typeof segmentTextWords;
            BASE_DUAL_THEME: typeof BASE_DUAL_THEME;
            DEFAULT_THEME: typeof DEFAULT_THEME;
            DAYLIGHT_THEME: typeof DAYLIGHT_THEME;
        };
    }
}

(globalThis as { window?: Window }).window && ((globalThis as any).window.LumiereFolia = {
    MotionValue,
    compileLumiereProgram,
    findLumiereParagraphIndexAtTime,
    LumierePixiRuntime,
    DEFAULT_LUMIERE_PARAMS,
    segmentTextWords,
    BASE_DUAL_THEME,
    DEFAULT_THEME,
    DAYLIGHT_THEME,
});
