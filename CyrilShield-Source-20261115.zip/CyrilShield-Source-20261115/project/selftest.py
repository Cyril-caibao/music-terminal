# -*- coding: utf-8 -*-
"""CyrilShield 自检脚本（无需图形界面）。

用法：python selftest.py  [目标EXE路径]
不传参数时默认使用 C:\\Windows\\System32\\notepad.exe 作为样本。
"""
from __future__ import annotations

import hashlib
import os
import random
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cyrilshield import _stream, antitamper, apk, axml, dexvm, pe, upx, vmgen  # noqa: E402

PASS, FAIL, SKIP = "[ OK ]", "[FAIL]", "[SKIP]"
results = []
skipped = []


def check(name, fn):
    try:
        detail = fn()
        results.append(True)
        print(f"{PASS} {name}" + (f" — {detail}" if detail else ""))
    except Exception as exc:
        results.append(False)
        print(f"{FAIL} {name} — {type(exc).__name__}: {exc}")


def skip(name, why):
    skipped.append(name)
    print(f"{SKIP} {name} — {why}")


def main():
    flags = {a for a in sys.argv[1:] if a.startswith("--")}
    positional = [a for a in sys.argv[1:] if not a.startswith("--")]
    sample = positional[0] if positional else r"C:\Windows\System32\notepad.exe"
    if not os.path.isfile(sample):
        print(f"样本不存在：{sample}")
        return 1
    tmp = tempfile.mkdtemp(prefix="cyrilshield_selftest_")
    print("样本:", sample)
    print("临时目录:", tmp, "\n")

    f = None

    def t_pe():
        nonlocal f
        f = pe.load(sample)
        s = f.summary()
        return f"{s['machine']} / {s['pe_type']} / {len(s['sections'])} 节区"
    check("PE 头解析", t_pe)

    def t_icons():
        groups = f.extract_icon_groups()
        out = os.path.join(tmp, "icons")
        files = pe.export_icons(f, out, True, True, log=lambda *_: None)
        assert files, "未导出任何文件"
        return f"{len(groups)} 组图标 → {len(files)} 个文件"
    check("图标提取（ICO + PNG）", t_icons)

    def t_png():
        from PIL import Image
        pngs = [os.path.join(r, x) for r, _, fs in os.walk(os.path.join(tmp, "icons"))
                for x in fs if x.lower().endswith(".png")]
        for p in pngs:
            Image.open(p).verify()
        return f"{len(pngs)} 张 PNG 全部可解码" if pngs else "无 PNG（样本可能无图标）"
    try:
        import PIL  # noqa: F401
        check("PNG 图像有效性", t_png)
    except ImportError:
        print("[SKIP] PNG 图像有效性 — 未安装 Pillow")

    tool = upx.find_upx()
    packed = os.path.join(tmp, "packed.exe")
    restored = os.path.join(tmp, "restored.exe")

    def t_upx():
        assert tool, "未找到 upx.exe"
        opt = upx.PackOptions(level=7, force=True)
        rc, _, _ = upx.execute("pack", tool, sample, packed, opt,
                               on_line=lambda *_: None)
        assert rc == 0 and os.path.isfile(packed), "压缩失败"
        a, b = os.path.getsize(sample), os.path.getsize(packed)
        return f"{a:,} → {b:,} 字节（{upx.version(tool).splitlines()[0]}）"
    check("UPX 压缩加壳", t_upx)

    def t_upt():
        rc, _, _ = upx.execute("test", tool, packed, on_line=lambda *_: None)
        assert rc == 0, "完整性测试失败"
        return "-t 通过"
    check("UPX 完整性测试", t_upt)

    def t_upd():
        rc, _, _ = upx.execute("unpack", tool, packed, restored,
                               on_line=lambda *_: None)
        assert rc == 0, "脱壳失败"
        # UPX 会重建 PE 头，因此不保证与原文件逐字节一致，只校验结构与量级
        r = pe.load(restored).summary()
        o = pe.load(sample).summary()
        assert r["machine"] == o["machine"] and r["pe_type"] == o["pe_type"], "还原后 PE 结构不一致"
        a, b = o["size"], r["size"]
        assert abs(a - b) <= max(8192, a * 0.15), f"还原大小异常：{a:,} → {b:,}"
        return f"还原为有效 PE，{a:,} → {b:,} 字节（UPX 不保证逐字节相同）"
    check("UPX 脱壳还原有效性", t_upd)

    def t_vmprog():
        plain = open(sample, "rb").read()
        rng = random.SystemRandom()
        key = rng.randbytes(32)
        prog, ops, plan = vmgen.make_program(key, 2, rng)
        payload = os.path.join(tmp, plan.payload_name)
        with open(payload, "wb") as fh:
            fh.write(vmgen.pack_payload(plain, key, vmgen.FLAG_VERIFY,
                                        os.path.basename(sample), "", plan))
        outdir = os.path.join(tmp, "vmcheck")
        os.makedirs(outdir, exist_ok=True)
        assert vmgen.selftest(prog, ops, plan, payload, outdir), "字节码执行失败"
        h1 = hashlib.sha256(plain).hexdigest()
        h2 = hashlib.sha256(open(os.path.join(outdir, "restored.exe"), "rb").read()).hexdigest()
        assert h1 == h2, "解密还原内容不一致"
        return f"{len(prog) // 8} 条虚拟指令，还原哈希一致"
    check("VM 字节码 / 载荷加解密", t_vmprog)

    def t_poly():
        rng = random.SystemRandom()
        key = rng.randbytes(32)
        a = vmgen.make_program(key, 1, rng)
        b = vmgen.make_program(key, 1, rng)
        assert a[0] != b[0], "两次构建字节码相同"
        assert a[1] != b[1], "两次构建操作码映射相同"
        pa, pb = a[2], b[2]
        assert pa.magic != pb.magic, "载荷魔数未随机化"
        assert pa.salt != pb.salt, "密钥盐未随机化"
        assert len(a[2].names) == len(set(a[2].names.values())), "符号名重复"
        return f"魔数/盐/字段排列/符号名均随机（{pa.order} vs {pb.order}）"
    check("VM 多态随机化", t_poly)

    def t_guard_mode():
        assert antitamper.guard_mode(False, False) == 0
        assert antitamper.guard_mode(True, False) == 1
        assert antitamper.guard_mode(False, True) == 2
        assert antitamper.guard_mode(True, True) == 3
        return "关闭 / 反调试 / 反分析 / 全开 = 0 / 1 / 2 / 3"
    check("守卫位掩码", t_guard_mode)

    def t_guard_source():
        for mode in (0, 1, 2, 3):
            for sec in (False, True):
                src = antitamper.injected_source(mode, sec)
                compile(src, "<guard>", "exec")
                assert "__GUARD_MODE__" not in src
                assert "__SECURE_TEMP__" not in src
        return "4 种守卫 × 2 种释放均可编译，占位符全部消除"
    check("守卫注入源码语法", t_guard_source)

    def t_guard_runtime():
        ns = {"__name__": "_guard_probe"}
        exec(compile(antitamper.injected_source(0, False), "<guard>", "exec"), ns)
        assert ns["_at_guard"]() is True, "守卫关闭时必须放行"
        assert callable(ns["_at_spawn"]), "释放函数未定义"
        return "关闭态放行 · 检测异常不阻断 · 释放函数就位"
    check("守卫运行时放行", t_guard_runtime)

    def t_stub_inject():
        rng = random.SystemRandom()
        key = rng.randbytes(32)
        prog, ops, plan = vmgen.make_program(key, 1, rng)
        for mode in (0, 3):
            for sec in (False, True):
                stub = vmgen.render_stub(prog, ops, "probe", plan,
                                         mode=mode, secure_temp=sec)
                compile(stub.source, "<stub>", "exec")
                assert "__INJECTED_SOURCE__" not in stub.source
                assert "_at_guard()" in stub.source
                assert "_at_spawn(" in stub.source
        return "注入后 boot.py 源码 4 组参数均可编译，调用点齐全"
    check("stub 注入后完整性", t_stub_inject)

    def t_upxb():
        tool = upx.find_upx()
        assert tool, "未找到内置 upx.exe"
        root = os.path.dirname(os.path.dirname(os.path.abspath(upx.__file__)))
        assert os.path.abspath(tool).startswith(root), f"UPX 不是内置副本：{tool}"
        return os.path.relpath(tool, root)
    check("内置 UPX", t_upxb)

    def t_web():
        from cyrilshield import server
        wd = server.web_dir()
        for n in ("index.html", "app.css", "app.js"):
            assert os.path.isfile(os.path.join(wd, n)), f"缺少界面资源 {n}"
        return wd
    check("Web 界面资源", t_web)

    def t_backend():
        ok, info = vmgen.check_backend()
        return info
    check("VM 构建后端", t_backend)

    # ---------------- APK 加固 ----------------
    apk_sample = next((a for a in positional if a.lower().endswith(".apk")
                       and os.path.isfile(a)), None)
    if not apk_sample:
        cand = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "tests", "sample.apk")
        if os.path.isfile(cand):
            apk_sample = cand
    tools = apk.find_tools()

    def t_seal():
        rng = random.Random(2026)
        rows = [[rng.getrandbits(32) for _ in range(4)] for _ in range(8)]
        mat = b"".join((rows[g][i] ^ rows[g + 4][i]).to_bytes(4, "big")
                       for g in range(4) for i in range(4))
        sr, sp = rng.randbytes(32), rng.randbytes(32)
        root = _stream.root_key(sr, mat)
        k0 = _stream.sub_key(root, sp, 0)
        k1 = _stream.sub_key(root, sp, 1)
        assert k0 != k1, "不同段的子密钥不应相同"
        assert _stream.root_key(sr, mat) == root, "根密钥派生不稳定"
        assert _stream.root_key(sp, mat) != root, "换盐应得到不同根密钥"
        plain = b"dex\n035\x00" + bytes(range(256)) * 40
        nonce = rng.randbytes(_stream.NONCE)
        blob = _stream.seal(k0, nonce, plain)
        assert len(blob) == len(plain) + _stream.TRAILER, "封装后长度异常"
        assert blob[:4] != b"PSPL" and blob[:4] != b"dex\n", "载荷不应带可识别头部"
        assert _stream.open_sealed(k0, blob) == plain, "往返解密不一致"
        assert _stream.open_sealed(k1, blob) == b"", "错误子密钥应拒绝解密"
        bad = bytearray(blob)
        bad[len(bad) // 3] ^= 0x01
        assert _stream.open_sealed(k0, bytes(bad)) == b"", "篡改密文未被检出"
        trunc = blob[:-1]
        assert _stream.open_sealed(k0, trunc) == b"", "截断载荷未被检出"
        return (f"{len(blob):,} 字节 · 尾部 {_stream.TRAILER} 字节元数据 · "
                f"篡改/截断可检出")
    check("载荷容器封装", t_seal)

    # ---------------- APK 引导链 VM 虚拟化 ----------------
    def _vm_fixture(seed=20261108, n=4):
        rng = random.Random(seed)
        rows = [[rng.getrandbits(32) for _ in range(4)] for _ in range(8)]
        mat = b"".join((rows[g][i] ^ rows[g + 4][i]).to_bytes(4, "big")
                       for g in range(4) for i in range(4))
        sr, sp = rng.randbytes(32), rng.randbytes(32)
        root = _stream.root_key(sr, mat)
        chunks = [b"dex\n035\x00" + bytes([i]) + os.urandom(180 + i * 73)
                  for i in range(n)]
        order = list(range(n))
        rng.shuffle(order)
        if n > 1 and order == list(range(n)):
            order[0], order[1] = order[1], order[0]
        blobs = []
        for i in range(n):
            k = _stream.sub_key(root, sp, i)
            blobs.append(_stream.seal(k, rng.randbytes(16), chunks[order[i]]))
        prefixes = [bytes([0x11]) + struct.pack(">H", i) for i in range(n)]
        want = hashlib.sha256(b"".join(chunks)).digest()
        return rng, rows, sr, sp, prefixes, want, order, chunks, blobs

    def _vm_prog(fx, seed=123, verify=True):
        _rng, rows, sr, sp, pfx, want, order, _c, _b = fx
        return dexvm.compile_program(dexvm.VmPlan(
            rows, sr, sp, pfx, want if verify else b"",
            emit_order=order, seed=seed))

    def t_dexvm():
        fx = _vm_fixture()
        prog = _vm_prog(fx)
        parts, ok = dexvm.interp(prog, fx[8])
        assert ok and parts == fx[7], "VM 未能把乱序分片还原成原序"
        bad = list(fx[8])
        bad[0] = bad[0][:-1] + bytes([bad[0][-1] ^ 1])
        _, ok2 = dexvm.interp(prog, bad)
        assert not ok2, "载荷被篡改后 VM 仍放行"
        p2 = _vm_prog(fx, seed=999)
        assert prog.code != p2.code and prog.ops != p2.ops and prog.mask != p2.mask, \
            "换 seed 后字节码未变化，多态失效"
        p3 = _vm_prog(fx, seed=7, verify=False)
        parts3, ok3 = dexvm.interp(p3, fx[8])
        assert ok3 and parts3 == fx[7], "关闭整体校验后仍应正常还原"
        return (f"{len(prog.code) // dexvm.W} 条指令 · {prog.junk} 条垃圾 · "
                f"{prog.nparts} 片乱序还原 · 篡改可检出")
    check("APK 引导链 VM（编译/还原/篡改/多态）", t_dexvm)

    JAVA_HARNESS = """package vmtest;
import java.security.MessageDigest;
public class T {
  static String hx(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b){int v=x&255;if(v<16)s.append('0');s.append(Integer.toHexString(v));}return s.toString();}
  public static void main(String[] a) throws Exception {
    int[] c = new int[]{@CODE@};
    byte[][] pl = new byte[][]{@POOL@};
    byte[] m = @MASK@;
    int[] o = new int[]{@OPS@};
    final byte[][] as = new byte[][]{@ASSETS@};
    byte[][] r = Vm.run(c, pl, m, o, new Vm.Host(){public byte[] asset(int i){return as[i];}});
    if (r == null) { System.out.println("NULL"); return; }
    for (int i=0;i<r.length;i++) System.out.println(i+" "+r[i].length+" "+hx(MessageDigest.getInstance("SHA-256").digest(r[i])));
  }
}
"""
    def t_dexvm_dual():
        javac, java = shutil.which("javac"), shutil.which("java")
        assert javac and java, "缺少 javac/java"
        fx = _vm_fixture(seed=4242, n=4)
        prog = _vm_prog(fx, seed=555)
        work = os.path.join(tmp, "vmjava")
        d = os.path.join(work, "vmtest")
        os.makedirs(d, exist_ok=True)
        open(os.path.join(d, "Vm.java"), "w", encoding="utf-8").write(
            dexvm.java_source(prog, "vmtest", "Vm"))
        aj = ", ".join("new byte[]{%s}" % ", ".join(
            str(b - 256 if b > 127 else b) for b in x) for x in fx[8])
        h = (JAVA_HARNESS.replace("@CODE@", prog.as_java_ints())
             .replace("@POOL@", prog.as_java_pool())
             .replace("@MASK@", prog.as_java_mask())
             .replace("@OPS@", prog.as_java_ops())
             .replace("@ASSETS@", aj))
        open(os.path.join(d, "T.java"), "w", encoding="utf-8").write(h)
        obj = os.path.join(work, "obj")
        r = subprocess.run(
            [javac, "-encoding", "UTF-8", "-source", "8", "-target", "8",
             "-nowarn", "-d", obj, os.path.join(d, "Vm.java"),
             os.path.join(d, "T.java")],
            capture_output=True, text=True, timeout=180)
        assert r.returncode == 0, "Java 解释器编译失败：" + r.stderr[-300:]
        r2 = subprocess.run([java, "-cp", obj, "vmtest.T"],
                            capture_output=True, text=True, timeout=120)
        assert r2.returncode == 0, "Java 解释器运行失败：" + r2.stderr[-300:]
        lines = [l.split() for l in r2.stdout.strip().splitlines()]
        assert len(lines) == len(fx[7]), "Java 侧返回分片数不符"
        for i, (_idx, ln, hx) in enumerate(lines):
            assert int(ln) == len(fx[7][i]), f"第 {i} 片长度不符"
            assert hx == hashlib.sha256(fx[7][i]).hexdigest(), f"第 {i} 片内容不符"
        shutil.rmtree(work, ignore_errors=True)
        return f"JDK 真编译运行，{len(lines)} 片哈希与 Python 侧逐字节一致"
    if shutil.which("javac") and shutil.which("java"):
        check("APK VM 双端一致性（JDK 解释器）", t_dexvm_dual)
    else:
        skip("APK VM 双端一致性（JDK 解释器）", "未找到 javac / java")

    def t_stub_source():
        fx = _vm_fixture(seed=777, n=3)
        prog = _vm_prog(fx, seed=31)
        ae = ["new byte[]{1,2,3}"] * 3
        g = apk.render_stub_sources(
            stub_pkg="com.test.psabc", stub_cls="ShellXyz", prog=prog,
            lens=[100, 200, 300], asset_enc=ae, ak=fx[0].randbytes(8),
            real_name="com.test.RealApp", sig=b"", mode=0,
            wipe_memory=True, debug=False, rng=fx[0])
        for ph in ("@CODE@", "@POOL@", "@ASSETS@", "@MODE@", "@VMCLS@",
                   "@RS@", "@LENS@", "@SG@", "@AK@", "@OPS@", "@MASK@"):
            assert ph not in g["app"], "残留占位符 " + ph
        for lit in ('"dexElements"', '"pathList"',
                    '"android.app.ActivityThread"', '"SHA-256"'):
            assert lit not in g["app"], "固定指纹未消除：" + lit
        for m in ("boot", "inject", "find", "dec", "sigOk", "envOk", "swap"):
            assert not re.search(r"\b" + m + r"\s*\(", g["app"]), \
                "方法名未随机化：" + m
        g2 = apk.render_stub_sources(
            stub_pkg="com.test.psabc", stub_cls="ShellXyz", prog=prog,
            lens=[100, 200, 300], asset_enc=ae, ak=fx[0].randbytes(8),
            real_name="com.test.RealApp", sig=b"", mode=0,
            wipe_memory=False, debug=False, rng=fx[0])
        assert g["app"].count("Arrays.fill") > g2["app"].count("Arrays.fill"), \
            "内存擦除开关未生效"
        return "占位符清零 · 反射字符串已编码 · 方法名已随机化 · 擦除开关有效"
    check("APK 壳源码生成与指纹消除", t_stub_source)

    ANDROID_STUBS = {
        "android/content/res/AssetManager.java":
            "package android.content.res;import java.io.InputStream;"
            "public class AssetManager{public InputStream open(String n)throws java.io.IOException{return null;}}",
        "android/content/Context.java":
            "package android.content;import java.io.File;public class Context{"
            "public android.content.res.AssetManager getAssets(){return null;}"
            "public android.content.pm.PackageManager getPackageManager(){return null;}"
            "public String getPackageName(){return \"\";}"
            "public File getCodeCacheDir(){return null;}"
            "public ClassLoader getClassLoader(){return null;}"
            "public Context getBaseContext(){return null;}"
            "protected void attachBaseContext(Context b){}}",
        "android/app/Application.java":
            "package android.app;import android.content.Context;"
            "public class Application extends Context{public void onCreate(){}}",
        "android/content/pm/Signature.java":
            "package android.content.pm;public class Signature{public byte[] toByteArray(){return null;}}",
        "android/content/pm/PackageInfo.java":
            "package android.content.pm;public class PackageInfo{public Signature[] signatures;}",
        "android/content/pm/PackageManager.java":
            "package android.content.pm;public class PackageManager{"
            "public static final int GET_SIGNATURES=64;"
            "public PackageInfo getPackageInfo(String p,int f)throws Exception{return null;}}",
        "android/os/Build.java":
            "package android.os;public class Build{"
            "public static final String FINGERPRINT=\"\",MODEL=\"\";"
            "public static final class VERSION{public static final int SDK_INT=30;}}",
        "android/os/Debug.java":
            "package android.os;public class Debug{public static boolean isDebuggerConnected(){return false;}}",
        "android/util/Log.java":
            "package android.util;public class Log{public static int i(String t,String m){return 0;}}",
        "dalvik/system/InMemoryDexClassLoader.java":
            "package dalvik.system;import java.nio.ByteBuffer;"
            "public class InMemoryDexClassLoader extends ClassLoader{"
            "public InMemoryDexClassLoader(ByteBuffer[] b,ClassLoader p){}"
            "public InMemoryDexClassLoader(ByteBuffer b,ClassLoader p){}}",
        "dalvik/system/DexClassLoader.java":
            "package dalvik.system;public class DexClassLoader extends ClassLoader{"
            "public DexClassLoader(String a,String b,String c,ClassLoader d){}}",
    }

    def t_stub_compile():
        javac = shutil.which("javac")
        assert javac, "缺少 javac"
        work = os.path.join(tmp, "apkstub")
        for rel, body in ANDROID_STUBS.items():
            p = os.path.join(work, "stubs", rel)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "w", encoding="utf-8").write(body + "\n")
        stub_files = [os.path.join(work, "stubs", r) for r in ANDROID_STUBS]
        fx = _vm_fixture(seed=909, n=3)
        prog = _vm_prog(fx, seed=66)
        ae = ["new byte[]{1,2,3}"] * 3
        ok = 0
        for ci, (mode, wipe, debug, withsig) in enumerate(
                ((0, True, False, False), (7, False, True, True),
                 (2, True, True, False), (5, False, False, True))):
            g = apk.render_stub_sources(
                stub_pkg="com.test.psabc", stub_cls="ShellXyz", prog=prog,
                lens=[100, 200, 300], asset_enc=ae, ak=fx[0].randbytes(8),
                real_name="com.test.RealApp",
                sig=hashlib.sha256(b"cert").digest() if withsig else b"",
                mode=mode, wipe_memory=wipe, debug=debug, rng=fx[0])
            d = os.path.join(work, "c%d" % ci, "com", "test", "psabc")
            os.makedirs(d, exist_ok=True)
            app = os.path.join(d, "ShellXyz.java")
            vmj = os.path.join(d, g["vm_class"] + ".java")
            open(app, "w", encoding="utf-8").write(g["app"])
            open(vmj, "w", encoding="utf-8").write(g["vm"])
            r = subprocess.run(
                [javac, "-encoding", "UTF-8", "-source", "8", "-target", "8",
                 "-nowarn", "-d", os.path.join(work, "c%d" % ci, "obj"),
                 app, vmj] + stub_files,
                capture_output=True, text=True, timeout=180)
            assert r.returncode == 0, f"组合 {ci} 编译失败：" + r.stderr[-300:]
            ok += 1
        shutil.rmtree(work, ignore_errors=True)
        return f"{ok} 组开关组合（mode/wipe/debug/签名绑定）javac 编译通过"
    if shutil.which("javac"):
        check("APK 壳源码编译校验（桩类）", t_stub_compile)
    else:
        skip("APK 壳源码编译校验（桩类）", "未找到 javac")

    root = apk.bundled_toolchain()

    def t_bundled():
        t = apk._tools_from_bundled(root)
        assert t["ok"], "缺少：" + "、".join(t["missing"])
        assert t["bundled"], "未标记为内置"
        total = 0
        for base, _d, files in os.walk(root):
            for f in files:
                total += os.path.getsize(os.path.join(base, f))
        return (f"{total / 1048576:.0f} MB · JRE {os.path.basename(t['java_home'])} · "
                f"platform {t['platform']}")
    if root:
        check("内置工具链（便携版）", t_bundled)
    else:
        skip("内置工具链（便携版）", "未生成 toolchain/，可用 build_portable.py 生成")

    if not apk_sample:
        skip("AXML 清单改写", "未提供 APK 样本")
        skip("APK 结构解析", "未提供 APK 样本")
        skip("APK 加固构建", "未提供 APK 样本")
    else:
        def t_axml():
            raw = zipfile.ZipFile(apk_sample).read("AndroidManifest.xml")
            doc = axml.Document.parse(raw)
            same = doc.to_bytes() == raw
            assert same, "未改动时序列化结果应与原文件逐字节相同"
            info = axml.manifest_info(doc)
            doc2 = axml.Document.parse(raw)
            axml.set_application_class(doc2, "com.test.ShellApp")
            out = doc2.to_bytes()
            info2 = axml.manifest_info(axml.Document.parse(out))
            assert info2["app_class"] == "com.test.ShellApp", "壳类名未写入"
            assert info2["package"] == info["package"], "包名被破坏"
            n1 = len(axml.Document.parse(raw).resource_ids)
            n2 = len(axml.Document.parse(out).resource_ids)
            assert n2 == n1, "资源映射表被破坏"
            return f"{len(doc.pool.strings)} 条字符串 / {n1} 条资源映射，往返逐字节一致"
        check("AXML 清单改写", t_axml)

        def t_apkinspect():
            d = apk.inspect(apk_sample, tools)
            assert d["package"], "未解析出包名"
            assert d["dexes"], "未解析出 dex"
            return (f"{d['package']} · {len(d['dexes'])} 个 dex · "
                    f"签名 {'+'.join(d['signature']['schemes']) or '无'}")
        check("APK 结构解析", t_apkinspect)

        if not tools["ok"]:
            skip("APK 加固构建", "缺少 " + "、".join(tools["missing"]))
        else:
            def t_apkbuild():
                out = os.path.join(tmp, "protected.apk")
                r = apk.protect(apk_sample, out, apk.ApkOptions(level="strong", seed=42),
                                log=lambda *_: None)
                assert os.path.isfile(out), "未生成 APK"
                assert all(r["checks"].values()), "产物自检未通过"
                names = zipfile.ZipFile(out).namelist()
                assert not any(n.endswith(".dex") and n != "classes.dex" for n in names), \
                    "原始 dex 未被移除"
                return (f"{r['size_before']:,} → {r['size_after']:,} 字节 · "
                        f"{r['payload_parts']} 段载荷 · 壳类 {r['stub_class']}")
            check("APK 加固构建", t_apkbuild)

            def t_apkcompat():
                out = os.path.join(tmp, "compat.apk")
                r = apk.protect(apk_sample, out, apk.ApkOptions(level="compat", seed=7),
                                log=lambda *_: None)
                names = zipfile.ZipFile(out).namelist()
                assert "classes.dex" in names, "兼容模式不应移除 dex"
                return f"{r['size_after']:,} 字节，dex 原样保留"
            check("APK 兼容模式", t_apkcompat)

    if "--full" in flags:
        def t_vmbuild():
            out = os.path.join(tmp, "vm_protected.exe")
            r = vmgen.build(sample, out, vmgen.VMOptions(junk_level=1),
                            on_line=lambda *_: None)
            assert os.path.isfile(out), "未生成 EXE"
            return f"输出 {r.output_size:,} 字节 / {r.program_size} 条虚拟指令"
        check("VM 壳完整构建", t_vmbuild)

    print("\n" + "=" * 60)
    line = f"结果：{sum(results)}/{len(results)} 项通过"
    if skipped:
        line += f"（{len(skipped)} 项跳过）"
    print(line)
    if "--keep" not in flags:
        shutil.rmtree(tmp, ignore_errors=True)
    else:
        print("临时产物保留于:", tmp)
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
