# 第十批改动：Windows 多线程上下文 + Linux ELF 加固入口

日期：2026-11-14　基线：第九批（多线程上下文 / 负 RVA）

## 0. 一句话结论

- **Linux 侧**：`protect_elf` + `libcsvm_elfhook.so` 跑通「ELF 函数级虚拟化加固」，
  加固后输出与原生**逐字节一致**（`28046 2400` / `28046`）；集成自检 20 项 → **13 通过 / 7 跳过 / 0 失败**。
- **Windows 侧**：代码补齐了与 Linux 对齐的 **FLS 每线程上下文池 + VEH 异常安全网**，
  并给了真机自测脚本 `win_thread_demo.exe`；**但本沙箱无 Windows 工具链，代码未编译、未真机验证**，
  不宣称「Windows 已达标」。
- 期间定位并修复了一个**内核解码 bug**（SIB 无基址寻址被当成 RBP 基址），
  这个 bug 正是 ELF 入口首轮「结果差几个数」的根因。

## 1. Linux ELF 加固入口（新增）

| 文件 | 作用 |
| --- | --- |
| `native/src/elf_hook.c` | 运行时挂钩库：解析 payload、`dl_iterate_phdr` 找主程序基址、±2GB 内拿执行页、写 stub、改函数头、共享 trampoline、constructor 自动挂钩 / destructor 统计 |
| `cyrilshield/vmp/protect_elf.py` | 最小 ELF64 解析（PT_LOAD / `.symtab` / `endbr64` 判定）+ 调 `codevm.compile` 生成 payload；CLI 支持符号名、`--list`、`--rva 0x…:len=…` |

设计取舍：**不改 ELF 程序头、不追加 PT_LOAD**（改节表/程序头风险高），改为
`LD_PRELOAD` 运行时挂钩 —— 原文件一个字节不改。

挂钩链路：

```
目标函数头 5B ──E9 rel32──▶ stub（movabs r10,meta; movabs r11,trampoline; jmp r11）
   ▶ trampoline（16 GPR + FLAGS 全量保存）
   ▶ csvm_elf_enter(meta, slots) ─▶ csvm_run_host(runtime_base = 函数真实地址)
   ▶ 全量恢复 + ret
```

- stub 用 `r10/r11`（调用者保存、且不是参数寄存器），不碰 `rdi/rsi/rdx/rcx/r8/r9`；
- 有 `endbr64` 时保留它，从 `+4` 开始改（CET 下间接调用仍合法）；
- `runtime_base` 传函数真实地址，`RIP` 相对寻址（LEA/MOV 里的 `[rip+disp32]`）才对得上。

实测（本沙箱）：

| 用例 | 结果 |
| --- | --- |
| `/tmp/elfdemo`（`f_secret`，-O2 无 CET） | payload 2363B，1 函数，RVA 0x1190，62B；挂钩 1/1；VM 调用 6 次；`sum=28046` **= 原生** |
| `/tmp/elfdemo2`（`f_secret` + `f_sum`，`-fcf-protection=full`） | payload 4451B，2 函数；输出 `28046 2400` **= 原生**（含 endbr64 保留路径） |
| 集成自检 `t_elf_entry` | PASS：2 函数挂钩、VM 调用 7 次、输出逐字节一致 |

用法：

```bash
# 1) 看有哪些可保护函数（需未 strip）
python3 -m cyrilshield.vmp.protect_elf ./prog --list
# 2) 生成 payload
python3 -m cyrilshield.vmp.protect_elf ./prog f_secret f_sum
# 3) 运行（原文件不改）
LD_PRELOAD=./native/out/libcsvm_elfhook.so \
CSVM_ELF_PAYLOAD=./prog.csvmpayload ./prog
```

## 2. 内核修复：SIB「无基址」寻址

**现象**：ELF 入口首轮 `sum=28054` ≠ 原生 `28046`，差值呈「`y%7` 算错」形态。

**根因**：`lea rax,[rdx*8+disp32]` 的编码是 `48 8d 04 d5 …`，即 ModRM `mod=00, rm=100(SIB)`、
SIB `base=101`。按 x86-64 规则这是**无基址**（绝对 `disp32`），但内核把它当成 `base=RBP`，
于是 `% 7` 的余数里被漏进了调用者的 `RBP`。

**证据链**：同一段字节码在独立映射上 10 个 seed 全对；挂钩路径上把 `RBP` 槽位人为设
0/1/2… 结果随之线性变化（0x123a → 0x123b → 0x122c…），锁定为「`RBP` 泄漏」而非 VM 本身算错。

**修复**（`native/src/codevm.c`）：

- 解析 SIB 时，`mod==0 && (s&7)==5` 标记 `sib_nobase`，`sib_base` 置哨兵 `255`（`REX.B` 不改变该规则）；
- 编译期把 `base==255` 原样编码为槽位 `255`，不再过 `reg_map`；
- 运行期 `mem_addr()` 遇 `base_slot==255` 从 0 起算（`index*scale + disp`），`LEA` 同路径生效。

这同时修好了编译器生成的「大常量除法/取模」`lea` 序列 —— gcc/clang 在 `-O2` 下大量产出这种指令。

## 3. Windows 多线程上下文（对齐 Linux）

| 能力 | Linux（第九批，已实测） | Windows（第十批，代码已写 / **未编译**） |
| --- | --- | --- |
| 每线程上下文池 | `pthread_key` + `__thread` 链，≥4 复用 | **FLS**（`FlsAlloc` + 析构回调）每线程空闲链，同 `CSVM_CTX_POOL_MAX=4` |
| 异常安全网 | run 级装 `sigaction` + 每线程 `sigjmp_buf` 帧栈，可嵌套 | **VEH**（`AddVectoredExceptionHandler`）+ 线程局部帧栈；异常时改写 `CONTEXT->Rip/Rsp` 回恢复点，等价 longjmp |
| 可重入 / 嵌套 | 帧栈 + 池再借，已实测 | 同结构（帧栈 `prev` 链 + 池再借） |
| 故障隔离 | 单线程故障 = TRAP，其余 7 线程不受影响 | 捕获 AV / 非法指令 / 除零 / 特权指令；线程互不影响 |
| 构建开关 | `CSVM_TLS_POOL` | `CSVM_WIN_TLS` / `CSVM_VEH_GUARD`，需真实 `windows.h` 与 kernel32 导入 |

**构建边界（必须说清）**：

- `build.bat`（MinGW-w64，链接完整 CRT）→ 走 **FLS + VEH** 路径；
- `build-win.sh`（clang + lld-link + `/noentry`，`-DCSVM_NO_CRT`）→ 拿不到 `windows.h`/Fls/VEH，
  **退回 calloc 直通 + 安全网桩**，行为与第八批一致（交叉产物仍是「能跑但保护能力残缺」）。
- VEH 分支用 GCC/Clang 的 `&&label`（labels-as-values），MSVC `cl` 不支持，故仍需 MinGW；
  这一点与内核本来就不能用 MSVC 编译（`__int128` + GNU asm）一致。

新增真机自测：`native/src/win_thread_demo.c` → `out\win_thread_demo.exe`，4 项：

1. 单线程池复用 2000 次；
2. 8 线程 × 2000 次两 seed 交替；
3. 8 线程并发 VM-exit 3200 次（宿主函数真实被调）；
4. 故障隔离：一线程在 VM-exit 里解引用空指针，被 VEH 捕获为 TRAP，其余 7 线程照常。

期望最后一行 `[win-thread] RESULT=PASS`。
该程序的机器码与期望值已在 Linux 内核上交叉核对过（同一段 26 字节代码在 VM 下与原生一致），
但**程序本身未在 Windows 上跑过**。

## 4. 实测汇总（本沙箱）

| 项 | 数字 |
| --- | --- |
| Linux 构建 | `bash native/build.sh` 12 步全过（新增第 10 步 `libcsvm_elfhook.so`） |
| 集成自检 | 20 项：**13 通过 / 7 跳过 / 0 失败**（新增 `t_elf_entry`） |
| 多线程回归 | `thread_demo` 6/6 PASS，`[thread] RESULT=PASS`，VM-exit 吞吐 17.7 万 ops/s |
| ELF 入口 | 单函数 2363B / 6 次 VM 调用；双函数 4451B / 7 次调用；输出与原生逐字节一致 |
| 冷段负 RVA 回归 | `c_table(0..11)` **12/12** 一致（`runtime_base = 镜像基址 + origin(0x1080)`） |
| Windows | **未编译、未真机验证**（沙箱无 mingw / clang / lld-link） |

## 5. 还是没做到的（诚实清单）

- Windows 侧 FLS 池 / VEH 安全网**没有一行被编译器验证过**，更没有真机数据；
  `win_thread_demo.exe` 属「待你在 Windows 上跑」的脚本。真机失败点最可能在：
  VEH 改写 `Rip/Rsp` 后局部变量状态（`volatile` 只覆盖了一部分）、
  以及 DLL 里 `__declspec(thread)` 与 FLS 混用（本实现主体走 FLS，`csvm_tls_frame` 仍是 TLS 变量）。
- ELF 入口前提仍是「函数有符号 / 有长度 / 入口 5 字节内没有别的跳转落点」；
  stripped 二进制只能走 `--rva 0x…:len=…` 手工指定。
- 只做 x86-64；不覆盖 PLT/GOT 间接调用、不覆盖 C++ 异常表、不覆盖 IFUNC。
- 安全边界不变：不提供绕过杀软/EDR/安装拦截的手段，不做 AMSI/ETW 补丁、进程注入、驱动、反 EDR。

## 6. 复跑命令

```bash
cd v9
bash native/build.sh                      # 12 步（含 ELF 挂钩库）
./native/out/thread_demo                  # 期望 [thread] RESULT=PASS
python3 selftest_integration.py           # 期望 13 通过 / 7 跳过 / 0 失败

# ELF 入口手工复现
gcc -O2 -fcf-protection=full /tmp/elfdemo2.c -o /tmp/elfdemo2
python3 -m cyrilshield.vmp.protect_elf /tmp/elfdemo2 f_secret f_sum
LD_PRELOAD=$PWD/native/out/libcsvm_elfhook.so \
CSVM_ELF_PAYLOAD=/tmp/elfdemo2.csvmpayload CSVM_ELF_DEBUG=1 /tmp/elfdemo2
```

Windows（在真机 / WSL 里）：

```bat
cd native
build.bat
out\win_thread_demo.exe
```
