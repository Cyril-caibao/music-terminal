import sys, os
sys.path.insert(0, ".")
os.environ["CYRILSHIELD_BOOTSTUB"] = os.path.abspath("native/out/bootstub_dbg.exe")
from cyrilshield import vmgen
vo = vmgen.VMOptions(junk_level=2, verify=True, cleanup=True, forward_args=True,
                     keep_icon=False, anti_debug=True, anti_sandbox=True,
                     secure_temp=True, vmp_enabled=False, shell="c")
vmgen.build("native/out/hello42.exe", "native/out/hello42_protected_dbg.exe",
            vo, on_line=lambda s: None)
print("built")
