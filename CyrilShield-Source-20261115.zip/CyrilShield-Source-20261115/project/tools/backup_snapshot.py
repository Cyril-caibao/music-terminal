# -*- coding: utf-8 -*-
"""生成当前版本的可恢复快照（源码 + 成品 EXE + 插件副本 + 哈希清单 + zip）。

用法：python tools/backup_snapshot.py [目标目录]
默认目标：D:\\CyrilShield_backup_<日期>_v<版本>
只在备份 zip 校验通过后才应清理旧备份（见脚本输出）。
"""
from __future__ import annotations

import datetime
import hashlib
import os
import shutil
import sys
import zipfile

ROOT = r"D:\Cyril-Shield"
PLUGIN_ROOT = r"D:\Terminal-Windows"
SKIP_DIRS = {
    ".git", "build", ".build", ".build_portable", "dist", "dist_portable",
    ".simtmp", ".lab", "__pycache__", ".pytest_cache",
}
SKIP_FILE_SUFFIX = (".pyc", ".pyo")
SKIP_FILE_NAMES = {
    # 旧版交付包属于「之前的备份」范畴，不进当前快照
    "CyrilShield-Full-v9-win-elf.zip",
    "CyrilShield-vmp-exe.zip",
    "CyrilShield-vmp-exe-changed.zip",
}


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def copy_tree(src: str, dst: str) -> int:
    n = 0
    for base, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        rel = os.path.relpath(base, src)
        outdir = dst if rel == "." else os.path.join(dst, rel)
        os.makedirs(outdir, exist_ok=True)
        for name in files:
            if name.endswith(SKIP_FILE_SUFFIX) or name in SKIP_FILE_NAMES:
                continue
            s = os.path.join(base, name)
            d = os.path.join(outdir, name)
            shutil.copy2(s, d)
            n += 1
    return n


def version() -> str:
    ns: dict = {}
    p = os.path.join(ROOT, "cs_version.py")
    txt = open(p, encoding="utf-8").read()
    import re
    m = re.search(r"StringStruct\('FileVersion',\s*'([^']+)'\)", txt)
    return m.group(1).rsplit(".", 1)[0] if m else "unknown"


def main() -> int:
    ver = version()
    today = datetime.datetime.now().strftime("%Y%m%d")
    dest = (sys.argv[1] if len(sys.argv) > 1
            else rf"D:\CyrilShield_backup_{today}_v{ver.replace('.', '')}")
    # 断点收尾：目标目录已存在且含 source/ 与 bin/ 时，跳过复制，
    # 只补哈希清单、说明与 zip（用于复制成功但后续阶段中断的场景）。
    finish_only = (os.path.isdir(dest)
                   and os.path.isdir(os.path.join(dest, "source"))
                   and os.path.isdir(os.path.join(dest, "bin")))
    if finish_only:
        print("断点收尾模式（跳过复制）：", dest)
    else:
        if os.path.exists(dest):
            print("目标已存在但不是有效快照，拒绝覆盖：", dest)
            return 2
        os.makedirs(dest)
        print("备份目标：", dest)

    total = 0
    if not finish_only:
        total += copy_tree(ROOT, os.path.join(dest, "source"))
        print("源码文件：", total)

        bindir = os.path.join(dest, "bin")
        os.makedirs(bindir)
        bins = [
            (os.path.join(ROOT, "dist", "CyrilShield.exe"), "CyrilShield.exe"),
            (os.path.join(ROOT, "dist_portable", "CyrilShield-Portable.exe"),
             "CyrilShield-Portable.exe"),
        ]
        for src, name in bins:
            if not os.path.isfile(src):
                print("缺少成品，中止：", src)
                return 3
            shutil.copy2(src, os.path.join(bindir, name))
            print("成品：", name, os.path.getsize(src), "字节")

        plug = os.path.join(dest, "plugin-components")
        for rel, tag in (("components/cyrilshield", "components"),
                         ("dist/components/cyrilshield", "dist-components")):
            src = os.path.join(PLUGIN_ROOT, rel.replace("/", os.sep))
            if os.path.isdir(src):
                total += copy_tree(src, os.path.join(plug, tag))
                print("插件副本：", tag)

    # 哈希清单（不含清单自身与 README）；被占用/异常的文件如实记录跳过
    entries = []
    skipped = []
    for base, dirs, files in os.walk(dest):
        dirs.sort()
        for name in sorted(files):
            p = os.path.join(base, name)
            rel = os.path.relpath(p, dest).replace("\\", "/")
            if rel in ("SHA256SUMS.txt", "README.md"):
                continue
            try:
                entries.append((sha256(p), os.path.getsize(p), rel))
            except OSError as exc:
                skipped.append((rel, str(exc)))
    if skipped:
        print("哈希跳过（文件不可用，已记入 README）：")
        for rel, why in skipped:
            print("  ", rel, "->", why)
    sumfile = os.path.join(dest, "SHA256SUMS.txt")
    with open(sumfile, "w", encoding="utf-8", newline="\n") as f:
        for h, size, rel in entries:
            f.write(f"{h}  {size:>12}  {rel}\n")

    readme = os.path.join(dest, "README.md")
    with open(readme, "w", encoding="utf-8", newline="\n") as f:
        f.write(f"""# CyrilShield v{ver} 完整快照

- 生成时间：{datetime.datetime.now().isoformat(timespec='seconds')}
- 来源：`{ROOT}`
- 内容：
  - `source/` 源码树（cyrilshield / native / docs / tools / 自测脚本 /
    spec / 构建脚本），已排除 dist、build、__pycache__ 与旧交付 zip
  - `bin/` 两份成品 EXE（主 EXE + 便携版）
  - `plugin-components/` Terminal-Windows 的两处插件副本
  - `SHA256SUMS.txt` 逐文件哈希与字节数
- 校验：`SHA256SUMS.txt` 每行格式为 `<sha256>  <bytes>  <相对路径>`
- 恢复：把 `source/` 覆盖回工作副本，`bin/` 覆盖回 dist / dist_portable，
  `plugin-components/` 覆盖回对应插件目录
- 本次快照对应的关键实现见 `CHANGES.md` 的 v{ver} 章节与 `docs/VMP-EXE-PARITY.md`
""")
    if skipped:
        with open(readme, "a", encoding="utf-8", newline="\n") as f:
            f.write("\n## 哈希阶段跳过的文件（复制成功但读取失败）\n\n")
            for rel, why in skipped:
                f.write(f"- `{rel}`：{why}\n")

    zpath = dest + ".zip"
    zip_skipped = []
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for base, dirs, files in os.walk(dest):
            dirs.sort()
            for name in sorted(files):
                p = os.path.join(base, name)
                try:
                    z.write(p, os.path.join(os.path.basename(dest),
                                            os.path.relpath(p, dest)))
                except OSError as exc:
                    zip_skipped.append((os.path.relpath(p, dest), str(exc)))
    if zip_skipped:
        print("ZIP 跳过：", zip_skipped[:5])
    # zip 完整性校验：逐条目 CRC
    with zipfile.ZipFile(zpath) as z:
        bad = z.testzip()
        count = len(z.namelist())
    if bad:
        print("ZIP 校验失败：", bad)
        return 4
    print(f"ZIP_OK  {zpath}  {os.path.getsize(zpath):,} 字节 / {count} 个条目")
    print(f"SNAPSHOT_OK  清单条目 {len(entries)} 个")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
