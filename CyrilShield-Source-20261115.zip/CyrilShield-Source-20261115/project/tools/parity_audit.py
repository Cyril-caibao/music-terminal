# -*- coding: utf-8 -*-
"""对标评审的「攻击者视角」自动化基线审计（Level-0 自审）。

用途
----
把「VMP 对标」里那些靠嘴说的结论，变成对**实际交付二进制**的可复现检查。
只覆盖能自动化的静态层 + 字节码层检查：

  1. 发布运行 DLL 导出白名单
  2. .rdata 是否残留明文 handler / 分派地址表
  3. 仅凭 .csvm blob 能否离线还原全部指令（抗提取强度实测）
  4. 字节码篡改 / 重放是否被完整性链拒绝
  5. 运行期临时释放的明文驻留姿态（静态代码事实）
  6. 真实 PE 的「任意函数全量虚拟化」可编译率（指令覆盖量化）

**这不是** IDA / 模拟执行器 / 脱壳工具的对抗测试，也不宣称等价于商业壳
十余年的对抗积累。它是一条 Level-0 基线：先保证「自己声称的东西」在
交付的二进制里真的成立，再谈外部对抗。

运行
----
    python tools/parity_audit.py                 # 全量（含覆盖率的隔离子进程）
    python tools/parity_audit.py --no-coverage  # 只跑 1~5
    python tools/parity_audit.py --json 路径     # 额外写 JSON 报告

覆盖率部分在独立子进程里跑：C 内核若在某个真实函数片段上崩溃，
主审计不会被带走，且会把崩溃点作为一条发现如实记下来。
"""
from __future__ import annotations

import argparse
import ctypes
import datetime
import json
import os
import re
import struct
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "native" / "out"
RUNTIME_DLL = OUT / "CyrilShield.CodeVM.runtime.dll"
DEV_DLL = OUT / "CyrilShield.CodeVM.dll"
BOOTSTUB = ROOT / "native" / "src" / "bootstub.c"
ANTITAMPER = ROOT / "cyrilshield" / "antitamper.py"
SAMPLES = [OUT / "hello42.exe", OUT / "peintegrate.exe", OUT / "bootstub.exe"]

# csvm_container.h 里随源码公开的编译期常量（不随 .csvm 段落盘，但在 DLL 代码里）
CSVM_KS_CONST = 0xC391A7E15B0D42F9
MASK64 = (1 << 64) - 1
MASK32 = (1 << 32) - 1
HDR_FMT = "<8s8IQI16s24s"          # csvm_file_hdr_t, pack(1), 92B
ANALYSIS_EXPORTS = {"csvm_compile", "csvm_compile_cfg", "csvm_disasm",
                    "csvm_stats", "csvm_run", "csvm_run_regs"}
EXPECTED_RUNTIME_EXPORTS = 8
# 已知可被内核编译的一小段 x86-64：sub rsp,28 / mov eax,42 / add rsp,28 / ret
PROBE_CODE = bytes.fromhex("4883ec28b82a0000004883c428c3")

# 审计刻意**不 import 项目自身的 cyrilshield 包**：攻击者拿到的是交付的 DLL
# 与 PE，不是源码包。直接 ctypes 调导出，结论才不依赖被审计对象的编排层。
_KERNEL = None


def kernel():
    global _KERNEL
    if _KERNEL is not None:
        return _KERNEL
    lib = ctypes.CDLL(str(DEV_DLL))
    u8p = ctypes.POINTER(ctypes.c_uint8)
    lib.csvm_compile.argtypes = [u8p, ctypes.c_size_t, ctypes.c_uint64,
                                 ctypes.POINTER(ctypes.c_void_p),
                                 ctypes.POINTER(ctypes.c_size_t),
                                 ctypes.c_char_p, ctypes.c_size_t]
    lib.csvm_compile.restype = ctypes.c_int
    lib.csvm_free.argtypes = [ctypes.c_void_p]
    lib.csvm_run.argtypes = [ctypes.c_void_p, ctypes.c_size_t,
                             ctypes.POINTER(ctypes.c_uint64), ctypes.c_size_t,
                             ctypes.POINTER(ctypes.c_uint64),
                             ctypes.c_char_p, ctypes.c_size_t]
    lib.csvm_run.restype = ctypes.c_int
    _KERNEL = lib
    return lib


def vm_compile(code: bytes, seed: int) -> bytes:
    lib = kernel()
    src = (ctypes.c_uint8 * len(code)).from_buffer_copy(code)
    out, n = ctypes.c_void_p(), ctypes.c_size_t()
    err = ctypes.create_string_buffer(512)
    rc = lib.csvm_compile(src, len(code), seed, ctypes.byref(out),
                          ctypes.byref(n), err, 512)
    if rc != 0:
        raise RuntimeError(err.value.decode("utf-8", "replace"))
    try:
        return ctypes.string_at(out, n.value)
    finally:
        lib.csvm_free(out)


def vm_run(blob: bytes) -> int:
    lib = kernel()
    buf = ctypes.create_string_buffer(blob)
    args = (ctypes.c_uint64 * 6)()
    ret, err = ctypes.c_uint64(), ctypes.create_string_buffer(512)
    rc = lib.csvm_run(buf, len(blob), args, 0, ctypes.byref(ret), err, 512)
    if rc != 0:
        raise RuntimeError(err.value.decode("utf-8", "replace"))
    return ret.value


# ------------------------------------------------------------------ PE 解析 --
def parse_pe(path: Path) -> dict:
    d = path.read_bytes()
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    if d[pe:pe + 4] != b"PE\0\0":
        raise ValueError("不是 PE")
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    optsz = struct.unpack_from("<H", d, pe + 20)[0]
    opt = pe + 24
    magic = struct.unpack_from("<H", d, opt)[0]
    if magic != 0x20B:
        raise ValueError("不是 PE32+")
    base = struct.unpack_from("<Q", d, opt + 24)[0]
    dd = opt + 112
    secs = []
    for i in range(nsec):
        o = opt + optsz + i * 40
        name = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vs, va, rs, rp = struct.unpack_from("<IIII", d, o + 8)
        secs.append({"name": name, "va": va, "vs": vs, "raw": rp, "rs": rs})
    erva, esz = struct.unpack_from("<II", d, dd)
    pdrva, pdsz = struct.unpack_from("<II", d, dd + 3 * 8)

    def r2o(rva):
        for s in secs:
            if s["va"] <= rva < s["va"] + max(s["vs"], s["rs"]):
                return s["raw"] + (rva - s["va"])
        return None

    names = []
    eo = r2o(erva) if erva else None
    if eo is not None:
        nnam = struct.unpack_from("<I", d, eo + 24)[0]
        anames = struct.unpack_from("<I", d, eo + 32)[0]
        ao = r2o(anames)
        if ao is not None:
            for i in range(nnam):
                nr = struct.unpack_from("<I", d, ao + i * 4)[0]
                no = r2o(nr)
                if no is None:
                    continue
                end = d.index(b"\0", no)
                names.append(d[no:end].decode("latin1"))
    return {"data": d, "base": base, "sections": secs, "exports": names,
            "rva2off": r2o, "pdata": (pdrva, pdsz)}


def pdata_functions(pe: dict) -> list[tuple[int, int, int]]:
    """(Begin, End, UNWIND_INFO flags)；flags 非 0 = 带 EH / 链式展开。"""
    d, r2o = pe["data"], pe["rva2off"]
    rva, size = pe["pdata"]
    off = r2o(rva) if rva else None
    if off is None:
        return []
    out = []
    for i in range(min(size // 12, 8192)):
        begin, end, uw = struct.unpack_from("<III", d, off + 12 * i)
        if end <= begin:
            continue
        uo = r2o(uw)
        flags = (d[uo] >> 3) & 0x1F if uo is not None and uo < len(d) else 0
        out.append((begin, end, flags))
    return out


def rva_bytes(pe: dict, rva: int, size: int) -> bytes | None:
    off = pe["rva2off"](rva)
    if off is None or off + size > len(pe["data"]):
        return None
    return pe["data"][off:off + size]


def rec(cid, title, verdict, meaning, evidence):
    return {"id": cid, "title": title, "verdict": verdict,
            "meaning": meaning, "evidence": evidence}


# ------------------------------------------------------------- 1. 导出白名单 --
def check_exports():
    ev = []
    try:
        rt = parse_pe(RUNTIME_DLL)
        dv = parse_pe(DEV_DLL)
    except Exception as e:
        return rec("A1", "发布运行 DLL 导出白名单", "ERROR",
                   "无法解析 DLL，检查失败", [str(e)])
    leak = sorted(set(rt["exports"]) & ANALYSIS_EXPORTS)
    ev.append(f"运行 DLL：{len(rt['exports'])} 个导出 -> {', '.join(rt['exports'])}")
    ev.append(f"构建期 DLL：{len(dv['exports'])} 个导出（含 "
              f"{', '.join(sorted(set(dv['exports']) & ANALYSIS_EXPORTS))}），仅用于构建，不随成品分发")
    ok = (len(rt["exports"]) == EXPECTED_RUNTIME_EXPORTS and not leak)
    return rec("A1", "发布运行 DLL 导出白名单",
               "PASS" if ok else "FAIL",
               "发布版不带反编译 / 编译 / 统计接口，静态 dump 者拿不到自带反编译器"
               if ok else "运行 DLL 仍暴露分析接口或数量异常",
               ev + (["泄漏的分析接口：" + ", ".join(leak)] if leak else []))


# -------------------------------------------------- 2. 明文分派地址表（关键）--
def check_dispatch_table():
    try:
        p = parse_pe(RUNTIME_DLL)
    except Exception as e:
        return rec("A2", ".rdata 明文分派地址表", "ERROR", "解析失败", [str(e)])
    text = next(s for s in p["sections"] if s["name"] == ".text")
    rdata = next(s for s in p["sections"] if s["name"] == ".rdata")
    lo, hi = text["va"], text["va"] + text["vs"]
    buf = p["data"][rdata["raw"]:rdata["raw"] + rdata["rs"]]
    total, longest, best_off, run, cur_start = 0, 0, 0, 0, 0
    for i in range(0, len(buf) - 7, 8):
        v = struct.unpack_from("<Q", buf, i)[0]
        ok = (lo <= v < hi) or (lo <= v - p["base"] < hi)
        if ok:
            if run == 0:
                cur_start = i
            run += 1
            total += 1
            if run > longest:
                longest, best_off = run, cur_start
        else:
            run = 0
    ev = [
        f"扫描 .rdata {len(buf):,} 字节（8 字节对齐）",
        f"落在 .text [0x{lo:x},0x{hi:x}) 的疑似代码指针：{total} 个",
        f"最长连续序列：{longest} 个（.rdata 文件偏移 0x{best_off:x}）",
        "来源：native/src/codevm.c:1546 `static void *const cg_plain[BC_COUNT]`"
        "（computed-goto 只异或了运行时副本 cg_enc[]，静态源表仍在 .rdata）",
    ]
    # 连续 >= 16 个 8 字节指针 = 典型的跳转/分派表，而非偶发指针
    bad = longest >= 16
    return rec("A2", ".rdata 明文分派地址表", "FAIL" if bad else "PASS",
               "「静态 dump 无明文 handler 地址表」的声称不成立："
               "computed-goto 消除的是中心 switch，不是 .rdata 里的静态标签数组"
               if bad else "未发现连续明文分派地址表", ev)


# --------------------------------------------- 3. 仅凭 blob 离线还原字节码 --
def ks64(seed: int, salt: bytes, off: int) -> int:
    s0 = int.from_bytes(salt[:8], "little")
    s1 = int.from_bytes(salt[8:], "little")
    blk = off >> 3
    k = (seed ^ CSVM_KS_CONST
         ^ ((blk * 0x9E3779B97F4A7C15) & MASK64)
         ^ s0
         ^ ((s1 * 0xBF58476D1CE4E5B9) & MASK64)) & MASK64
    k = (k + 0x9E3779B97F4A7C15) & MASK64
    k = ((k ^ (k >> 30)) * 0xBF58476D1CE4E5B9) & MASK64
    k = ((k ^ (k >> 27)) * 0x94D049BB133111EB) & MASK64
    return (k ^ (k >> 31)) & MASK64


def decrypt_region(blob_at_off: bytes, seed: int, salt: bytes,
                   abs_off: int) -> bytearray:
    q = bytearray(blob_at_off)
    for i in range(len(q)):
        o = abs_off + i
        q[i] ^= (ks64(seed, salt, o) >> ((o & 7) * 8)) & 0xFF
    return q


def check_bytecode_offline():
    ev = []
    blob = vm_compile(PROBE_CODE, 0x123456789ABCDEF0)
    (magic, ver, flags, total, enc_off, enc_size,
     n_insn, n_ir, n_junk, seed, hdr_mac, salt, _res) = struct.unpack_from(HDR_FMT, blob, 0)
    ev += [
        f"blob {len(blob)}B / {n_insn} 条指令 / magic {magic[:5]!r}",
        f"文件头**明文**保存 seed=0x{seed:016x} 与 16B salt",
        f"keystream 常量 CSVM_KS_CONST=0x{CSVM_KS_CONST:016x} 为源码固定值（DLL 代码里可抠出）",
    ]
    enc = decrypt_region(blob[enc_off:enc_off + enc_size], seed, salt, 0)
    meta_ok = (bytes(enc[:8]) == magic and struct.unpack_from("<I", enc, 8)[0] == ver)
    head = struct.unpack_from("<I", enc, 576)[0] if n_insn else 0
    rec_off = struct.unpack_from("<%dI" % n_insn, enc, 576) if n_insn else ()
    recovered = 0
    for pc, ro in enumerate(rec_off):
        if ro + 4 > len(enc):
            continue
        vl, ppre = enc[ro], enc[ro + 1]
        if 0 < vl <= 40 and ppre <= 7 and ro + 3 + ppre + vl <= len(enc):
            recovered += 1
    ev += [
        f"纯 Python 复现 keystream 解密整段加密区 -> meta 校验 {'通过' if meta_ok else '失败'}",
        f"记录偏移表首项 {head}，成功定位并解出 {recovered}/{n_insn} 条指令记录",
    ]
    fully = meta_ok and recovered == n_insn and n_insn > 0
    return rec("A3", "仅凭 blob 离线还原字节码", "FAIL" if fully else "WARN",
               "抗提取层是**对称混淆**而非密码学保密：拿到 .csvm 段 + 公开常量即可"
               "离线还原完整 IR 指令流，整段拷贝型提取成立（对应评审第 2 条）"
               if fully else "离线还原未完全成立，需复核",
               ev)


# ------------------------------------------------------- 4. 完整性链抗篡改 --
def check_integrity():
    try:
        blob = vm_compile(PROBE_CODE, 0x123456789ABCDEF0)
        base_rc = vm_run(blob)
    except Exception as e:
        return rec("A4", "字节码完整性链", "ERROR", "探针执行失败", [repr(e)])
    (_mg, _v, _f, _t, enc_off, enc_size, n_insn, *_rest) = struct.unpack_from(HDR_FMT, blob, 0)
    enc_head = 576 + 8 * n_insn
    cases = {
        "header.salt 单字节翻转": 52,
        "meta/索引表 单字节翻转": enc_off + 576 + 4,
        "指令记录体 单字节翻转": enc_off + enc_head + 20,
    }
    ev = [f"未篡改探针执行成功，返回 RAX={base_rc}"]
    rejected = 0
    for name, pos in cases.items():
        if pos >= len(blob):
            ev.append(f"{name}：位置越界，跳过")
            continue
        m = bytearray(blob)
        m[pos] ^= 0x5A
        try:
            vm_run(bytes(m))
            ev.append(f"{name}：**被接受**（完整性链失效）")
        except RuntimeError as e:
            rejected += 1
            ev.append(f"{name}：拒绝 -> {str(e)[:78]}")
    ok = rejected == len(cases)
    return rec("A4", "字节码完整性链（hdr_mac / rec_mac）",
               "PASS" if ok else "FAIL",
               "头、meta/索引表、逐条记录三层篡改均被拒绝；防重排/复制由绑定 pc 的 rec_mac 提供"
               if ok else "存在未拦截的篡改路径", ev)


# --------------------------------------------------- 5. 临时释放明文驻留姿态 --
def check_temp_posture():
    ev, facts = [], {}
    boot = BOOTSTUB.read_text(encoding="utf-8", errors="replace")
    anti = ANTITAMPER.read_text(encoding="utf-8", errors="replace")
    facts["payload_delete_on_close"] = "FILE_FLAG_DELETE_ON_CLOSE" in boot
    facts["python_delete_on_close"] = "FILE_FLAG_DELETE_ON_CLOSE" in anti
    # 侧载 DLL 的写入函数体里是否也带 delete-on-close
    i = boot.find("cs_write_side_dll")
    seg = boot[i:i + 2200] if i >= 0 else ""
    facts["side_dll_delete_on_close"] = "FILE_FLAG_DELETE_ON_CLOSE" in seg
    facts["fallback_plain_write"] = "CREATE_ALWAYS" in boot and "secure_tried" in boot
    facts["full_plaintext_in_memory"] = "self.ct" in anti or "ct_bytes" in anti
    ev += [
        f"C 外壳载荷 EXE 主力路径 delete-on-close：{facts['payload_delete_on_close']}",
        f"Python 外壳 delete-on-close：{facts['python_delete_on_close']}",
        f"同目录侧载运行内核 DLL 也用 delete-on-close：{facts['side_dll_delete_on_close']}",
        f"存在常规写盘回落（secure 失败时）：{facts['fallback_plain_write']}",
        f"解密后完整原始 EXE 仍以明文存在于进程内存：{facts['full_plaintext_in_memory']}",
        "结论：评审第 3 条的「零成本盯临时目录」对主力路径已过时，但"
        "「DLL 常规写盘 + 回落路径 + 内存完整明文」仍成立；"
        "驱动级 / 进程镂空属于项目红线（SECURITY-NOTES 第五节、RED-TEAM-ROE 第一节），不实现。",
    ]
    return rec("A5", "运行期临时释放 / 抗 dump 姿态", "INFO",
               "缩短明文驻留窗口 + 去固定特征，非「不落地」，非抗内存 dump", ev)


# --------------------------------------------- 6. 覆盖率（隔离子进程） --
def coverage_worker(pe_path: Path, out_path: Path, limit: int) -> int:
    """在独立进程里逐函数试编译；每完成一个就落盘一行，崩溃也留得下证据。"""
    pe = parse_pe(pe_path)
    ranges = pdata_functions(pe)
    with open(out_path, "w", encoding="utf-8") as f:
        tried = 0
        for i, (begin, end, flags) in enumerate(ranges):
            size = end - begin
            row = {"i": i, "rva": hex(begin), "size": size, "flags": flags}
            if flags != 0:
                row["result"] = "eh_skip"
            elif size < 8 or size > 512:
                row["result"] = "size_skip"
            else:
                code = rva_bytes(pe, begin, size)
                if code is None:
                    row["result"] = "unmapped"
                else:
                    try:
                        vm_compile(code, 0x5A5A5A5A)
                        row["result"] = "ok"
                    except RuntimeError as e:
                        msg = str(e)
                        m = re.search(r"偏移\s*\d+:\s*(.+)", msg)
                        row["result"] = "reject"
                        row["reason"] = (m.group(1) if m else msg).strip()[:120]
                    tried += 1
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            f.flush()
            if tried >= limit:
                break
    return 0


def check_coverage(limit: int, timeout: int):
    ev, summary = [], []
    tmpdir = Path(os.environ.get("TEMP", ".")) / "cs_parity_audit"
    tmpdir.mkdir(parents=True, exist_ok=True)
    for sample in SAMPLES:
        if not sample.exists():
            ev.append(f"{sample.name}：样本不存在，跳过")
            continue
        jl = tmpdir / (sample.stem + ".jsonl")
        if jl.exists():
            jl.unlink()
        cmd = [sys.executable, str(Path(__file__).resolve()), "--worker",
               str(sample), str(jl), str(limit)]
        try:
            p = subprocess.run(cmd, capture_output=True, timeout=timeout,
                               cwd=str(ROOT))
            crashed = p.returncode != 0
        except subprocess.TimeoutExpired:
            crashed, p = True, None
        rows = []
        if jl.exists():
            for line in jl.read_text(encoding="utf-8").splitlines():
                try:
                    rows.append(json.loads(line))
                except Exception:
                    pass
        tested = [r for r in rows if r["result"] in ("ok", "reject", "unmapped")]
        ok = sum(1 for r in tested if r["result"] == "ok")
        eh = sum(1 for r in rows if r["result"] == "eh_skip")
        rate = (100.0 * ok / len(tested)) if tested else 0.0
        reasons = {}
        for r in tested:
            if r["result"] == "reject":
                reasons[r.get("reason", "?")] = reasons.get(r.get("reason", "?"), 0) + 1
        top = sorted(reasons.items(), key=lambda x: -x[1])[:6]
        ev.append(f"{sample.name}：.pdata 条目扫描 {len(rows)} 个，实编译 {len(tested)} 个，"
                  f"直接通过 {ok} 个（{rate:.1f}%），带 EH 跳过 {eh} 个")
        for reason, cnt in top:
            ev.append(f"    拒绝原因 x{cnt}: {reason}")
        if crashed:
            ev.append(f"    **内核在该样本上异常退出**（returncode="
                      f"{p.returncode if p else 'timeout'}），已处理 {len(rows)} 个片段；"
                      "这本身是一条对抗层面的发现")
        summary.append({"sample": sample.name, "rows": len(rows),
                        "tested": len(tested), "compiled": ok,
                        "rate": round(rate, 2), "eh_skip": eh,
                        "top_reasons": top, "worker_crashed": crashed})
    return rec("A6", "真实 PE 的任意函数可虚拟化率", "INFO",
               "把「指令覆盖差一个量级」从定性说法变成可复跑的百分比；"
               "统计口径：.pdata 中 flags=0、8~512B 的函数，不做尾部重试、不自动裁边界",
               ev), summary


# ------------------------------------------------------------------ 主流程 --
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-coverage", action="store_true")
    ap.add_argument("--limit", type=int, default=200)
    ap.add_argument("--timeout", type=int, default=180)
    ap.add_argument("--json", default="")
    ap.add_argument("--worker", nargs=3, metavar=("PE", "JSONL", "LIMIT"))
    args = ap.parse_args()
    if args.worker:
        return coverage_worker(Path(args.worker[0]), Path(args.worker[1]),
                               int(args.worker[2]))

    checks = [check_exports(), check_dispatch_table(),
              check_bytecode_offline(), check_integrity(), check_temp_posture()]
    cov_summary = []
    if not args.no_coverage:
        c, cov_summary = check_coverage(args.limit, args.timeout)
        checks.append(c)

    report = {
        "generated": datetime.datetime.now().isoformat(timespec="seconds"),
        "scope": "Level-0 攻击者视角自审（静态 + 字节码层），非 IDA / 模拟器 / 脱壳工具对抗测试",
        "checks": checks,
        "coverage_summary": cov_summary,
    }
    print("# 对标评审 · 自动化基线审计")
    print(f"> 生成时间：{report['generated']}  |  {report['scope']}\n")
    for c in checks:
        print(f"## [{c['verdict']}] {c['id']} {c['title']}")
        print(f"{c['meaning']}\n")
        for line in c["evidence"]:
            print(f"- {line}")
        print()
    tally = {}
    for c in checks:
        tally[c["verdict"]] = tally.get(c["verdict"], 0) + 1
    print("## 汇总：" + " / ".join(f"{k}={v}" for k, v in sorted(tally.items())))
    if args.json:
        Path(args.json).write_text(json.dumps(report, ensure_ascii=False, indent=2),
                                   encoding="utf-8")
        print(f"JSON 报告：{args.json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
