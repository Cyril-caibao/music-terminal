# -*- coding: utf-8 -*-
"""v3.3.3 回归：运行内核内嵌后，函数级虚拟化成品可单文件真机运行。

验证点：
  1. overlay 尾表 version=2、dll_len 等于运行内核字节数；
  2. 输出目录不再出现外部 CyrilShield.CodeVM.dll（真单文件）；
  3. 虚拟化 + C 外壳产物真机运行 rc=0 且载荷 marker 正常（旧版会 err=126）；
  4. 临时释放目录 cleanup 干净。
"""
from __future__ import annotations

import glob
import os
import struct
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cyrilshield import vmgen                       # noqa: E402
from cyrilshield.vmp import codevm as cv           # noqa: E402
from cyrilshield.vmp import integration as it      # noqa: E402

TARGET = os.path.join("native", "out", "hello42.exe")
MARKER = os.path.join(tempfile.gettempdir(), "hello42_marker.txt")
FAILS: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(("PASS " if ok else "FAIL ") + name + ("  " + detail if detail else ""))
    if not ok:
        FAILS.append(name)


def text_section(data: bytes):
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    nsec = struct.unpack_from("<H", data, pe + 6)[0]
    opt = struct.unpack_from("<H", data, pe + 20)[0]
    sec = pe + 24 + opt
    for i in range(nsec):
        o = sec + i * 40
        nm = data[o:o + 8].rstrip(b"\x00").decode("ascii", "replace")
        vs, va, rs, ro = struct.unpack_from("<IIII", data, o + 8)
        if nm == ".text" and rs > 0:
            return va, rs
    raise RuntimeError("no .text section")


def compile_windows(data: bytes, count: int = 6):
    """找若干个真实可编译的 64 字节窗口，避免拿指令中间当函数起点。"""
    va, rs = text_section(data)
    vm = cv.get_codevm()
    out = []
    off = 0
    while len(out) < count and off < min(rs, 400000):
        try:
            code = it.extract_pe_function(data, va + off, 64)
            vm.compile(code, seed=12345)
            out.append((va + off, 64))
            off += 256
        except (cv.CodeVMError, it.IntegrationError):
            off += 16
    return out


def main() -> int:
    data = open(TARGET, "rb").read()
    wins = compile_windows(data)
    check("找到可编译函数窗口", bool(wins), f"n={len(wins)}")

    out = os.path.join(tempfile.gettempdir(), "cs333_e2e.exe")
    side = os.path.join(os.path.dirname(out), "CyrilShield.CodeVM.dll")
    for p in (out, side, MARKER):
        if os.path.exists(p):
            os.remove(p)

    before = set(glob.glob(os.path.join(tempfile.gettempdir(), "_cs*")))
    logs: list[str] = []
    vo = vmgen.VMOptions(
        junk_level=2, verify=True, cleanup=True, forward_args=True,
        keep_icon=False, anti_debug=True, anti_sandbox=True,
        secure_temp=True, vmp_enabled=False, shell="c",
        virtualize=True, vm_func_list=[wins[0]],
    )
    vmgen.build(TARGET, out, vo, on_line=logs.append)

    blob = open(out, "rb").read()
    tail = blob[-vmgen.CS_OVERLAY_TAIL:]
    check("overlay 魔数", tail[:8] == vmgen.CS_OVERLAY_MAGIC)
    ver, dll_len, cfg_len, pl_len = struct.unpack_from("<IIQQ", tail, 8)
    check("overlay version=2", ver == 2, f"ver={ver}")
    rt = vmgen._runtime_kernel_bytes(lambda s: None)
    check("dll_len 与运行内核一致", dll_len == len(rt),
          f"dll_len={dll_len:,} rt={len(rt):,}")
    check("输出目录无外部 DLL", not os.path.exists(side))
    check("日志声明单文件", any("单文件" in s for s in logs))

    rc = -999
    txt = ""
    for i, w in enumerate(wins):
        if i:
            logs2: list[str] = []
            vo.vm_func_list = [w]
            vmgen.build(TARGET, out, vo, on_line=logs2.append)
        if os.path.exists(MARKER):
            os.remove(MARKER)
        try:
            r = subprocess.run([out, "ARG1", "ARG TWO"],
                               capture_output=True, timeout=60)
            rc = r.returncode
        except subprocess.TimeoutExpired:
            rc = -998
        if os.path.exists(MARKER):
            txt = open(MARKER, encoding="utf-8", errors="replace").read().strip()
        else:
            txt = ""
        # 小程序的 .text 里函数很少，某些窗口会覆盖写 marker 的必经路径；
        # 换窗口直到行为完整，最多试完所有候选。
        if rc == 0 and "ARG1" in txt and "ARG TWO" in txt:
            break
    check("真机运行 rc=0（无 err=126）", rc == 0, f"rc={rc}")
    check("载荷 marker 文件创建（证明导入表解析成功）",
          os.path.exists(MARKER), repr(txt[:60]))
    check("载荷参数透传正确", "ARG1" in txt and "ARG TWO" in txt,
          repr(txt[:90]))

    after = set(glob.glob(os.path.join(tempfile.gettempdir(), "_cs*")))
    check("临时释放目录已清理", not (after - before),
          f"残留={len(after - before)}")

    for p in (out, MARKER):
        if os.path.exists(p):
            os.remove(p)
    print("-" * 60)
    print("FAILS: " + (", ".join(FAILS) if FAILS else "none"))
    return 1 if FAILS else 0


if __name__ == "__main__":
    raise SystemExit(main())
