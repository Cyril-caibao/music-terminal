/* 集成层验证样本：真实 gcc -O2 产物，刻意包含
 *   - 运行时变量除法（DIV/IDIV，编译器不会优化成乘法移位）
 *   - 128 位乘法（MUL / IMUL 单操作数形式，F7 /4 /5）
 *   - RIP 相对寻址访问自身常量池（现代 x64 访问全局数据的默认方式）
 * 全部是不碰外部 API 的纯计算函数，适合作为「最小可用集成」的第一个目标。
 */
#include <stdint.h>

static const uint64_t KT[8] = {
    0x9E3779B97F4A7C15ULL, 0xBF58476D1CE4E5B9ULL,
    0x94D049BB133111EBULL, 0xD6E8FEB86659FD93ULL,
    0x123456789ABCDEF0ULL, 0xFEDCBA9876543210ULL,
    0x0102030405060708ULL, 0x8877665544332211ULL,
};

/* 主目标：一次函数里同时出现 DIV + RIP 相对 + 乘法 + 分支 */
__attribute__((noinline)) uint64_t f_protected(uint64_t x, uint64_t d) {
    uint64_t a = x ^ KT[x & 7];
    uint64_t b = KT[(x >> 3) & 7];
    uint64_t q = a / d;
    uint64_t r = a % d;
    uint64_t m = q * b;
    uint64_t z = (q > r) ? (m + r) : (m ^ r);
    return z + KT[7] + x;
}

/* 无符号 128 位乘：gcc 生成 mul r/m64 (F7 /4)，取高 64 位 */
__attribute__((noinline)) uint64_t f_mulhi(uint64_t a, uint64_t b) {
    unsigned __int128 p = (unsigned __int128)a * b;
    return (uint64_t)(p >> 64);
}

/* 有符号除法：gcc 生成 cqo + idiv r/m64 (F7 /7) */
__attribute__((noinline)) int64_t f_idiv(int64_t a, int64_t b) {
    return a / b;
}

/* 有符号 128 位乘：gcc 生成 imul r/m64 (F7 /5) + cqo 系列，取高 64 位 */
__attribute__((noinline)) int64_t f_imulhi(int64_t a, int64_t b) {
    __int128 p = (__int128)a * b;
    return (int64_t)(p >> 64);
}

int main(void) { return 0; }
