/* 第八批第 5 项：多函数批量改写的目标样本（Windows PE32+，无 CRT 依赖）。
 * 两个独立导出的纯计算函数，供 peintegrate --batch 一次改写两处函数头，
 * 验证「共享 1 个 .csvm 节区 + 1 个 IAT + N 个 stub / N 份字节码」。 */
typedef unsigned long long u64;

__declspec(dllexport) u64 f_a(u64 x) {
    return x * 3u + 7u;
}

__declspec(dllexport) u64 f_b(u64 x) {
    return (x ^ 0x5A5A5A5A5A5A5A5AULL) + 11u;
}
