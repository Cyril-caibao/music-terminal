/* Windows PE 目标样本（交叉编译用，无 CRT 依赖）。
 * 纯计算函数，含 DIV、RIP 相对常量池、128 位乘法语义，用于验证 PE 集成器。 */
typedef unsigned long long u64;
static const u64 KT[8] = {
    0x9E3779B97F4A7C15ULL, 0xBF58476D1CE4E5B9ULL,
    0x94D049BB133111EBULL, 0xD6E8FEB86659FD93ULL,
    0x123456789ABCDEF0ULL, 0xFEDCBA9876543210ULL,
    0x0102030405060708ULL, 0x8877665544332211ULL,
};
__declspec(dllexport) u64 f_protected(u64 x, u64 d) {
    u64 a = x ^ KT[x & 7];
    u64 b = KT[(x >> 3) & 7];
    u64 q = a / d, r = a % d;
    u64 m = q * b;
    u64 z = (q > r) ? (m + r) : (m ^ r);
    return z + KT[7] + x;
}
