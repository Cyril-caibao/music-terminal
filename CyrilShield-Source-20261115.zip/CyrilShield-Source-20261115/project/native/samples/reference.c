#include <stdint.h>
__attribute__((noinline)) uint64_t f_fib(uint64_t n) {
    uint64_t a = 0, b = 1;
    for (uint64_t i = 0; i < n; ++i) { uint64_t t = a + b; a = b; b = t; }
    return a;
}
__attribute__((noinline)) uint64_t f_mix(uint64_t x, uint64_t y) {
    uint64_t h = x ^ 0x9e3779b97f4a7c15ULL;
    h ^= h >> 30; h *= 0xbf58476d1ce4e5b9ULL;
    h ^= h >> 27; h *= 0x94d049bb133111ebULL;
    h ^= (y << 7) | (y >> 57);
    return h ^ (h >> 31);
}
__attribute__((noinline)) int64_t f_branch(int64_t a, int64_t b) {
    if (a < b) return a - b;
    if (a == b) return 0;
    return (a > b) ? (a + b) : (a ^ b);
}
int main(void) { return (int)(f_fib(10) + f_mix(1,2) + f_branch(3,4)); }
