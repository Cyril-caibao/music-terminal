#!/usr/bin/env bash
# 交叉产出 Windows 侧真实 PE（Linux 上用 clang + lld-link + llvm-lib）。
# 需要：clang / lld-link / llvm-lib / llvm-readobj（Ubuntu: llvm / lld / clang 包）。
# 产出：
#   out/CyrilShield.CodeVM.dll   **发布版运行 DLL**：只导出 8 个运行入口，
#                                不含 csvm_compile/disasm/stats/run/run_regs
#                                等分析接口（第八批抗提取），只依赖 msvcrt.dll
#   out/win_target.dll            PE 集成器的目标样本 DLL（导出 f_protected）
# 说明：/noentry 自包含 DLL 没有 CRT 提供 _fltused，故 CFLAGS 带
#       -DCSVM_NO_CRT 让 codevm.c 自定义该符号；build.bat 链接完整 CRT，
#       不带此宏，避免重复定义。
#       -DCSVM_NO_AUTOEXPORT 关闭 __declspec(dllexport)，改由下方 /export:
#       白名单精确控制导出，防止分析接口被自动导出。
#       构建期编译/反汇编请用 Linux 开发版 .so（build.sh）或 csvm CLI。
# Windows 原生构建请用 build.bat（MinGW-w64 gcc）。
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/out"
mkdir -p "$OUT"
TARGET="--target=x86_64-pc-windows-msvc"
CFLAGS="-O2 -fno-stack-protector -fcf-protection=none -DCSVM_NO_CRT -DCSVM_NO_AUTOEXPORT -I$ROOT/include -I$ROOT/win_shim"

for t in clang lld-link llvm-lib llvm-readobj; do
  command -v "$t" >/dev/null || { echo "缺少 $t，跳过 Windows 交叉产物"; exit 0; }
done
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "[1/6] 生成 msvcrt.dll 导入库"
llvm-lib /def:"$ROOT/win_shim/msvcrt.def" /machine:x64 /out:"$TMP/msvcrt.lib" >/dev/null

echo "[2/6] 编译 C 内核、L2 VM-exit 桩（COFF）与 128 位除法补丁"
clang $TARGET $CFLAGS -c "$ROOT/src/codevm.c" -o "$TMP/codevm.obj"
clang $TARGET $CFLAGS -c "$ROOT/src/exit_trampoline.c" -o "$TMP/exit_trampoline.obj"
clang $TARGET -O2 -c "$ROOT/src/win_int128.c" -o "$TMP/int128.obj"

echo "[3/6] 链接 CyrilShield.CodeVM.dll"
# 发布版白名单：只留运行入口（PE stub 只需 csvm_enter）。分析/构建接口
# csvm_compile / csvm_compile_cfg / csvm_disasm / csvm_stats / csvm_run /
# csvm_run_regs 一律不导出，静态 dump 者拿不到自带反编译器。
EXPORTS=()
for s in csvm_enter csvm_run_host csvm_run_host_ex csvm_run_host_fpu \
         csvm_host_mem_direct csvm_free csvm_abi_version csvm_version_string; do
    EXPORTS+=("/export:$s")
done
lld-link /dll /noentry /machine:x64 /out:"$OUT/CyrilShield.CodeVM.dll" \
    "${EXPORTS[@]}" "$TMP/codevm.obj" "$TMP/exit_trampoline.obj" \
    "$TMP/int128.obj" "$TMP/msvcrt.lib"

echo "[4/6] 编译 PE 目标样本 win_target.dll"
clang $TARGET -O2 -fcf-protection=none -c "$ROOT/samples/win_target.c" -o "$TMP/win_target.obj"
lld-link /dll /noentry /machine:x64 /out:"$OUT/win_target.dll" \
    /export:f_protected "$TMP/win_target.obj"

echo "[5/6] 编译多函数批量样本 win_multi.dll"
clang $TARGET -O2 -fcf-protection=none -c "$ROOT/samples/win_multi.c" -o "$TMP/win_multi.obj"
lld-link /dll /noentry /machine:x64 /out:"$OUT/win_multi.dll" \
    /export:f_a /export:f_b "$TMP/win_multi.obj"

echo "[6/6] 校验（Windows 多线程自测 exe 只在 MinGW 真机构建，见 build.bat 第 5 步）"
llvm-readobj --coff-exports "$OUT/CyrilShield.CodeVM.dll" | grep -c "Name: csvm_" | xargs echo "  发布内核导出符号数(应=8):"
llvm-readobj --coff-exports "$OUT/win_target.dll" | grep -c "Name: f_protected" | xargs echo "  单函数样本导出数:"
llvm-readobj --coff-exports "$OUT/win_multi.dll" | grep -c "Name: f_" | xargs echo "  批量样本导出数(应=2):"
echo "完成：$OUT"
