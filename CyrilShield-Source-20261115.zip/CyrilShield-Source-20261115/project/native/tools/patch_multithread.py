import re, sys, io

p = "native/src/codevm.c"
s = open(p, encoding="utf-8").read()

# ---------- 1. 引入 pthread ----------
s = s.replace("""#include <setjmp.h>
#include <signal.h>
#endif""", """#include <setjmp.h>
#include <signal.h>
#include <pthread.h>
#endif

/* 每线程 VM 上下文池用到 pthread_key（POSIX）；Windows 侧走 calloc 直通。 */
#if !defined(_WIN32) && !defined(__MINGW32__)
#include <pthread.h>
#define CSVM_TLS_POOL 1
#endif""", 1)

# ---------- 2. 重写 VM-exit 异常安全网 ----------
old_guard_start = s.index("static __thread int         csvm_in_exit")
old_guard_end_marker = "#endif /* CSVM_SIGNAL_GUARD */"
old_guard_end = s.index(old_guard_end_marker, old_guard_start) + len(old_guard_end_marker)
new_guard = r'''/* ---- 第九批（多线程上下文）VM-exit 异常安全网重写 ----
   旧实现两个多线程问题：
   ① 每次 VM-exit 做 8 次 sigaction 安装/还原 —— 外部调用越频繁越慢，
      且 csvm_old_sa[] 是进程级静态，两线程并发安装时互相覆盖「旧处理器」；
   ② csvm_in_exit 是线程局部的，没有 frame 栈，VM → 宿主函数 → VM 的嵌套
      场景下内层会直接跳过安全网。
   现在：
   · 安装/还原提到 run 级，用互斥 + 引用计数，进程内只装一次；
   · 每线程一个 frame 栈（可嵌套、可重入），故障只 longjmp 到本线程栈顶；
   · 本线程不在安全网内时，链回安装前保存的处理器 / 重新递送默认行为，
     不吞别的线程或宿主自己的异常。 */
typedef struct csvm_guard_frame {
    sigjmp_buf                jb;
    struct csvm_guard_frame  *prev;
} csvm_guard_frame_t;

static __thread csvm_guard_frame_t *csvm_tls_frame = NULL;
static pthread_mutex_t csvm_guard_mu = PTHREAD_MUTEX_INITIALIZER;
static int             csvm_guard_refs = 0;
static int             csvm_guard_installed = 0;
static struct sigaction csvm_guard_old[4];
static const int       csvm_fault_sigs[4] = { SIGSEGV, SIGBUS, SIGFPE, SIGILL };

static void csvm_fault_handler(int sig, siginfo_t *si, void *uc) {
    if (csvm_tls_frame) siglongjmp(csvm_tls_frame->jb, sig);
    /* 本线程不在安全网内：链回安装前的处理器；没有则恢复默认并重新递送。 */
    for (int i = 0; i < 4; ++i) {
        if (csvm_fault_sigs[i] != sig) continue;
        struct sigaction *old = &csvm_guard_old[i];
        if (old->sa_flags & SA_SIGINFO) {
            if (old->sa_sigaction && old->sa_sigaction != csvm_fault_handler) {
                old->sa_sigaction(sig, si, uc);
                return;
            }
        } else if (old->sa_handler && old->sa_handler != SIG_DFL &&
                   old->sa_handler != SIG_IGN) {
            old->sa_handler(sig);
            return;
        }
        break;
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

/* 进程级 0->1 安装、1->0 还原；并发 run 共享同一次安装。 */
static void csvm_guard_run_begin(void) {
    pthread_mutex_lock(&csvm_guard_mu);
    if (++csvm_guard_refs == 1 && !csvm_guard_installed) {
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_sigaction = csvm_fault_handler;
        sa.sa_flags = SA_SIGINFO | SA_NODEFER;
        sigemptyset(&sa.sa_mask);
        for (int i = 0; i < 4; ++i)
            sigaction(csvm_fault_sigs[i], &sa, &csvm_guard_old[i]);
        csvm_guard_installed = 1;
    }
    pthread_mutex_unlock(&csvm_guard_mu);
}

static void csvm_guard_run_end(void) {
    pthread_mutex_lock(&csvm_guard_mu);
    if (csvm_guard_refs > 0 && --csvm_guard_refs == 0 && csvm_guard_installed) {
        for (int i = 0; i < 4; ++i)
            sigaction(csvm_fault_sigs[i], &csvm_guard_old[i], NULL);
        csvm_guard_installed = 0;
    }
    pthread_mutex_unlock(&csvm_guard_mu);
}

/* exit 级 frame：返回 0 = 正常进入；非 0 = 宿主异常（信号号，已弹栈）。 */
static int csvm_guard_enter(csvm_guard_frame_t *fr) {
    fr->prev = csvm_tls_frame;
    csvm_tls_frame = fr;
    int rc = sigsetjmp(fr->jb, 1);
    if (rc != 0) csvm_tls_frame = fr->prev;
    return rc;
}
static void csvm_guard_exit(csvm_guard_frame_t *fr) { csvm_tls_frame = fr->prev; }

#else  /* Windows / 非 POSIX：安全网桩（SEH 属真机边界，见文档） */
typedef struct { int unused; } csvm_guard_frame_t;
static void csvm_guard_run_begin(void) { }
static void csvm_guard_run_end(void) { }
static int  csvm_guard_enter(csvm_guard_frame_t *fr) { (void)fr; return 0; }
static void csvm_guard_exit(csvm_guard_frame_t *fr) { (void)fr; }
#endif /* CSVM_SIGNAL_GUARD */'''
s = s[:old_guard_start] + new_guard + s[old_guard_end:]

# ---------- 3. vm_do_exit 改用 frame ----------
s = s.replace("""    int rc;
    int fault = csvm_enter_guarded();
    if (fault) {
        *trap = 1; *why = "VM-exit 外部调用触发宿主异常（段错误/浮点/非法指令），已捕获为 TRAP";
        return -1;
    }""", """    int rc;
    csvm_guard_frame_t fr;
    int fault = csvm_guard_enter(&fr);
    if (fault) {
        *trap = 1; *why = "VM-exit 外部调用触发宿主异常（段错误/浮点/非法指令），已捕获为 TRAP";
        return -1;
    }""", 1)
s = s.replace("""        csvm_leave_guarded();
        *trap = 1; *why = "未提供 VM-exit 回调"; return -1;""", """        csvm_guard_exit(&fr);
        *trap = 1; *why = "未提供 VM-exit 回调"; return -1;""", 1)
s = s.replace("""    csvm_leave_guarded();
    if (rc != 0) { *trap = 1; *why = "VM-exit 原生调用失败"; return -1; }""", """    csvm_guard_exit(&fr);
    if (rc != 0) { *trap = 1; *why = "VM-exit 原生调用失败"; return -1; }""", 1)

# ---------- 4. 分派表去全局 ----------
old_disp_start = s.index("static csvm_hfn g_handlers[IR_COUNT + 1];")
old_disp_end = s.index("static int run_blob(", old_disp_start)
new_disp = r'''/* 第九批（多线程上下文）：handler 分派不再驻留全局表。
   旧实现把「哪些逻辑 op 走噪声等价 handler」写进进程级 g_handlers[]，
   每次 run 用 blob 的 seed 重建 —— 两个线程跑不同 seed 的字节码时，
   函数指针被并发改写（数据竞争，形式上是 UB）。
   现在改为纯函数算一个 32 位掩码，掩码只放 run_blob 的栈帧里：
   任何线程都不再写共享状态，语义与旧实现逐位等价（同一 seed 选出同一组）。 */
static uint32_t csvm_dispatch_mask(uint64_t seed) {
    uint32_t mask = 0;
    static const int mut_ops[] = {
        IR_ADD, IR_SUB, IR_XOR, IR_AND, IR_OR, IR_CMP, IR_TEST,
        IR_MOV, IR_INC, IR_DEC, IR_NOT, IR_NEG, IR_IMUL, IR_IMUL3
    };
    uint64_t s = seed ^ 0xC5B17E1D2A3F4C09ULL;
    for (size_t i = 0; i < sizeof(mut_ops) / sizeof(mut_ops[0]); ++i) {
        int op = mut_ops[i];
        if (op < 0 || op >= 32) continue;
        if (csvm_disp_rng(&s) & 1u) mask |= 1u << op;
    }
    return mask;
}

/* ---- 第九批（多线程上下文）：每线程 VM 上下文池 ----
   vm_t 里带 64KB 沙箱内存 + XMM 文件，旧实现每 run 都 calloc/free 一次，
   高频调用时是 malloc 风暴。这里给每线程一个复用池：拿不到就新建，
   归还时擦除敏感字段再挂回本线程空闲链（最多 4 个）；线程退出由 pthread_key
   析构回收。嵌套 run（VM → 宿主函数 → VM）会自然再借一个，不会互相踩。 */
#define CSVM_CTX_POOL_MAX 4

typedef struct csvm_ctx_node {
    vm_t *v;
    struct csvm_ctx_node *next;
} csvm_ctx_node_t;

#if defined(CSVM_TLS_POOL)
static pthread_key_t  csvm_pool_key;
static pthread_once_t csvm_pool_once = PTHREAD_ONCE_INIT;
static __thread csvm_ctx_node_t *csvm_tls_pool = NULL;
static __thread int csvm_tls_pool_len = 0;
static __thread int csvm_tls_borrowed = 0;

static void csvm_pool_dtor(void *p) {
    csvm_ctx_node_t *n = (csvm_ctx_node_t *)p;
    while (n) {
        csvm_ctx_node_t *nx = n->next;
        free(n->v); free(n); n = nx;
    }
}
static void csvm_pool_key_init(void) { pthread_key_create(&csvm_pool_key, csvm_pool_dtor); }

static vm_t *csvm_ctx_acquire(void) {
    pthread_once(&csvm_pool_once, csvm_pool_key_init);
    vm_t *v = NULL;
    if (csvm_tls_pool) {
        csvm_ctx_node_t *n = csvm_tls_pool;
        csvm_tls_pool = n->next; csvm_tls_pool_len--;
        v = n->v; free(n);
    } else {
        v = (vm_t *)calloc(1, sizeof(vm_t));
        if (!v) return NULL;
    }
    memset(v, 0, sizeof(*v));
    csvm_tls_borrowed++;
    return v;
}

static void csvm_ctx_release(vm_t *v) {
    if (!v) return;
    csvm_sec_zero(v, sizeof(*v));
    if (csvm_tls_borrowed > 0) csvm_tls_borrowed--;
    if (csvm_tls_pool_len < CSVM_CTX_POOL_MAX) {
        csvm_ctx_node_t *n = (csvm_ctx_node_t *)malloc(sizeof(*n));
        if (n) {
            n->v = v; n->next = csvm_tls_pool; csvm_tls_pool = n; csvm_tls_pool_len++;
            pthread_setspecific(csvm_pool_key, csvm_tls_pool);
            return;
        }
    }
    free(v);
}
#else
static void *csvm_ctx_acquire(void) { return calloc(1, sizeof(vm_t)); }
static void csvm_ctx_release(void *v) { free(v); }
#endif

'''
s = s[:old_disp_start] + new_disp + s[old_disp_end:]

# ---------- 5. run_blob 改名 inner + 包一层 guard ----------
s = s.replace("""static int run_blob(const csvm_open_t *oc,""",
"""static int run_blob_inner(const csvm_open_t *oc,""", 1)

# 捕获函数签名的参数列表，用于后面生成 wrapper
sig_start = s.index("static int run_blob_inner(const csvm_open_t *oc,")
sig_end = s.index("{\n    const bc_hdr_t *h = &oc->h;", sig_start)
sig_text = s[sig_start:sig_end]
# 参数名列表
args = """oc,
                    regs_in, regs_out, xmm_in, xmm_out, host_mode, runtime_base,
                    memfn, mem_ctx, exitfn, exit_ctx, fpu_exitfn, fpu_exit_ctx,
                    err, cap"""

wrapper = sig_text.replace("run_blob_inner", "run_blob") + """{
    csvm_guard_run_begin();
    int rc = run_blob_inner(""" + args + """);
    csvm_guard_run_end();
    return rc;
}

"""
s = s[:sig_start] + wrapper + s[sig_start:]

# ---------- 6. run_blob_inner 内改用上下文池 ----------
s = s.replace("""    vm_t *v = (vm_t *)calloc(1, sizeof(vm_t));
    if (!v) { set_err(err, cap, "内存不足"); return -1; }""",
"""    vm_t *v = (vm_t *)csvm_ctx_acquire();
    if (!v) { set_err(err, cap, "内存不足"); return -1; }""", 1)

# 把 run_blob_inner 里的 free(v) 换成 release（作用域限定该函数）
inner_start = s.index("static int run_blob_inner(")
inner_end = s.index("CSVM_API int csvm_compile(", inner_start)
inner_body = s[inner_start:inner_end]
inner_body_new = inner_body.replace("free(v);", "csvm_ctx_release(v);")
inner_body_new = inner_body_new.replace(
"""    int need_fpu = (oc->fh.flags & BC_FLAG_NEED_FPU) != 0;""",
"""    uint32_t hmask = csvm_dispatch_mask(oc->fh.seed);
    int need_fpu = (oc->fh.flags & BC_FLAG_NEED_FPU) != 0;""", 1)
inner_body_new = inner_body_new.replace(
"""        csvm_dispatch_ensure((uint64_t)oc->fh.seed);""", "", 1)
inner_body_new = inner_body_new.replace(
"""        g_handlers[lop](v, b, h, mask, &trap, &why, pc, &next, &halt, host_mode, oc);""",
"""        if ((hmask >> (lop & 31)) & 1u)
            exec_op_noisy(v, b, h, mask, &trap, &why, pc, &next, &halt, host_mode, oc);
        else
            exec_step(v, b, h, mask, &trap, &why, pc, &next, &halt, host_mode, oc);""", 1)
s = s[:inner_start] + inner_body_new + s[inner_end:]

open(p, "w", encoding="utf-8").write(s)
print("patched")
