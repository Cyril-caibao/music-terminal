﻿# CyrilShield 第八批 —— Windows 真机冷启动验证链
#
# 用途：在**真实 Windows x64** 上冷启动加载被 peintegrate 改写过的 PE，
#       验证「函数头 E9 -> VM stub -> csvm_enter -> 宿主原生内存执行」整条链，
#       并把 VM 返回值与未改写的原始 DLL 逐项比对。
#
# 为什么需要这个脚本：Linux 沙箱里只能做 PE 字节级检查与 Linux stub 执行
#   （selftest_integration.py 的 t_pe_stub_exec），无法验证 Windows 加载器、
#   IAT 绑定、DEP/W^X、真实 SEH 链下的冷启动。这一步必须由使用者在真机执行。
#
# 前置：
#   1) native/build-win.sh（Linux 交叉）或 native/build.bat（Windows MinGW）
#   2) 产物同目录：CyrilShield.CodeVM.dll / win_target.dll（原始）/
#                  win_target.protected.dll（改写后，用 peintegrate 生成）
#   3) PowerShell 5.1+ / 7+，允许 Add-Type 编译 P/Invoke
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File win_coldboot_verify.ps1 `
#       -Original .\win_target.dll -Protected .\win_target.protected.dll `
#       -RuntimeDll .\CyrilShield.CodeVM.dll
#
# 退出码：0 = 全部 PASS；非 0 = 有 FAIL（含真机缺件，明确报错不静默跳过）。
param(
    [Parameter(Mandatory=$true)][string]$Original,
    [Parameter(Mandatory=$true)][string]$Protected,
    [Parameter(Mandatory=$true)][string]$RuntimeDll,
    [string]$Symbol = "f_protected"
)

$ErrorActionPreference = "Stop"
$fail = 0
function Chk([bool]$cond, [string]$name, [string]$detail = "") {
    if ($cond) { Write-Host ("  [PASS] {0} {1}" -f $name, $detail) }
    else { Write-Host ("  [FAIL] {0} {1}" -f $name, $detail); $script:fail++ }
}

Write-Host "=== CyrilShield Windows 真机冷启动验证 ==="
Write-Host ("原 DLL      : {0}" -f (Resolve-Path $Original))
Write-Host ("改写 DLL    : {0}" -f (Resolve-Path $Protected))
Write-Host ("运行时 DLL  : {0}" -f (Resolve-Path $RuntimeDll))

# --- 1. 文件齐备（缺件直接失败，不静默跳过）---
foreach ($p in @($Original, $Protected, $RuntimeDll)) {
    Chk (Test-Path $p) "文件存在" $p
}
if ($fail -gt 0) { Write-Host "缺件，终止"; exit 2 }

# --- 2. 静态结构：.csvm 节区 + 导入 csvm_enter ---
$bytes = [System.IO.File]::ReadAllBytes((Resolve-Path $Protected))
$pe = [BitConverter]::ToInt32($bytes, 0x3C)
Chk ([System.Text.Encoding]::ASCII.GetString($bytes, $pe, 4) -eq "PE`0`0") "PE32+ 签名"
$nsec = [BitConverter]::ToInt16($bytes, $pe + 6)
$optSize = [BitConverter]::ToInt16($bytes, $pe + 20)
$secOff = $pe + 24 + $optSize
$hasCsvm = $false
for ($i = 0; $i -lt $nsec; $i++) {
    $o = $secOff + 40 * $i
    $nm = [System.Text.Encoding]::ASCII.GetString($bytes, $o, 8).TrimEnd([char]0)
    if ($nm -eq ".csvm") { $hasCsvm = $true }
}
Chk $hasCsvm ".csvm 节区存在" "节区数=$nsec"
$txt = [System.Text.Encoding]::ASCII.GetString($bytes)
Chk ($txt.Contains("CyrilShield.CodeVM.dll")) "导入运行时 DLL"
Chk ($txt.Contains("csvm_enter")) "导入 csvm_enter"

# --- 3. 发布版运行时 DLL 不含分析接口（抗提取）---
if (Get-Command dumpbin -ErrorAction SilentlyContinue) {
    $exp = & dumpbin /exports $RuntimeDll 2>$null | Out-String
    Chk (-not ($exp -match "csvm_disasm|csvm_compile|csvm_stats|csvm_run_regs")) `
        "发布DLL无分析接口导出" "(dumpbin 复核)"
} else {
    Write-Host "  [INFO] 无 dumpbin，跳过导出表复核（Linux 侧已由 llvm-readobj 校验 8 个导出）"
}

# --- 4. 真机冷启动：分别加载原 DLL 与改写 DLL，调用同一导出函数比对 ---
$src = @"
using System;
using System.Runtime.InteropServices;
public static class CsvmColdBoot {
    // 必须用 LOAD_WITH_ALTERED_SEARCH_PATH(0x8)：改写 DLL 依赖同目录的
    // CyrilShield.CodeVM.dll，而默认搜索顺序不含「被加载模块自己的目录」，
    // 直接 LoadLibrary 会得到 err=126（找不到模块）。
    [DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern IntPtr LoadLibraryEx(string lpFileName, IntPtr hFile, uint dwFlags);
    [DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
    public static extern IntPtr GetProcAddress(IntPtr h, string lpProcName);
    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool FreeLibrary(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate ulong Fn(ulong a, ulong b);
    public static ulong Call(string dll, string sym, ulong a, ulong b) {
        IntPtr h = LoadLibraryEx(dll, IntPtr.Zero, 0x00000008);
        if (h == IntPtr.Zero) throw new Exception("LoadLibrary 失败: " + dll + " err=" + Marshal.GetLastWin32Error());
        try {
            IntPtr p = GetProcAddress(h, sym);
            if (p == IntPtr.Zero) throw new Exception("GetProcAddress 失败: " + sym);
            Fn f = (Fn)Marshal.GetDelegateForFunctionPointer(p, typeof(Fn));
            return f(a, b);
        } finally { FreeLibrary(h); }
    }
}
"@
try { Add-Type -TypeDefinition $src -ErrorAction Stop }
catch { Write-Host ("  [FAIL] Add-Type: {0}" -f $_); exit 3 }

# 与 selftest_integration.py / hotpatch_demo 相同的输入集。
# 一律用十进制字符串：PowerShell 把 0xDEADBEEF 解析成负 Int32，
# 0xFFFFFFFFFFFFFFFF 也会溢出，直接写十六进制字面量会在转换时报错。
$cases = @(
    @("0", "1"), @("1", "1"), @("7", "3"), @("4660", "5"),
    @("3735928559", "9"), @("18446744073709551615", "7"),
    @("12345", "11"), @("11400714819323198485", "3")
)
$pass = 0
foreach ($c in $cases) {
    [uint64]$a = [uint64]::Parse($c[0]); [uint64]$b = [uint64]::Parse($c[1])
    try {
        $want = [CsvmColdBoot]::Call((Resolve-Path $Original),  $Symbol, $a, $b)
        $got  = [CsvmColdBoot]::Call((Resolve-Path $Protected), $Symbol, $a, $b)
        if ($got -eq $want) { $pass++ }
        else { Write-Host ("  [FAIL] COLDBOOT a=0x{0:X} b={1} vm=0x{2:X} native=0x{3:X}" -f $a,$b,$got,$want); $fail++ }
    } catch {
        Write-Host ("  [FAIL] COLDBOOT a=0x{0:X} b={1} 异常: {2}" -f $a,$b,$_); $fail++
    }
}
Chk ($pass -eq $cases.Count) "真机冷启动结果一致" ("{0}/{1}" -f $pass, $cases.Count)

Write-Host ("=== RESULT={0} ===" -f $(if ($fail -eq 0) { "PASS" } else { "FAIL" }))
exit $(if ($fail -eq 0) { 0 } else { 1 })
