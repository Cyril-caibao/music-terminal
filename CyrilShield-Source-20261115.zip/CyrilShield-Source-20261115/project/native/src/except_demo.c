/* CyrilShield 第九批 #36 —— VM-exit 异常穿透验证（System V / Linux）
 *
 * 验证：VM 内的函数通过 VM-exit 调用一个会触发宿主异常的外部函数
 * （解引用空指针 = SIGSEGV、整数除零 = SIGFPE），VM 不应让宿主进程崩溃，
 * 而应捕获异常并以带原因的 TRAP 优雅终止（rc != 0 + 错误信息）。
 *
 * 被调函数刻意不依赖 VM 传入的寄存器，直接触发确定性的宿主异常，
 * 因此与平台调用约定的寄存器映射无关。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#include "cs_codevm.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

typedef uint64_t (*csvm_fn4)(uint64_t, uint64_t, uint64_t, uint64_t);

/* 必然触发 SIGSEGV 的外部函数（解引用空指针） */
static uint64_t g_bad_ptr = 0;
__attribute__((used, noinline, noipa, section("cv_badread")))
static uint64_t bad_read(void) {
    return *(volatile uint64_t *)g_bad_ptr;
}
extern const uint8_t __start_cv_badread[], __stop_cv_badread[];

/* VM 内包装：call bad_read -> VM-exit */
__attribute__((used, noinline, noipa, section("cv_callbad")))
static uint64_t f_call_bad(void) { return bad_read(); }
extern const uint8_t __start_cv_callbad[], __stop_cv_callbad[];

/* 必然触发 SIGFPE 的外部函数（整数除零） */
__attribute__((used, noinline, noipa, section("cv_baddiv")))
static uint64_t bad_div(void) {
    volatile uint64_t z = 0;
    return 1u / z;
}
extern const uint8_t __start_cv_baddiv[], __stop_cv_baddiv[];

__attribute__((used, noinline, noipa, section("cv_calldiv")))
static uint64_t f_call_bad_div(void) { return bad_div(); }
extern const uint8_t __start_cv_calldiv[], __stop_cv_calldiv[];

/* 与 csvm_default_exit 等价的本地 VM-exit 回调（按 Win x64 约定调用目标外部函数）。
   信号安全网在 vm_do_exit 内部包裹此回调，因此宿主异常仍会被捕获为 TRAP。 */
static int my_exit(void *ctx, uint64_t target, uint64_t regs[16]) {
    (void)ctx;
    if (!target) return -1;
    csvm_fn4 fn = (csvm_fn4)(uintptr_t)target;
    regs[0] = fn(regs[1], regs[2], regs[8], regs[9]);
    return 0;
}

static int run_and_expect_trap(const char *name, const uint8_t *code, size_t len) {
    uint8_t *bc = NULL; size_t bcn = 0;
    char err[CSVM_ERR_CAP] = {0};
    int rc = csvm_compile(code, len, 0x6E781u, &bc, &bcn, err, sizeof(err));
    if (rc != 0) { printf("  [%s] compile 失败(%d): %s\n", name, rc, err); return -1; }

    uint64_t stack[256]; memset(stack, 0, sizeof(stack));
    uint64_t rin[16] = {0}, rout[16] = {0};
    rin[4] = (uint64_t)(uintptr_t)&stack[128];
    rc = csvm_run_host_ex(bc, bcn, rin, rout,
                          (uint64_t)(uintptr_t)code,
                          NULL, NULL, my_exit, NULL, err, sizeof(err));
    csvm_free(bc);
    /* 期望：rc != 0 且 err 含「宿主异常」字样（说明被捕获为 TRAP，而非进程崩溃） */
    int ok = (rc != 0) && strstr(err, "宿主异常") != NULL;
    printf("  [%s] rc=%d err=\"%s\" -> %s\n", name, rc, err, ok ? "PASS" : "FAIL");
    return ok ? 0 : 1;
}

int main(void) {
    int bad = 0;
    printf("[except] VM-exit 异常穿透：VM 不应崩溃，应优雅 TRAP\n");

    size_t l1 = (size_t)(__stop_cv_callbad - __start_cv_callbad);
    if (run_and_expect_trap("call-null-deref(SEGV)", __start_cv_callbad, l1) != 0) bad |= 1;

    size_t l2 = (size_t)(__stop_cv_calldiv - __start_cv_calldiv);
    if (run_and_expect_trap("call-div0(FPE)", __start_cv_calldiv, l2) != 0) bad |= 2;

    printf("[except] RESULT=%s%s\n", bad == 0 ? "PASS" : "FAIL",
           bad == 0 ? "（两个宿主异常均被捕获为 TRAP，进程存活）" : "");
    return bad == 0 ? 0 : 1;
}
