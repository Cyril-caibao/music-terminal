/* 在 Linux 上真实执行 peintegrate 生成的 Windows x64 VM stub。
 *
 * 目的：沙箱没有 Windows 加载器，无法直接跑改写后的 PE。但 stub 是纯
 * x86-64 机器码，只要把 3 个 RIP 相对 disp32 重定向到本进程内的等价目标，
 * 就能在真实 CPU 上验证「Windows x64 上下文切换 + 调解释器 + 返回值」这条链。
 *
 * 验证方法：
 *   - 一块 RWX mmap 模拟 PE 映像布局：runtime_base=+0x1000, KT 常量池=+0x2000
 *   - stub 放 +0x0，字节码放 +0x4000，IAT 槽放 +0x5000
 *   - patch stub 里的 lea rcx / lea r9 / call [rip+disp] 三个 disp32
 *   - IAT 槽填 cs_bridge（Win x64 -> SysV 参数重排 -> csvm_enter）
 *   - cs_call_stub 按 Windows x64 约定（RCX/RDX + 32B 影子空间）调用 stub
 *   - 与同源 C 参考函数逐字节比对
 *
 * 注意：这里执行的是**集成器产出的 stub 字节本身**，不是另写一份等价汇编。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1   /* MAP_ANONYMOUS：-std=c11 严格模式下 glibc 需显式开启 */
#endif
#include "cs_codevm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>

/* 与 win_target.c 完全一致的常量池 */
static const uint64_t KT[8] = {
    0x9E3779B97F4A7C15ULL, 0xBF58476D1CE4E5B9ULL,
    0x94D049BB133111EBULL, 0xD6E8FEB86659FD93ULL,
    0x123456789ABCDEF0ULL, 0xFEDCBA9876543210ULL,
    0x0102030405060708ULL, 0x8877665544332211ULL,
};

__attribute__((noinline)) static uint64_t ref_protected(uint64_t x, uint64_t d) {
    uint64_t a = x ^ KT[x & 7];
    uint64_t b = KT[(x >> 3) & 7];
    uint64_t q = a / d, r = a % d;
    uint64_t m = q * b;
    uint64_t z = (q > r) ? (m + r) : (m ^ r);
    return z + KT[7] + x;
}

extern uint64_t cs_call_stub(void *stub, uint64_t x, uint64_t d);
extern void cs_bridge(void);

/* Win x64 (RCX,RDX,R8,R9) -> SysV (RDI,RSI,RDX,RCX) -> csvm_enter */
__asm__(
".text\n"
".globl cs_bridge\n"
"cs_bridge:\n"
"    movq %rcx, %rdi\n"
"    movq %rdx, %rsi\n"
"    movq %r8,  %rdx\n"
"    movq %r9,  %rcx\n"
"    jmp  csvm_enter@PLT\n"
".globl cs_call_stub\n"
"cs_call_stub:\n"                 /* RDI=stub, RSI=x, RDX=d */
"    pushq %rbp\n"
"    movq  %rsp, %rbp\n"
"    subq  $32, %rsp\n"          /* Windows x64 影子空间 */
"    movq  %rsi, %rcx\n"         /* 第 1 参数 -> RCX（RDX 已是第 2 参数） */
"    call  *%rdi\n"
"    addq  $32, %rsp\n"
"    popq  %rbp\n"
"    ret\n"
);

static void patch_disp(uint8_t *code, int32_t off, uint64_t target,
                       uint64_t stub_addr) {
    int64_t d = (int64_t)target - (int64_t)(stub_addr + (uint64_t)off + 4);
    if (d < INT32_MIN || d > INT32_MAX) {
        fprintf(stderr, "disp32 越界 off=%d d=%lld\n", off, (long long)d);
        exit(2);
    }
    int32_t d32 = (int32_t)d;
    memcpy(code + off, &d32, 4);
}

int main(int argc, char **argv) {
    if (argc < 6) {
        fprintf(stderr, "用法: %s <stub.bin> <bc.csvm> <disp_bc> <disp_func> <disp_iat>\n",
                argv[0]);
        return 2;
    }
    int32_t d_bc = atoi(argv[3]), d_func = atoi(argv[4]), d_iat = atoi(argv[5]);

    FILE *f = fopen(argv[1], "rb");
    if (!f) return 2;
    fseek(f, 0, SEEK_END); long sn = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *sbuf = (uint8_t *)malloc((size_t)sn);
    if (fread(sbuf, 1, (size_t)sn, f) != (size_t)sn) return 2;
    fclose(f);

    f = fopen(argv[2], "rb");
    if (!f) return 2;
    fseek(f, 0, SEEK_END); long bn = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *bc = (uint8_t *)malloc((size_t)bn);
    if (fread(bc, 1, (size_t)bn, f) != (size_t)bn) return 2;
    fclose(f);

    /* 一块 64KB RWX 模拟映像，保证所有 RIP 相对目标都在 disp32 范围内 */
    uint8_t *reg = (uint8_t *)mmap(NULL, 0x10000,
                                   PROT_READ | PROT_WRITE | PROT_EXEC,
                                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (reg == MAP_FAILED) { perror("mmap"); return 2; }
    uint8_t *stub_addr = reg;
    uint8_t *bc_addr   = reg + 0x4000;
    uint8_t *iat_addr  = reg + 0x5000;
    uint64_t runtime_base = (uint64_t)(uintptr_t)(reg + 0x1000);

    memcpy(stub_addr, sbuf, (size_t)sn);
    memcpy(bc_addr, bc, (size_t)bn);
    memcpy(reg + 0x2000, KT, sizeof(KT));          /* .rdata RVA 0x2000 */
    *(uint64_t *)iat_addr = (uint64_t)(uintptr_t)cs_bridge;

    patch_disp(stub_addr, d_bc,   (uint64_t)(uintptr_t)bc_addr,
               (uint64_t)(uintptr_t)stub_addr);
    patch_disp(stub_addr, d_func, runtime_base,
               (uint64_t)(uintptr_t)stub_addr);
    patch_disp(stub_addr, d_iat,  (uint64_t)(uintptr_t)iat_addr,
               (uint64_t)(uintptr_t)stub_addr);
    __builtin___clear_cache((char *)stub_addr, (char *)stub_addr + sn);

    static const uint64_t XS[] = {
        0ULL, 1ULL, 7ULL, 12345ULL, 0xFFFFFFFFFFFFFFFFULL,
        0x123456789ABCDEFULL, 999ULL, 1ULL << 63,
    };
    static const uint64_t DS[] = {
        1ULL, 7ULL, 97ULL, 3ULL, 13ULL, 0x9E37ULL, 0xFFFFFFFFFFFFFFFULL, 5ULL,
    };
    const size_t n = sizeof(XS) / sizeof(XS[0]);
    int ok = 0;
    for (size_t i = 0; i < n; ++i) {
        volatile uint64_t vx = XS[i], vd = DS[i];
        uint64_t want = ref_protected(vx, vd);
        uint64_t got = cs_call_stub((void *)stub_addr, vx, vd);
        int good = (got == want);
        ok += good;
        printf("case %zu x=0x%016llx d=0x%016llx ref=0x%016llx "
               "pe_stub=0x%016llx %s\n",
               i, (unsigned long long)XS[i], (unsigned long long)DS[i],
               (unsigned long long)want, (unsigned long long)got,
               good ? "OK" : "MISMATCH");
    }
    printf("RESULT=%s %d/%zu\n", ok == (int)n ? "PASS" : "FAIL", ok, n);
    return ok == (int)n ? 0 : 1;
}
