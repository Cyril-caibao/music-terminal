/* CyrilShield PE 集成器 — 把目标函数入口改写成 jmp VM stub
 *
 * 对应「最小可用集成」里程碑第 2/3 步的 PE 实现：
 *   1) 解析 PE32+，按 RVA 定位目标函数
 *   2) 新增 .csvm 节区，放：字节码 + Windows x64 VM stub + 导入表
 *   3) 函数头 5 字节改成 E9 rel32 -> 新节区 stub
 *   4) 修 NumberOfSections / SizeOfImage / Import / IAT / 节表 / 重算 Checksum
 *
 * stub 用 RIP 相对访问字节码与 IAT，因此**不需要新增基址重定位项**；
 * runtime_base（目标函数运行时地址）由 stub 用 lea r9,[rip+disp] 现场算出，
 * 不受 ASLR 影响。DLL（CyrilShield.CodeVM.dll，导出 csvm_enter）需随 EXE 同目录部署。
 *
 * 明确不做：AMSI/ETW 补丁、进程注入、驱动、反 EDR、进程镂空。
 * 边界：单次只改写单个函数，目标须落在内核受限子集内（FF/4 间接跳转与
 * 标量 SSE 已支持）；不处理异常展开表 / TLS / 多线程 VM 上下文 / CFG /
 * 字符串指令与 packed SIMD，见 docs/CODE-VM.md 第 6 节。
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define DLL_NAME   "CyrilShield.CodeVM.dll"
#define ENTER_SYM  "csvm_enter"
#define SEC_NAME   ".csvm"
#define STUB_FRAME 200u          /* stub 栈帧大小（16 GPR + flags + 暂存 + 对齐） */
/* CNT_CODE | MEM_EXECUTE | MEM_READ | MEM_WRITE
   .csvm 同时承载 stub 代码与本次新增的 IAT（FirstThunk 落在这里）。
   加载器解析导入时会把真实函数地址**写入** IAT，节区不可写就会在
   LoadLibrary 阶段触发 0xC0000005（写 0x…3C600）。故必须带 MEM_WRITE。 */
#define SCN_CODE   (0xE0000020u)

/* ------------------------------------------------------------------ 小工具 */
static uint16_t rd16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t rd32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static uint64_t rd64(const uint8_t *p) {
    return (uint64_t)rd32(p) | ((uint64_t)rd32(p + 4) << 32);
}
static void wr16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void wr32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}
static uint32_t align_up(uint32_t v, uint32_t a) {
    return a ? (uint32_t)(((uint64_t)v + a - 1) / a * a) : v;
}
/* PE 映像校验和（与 CheckSumMappedFile 等价）：整个文件按 16 位小端字累加，
 * 每步把进位折回低 16 位，最终折叠一次后加文件长度。checksum 字段本身按 0
 * 参与运算（加 0 等价于跳过）——所以调用前该字段必须已清零。改写会变动全文件，
 * 故必须在所有其它字段/节表/函数头都写完之后、写盘之前计算。 */
static uint32_t pe_checksum(const uint8_t *p, size_t n) {
    uint64_t sum = 0;
    size_t i = 0;
    for (; i + 1 < n; i += 2) {
        sum += (uint32_t)p[i] | ((uint32_t)p[i + 1] << 8);
        sum = (sum & 0xFFFFu) + (sum >> 16);
    }
    if (i < n) {                       /* 奇数长度：最后一个字节 */
        sum += p[i];
        sum = (sum & 0xFFFFu) + (sum >> 16);
    }
    sum = (sum & 0xFFFFu) + (sum >> 16);   /* 最终折叠到 16 位 */
    return (uint32_t)(sum + (uint32_t)n);
}

typedef struct { uint8_t *p; size_t n, cap; } Buf;
static void bgrow(Buf *b, size_t need) {
    if (b->n + need <= b->cap) return;
    size_t c = b->cap ? b->cap * 2 : 256;
    while (c < b->n + need) c *= 2;
    b->p = (uint8_t *)realloc(b->p, c);
    if (!b->p) { fprintf(stderr, "内存不足\n"); exit(3); }
    b->cap = c;
}
static void b8(Buf *b, uint8_t v) { bgrow(b, 1); b->p[b->n++] = v; }
static void b32(Buf *b, uint32_t v) {
    bgrow(b, 4);
    wr32(b->p + b->n, v); b->n += 4;
}
static void bbytes(Buf *b, const void *p, size_t n) {
    bgrow(b, n); memcpy(b->p + b->n, p, n); b->n += n;
}
static void bzeros(Buf *b, size_t n) {
    bgrow(b, n); memset(b->p + b->n, 0, n); b->n += n;
}
static void bset(Buf *b, size_t off, const void *p, size_t n) {
    memcpy(b->p + off, p, n);
}

/* ------------------------------------------------------------------- PE 解析 */
typedef struct {
    uint8_t  *d;
    size_t    n;
    uint32_t  pe_off, coff, nsec, opt_size, opt_off, sec_off;
    uint64_t  image_base;
    uint32_t  sect_align, file_align, size_image, size_headers;
    uint32_t  num_rva, dd_off, checksum_off;
} PE;

static int pe_open(PE *pe, uint8_t *d, size_t n) {
    memset(pe, 0, sizeof(*pe));
    if (n < 0x40 || d[0] != 'M' || d[1] != 'Z') return -1;
    uint32_t o = rd32(d + 0x3C);
    if ((size_t)o + 24 > n || memcmp(d + o, "PE\0\0", 4) != 0) return -2;
    pe->d = d; pe->n = n; pe->pe_off = o; pe->coff = o + 4;
    pe->nsec = rd16(d + pe->coff + 2);
    pe->opt_size = rd16(d + pe->coff + 16);
    pe->opt_off = pe->coff + 20;
    pe->sec_off = pe->opt_off + pe->opt_size;
    if ((size_t)pe->sec_off + 40u * pe->nsec > n) return -3;
    if (rd16(d + pe->opt_off) != 0x20B) return -4;   /* 仅 PE32+ */
    const uint8_t *op = d + pe->opt_off;
    pe->image_base   = rd64(op + 24);
    pe->sect_align   = rd32(op + 32);
    pe->file_align   = rd32(op + 36);
    pe->size_image   = rd32(op + 56);
    pe->size_headers = rd32(op + 60);
    pe->checksum_off = pe->opt_off + 64;
    pe->num_rva      = rd32(op + 108);
    pe->dd_off       = pe->opt_off + 112;
    if (pe->num_rva < 13) return -5;
    if ((size_t)pe->dd_off + 16u * pe->num_rva > n) return -6;
    return 0;
}

static void sec_info(const PE *pe, uint32_t i, uint32_t *vs, uint32_t *va,
                     uint32_t *rs, uint32_t *ro) {
    const uint8_t *s = pe->d + pe->sec_off + i * 40u;
    *vs = rd32(s + 8); *va = rd32(s + 12);
    *rs = rd32(s + 16); *ro = rd32(s + 20);
}

static int rva_to_off(const PE *pe, uint32_t rva, uint32_t *off) {
    for (uint32_t i = 0; i < pe->nsec; ++i) {
        uint32_t vs, va, rs, ro;
        sec_info(pe, i, &vs, &va, &rs, &ro);
        uint32_t span = vs > rs ? vs : rs;
        if (rva >= va && rva - va < span) {
            if (rva - va >= rs) return -1;         /* 在 BSS 里，无文件字节 */
            *off = ro + (rva - va);
            return *off < pe->n ? 0 : -1;
        }
    }
    return -1;
}

/* 读取原有导入描述符，供新节区的导入表**保留**。
 *
 * 背景：早期实现直接把 Import Directory 指向「只含 CyrilShield.CodeVM.dll 一条」
 * 的新表，等于把目标模块原有的 api-ms-win-crt-* 与 KERNEL32 导入全部抹掉。
 * 在 Linux 样本（导入极少或为空）上看不出来，但真实 DLL 一加载就
 * WinError 1114（DLL 初始化例程失败）。正确做法是：把原描述符数组原样搬进
 * 新节区，在末尾追加 CodeVM 一条，再补 terminator。
 *
 * 返回原描述符数量（不含 terminator）；imp_off 为原表文件偏移，imp_size 为原目录大小。
 */
static uint32_t count_import_descs(const PE *pe, const uint8_t *buf, uint32_t buf_n,
                                   uint32_t *imp_off, uint32_t *imp_size) {
    *imp_off = 0;
    *imp_size = rd32(buf + pe->dd_off + 1 * 8 + 4);
    uint32_t rva = rd32(buf + pe->dd_off + 1 * 8 + 0);
    if (!rva) return 0;
    uint32_t off = 0;
    if (rva_to_off(pe, rva, &off) != 0) return 0;
    uint32_t maxn = *imp_size / 20u;
    if (maxn == 0 || maxn > 1024u) maxn = 1024u;
    uint32_t n = 0;
    for (; n < maxn; ++n) {
        if (off + n * 20u + 20u > buf_n) break;
        if (rd32(buf + off + n * 20u + 12u) == 0) break;   /* Name == 0 即结束 */
    }
    *imp_off = off;
    return n;
}

/* ------------------------------------------- v3.3.5：异常展开（unwind）子集
 * Windows x64 的 RtlLookupFunctionEntry 依赖 .pdata 的 RUNTIME_FUNCTION 表。
 * 旧版把目标函数头改成 E9 -> .csvm stub 后，stub 不在任何展开表里：一旦
 * stub 执行期间出现 SEH 异常（VM-exit 调用触发 AV、除零等），OS 找不到
 * unwind 信息会直接终止进程。这里为 .csvm 节区补一份共享 UNWIND_INFO，
 * 并为每个 stub 追加 RUNTIME_FUNCTION 条目；原表整段保留、dd[3] 改指向新表。
 *
 * stub prologue（build_stub 的 prologue[]）逐条偏移：
 *   0  sub rsp,200 (7B)
 *   7..21  保存 rax/rcx/rdx（易失，unwind 不描述）
 *   21 mov [rsp+24],rbx  -> 26
 *   39 mov [rsp+40],rbp  -> 44
 *   44 mov [rsp+48],rsi  -> 49
 *   49 mov [rsp+56],rdi  -> 54
 *   74 mov [rsp+96],r12  -> 79
 *   79 mov [rsp+104],r13 -> 84
 *   84 mov [rsp+112],r14 -> 89
 *   89 mov [rsp+120],r15 -> 94
 *   94..104 pushfq/pop/mov [rsp+128],rax（FLAGS）
 * 共 8 个非易失寄存器用 UWOP_SAVE_NONVOL(8)，加 UWOP_ALLOC_LARGE(1)，
 * 每项 2 个 UNWIND_CODE slot -> 18 slots = 36B + 4B 头 = 40B。
 * UNWIND_CODE 必须按 CodeOffset 降序（prologue 逆序）排列。
 *
 * 诚实边界：stub 在 call 前后各 sub/add rsp,32（影子空间），异常恰发生在
 * call 内部时 RSP 比 unwind 描述少 32，链式展开仍不完美；因此对「原函数
 * 本身带 unwind 信息」的目标，Python 编排层会跳过虚拟化（见
 * integration.pdata_covered_ranges），不把可展开函数变成不可展开函数。
 */
#define CS_UNWIND_SIZE 40u
static void emit_unwind_info(uint8_t *p) {
    memset(p, 0, CS_UNWIND_SIZE);
    p[0] = 1u;        /* Version=1, Flags=0（无 EHANDLER / CHAININFO） */
    p[1] = 104u;      /* SizeOfProlog：到 pushfq/pop/mov FLAGS 结束 */
    p[2] = 18u;       /* CountOfCodes：9 项 x 2 slot */
    p[3] = 0u;        /* FrameRegister=0 / FrameOffset=0 */
    uint32_t at = 4;
#define CS_UCODE(off, op, info, extra) do { \
        p[at++] = (uint8_t)(off); \
        p[at++] = (uint8_t)((((info) & 0xF) << 4) | ((op) & 0xF)); \
        p[at++] = (uint8_t)((extra) & 0xFF); \
        p[at++] = (uint8_t)(((extra) >> 8) & 0xFF); \
    } while (0)
    CS_UCODE(94, 8, 15, 15);  /* r15 @ [rsp+120] */
    CS_UCODE(89, 8, 14, 14);  /* r14 @ [rsp+112] */
    CS_UCODE(84, 8, 13, 13);  /* r13 @ [rsp+104] */
    CS_UCODE(79, 8, 12, 12);  /* r12 @ [rsp+96]  */
    CS_UCODE(54, 8,  7,  7);  /* rdi @ [rsp+56]  */
    CS_UCODE(49, 8,  6,  6);  /* rsi @ [rsp+48]  */
    CS_UCODE(44, 8,  5,  5);  /* rbp @ [rsp+40]  */
    CS_UCODE(26, 8,  3,  3);  /* rbx @ [rsp+24]  */
    CS_UCODE( 7, 1,  0, 25);  /* sub rsp,200 -> 200/8 */
#undef CS_UCODE
}

/* ------------------------------------------------- Windows x64 VM stub 发射 */
/* 调用 csvm_enter(bc, len, slots, runtime_base)：4 参数全寄存器。
 * stub 自行保存 16 GPR + FLAGS，分配 32 字节影子空间，call [rip+iat]，
 * 把返回值放 RAX，恢复现场后 ret。全部用 RIP 相对，无需重定位。 */
static Buf build_stub(uint32_t stub_rva, uint32_t bc_rva, uint32_t bc_len,
                      uint32_t iat_rva, uint32_t func_rva) {
    Buf b = {0};
    uint32_t at;
    /* ---- 保存现场 ---- */
    const uint8_t prologue[] = {
        0x48,0x81,0xEC,0xC8,0x00,0x00,0x00,       /* sub rsp,200 */
        0x48,0x89,0x04,0x24,                       /* mov [rsp+0],rax   */
        0x48,0x89,0x4C,0x24,0x08,                  /* mov [rsp+8],rcx   */
        0x48,0x89,0x54,0x24,0x10,                  /* mov [rsp+16],rdx  */
        0x48,0x89,0x5C,0x24,0x18,                  /* mov [rsp+24],rbx  */
        0x48,0x8D,0x84,0x24,0xC8,0x00,0x00,0x00,  /* lea rax,[rsp+200] */
        0x48,0x89,0x44,0x24,0x20,                  /* mov [rsp+32],rax  (RSP slot) */
        0x48,0x89,0x6C,0x24,0x28,                  /* mov [rsp+40],rbp  */
        0x48,0x89,0x74,0x24,0x30,                  /* mov [rsp+48],rsi  */
        0x48,0x89,0x7C,0x24,0x38,                  /* mov [rsp+56],rdi  */
        0x4C,0x89,0x44,0x24,0x40,                  /* mov [rsp+64],r8   */
        0x4C,0x89,0x4C,0x24,0x48,                  /* mov [rsp+72],r9   */
        0x4C,0x89,0x54,0x24,0x50,                  /* mov [rsp+80],r10  */
        0x4C,0x89,0x5C,0x24,0x58,                  /* mov [rsp+88],r11  */
        0x4C,0x89,0x64,0x24,0x60,                  /* mov [rsp+96],r12  */
        0x4C,0x89,0x6C,0x24,0x68,                  /* mov [rsp+104],r13 */
        0x4C,0x89,0x74,0x24,0x70,                  /* mov [rsp+112],r14 */
        0x4C,0x89,0x7C,0x24,0x78,                  /* mov [rsp+120],r15 */
        0x9C,                                      /* pushfq */
        0x58,                                      /* pop rax */
        0x48,0x89,0x84,0x24,0x80,0x00,0x00,0x00,  /* mov [rsp+128],rax (FLAGS) */
    };
    bbytes(&b, prologue, sizeof(prologue));

    /* lea rcx, [rip+disp]  -> 字节码 */
    at = (uint32_t)b.n;
    b8(&b, 0x48); b8(&b, 0x8D); b8(&b, 0x0D);
    b32(&b, (uint32_t)((int64_t)bc_rva - (int64_t)(stub_rva + at + 7)));

    /* mov rdx, imm32 (bc_len) */
    b8(&b, 0x48); b8(&b, 0xC7); b8(&b, 0xC2); b32(&b, bc_len);

    /* lea r8, [rsp] -> slots */
    const uint8_t lea_r8[] = {0x4C, 0x8D, 0x04, 0x24};
    bbytes(&b, lea_r8, sizeof(lea_r8));

    /* lea r9, [rip+disp] -> 目标函数运行时地址（runtime_base） */
    at = (uint32_t)b.n;
    b8(&b, 0x4C); b8(&b, 0x8D); b8(&b, 0x0D);
    b32(&b, (uint32_t)((int64_t)func_rva - (int64_t)(stub_rva + at + 7)));

    /* sub rsp,32 (影子空间) ; call [rip+iat] ; add rsp,32 */
    const uint8_t call_pre[] = {0x48, 0x83, 0xEC, 0x20};
    bbytes(&b, call_pre, sizeof(call_pre));
    at = (uint32_t)b.n;
    b8(&b, 0xFF); b8(&b, 0x15);
    b32(&b, (uint32_t)((int64_t)iat_rva - (int64_t)(stub_rva + at + 6)));
    const uint8_t call_post[] = {
        0x48,0x83,0xC4,0x20,                        /* add rsp,32 */
        0x48,0x89,0x84,0x24,0x88,0x00,0x00,0x00,  /* mov [rsp+136],rax (结果暂存) */
        0x48,0x8B,0x84,0x24,0x80,0x00,0x00,0x00,  /* mov rax,[rsp+128] (FLAGS) */
        0x50,                                      /* push rax */
        0x9D,                                      /* popfq */
    };
    bbytes(&b, call_post, sizeof(call_post));

    /* 恢复除 RAX/RSP 外的 GPR */
    const uint8_t restore[] = {
        0x48,0x8B,0x4C,0x24,0x08,                  /* mov rcx,[rsp+8]   */
        0x48,0x8B,0x54,0x24,0x10,                  /* mov rdx,[rsp+16]  */
        0x48,0x8B,0x5C,0x24,0x18,                  /* mov rbx,[rsp+24]  */
        0x48,0x8B,0x6C,0x24,0x28,                  /* mov rbp,[rsp+40]  */
        0x48,0x8B,0x74,0x24,0x30,                  /* mov rsi,[rsp+48]  */
        0x48,0x8B,0x7C,0x24,0x38,                  /* mov rdi,[rsp+56]  */
        0x4C,0x8B,0x44,0x24,0x40,                  /* mov r8,[rsp+64]   */
        0x4C,0x8B,0x4C,0x24,0x48,                  /* mov r9,[rsp+72]   */
        0x4C,0x8B,0x54,0x24,0x50,                  /* mov r10,[rsp+80]  */
        0x4C,0x8B,0x5C,0x24,0x58,                  /* mov r11,[rsp+88]  */
        0x4C,0x8B,0x64,0x24,0x60,                  /* mov r12,[rsp+96]  */
        0x4C,0x8B,0x6C,0x24,0x68,                  /* mov r13,[rsp+104] */
        0x4C,0x8B,0x74,0x24,0x70,                  /* mov r14,[rsp+112] */
        0x4C,0x8B,0x7C,0x24,0x78,                  /* mov r15,[rsp+120] */
        0x48,0x8B,0x84,0x24,0x88,0x00,0x00,0x00,  /* mov rax,[rsp+136] (VM 结果) */
        0x48,0x81,0xC4,0xC8,0x00,0x00,0x00,       /* add rsp,200 */
        0xC3,                                      /* ret */
    };
    bbytes(&b, restore, sizeof(restore));
    return b;
}

/* ------------------------------------------------------------------- 集成 */
static uint8_t *read_file(const char *path, size_t *n) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    if (sz <= 0) { fclose(f); return NULL; }
    uint8_t *p = (uint8_t *)malloc((size_t)sz);
    if (!p || fread(p, 1, (size_t)sz, f) != (size_t)sz) { free(p); fclose(f); return NULL; }
    fclose(f); *n = (size_t)sz; return p;
}
/* 在 stub 字节里找指令模式，返回紧随模式之后的 disp32 字段偏移。
 * 供 selftest_integration.py 在 Linux 上 patch 后真实执行这段 Windows stub。 */
static int32_t find_disp_off(const uint8_t *p, size_t n,
                             const uint8_t *pat, size_t pn) {
    if (pn > n) return -1;
    for (size_t i = 0; i + pn <= n; ++i)
        if (memcmp(p + i, pat, pn) == 0) return (int32_t)(i + pn);
    return -1;
}

static int write_file(const char *path, const uint8_t *p, size_t n) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    int ok = fwrite(p, 1, n, f) == n;
    fclose(f); return ok ? 0 : -1;
}

/* ---------------- 第八批第 5 项：多函数批量改写 ----------------
 * 用法: peintegrate --batch <in.exe> <out.exe> <report.json> <N>
 *                   <func_rva1_hex> <bc1.csvm> [<func_rva2_hex> <bc2.csvm> ...]
 * 共享 1 个 .csvm 节区 + 1 个 IAT/导入描述符，内含 N 个 stub 与 N 份
 * 字节码，N 个目标函数头各自 E9 跳到自己的 stub。旧单函数 CLI 不变。 */
static int batch_mode(int argc, char **argv) {
    if (argc < 8) {
        fprintf(stderr,
            "批量用法: %s --batch <input.exe> <output.exe> <report.json> <N> "
            "<func_rva1_hex> <bc1.csvm> [<func_rva2_hex> <bc2.csvm> ...]\n", argv[0]);
        return 2;
    }
    const char *in_path = argv[2], *out_path = argv[3], *rep_path = argv[4];
    int nf = atoi(argv[5]);
    if (nf < 1 || nf > 64 || argc != 6 + 2 * nf) {
        fprintf(stderr, "批量参数个数不匹配（N=%d, argc=%d）\n", nf, argc);
        return 2;
    }
    uint32_t *rvas       = (uint32_t *)calloc((size_t)nf, sizeof(uint32_t));
    uint32_t *func_offs  = (uint32_t *)calloc((size_t)nf, sizeof(uint32_t));
    uint32_t *bc_offs    = (uint32_t *)calloc((size_t)nf, sizeof(uint32_t));
    uint8_t **bcs        = (uint8_t **)calloc((size_t)nf, sizeof(uint8_t *));
    size_t   *bcns       = (size_t *)calloc((size_t)nf, sizeof(size_t));
    if (!rvas || !func_offs || !bc_offs || !bcs || !bcns) {
        fprintf(stderr, "内存不足\n"); return 3;
    }
    for (int i = 0; i < nf; ++i) {
        rvas[i] = (uint32_t)strtoul(argv[6 + 2 * i], NULL, 16);
        bcs[i] = read_file(argv[7 + 2 * i], &bcns[i]);
        if (!bcs[i] || bcns[i] < 16 || memcmp(bcs[i], "CSVM", 4) != 0) {
            fprintf(stderr, "函数 %d 的字节码无效\n", i); return 2;
        }
    }
    size_t pe_n;
    uint8_t *pe_buf = read_file(in_path, &pe_n);
    if (!pe_buf) { fprintf(stderr, "读取输入失败\n"); return 2; }
    PE pe;
    if (pe_open(&pe, pe_buf, pe_n) != 0) {
        fprintf(stderr, "PE 解析失败，仅支持 PE32+\n"); return 2;
    }
    for (int i = 0; i < nf; ++i) {
        if (rva_to_off(&pe, rvas[i], &func_offs[i]) != 0 || func_offs[i] + 5 > pe_n) {
            fprintf(stderr, "函数 %d RVA 0x%X 无法映射到文件偏移\n", i, rvas[i]);
            return 2;
        }
    }
    uint32_t sec_table_end = pe.sec_off + 40u * (pe.nsec + 1u);
    if (sec_table_end > pe.size_headers || sec_table_end > pe_n) {
        fprintf(stderr, "PE 头无空间新增节区\n"); return 2;
    }
    uint32_t lvs, lva, lrs, lro;
    sec_info(&pe, pe.nsec - 1, &lvs, &lva, &lrs, &lro);
    uint32_t new_va = align_up(lva + (lvs > lrs ? lvs : lrs), pe.sect_align);

    /* 所有 stub 长度一致（disp32 长度与值无关），用占位算一次 */
    Buf dummy = build_stub(new_va, new_va, 64, new_va, rvas[0]);
    uint32_t stub_size = (uint32_t)dummy.n;
    free(dummy.p);

    uint32_t stub_area = align_up(stub_size * (uint32_t)nf, 16);
    uint32_t cur = stub_area;
    for (int i = 0; i < nf; ++i) {
        bc_offs[i] = cur;
        cur = align_up(cur + (uint32_t)bcns[i], 16);
    }
    uint32_t iat_off  = cur;
    uint32_t ilt_off  = iat_off + 16;
    uint32_t hn_off   = ilt_off + 16;
    uint32_t hn_size  = align_up(2u + (uint32_t)strlen(ENTER_SYM) + 1u, 2u);
    uint32_t dll_off  = hn_off + hn_size;
    uint32_t dll_size = align_up((uint32_t)strlen(DLL_NAME) + 1u, 2u);
    uint32_t desc_off = align_up(dll_off + dll_size, 4);
    uint32_t imp_off  = 0, imp_sz = 0;
    uint32_t n_old    = count_import_descs(&pe, pe_buf, (uint32_t)pe_n, &imp_off, &imp_sz);
    uint32_t total    = desc_off + (n_old + 2u) * 20u;
    /* v3.3.5：异常表。原 .pdata（若有）整段复制，再为每个 stub 追加
       一条 RUNTIME_FUNCTION；dd[3] 改指向这张新表。 */
    uint32_t old_pd_rva  = rd32(pe_buf + pe.dd_off + 3 * 8u);
    uint32_t old_pd_size = rd32(pe_buf + pe.dd_off + 3 * 8u + 4u);
    uint32_t n_old_pf    = old_pd_size / 12u;
    uint32_t old_pd_off  = 0;
    if (n_old_pf && rva_to_off(&pe, old_pd_rva, &old_pd_off) != 0) {
        fprintf(stderr, "警告：原异常表 RVA 0x%X 无法映射，仅保留 stub 条目\n",
                old_pd_rva);
        n_old_pf = 0;
    }
    if (n_old_pf && (size_t)old_pd_off + n_old_pf * 12u > pe_n) n_old_pf = 0;
    uint32_t unwind_off = align_up(total, 4u);
    uint32_t unwind_rva = new_va + unwind_off;
    uint32_t pdata_off  = align_up(unwind_off + CS_UNWIND_SIZE, 4u);
    uint32_t pdata_rva  = new_va + pdata_off;
    uint32_t pdata_size = (n_old_pf + (uint32_t)nf) * 12u;
    uint32_t total_all  = pdata_off + pdata_size;
    uint32_t iat_rva  = new_va + iat_off, ilt_rva = new_va + ilt_off;
    uint32_t hn_rva   = new_va + hn_off, dll_rva = new_va + dll_off;
    uint32_t desc_rva = new_va + desc_off;

    Buf sd = {0}; bzeros(&sd, total_all);
    for (int i = 0; i < nf; ++i) {
        uint32_t s_rva = new_va + stub_size * (uint32_t)i;
        uint32_t b_rva = new_va + bc_offs[i];
        Buf s = build_stub(s_rva, b_rva, (uint32_t)bcns[i], iat_rva, rvas[i]);
        if (s.n != stub_size) { fprintf(stderr, "stub 长度不稳定\n"); free(s.p); return 3; }
        bset(&sd, stub_size * (uint32_t)i, s.p, s.n);
        free(s.p);
    }
    for (int i = 0; i < nf; ++i) bset(&sd, bc_offs[i], bcs[i], bcns[i]);
    uint8_t thunk[8] = {0}; wr32(thunk, hn_rva);
    bset(&sd, iat_off, thunk, 8); bset(&sd, ilt_off, thunk, 8);
    bset(&sd, hn_off + 2, ENTER_SYM, strlen(ENTER_SYM));
    bset(&sd, dll_off, DLL_NAME, strlen(DLL_NAME));
    if (n_old) bset(&sd, desc_off, pe_buf + imp_off, n_old * 20u);
    uint8_t desc[20] = {0};
    wr32(desc + 0, ilt_rva); wr32(desc + 12, dll_rva); wr32(desc + 16, iat_rva);
    bset(&sd, desc_off + n_old * 20u, desc, 20);

    /* UNWIND_INFO（所有 stub 共用一份） */
    emit_unwind_info(sd.p + unwind_off);
    /* RUNTIME_FUNCTION：先原条目（按原顺序，保持有序），再 stub 条目。
       .csvm 位于映像末尾，stub RVA 必然大于原表所有 BeginAddress。 */
    if (n_old_pf)
        memcpy(sd.p + pdata_off, pe_buf + old_pd_off, n_old_pf * 12u);
    for (int i = 0; i < nf; ++i) {
        uint8_t *e = sd.p + pdata_off + (n_old_pf + (uint32_t)i) * 12u;
        uint32_t begin = new_va + stub_size * (uint32_t)i;
        wr32(e, begin);
        wr32(e + 4, begin + stub_size);
        wr32(e + 8, unwind_rva);
    }

    uint32_t new_raw_off  = align_up((uint32_t)pe_n, pe.file_align);
    uint32_t new_raw_size = align_up(total_all, pe.file_align);
    size_t out_n = (size_t)new_raw_off + new_raw_size;
    uint8_t *out = (uint8_t *)calloc(1, out_n);
    if (!out) { fprintf(stderr, "内存不足\n"); return 3; }
    memcpy(out, pe_buf, pe_n);
    memcpy(out + new_raw_off, sd.p, total_all);

    wr16(out + pe.coff + 2, (uint16_t)(pe.nsec + 1));
    wr32(out + pe.opt_off + 56, align_up(new_va + total_all, pe.sect_align));
    wr32(out + pe.dd_off + 3 * 8 + 0, pdata_rva);
    wr32(out + pe.dd_off + 3 * 8 + 4, pdata_size);
    wr32(out + pe.dd_off + 1 * 8 + 0, desc_rva);
    wr32(out + pe.dd_off + 1 * 8 + 4, (n_old + 2u) * 20u);
    if (rd32(out + pe.dd_off + 12 * 8 + 0) == 0) {
        wr32(out + pe.dd_off + 12 * 8 + 0, iat_rva);
        wr32(out + pe.dd_off + 12 * 8 + 4, 16);
    }
    uint8_t *sh = out + pe.sec_off + 40u * pe.nsec;
    memset(sh, 0, 40); memcpy(sh, SEC_NAME, strlen(SEC_NAME));
    wr32(sh + 8, total_all); wr32(sh + 12, new_va);
    wr32(sh + 16, new_raw_size); wr32(sh + 20, new_raw_off);
    wr32(sh + 36, SCN_CODE);

    for (int i = 0; i < nf; ++i) {
        int64_t rel = (int64_t)(new_va + stub_size * (uint32_t)i) - (int64_t)(rvas[i] + 5);
        if (rel < INT32_MIN || rel > INT32_MAX) {
            fprintf(stderr, "函数 %d 的 stub 超出 rel32 范围\n", i); return 2;
        }
        out[func_offs[i]] = 0xE9;
        wr32(out + func_offs[i] + 1, (uint32_t)(int32_t)rel);
    }
    wr32(out + pe.checksum_off, 0);
    uint32_t final_ck = pe_checksum(out, out_n);
    wr32(out + pe.checksum_off, final_ck);
    if (write_file(out_path, out, out_n) != 0) {
        fprintf(stderr, "写出失败\n"); return 2;
    }

    FILE *rep = fopen(rep_path, "w");
    if (!rep) rep = stdout;
    fprintf(rep,
        "{\n  \"batch\": true,\n  \"functions\": %d,\n"
        "  \"section\": \"%s\",\n  \"section_rva\": \"0x%X\",\n"
        "  \"section_vsize\": %u,\n  \"section_raw_off\": \"0x%X\",\n"
        "  \"iat_rva\": \"0x%X\",\n  \"stub_size\": %u,\n"
        "  \"sections\": %u,\n  \"checksum\": \"0x%08X\",\n"
        "  \"unwind\": {\"enabled\": true, \"pdata_rva\": \"0x%X\", "
        "\"pdata_entries\": %u, \"stub_entries\": %d, "
        "\"unwind_rva\": \"0x%X\", \"original_entries\": %u},\n"
        "  \"items\": [\n",
        nf, SEC_NAME, new_va, total_all, new_raw_off, iat_rva, stub_size,
        pe.nsec + 1u, final_ck,
        pdata_rva, n_old_pf + (uint32_t)nf, nf, unwind_rva, n_old_pf);
    for (int i = 0; i < nf; ++i) {
        fprintf(rep,
            "    {\"func_rva\": \"0x%X\", \"stub_rva\": \"0x%X\", "
            "\"bc_rva\": \"0x%X\", \"bc_bytes\": %zu}%s\n",
            rvas[i], new_va + stub_size * (uint32_t)i,
            new_va + bc_offs[i], bcns[i], (i + 1 < nf) ? "," : "");
    }
    fprintf(rep, "  ]\n}\n");
    if (rep != stdout) fclose(rep);

    for (int i = 0; i < nf; ++i) free(bcs[i]);
    free(rvas); free(func_offs); free(bc_offs); free(bcs); free(bcns);
    free(out); free(sd.p); free(pe_buf);
    return 0;
}

/* 把字符串按 JSON 规则转义（反斜杠 / 引号 / 控制字符）。
   report.json 里会写输入输出路径，Windows 的 "D:\x\y" 不转义就是非法 JSON。 */
static void json_escape(char *dst, size_t cap, const char *src) {
    size_t j = 0;
    if (cap == 0) return;
    for (size_t i = 0; src && src[i] && j + 8 < cap; ++i) {
        unsigned char c = (unsigned char)src[i];
        switch (c) {
        case '\\': case '"':
            dst[j++] = '\\'; dst[j++] = (char)c; break;
        case '\n': dst[j++] = '\\'; dst[j++] = 'n'; break;
        case '\r': dst[j++] = '\\'; dst[j++] = 'r'; break;
        case '\t': dst[j++] = '\\'; dst[j++] = 't'; break;
        default:
            if (c < 0x20) j += (size_t)snprintf(dst + j, cap - j, "\\u%04x", c);
            else dst[j++] = (char)c;
        }
    }
    dst[j] = '\0';
}

int main(int argc, char **argv) {
    if (argc >= 2 && strcmp(argv[1], "--batch") == 0)
        return batch_mode(argc, argv);
    if (argc < 5) {
        fprintf(stderr,
            "用法: %s <input.exe> <func_rva_hex> <bytecode.csvm> <output.exe> [report.json]\n"
            "  例: %s target.dll 1000 f_protected.csvm target.protected.dll report.json\n",
            argv[0], argv[0]);
        return 2;
    }
    const char *in_path = argv[1], *bc_path = argv[3], *out_path = argv[4];
    uint32_t func_rva = (uint32_t)strtoul(argv[2], NULL, 16);

    size_t pe_n, bc_n;
    uint8_t *pe_buf = read_file(in_path, &pe_n);
    uint8_t *bc = read_file(bc_path, &bc_n);
    if (!pe_buf || !bc) { fprintf(stderr, "读取输入失败\n"); return 2; }
    if (bc_n < 16 || memcmp(bc, "CSVM", 4) != 0) {
        fprintf(stderr, "不是有效的 CodeVM 字节码（缺 CSVM 魔数）\n"); return 2;
    }

    PE pe;
    int rc = pe_open(&pe, pe_buf, pe_n);
    if (rc != 0) { fprintf(stderr, "PE 解析失败 (%d)，仅支持 PE32+\n", rc); return 2; }

    uint32_t func_off;
    if (rva_to_off(&pe, func_rva, &func_off) != 0 || func_off + 5 > pe_n) {
        fprintf(stderr, "函数 RVA 0x%X 无法映射到文件偏移\n", func_rva); return 2;
    }

    /* 节表是否还有空间放新条目 */
    uint32_t sec_table_end = pe.sec_off + 40u * (pe.nsec + 1u);
    if (sec_table_end > pe.size_headers || sec_table_end > pe_n) {
        fprintf(stderr, "PE 头无空间新增节区（需要收紧或扩展 headers）\n"); return 2;
    }

    /* 新节区 RVA：接在最后一个节区之后 */
    uint32_t lvs, lva, lrs, lro;
    sec_info(&pe, pe.nsec - 1, &lvs, &lva, &lrs, &lro);
    uint32_t last_span = lvs > lrs ? lvs : lrs;
    uint32_t new_va = align_up(lva + last_span, pe.sect_align);

    /* 第一遍：用占位 RVA 得到 stub 长度（disp32 长度固定，结果与值无关） */
    Buf dummy = build_stub(new_va, new_va, (uint32_t)bc_n, new_va, func_rva);
    uint32_t stub_size = (uint32_t)dummy.n;
    free(dummy.p);

    /* 新节区内部布局 */
    uint32_t bc_off   = align_up(stub_size, 16);
    uint32_t iat_off  = align_up(bc_off + (uint32_t)bc_n, 16);
    uint32_t ilt_off  = iat_off + 16;
    uint32_t hn_off   = ilt_off + 16;
    uint32_t hn_size  = align_up(2u + (uint32_t)strlen(ENTER_SYM) + 1u, 2u);
    uint32_t dll_off  = hn_off + hn_size;
    uint32_t dll_size = align_up((uint32_t)strlen(DLL_NAME) + 1u, 2u);
    uint32_t desc_off = align_up(dll_off + dll_size, 4);
    uint32_t imp_off  = 0, imp_sz = 0;
    uint32_t n_old    = count_import_descs(&pe, pe_buf, (uint32_t)pe_n, &imp_off, &imp_sz);
    uint32_t total    = desc_off + (n_old + 2u) * 20u;  /* 原描述符 + CodeVM + 结束 */

    uint32_t bc_rva   = new_va + bc_off;
    uint32_t iat_rva  = new_va + iat_off;
    uint32_t ilt_rva  = new_va + ilt_off;
    uint32_t hn_rva   = new_va + hn_off;
    uint32_t dll_rva  = new_va + dll_off;
    uint32_t desc_rva = new_va + desc_off;
    uint32_t stub_rva = new_va;

    Buf stub = build_stub(stub_rva, bc_rva, (uint32_t)bc_n, iat_rva, func_rva);
    if (stub.n != stub_size) { fprintf(stderr, "stub 长度不稳定\n"); return 3; }

    /* 组装新节区内容 */
    Buf sd = {0};
    bzeros(&sd, total);
    bset(&sd, 0, stub.p, stub.n);
    bset(&sd, bc_off, bc, bc_n);
    /* IAT 与 ILT 初值：指向 hint/name（加载器把 IAT 覆盖为真实函数地址） */
    uint8_t thunk[8] = {0}; wr32(thunk, hn_rva);
    bset(&sd, iat_off, thunk, 8);
    bset(&sd, ilt_off, thunk, 8);
    /* hint/name：u16 hint=0 + 名字 + \0 */
    bset(&sd, hn_off + 2, ENTER_SYM, strlen(ENTER_SYM));
    bset(&sd, dll_off, DLL_NAME, strlen(DLL_NAME));
    /* 原导入描述符（RVA 仍指原位置，逐字节照搬）+ CodeVM 描述符 + terminator */
    if (n_old) bset(&sd, desc_off, pe_buf + imp_off, n_old * 20u);
    uint8_t desc[20] = {0};
    wr32(desc + 0, ilt_rva);       /* OriginalFirstThunk */
    wr32(desc + 12, dll_rva);      /* Name */
    wr32(desc + 16, iat_rva);      /* FirstThunk */
    bset(&sd, desc_off + n_old * 20u, desc, 20);

    /* 扩展文件，追加新节区原始数据 */
    uint32_t new_raw_off  = align_up((uint32_t)pe_n, pe.file_align);
    uint32_t new_raw_size = align_up(total, pe.file_align);
    size_t out_n = (size_t)new_raw_off + new_raw_size;
    uint8_t *out = (uint8_t *)calloc(1, out_n);
    if (!out) { fprintf(stderr, "内存不足\n"); return 3; }
    memcpy(out, pe_buf, pe_n);
    memcpy(out + new_raw_off, sd.p, total);

    /* ---- 修 PE 头 ---- */
    wr16(out + pe.coff + 2, (uint16_t)(pe.nsec + 1));
    wr32(out + pe.opt_off + 56, align_up(new_va + total, pe.sect_align));
    /* CheckSum 在全部改写完成后重算（见下方 write_file 前），此处不置 0，
       因为计算时该字段必须按 0 参与——统一在重算点清零再写入。 */
    /* Import directory (index 1)：新表 = 原描述符 + CodeVM + terminator。
       IAT directory (index 12) 只在原来为空时才新建——加载器按每个描述符的
       FirstThunk 填充，不依赖 IAT 目录本身；保留原值才不会抹掉目标模块的 IAT。 */
    wr32(out + pe.dd_off + 1 * 8 + 0, desc_rva);
    wr32(out + pe.dd_off + 1 * 8 + 4, (n_old + 2u) * 20u);
    if (rd32(out + pe.dd_off + 12 * 8 + 0) == 0) {
        wr32(out + pe.dd_off + 12 * 8 + 0, iat_rva);
        wr32(out + pe.dd_off + 12 * 8 + 4, 16);
    }

    /* 新节表条目 */
    uint8_t *sh = out + pe.sec_off + 40u * pe.nsec;
    memset(sh, 0, 40);
    memcpy(sh, SEC_NAME, strlen(SEC_NAME));
    wr32(sh + 8, total);              /* VirtualSize */
    wr32(sh + 12, new_va);            /* VirtualAddress */
    wr32(sh + 16, new_raw_size);      /* SizeOfRawData */
    wr32(sh + 20, new_raw_off);       /* PointerToRawData */
    wr32(sh + 36, SCN_CODE);          /* Characteristics */

    /* ---- 目标函数头 5 字节改成 E9 rel32 ---- */
    uint8_t orig[5];
    memcpy(orig, out + func_off, 5);
    int64_t rel = (int64_t)stub_rva - (int64_t)(func_rva + 5);
    if (rel < INT32_MIN || rel > INT32_MAX) {
        fprintf(stderr, "stub 超出 rel32 范围\n"); return 2;
    }
    out[func_off] = 0xE9;
    wr32(out + func_off + 1, (uint32_t)(int32_t)rel);

    /* 所有字段/节表/导入表/函数头都改完，重算 PE 校验和。
       该字段本身按 0 参与运算，故先清零、算完再写回。 */
    wr32(out + pe.checksum_off, 0);
    uint32_t final_ck = pe_checksum(out, out_n);
    wr32(out + pe.checksum_off, final_ck);

    if (write_file(out_path, out, out_n) != 0) {
        fprintf(stderr, "写出失败\n"); return 2;
    }

    /* ---- 3 个 RIP 相对 disp32 的偏移（stub 内） ---- */
    static const uint8_t P_BC[]   = {0x48, 0x8D, 0x0D};  /* lea rcx,[rip+disp] */
    static const uint8_t P_FUNC[] = {0x4C, 0x8D, 0x0D};  /* lea r9,[rip+disp]  */
    static const uint8_t P_IAT[]  = {0xFF, 0x15};         /* call [rip+disp]    */
    int32_t d_bc   = find_disp_off(stub.p, stub.n, P_BC, sizeof(P_BC));
    int32_t d_func = find_disp_off(stub.p, stub.n, P_FUNC, sizeof(P_FUNC));
    int32_t d_iat  = find_disp_off(stub.p, stub.n, P_IAT, sizeof(P_IAT));

    /* ---- 报告（JSON） ---- */
    FILE *rep = (argc >= 6) ? fopen(argv[5], "w") : stdout;
    if (!rep) rep = stdout;
    /* Windows 路径含反斜杠（D:\a\b），直接塞进 JSON 字符串会产生非法转义
       （\C 之类），Python 侧 json.load 会崩。统一转义后再写。 */
    char in_esc[1024], out_esc[1024];
    json_escape(in_esc, sizeof in_esc, in_path);
    json_escape(out_esc, sizeof out_esc, out_path);
    fprintf(rep,
        "{\n"
        "  \"input\": \"%s\",\n  \"output\": \"%s\",\n"
        "  \"func_rva\": \"0x%X\",\n  \"func_file_off\": \"0x%X\",\n"
        "  \"orig_head\": \"%02x%02x%02x%02x%02x\",\n"
        "  \"patched_head\": \"e9%02x%02x%02x%02x\",\n"
        "  \"jmp_rel32\": %lld,\n"
        "  \"section\": \"%s\",\n  \"section_rva\": \"0x%X\",\n"
        "  \"section_vsize\": %u,\n  \"section_raw_off\": \"0x%X\",\n"
        "  \"stub_rva\": \"0x%X\",\n  \"stub_size\": %u,\n"
        "  \"bc_rva\": \"0x%X\",\n  \"bc_bytes\": %zu,\n"
        "  \"iat_rva\": \"0x%X\",\n  \"import_dll\": \"%s\",\n"
        "  \"import_sym\": \"%s\",\n"
        "  \"image_base\": \"0x%llX\",\n"
        "  \"size_of_image\": \"0x%X\",\n"
        "  \"sections\": %u,\n  \"relocations_added\": 0,\n"
        "  \"checksum\": \"0x%08X\",\n"
        "  \"disp_bc_off\": %d,\n  \"disp_func_off\": %d,\n  \"disp_iat_off\": %d\n"
        "}\n",
        in_esc, out_esc, func_rva, func_off,
        orig[0], orig[1], orig[2], orig[3], orig[4],
        out[func_off + 1], out[func_off + 2], out[func_off + 3], out[func_off + 4],
        (long long)rel, SEC_NAME, new_va, total, new_raw_off,
        stub_rva, stub_size, bc_rva, bc_n, iat_rva, DLL_NAME, ENTER_SYM,
        (unsigned long long)pe.image_base,
        rd32(out + pe.opt_off + 56), pe.nsec + 1u,
        final_ck,
        d_bc, d_func, d_iat);
    if (rep != stdout) fclose(rep);

    free(out); free(sd.p); free(stub.p); free(pe_buf); free(bc);
    return 0;
}
