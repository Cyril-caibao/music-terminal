/* CyrilShield 第十批 —— Windows 多线程 VM 上下文自测（真机用，MinGW / zig cc 构建）
 *
 * 与 Linux 侧 native/src/thread_demo.c 对齐的 4 项：
 *   ① TLS 上下文池复用：同线程 2000 次连续 run，池命中不崩、结果一致；
 *   ② 8 线程 × 2000 次两 seed 交替：结果全部正确；
 *   ③ 8 线程并发 VM-exit：宿主函数被真实调用 3200 次，返回值回填正确；
 *   ④ 故障隔离：一线程在 VM-exit 里解引用空指针，被 VEH 安全网捕获为 TRAP，
 *      其余线程结果不受影响、进程不崩。
 *
 * v3.2.4 真机首跑修正（三项都是首跑当场暴露的，记录在案）：
 *   a) v5 起 csvm_run_host 只接受 **编译后的 v5 加密容器**，不再直接吃 x86
 *      机器码 —— 旧版把裸字节塞进 run 端，每项都报「字节码无效」。现先
 *      csvm_compile 两份不同 seed 的容器，线程交替执行（不同 seed ⇒ 不同
 *      分派掩码 + 不同容器密钥流，覆盖「两线程跑不同 seed」竞态面）。
 *   b) host 模式 RSP 直通真实栈：regs_in[X_RSP] 必须给真实栈地址，旧版传 0，
 *      首个 push rbp 写 [0-8] 直接段错误（Linux 侧 thread_demo 的 rin[4] 一直
 *      是 &stack[24]，本 demo 漏抄了这一行）。
 *   c) 目标机器码 `mov rax,rdi / xor rax,rsi` 字面引用 RDI/RSI —— VM 语义以
 *      **机器码里的寄存器**为准，与宿主调用约定无关；参数必须放 in[7]/in[6]，
 *      旧版按 Win64 ABI 放 RCX/RDX 导致结果系统性错位。
 *   d) 旧版 ③/④ 是空转的：blob A 没有 call 指令，VM-exit 永不发生，
 *      worker_exit 只查 rc==0 就算过。现新增含 `call rel32` 的 blob C，
 *      ③ 验证宿主函数被真实调用 3200 次且 RAX=target+1 回填正确，
 *      ④ 的 fault 回调也由 blob C 真实触发。
 *
 * 构建（MinGW-w64 / zig cc）：
 *   zig cc -target x86_64-windows-gnu -O2 -Iinclude src/win_thread_demo.c \
 *       src/codevm.c src/exit_trampoline.c -o out/win_thread_demo.exe
 *   （或 gcc ... -Lout -lCyrilShield.CodeVM 链接 DLL）
 * 运行：out\win_thread_demo.exe   （期望最后一行是 [win-thread] RESULT=PASS）
 */
#include "cs_codevm.h"

#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* 目标程序 A/B：混合算术 + 条件跳转（验证标志位与分支）。
   注意：字节码字面使用 RDI/RSI —— 传参放 regs 编号 7/6。 */
static const unsigned char g_code[] = {
    0x55,                          /* push rbp */
    0x48, 0x89, 0xE5,              /* mov  rbp, rsp */
    0x48, 0x89, 0xF8,              /* mov  rax, rdi */
    0x48, 0x83, 0xC0, 0x07,        /* add  rax, 7 */
    0x48, 0x31, 0xF0,              /* xor  rax, rsi */
    0x48, 0x83, 0xF8, 0x20,        /* cmp  rax, 0x20 */
    0x7C, 0x03,                    /* jl   +3 */
    0x48, 0xD1, 0xE0,              /* shl  rax, 1 */
    0x5D,                          /* pop  rbp */
    0xC3                           /* ret */
};

/* 目标程序 C：mov rax,rdi 后 call rel32 到函数外的宿主地址 T（VM-exit）。
   call 位于偏移 7、长 5 字节，next_off=12；runtime_base=0 时
   target = next_off(12) + rel32。T 取 0x10000000，rel32 = T - 12。 */
#define EXIT_TARGET   0x10000000ULL
#define CALL_NEXT_OFF 12u
static const unsigned char g_code_ext[] = {
    0x55,                          /* push rbp */
    0x48, 0x89, 0xE5,              /* mov  rbp, rsp */
    0x48, 0x89, 0xF8,              /* mov  rax, rdi */
    0xE8, 0x00, 0x00, 0x00, 0x00,  /* call rel32（编译前回填） */
    0x5D,                          /* pop  rbp */
    0xC3                           /* ret */
};

/* 三份编译产物（main 预编译，所有线程共享只读 blob） */
static uint8_t *g_bcA, *g_bcB, *g_bcC;
static size_t   g_bcA_len, g_bcB_len, g_bcC_len;

static long g_ok = 0, g_bad = 0;
static volatile LONG g_calls = 0;

/* VM-exit 宿主函数：返回 target+1 */
static int exit_add1(void *ctx, uint64_t target, uint64_t regs[16]) {
    (void)ctx;
    InterlockedIncrement(&g_calls);
    regs[0] = target + 1;
    return 0;
}

/* 会触发访问违例的宿主函数（用于第 ④ 项） */
static int exit_fault(void *ctx, uint64_t target, uint64_t regs[16]) {
    (void)ctx; (void)target; (void)regs;
    volatile int *p = NULL;
    return *p;                 /* AV：应被 VEH 安全网捕获 */
}

/* 目标代码 A/B 语义：rax=(rdi+7)^rsi; cmp rax,0x20; jl 跳过 shl ——
   「有符号小于 0x20 时跳转（不翻倍），否则左移一位」。 */
static uint64_t want(uint64_t a, uint64_t b) {
    uint64_t r = (a + 7) ^ b;
    if ((int64_t)r >= 0x20) r <<= 1;
    return r;
}

static int run_once(uint64_t a, uint64_t b, uint64_t out[16], char *err, size_t cap) {
    uint64_t stack[64] = {0}, in[16] = {0};
    /* 机器码字面用 RDI/RSI → regs 编号 7/6（不是 Win64 ABI 的 1/2；
       VM 语义跟机器码走，与宿主调用约定无关） */
    in[7] = a; in[6] = b;
    /* host 模式 RSP 直通真实栈：必须给真实栈地址，否则首个 push 写 [0-8] 段错误 */
    in[4] = (uint64_t)(uintptr_t)&stack[24];
    return csvm_run_host(g_bcA, g_bcA_len, in, out, 0, NULL, NULL, err, cap);
}

/* 两 seed 交替：奇偶轮次分别跑 A/B 两个编译产物（不同 seed ⇒ 不同
   分派掩码 + 不同容器密钥流），覆盖「两线程跑不同 seed 字节码」的竞态面 */
static DWORD WINAPI worker(LPVOID p) {
    long *slot = (long *)p;
    uint64_t stack[64] = {0}, out[16], in[16];
    const uint64_t rsp = (uint64_t)(uintptr_t)&stack[24];
    char err[256];
    for (int i = 0; i < 2000; ++i) {
        uint64_t a = (uint64_t)(i + *slot), b = (uint64_t)(i * 2 + 1);
        const uint8_t *bc = (i & 1) ? g_bcB : g_bcA;
        size_t bc_len = (i & 1) ? g_bcB_len : g_bcA_len;
        memset(err, 0, sizeof(err));
        memset(in, 0, sizeof(in));
        in[7] = a; in[6] = b;
        in[4] = rsp;
        if (csvm_run_host(bc, bc_len, in, out, 0, NULL, NULL, err, sizeof(err)) != 0
            || out[0] != want(a, b)) {
            InterlockedIncrement(&g_bad);
            return 0;
        }
    }
    InterlockedIncrement(&g_ok);
    return 0;
}

static DWORD WINAPI worker_exit(LPVOID p) {
    (void)p;
    uint64_t stack[64] = {0}, out[16], in[16];
    char err[256];
    for (int i = 0; i < 400; ++i) {
        memset(err, 0, sizeof(err));
        memset(in, 0, sizeof(in));
        in[7] = (uint64_t)i;
        in[4] = (uint64_t)(uintptr_t)&stack[24];
        if (csvm_run_host_ex(g_bcC, g_bcC_len, in, out, 0,
                             NULL, NULL, exit_add1, NULL,
                             err, sizeof(err)) != 0
            || out[0] != EXIT_TARGET + 1) {
            InterlockedIncrement(&g_bad);
            return 0;
        }
    }
    InterlockedIncrement(&g_ok);
    return 0;
}

static DWORD WINAPI worker_fault(LPVOID p) {
    (void)p;
    uint64_t stack[64] = {0}, out[16], in[16];
    char err[256];
    memset(err, 0, sizeof(err));
    in[4] = (uint64_t)(uintptr_t)&stack[24];
    int rc = csvm_run_host_ex(g_bcC, g_bcC_len, in, out, 0,
                              NULL, NULL, exit_fault, NULL,
                              err, sizeof(err));
    /* 期望：捕获为 TRAP，返回非 0 而不是整个进程崩掉 */
    if (rc != 0) InterlockedIncrement(&g_ok); else InterlockedIncrement(&g_bad);
    return 0;
}

int main(void) {
    char err[256];
    uint64_t out[16];
    HANDLE th[9];
    long slot[8];
    int fails = 0;

    setvbuf(stdout, NULL, _IONBF, 0);   /* 真机调试：崩溃时也不丢输出 */
    printf("== CyrilShield Windows 多线程上下文自测 ==\n");

    /* ⓪ 预编译三份 v5 容器（A/B 同码不同 seed，C 含 call rel32 触发 VM-exit） */
    {
        char cerr[512] = {0};
        unsigned char ext[sizeof(g_code_ext)];
        memcpy(ext, g_code_ext, sizeof(ext));
        /* 回填 rel32 = T - next_off（小端 int32） */
        int32_t rel = (int32_t)(EXIT_TARGET - CALL_NEXT_OFF);
        memcpy(&ext[8], &rel, 4);
        if (csvm_compile(g_code, sizeof(g_code), 0xC0FFEEA1ULL,
                         &g_bcA, &g_bcA_len, cerr, sizeof(cerr)) != 0) {
            printf("[0] 编译容器 A 失败：%s\n", cerr);
            return 1;
        }
        if (csvm_compile(g_code, sizeof(g_code), 0xB16B00B5ULL,
                         &g_bcB, &g_bcB_len, cerr, sizeof(cerr)) != 0) {
            printf("[0] 编译容器 B 失败：%s\n", cerr);
            return 1;
        }
        if (csvm_compile(ext, sizeof(ext), 0x5EEDC0DEULL,
                         &g_bcC, &g_bcC_len, cerr, sizeof(cerr)) != 0) {
            printf("[0] 编译容器 C 失败：%s\n", cerr);
            return 1;
        }
        printf("[0] 预编译容器：A=%zu B=%zu C=%zu 字节（C 含 call rel32 → 0x%llX）\n",
               g_bcA_len, g_bcB_len, g_bcC_len, (unsigned long long)EXIT_TARGET);
    }

    /* ① 单线程连续 2000 次（池复用路径） */
    g_ok = g_bad = 0;
    for (int i = 0; i < 2000; ++i) {
        uint64_t a = (uint64_t)i, b = (uint64_t)(i + 3);
        memset(err, 0, sizeof(err));
        if (run_once(a, b, out, err, sizeof(err)) != 0 || out[0] != want(a, b)) {
            printf("    [1] 失败 @i=%d：rc 错误 [%s] out0=%llu want=%llu\n",
                   i, err, (unsigned long long)out[0], (unsigned long long)want(a, b));
            g_bad++;
            break;
        }
        g_ok++;
    }
    printf("[1] 单线程池复用 2000 次：%ld 正确 / %ld 错\n", g_ok, g_bad);
    fails += (g_bad != 0);

    /* ② 8 线程 × 2000 次两 seed 交替 */
    g_ok = g_bad = 0;
    for (int i = 0; i < 8; ++i) { slot[i] = i; th[i] = CreateThread(NULL, 0, worker, &slot[i], 0, NULL); }
    WaitForMultipleObjects(8, th, TRUE, INFINITE);
    for (int i = 0; i < 8; ++i) CloseHandle(th[i]);
    printf("[2] 8 线程 × 2000 次：%ld 线程全过 / %ld 失败\n", g_ok, g_bad);
    fails += (g_bad != 0 || g_ok != 8);

    /* ③ 8 线程并发 VM-exit（blob C 的 call rel32 真实调用宿主函数） */
    g_ok = g_bad = 0; g_calls = 0;
    for (int i = 0; i < 8; ++i) th[i] = CreateThread(NULL, 0, worker_exit, NULL, 0, NULL);
    WaitForMultipleObjects(8, th, TRUE, INFINITE);
    for (int i = 0; i < 8; ++i) CloseHandle(th[i]);
    printf("[3] 8 线程并发 VM-exit 3200 次：%ld 线程全过 / %ld 失败 / 实际宿主调用 %ld\n",
           g_ok, g_bad, (long)g_calls);
    fails += (g_bad != 0 || g_ok != 8 || g_calls != 8 * 400);

    /* ④ 故障隔离：一个线程在 VM-exit 里 AV，其余线程照常 */
    g_ok = g_bad = 0;
    for (int i = 0; i < 8; ++i) {
        slot[i] = i;
        th[i] = CreateThread(NULL, 0, (i == 0) ? worker_fault : worker, &slot[i], 0, NULL);
    }
    WaitForMultipleObjects(8, th, TRUE, INFINITE);
    for (int i = 0; i < 8; ++i) CloseHandle(th[i]);
    printf("[4] 故障隔离：%ld 项通过 / %ld 项失败（期望 8 项，含 1 个被安全网捕获）\n",
           g_ok, g_bad);
    fails += (g_bad != 0);

    csvm_free(g_bcA); csvm_free(g_bcB); csvm_free(g_bcC);
    printf("----------------------------------------------------------------------------------\n");
    printf("[win-thread] RESULT=%s\n", fails ? "FAIL" : "PASS");
    return fails ? 1 : 0;
}
