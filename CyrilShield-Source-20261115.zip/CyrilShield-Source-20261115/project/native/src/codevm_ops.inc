/* codevm_ops.inc —— exec_step 的操作码语义体（由 tools 脚本从 codevm.c 抽出）。
 * 本文件被 codevm.c #include 一次；包含前须定义：
 *   CS_CASE(op)  computed-goto 模式: L_##op:  /  switch 模式: case op:
 *   CS_DEFAULT   computed-goto 模式: L_default: / switch 模式: default:
 * 注意：外层 case 体的 break 在 CG 模式下借 do{...}while(0) 跳出，
 *       内层 switch 的 break 仍归内层；return 语义两种模式一致。
 * 修改指令语义请改本文件，不要回去改 codevm.c 的旧 switch。 */
            CS_CASE(BC_JUNK)
            CS_CASE(IR_NOP)
                break;
            CS_CASE(IR_HALT)
                *halt_out = 1; return;
            CS_CASE(IR_TRAP)
                trap = 1; why = "字节码 @%u 命中 TRAP（不支持的语义）"; *halt_out = 1; return;
            CS_CASE(IR_MOV)
                bb = RDB(); WRA(bb); break;
            CS_CASE(IR_MOVZX)
                {
                uint8_t sw = b->src_width ? b->src_width : 8;
                uint64_t raw = read_oper(v, b, b->b_kind, b->b_reg, sw, mask, &trap, &why);
                WRA(trim(raw, sw)); break;
            }
            CS_CASE(IR_MOVSX)
                {
                /* 源按 src_width 精确读（跳转表 movsxd 只读 4 字节表项，
                   否则会误把相邻表项高 32 位读进来导致目标地址跑飞）；
                   目标按 b->width 写（通常 64）。 */
                uint8_t sw = b->src_width ? b->src_width : 8;
                uint64_t raw = read_oper(v, b, b->b_kind, b->b_reg, sw, mask, &trap, &why);
                int64_t sv;
                if (sw < 64) { uint64_t sg = 1ULL << (sw - 1); sv = (int64_t)((raw ^ sg) - sg); }
                else sv = (int64_t)raw;
                WRA((uint64_t)sv); break;
            }
            CS_CASE(IR_LEA)
                {
                /* LEA：只算地址，不读内存 */
                uint64_t addr;
                if (!mem_addr(v, b, b->b_reg, mask, 0, &addr)) {
                    trap = 1; why = "LEA 地址越界"; break;
                }
                write_oper(v, b, OK_REG, b->a_reg, w, addr, mask, &trap, &why);
                break;
            }
            CS_CASE(IR_ADD)
            CS_CASE(IR_SUB)
            CS_CASE(IR_XOR)
            CS_CASE(IR_AND)
            CS_CASE(IR_OR)
            CS_CASE(IR_CMP)
            CS_CASE(IR_TEST)
                {
                a = RDA(); bb = RDB();
                int is_sub = (lop == IR_SUB || lop == IR_CMP);
                int is_logic = (lop == IR_XOR || lop == IR_AND ||
                                lop == IR_OR || lop == IR_TEST);
                switch (lop) {
                    case IR_ADD: res = a + bb; break;
                    case IR_SUB: case IR_CMP: res = a - bb; break;
                    case IR_XOR: res = a ^ bb; break;
                    case IR_TEST: res = a & bb; break;   /* TEST 是 AND，不是 XOR */
                    case IR_AND: res = a & bb; break;
                    default: res = a | bb; break;
                }
                res = trim(res, w);
                v->flags = is_logic ? logic_flags(res, w)
                                    : calc_flags(res, a, bb, w, is_sub, 0, v->flags);
                if (lop != IR_CMP && lop != IR_TEST) WRA(res);
                break;
            }
            CS_CASE(IR_INC)
            CS_CASE(IR_DEC)
                {
                a = RDA();
                res = trim((lop == IR_INC) ? a + 1 : a - 1, w);
                v->flags = calc_flags(res, a, 1, w, lop == IR_DEC, 1, v->flags);
                WRA(res); break;
            }
            CS_CASE(IR_NEG)
                {
                a = RDA(); res = trim((~(a)) + 1, w);
                v->flags = calc_flags(res, 0, a, w, 1, 0, v->flags);
                WRA(res); break;
            }
            CS_CASE(IR_NOT)
                a = RDA(); WRA(trim(~a, w)); break;
            CS_CASE(IR_IMUL)
                {
                a = RDA(); bb = RDB();
                res = trim(a * bb, w);
                WRA(res); break;
            }
            CS_CASE(IR_IMUL3)
                {
                bb = RDB();
                int64_t imm = (int64_t)((uint64_t)b->imm ^ mask);
                res = trim(bb * (uint64_t)imm, w);
                write_oper(v, b, OK_REG, b->a_reg, w, res, mask, &trap, &why);
                break;
            }
            CS_CASE(IR_MUL)
            CS_CASE(IR_IMUL1)
            CS_CASE(IR_DIV)
            CS_CASE(IR_IDIV)
                {
                /* F6/F7 /4~/7：隐式 RDX:RAX（8 位时 AX）双操作数 */
                uint64_t src = RDB();
                uint8_t mw = b->width ? b->width : 64;
                uint8_t s_ax = h->reg_map[X_RAX], s_dx = h->reg_map[X_RDX];
                uint64_t mm = wmask(mw);
                if (mw == 8) {
                    uint8_t al = (uint8_t)v->r[s_ax], rm8 = (uint8_t)src;
                    uint16_t ax = (uint16_t)v->r[s_ax];
                    if (lop == IR_MUL || lop == IR_IMUL1) {
                        uint16_t p = (lop == IR_MUL)
                            ? (uint16_t)((uint16_t)al * rm8)
                            : (uint16_t)((int16_t)((int8_t)al * (int8_t)rm8));
                        v->r[s_ax] = (v->r[s_ax] & ~(uint64_t)0xFFFF) | p;
                        v->flags = (p >> 8) ? (F_CF | F_OF) : 0;
                    } else {
                        if (!rm8) { trap = 1; why = "DIV 除零"; break; }
                        uint8_t q, r;
                        if (lop == IR_DIV) { q = (uint8_t)(ax / rm8); r = (uint8_t)(ax % rm8); }
                        else {
                            int16_t sa = (int16_t)ax; int8_t sd = (int8_t)rm8;
                            q = (uint8_t)(sa / sd); r = (uint8_t)(sa % sd);
                        }
                        v->r[s_ax] = (v->r[s_ax] & ~(uint64_t)0xFFFF)
                                   | ((uint16_t)r << 8) | q;
                    }
                } else {
                    uint64_t av = v->r[s_ax] & mm, dv = v->r[s_dx] & mm;
                    uint64_t sv = src & mm;
                    if (lop == IR_MUL || lop == IR_IMUL1) {
                        __uint128_t p;
                        if (lop == IR_MUL) p = (__uint128_t)av * sv;
                        else {
                            __int128_t sa = (mw == 64)
                                ? (__int128_t)(int64_t)av
                                : ((__int128_t)(int64_t)(av << (64 - mw)) >> (64 - mw));
                            __int128_t sb = (mw == 64)
                                ? (__int128_t)(int64_t)sv
                                : ((__int128_t)(int64_t)(sv << (64 - mw)) >> (64 - mw));
                            p = (__uint128_t)(sa * sb);
                        }
                        v->r[s_ax] = (uint64_t)p & mm;
                        v->r[s_dx] = (uint64_t)(p >> mw) & mm;
                        uint64_t hi = v->r[s_dx] & mm;
                        int ovf = (lop == IR_MUL)
                            ? (hi != 0)
                            : (hi != (((v->r[s_ax] >> (mw - 1)) & 1) ? mm : 0));
                        v->flags = ovf ? (F_CF | F_OF) : 0;
                    } else {
                        if (!sv) { trap = 1; why = "DIV 除零"; break; }
                        __uint128_t num = ((__uint128_t)dv << mw) | av;
                        __uint128_t q, r;
                        if (lop == IR_DIV) {
                            q = num / sv; r = num % sv;
                            if (q > mm) { trap = 1; why = "DIV 商溢出"; break; }
                        } else {
                            __int128_t sn, sd, sq, sr;
                            if (mw == 64) {
                                sn = (__int128_t)num;
                                sd = (__int128_t)(int64_t)sv;
                            } else {
                                __int128_t hi2 = (int64_t)(dv << (64 - mw)) >> (64 - mw);
                                sn = (hi2 << mw) | (__int128_t)av;
                                sd = (int64_t)(sv << (64 - mw)) >> (64 - mw);
                            }
                            if (!sd) { trap = 1; why = "IDIV 除零"; break; }
                            sq = sn / sd; sr = sn % sd;
                            __int128_t lim = (__int128_t)(mm >> 1);
                            if (sq > lim || sq < -lim - 1) {
                                trap = 1; why = "IDIV 商溢出"; break;
                            }
                            q = (__uint128_t)sq; r = (__uint128_t)sr;
                        }
                        v->r[s_ax] = (uint64_t)q & mm;
                        v->r[s_dx] = (uint64_t)r & mm;
                    }
                }
                break;
            }
            CS_CASE(IR_CQO)
                {
                uint8_t cw = b->width ? b->width : 64;
                uint64_t cm = wmask(cw);
                uint64_t ax = v->r[h->reg_map[X_RAX]] & cm;
                v->r[h->reg_map[X_RDX]] = ((ax >> (cw - 1)) & 1) ? cm : 0;
                break;
            }
            CS_CASE(IR_SHL)
            CS_CASE(IR_SHR)
            CS_CASE(IR_SAR)
            CS_CASE(IR_ROL)
            CS_CASE(IR_ROR)
                {
                a = RDA();
                uint64_t cnt = (b->b_kind == OK_REG)
                    ? (v->r[b->b_reg] & 0x3F) : (((uint64_t)b->imm ^ mask) & 0x3F);
                cnt &= (w >= 64) ? 63 : 31;
                if (lop == IR_SHL) res = trim(a << cnt, w);
                else if (lop == IR_SHR) res = trim(a >> cnt, w);
                else if (lop == IR_SAR) {
                    int64_t sa = (int64_t)a;
                    if (w < 64) { uint64_t s = 1ULL << (w - 1); sa = (int64_t)((sa ^ (int64_t)s) - (int64_t)s); }
                    res = trim((uint64_t)(sa >> cnt), w);
                } else if (lop == IR_ROL) {
                    uint64_t m = wmask(w); a &= m;
                    res = trim(cnt ? ((a << cnt) | (a >> (w - cnt))) : a, w);
                } else {
                    uint64_t m = wmask(w); a &= m;
                    res = trim(cnt ? ((a >> cnt) | (a << (w - cnt))) : a, w);
                }
                WRA(res);
                v->flags = logic_flags(res, w);
                break;
            }
            CS_CASE(IR_PUSH)
                a = RDA(); PUSHV(a); break;
            CS_CASE(IR_POP)
                { uint64_t t; POPV(t); WRA(t); break; }
            CS_CASE(IR_JMP)
                next = (uint32_t)((uint64_t)b->imm ^ mask); break;
            CS_CASE(IR_JCC)
                if (eval_cc(b->cc & 0xF, v->flags))
                    next = (uint32_t)((uint64_t)b->imm ^ mask);
                break;
            CS_CASE(IR_CALL)
                {
                if (host_mode) {
                    if (v->csp >= 256) { trap = 1; why = "VM 调用栈溢出"; break; }
                    v->callstack[v->csp++] = next;
                } else {
                    PUSHV((uint64_t)next);
                }
                next = (uint32_t)((uint64_t)b->imm ^ mask);
                break;
            }
            CS_CASE(IR_RET)
                {
                if (host_mode) {
                    if (v->csp == 0) { *halt_out = 1; return; }
                    next = v->callstack[--v->csp];
                } else {
                    uint64_t t; POPV(t);
                    if (t == RET_SENTINEL) { *halt_out = 1; return; }
                    next = (uint32_t)t;
                }
                break;
            }
            CS_CASE(IR_CALLEXT)
                {
                /* L2 VM-exit：把当前 16 个 GPR（含真实 RSP）交给宿主，
                   由平台桩完成 原生调用 + 上下文切换，返回后回写继续 VM。 */
                if (!host_mode) { trap = 1; why = "VM-exit 仅支持宿主真实内存模式"; break; }
                uint64_t target = 0;
                switch (b->exit_kind) {
                    case 1: {   /* 直接 rel32 */
                        uint64_t toff = (uint64_t)b->imm ^ mask;
                        target = v->runtime_base + (uint64_t)(int64_t)(int32_t)(uint32_t)toff;
                        break;
                    }
                    case 2: {   /* 间接 [rip+disp32]：从 IAT 槽读函数指针 */
                        int64_t d = (int64_t)((uint64_t)b->disp ^ mask);
                        uint64_t slot = v->runtime_base + b->next_off + (uint64_t)d;
                        target = load_mem(v, slot, 64);
                        break;
                    }
                    case 3: {   /* 间接 [base+idx*scale+disp] */
                        uint64_t addr;
                        if (!mem_addr(v, b, b->a_reg, mask, 1, &addr)) {
                            trap = 1; why = "VM-exit 间接地址越界"; break;
                        }
                        target = load_mem(v, addr, 64);
                        break;
                    }
                    case 4:     /* 间接 call reg */
                        target = v->r[b->a_reg]; break;
                    default:    trap = 1; why = "未知 VM-exit 目标类型"; break;
                }
                if (trap) break;
                if (!target) { trap = 1; why = "VM-exit 目标为空（IAT 槽未解析？）"; break; }
                /* 统一走 vm_do_exit：含 NEED_FPU 时自动切 GPR+XMM 通道，
                   FLAGS 在 call 后未定义，保守保持原值（见 CODE-VM.md L2）。 */
                vm_do_exit(v, h, target, &trap, &why);
                break;
            }
            CS_CASE(IR_JMPI)
                {
                /* FF/4 间接跳转。目标在函数字节范围内 -> 回填 bc 索引在 VM 内
                   闭环（switch 跳转表 / 间接分支）；在函数外 -> 尾调用 / 虚函数 /
                   函数指针，VM-exit 到原生并以其 RAX 作为整个 VM 的返回值终止。 */
                if (!host_mode) { trap = 1; why = "间接跳转仅支持宿主真实内存模式"; break; }
                uint64_t target = 0;
                switch (b->exit_kind) {
                    case 2: {   /* [rip+disp32] 读指针 */
                        int64_t d = (int64_t)((uint64_t)b->disp ^ mask);
                        uint64_t slot = v->runtime_base + b->next_off + (uint64_t)d;
                        target = load_mem(v, slot, 64); break;
                    }
                    case 3: {   /* [base+idx*scale+disp] */
                        uint64_t addr;
                        if (!mem_addr(v, b, b->a_reg, mask, 1, &addr)) {
                            trap = 1; why = "间接跳转地址越界"; break;
                        }
                        target = load_mem(v, addr, 64); break;
                    }
                    case 4: target = v->r[b->a_reg]; break;  /* jmp reg */
                    default: trap = 1; why = "未知间接跳转类型"; break;
                }
                if (trap) break;
                if (!target) { trap = 1; why = "间接跳转目标为空"; break; }
                uint32_t clen = h->reserved;
                if (v->runtime_base && clen && target >= v->runtime_base &&
                    target - v->runtime_base < clen) {
                    uint32_t byteoff = (uint32_t)(target - v->runtime_base);
                    int32_t hit = -1;
                    for (uint32_t k = 0; k < n_insn; ++k) {
                        if (oc->src_off[k] == byteoff) { hit = (int32_t)k; break; }
                    }
                    if (hit < 0) { trap = 1; why = "函数内间接跳转未命中指令边界"; break; }
                    next = (uint32_t)hit;
                } else {
                    vm_do_exit(v, h, target, &trap, &why);
                    if (trap) break;
                    *halt_out = 1; return;   /* 终止 VM，RAX 即被虚拟化函数的返回值 */
                }
                break;
            }
            CS_CASE(IR_TAILEXIT)
                {
                /* 直接 jmp rel32 到 CFG 闭包外（gcc -O2 sibling call / 尾递归优化）。
                   以 VM-exit tail 语义调用原生目标，RAX 作为整个 VM 返回值终止。 */
                if (!host_mode) { trap = 1; why = "直接尾调用仅支持宿主真实内存模式"; break; }
                uint64_t toff = (uint64_t)b->imm ^ mask;
                uint64_t target = v->runtime_base + (uint64_t)(int64_t)(int32_t)(uint32_t)toff;
                if (!target) { trap = 1; why = "直接尾调用目标为空"; break; }
                vm_do_exit(v, h, target, &trap, &why);
                if (trap) break;
                *halt_out = 1; return;
            }
            CS_CASE(IR_SETDF)
                /* cld / std：只影响 REP 字符串指令的方向，独立占一个标志位。 */
                if ((uint64_t)b->imm ^ mask) v->flags |= F_DF;
                else                        v->flags &= ~F_DF;
                break;
            CS_CASE(IR_REP)
                {
                /* 字符串指令子集：MOVS/STOS/CMPS/SCAS。隐式 RSI/RDI/RCX/RAX，
                   F_DF 决定 ±，b->width 决定每元素字节数，REP_LOOP 时循环 RCX 次。
                   宿主真实内存模式下通过 memfn 读写真实内存。 */
                if (!host_mode) { trap = 1; why = "REP 字符串指令仅支持宿主真实内存模式"; break; }
                uint8_t kind = (uint8_t)(b->rep_kind & 0x7Fu);
                int     loop = (b->rep_kind & REP_LOOP) != 0;
                uint8_t rw   = w;
                uint8_t step = (rw >= 64) ? 8 : (rw == 32 ? 4 : (rw == 16 ? 2 : 1));
                int     dir  = (v->flags & F_DF) ? -1 : 1;
                uint8_t s_si = h->reg_map[X_RSI], s_di = h->reg_map[X_RDI];
                uint8_t s_cx = h->reg_map[X_RCX], s_ax = h->reg_map[X_RAX];
                uint64_t count = loop ? v->r[s_cx] : 1;
                if (count > 1000000ULL) { trap = 1; why = "REP 循环次数异常"; break; }
                uint64_t last_flags = v->flags;
                for (uint64_t it = 0; it < count; ++it) {
                    uint64_t si = v->r[s_si], di = v->r[s_di];
                    if (kind == REP_MOVS) {
                        store_mem(v, di, load_mem(v, si, rw), rw);
                    } else if (kind == REP_STOS) {
                        store_mem(v, di, v->r[s_ax], rw);
                    } else if (kind == REP_CMPS || kind == REP_SCAS) {
                        uint64_t x = (kind == REP_CMPS) ? load_mem(v, si, rw) : v->r[s_ax];
                        uint64_t y = (kind == REP_CMPS) ? load_mem(v, di, rw) : load_mem(v, di, rw);
                        last_flags = calc_flags(trim(x - y, rw), x, y, rw, 1, 0, last_flags);
                    } else { trap = 1; why = "未知字符串指令子类型"; break; }
                    v->r[s_si] = (uint64_t)((int64_t)si + dir * (int64_t)step);
                    v->r[s_di] = (uint64_t)((int64_t)di + dir * (int64_t)step);
                    if (loop) v->r[s_cx] -= 1;
                    if (b->cc == REPCC_REPE  && !(last_flags & F_ZF)) break;
                    if (b->cc == REPCC_REPNE &&  (last_flags & F_ZF)) break;
                }
                if (!trap) v->flags = (v->flags & F_DF) | (last_flags & ~(uint64_t)F_DF);
                break;
            }
            CS_CASE(IR_FSSE)
                {
                uint8_t fop = b->exit_kind;
                uint8_t wb = b->width ? b->width : 64;   /* 标量宽度 32/64/128 */
                uint8_t iw = b->src_width ? b->src_width : 32; /* 整数宽度 32/64 */
                int b_mem = (b->b_kind == OK_MEM || b->b_kind == OK_RIPREL);
                uint64_t alo = 0, ahi = 0, blo = 0, bhi = 0;
                sse_read(v, b, b->b_kind, b->b_reg,
                         (fop == FOP_I2F || fop == FOP_MOVG2X) ? iw : wb,
                         mask, &blo, &bhi, &trap, &why);
                if (trap) break;
                sse_read(v, b, b->a_kind, b->a_reg, wb, mask,
                         &alo, &ahi, &trap, &why);
                if (trap) break;
                uint64_t rlo = alo, rhi = ahi;
                int write_back = 1;
                switch (fop) {
                    case FOP_MOV: case FOP_MOVG2X:
                        if (wb >= 128) { rlo = blo; rhi = bhi; }
                        else {
                            uint64_t lm = (wb >= 64) ? ~(uint64_t)0 : 0xFFFFFFFFULL;
                            if (b_mem) { rlo = blo & lm; rhi = 0; }
                            else       { rlo = (alo & ~lm) | (blo & lm); }
                        }
                        break;
                    case FOP_MOVX2G:
                        rlo = (iw >= 64) ? blo : (uint32_t)blo; rhi = 0; break;
                    case FOP_ADD: case FOP_SUB: case FOP_MUL: case FOP_DIV:
                    case FOP_MIN: case FOP_MAX:
                        if (wb == 32) {
                            float x = as_float((uint32_t)alo), y = as_float((uint32_t)blo), z;
                            switch (fop) {
                                case FOP_ADD: z = x + y; break; case FOP_SUB: z = x - y; break;
                                case FOP_MUL: z = x * y; break; case FOP_DIV: z = x / y; break;
                                case FOP_MIN: z = x < y ? x : y; break;
                                default:      z = x > y ? x : y; break;
                            }
                            rlo = (alo & ~0xFFFFFFFFULL) | f_bits(z);
                        } else {
                            double x = as_double(alo), y = as_double(blo), z;
                            switch (fop) {
                                case FOP_ADD: z = x + y; break; case FOP_SUB: z = x - y; break;
                                case FOP_MUL: z = x * y; break; case FOP_DIV: z = x / y; break;
                                case FOP_MIN: z = x < y ? x : y; break;
                                default:      z = x > y ? x : y; break;
                            }
                            rlo = d_bits(z);
                        }
                        rhi = ahi; break;
                    case FOP_SQRT:
                        if (wb == 32)
                            rlo = (alo & ~0xFFFFFFFFULL) | hw_sqrt_bits(blo, 1);
                        else
                            rlo = hw_sqrt_bits(blo, 0);
                        rhi = ahi; break;
                    case FOP_AND: rlo = alo & blo; rhi = ahi & bhi; break;
                    case FOP_XOR: rlo = alo ^ blo; rhi = ahi ^ bhi; break;
                    case FOP_I2F: {
                        int64_t iv = (iw >= 64) ? (int64_t)blo
                                                : (int64_t)(int32_t)(uint32_t)blo;
                        if (wb == 32) rlo = (alo & ~0xFFFFFFFFULL) | f_bits((float)iv);
                        else          rlo = d_bits((double)iv);
                        rhi = ahi; break;
                    }
                    case FOP_F2I: {
                        double d = (wb == 32) ? (double)as_float((uint32_t)blo)
                                              : as_double(blo);
                        int64_t iv;
                        if (d != d || d >= 9223372036854775808.0 ||
                            d < -9223372036854775808.0)
                            iv = (iw >= 64) ? (-9223372036854775807LL - 1)
                                            : (int64_t)INT32_MIN;
                        else iv = (int64_t)d;
                        rlo = (iw >= 64) ? (uint64_t)iv : (uint32_t)iv;
                        rhi = 0; break;
                    }
                    case FOP_CVTSS2SD:
                        rlo = d_bits((double)as_float((uint32_t)blo)); rhi = ahi; break;
                    case FOP_CVTSD2SS:
                        rlo = (alo & ~0xFFFFFFFFULL) |
                              f_bits((float)as_double(blo)); rhi = ahi; break;
                    case FOP_CMP: {
                        double x = (wb == 32) ? (double)as_float((uint32_t)alo) : as_double(alo);
                        double y = (wb == 32) ? (double)as_float((uint32_t)blo) : as_double(blo);
                        uint64_t f = 0;
                        if (x != x || y != y)     f = F_ZF | F_PF | F_CF;  /* unordered */
                        else if (x > y)           f = 0;
                        else if (x < y)           f = F_CF;
                        else                      f = F_ZF;               /* equal */
                        v->flags = f; write_back = 0; break;
                    }
                    /* ---- v9 打包整数 SIMD ---- */
                    case FOP_PINT: {
                        uint8_t pop = PINT_OP(b->src_width), plw = PINT_LW(b->src_width);
                        uint8_t lanesz = (plw >= 3) ? 8 : (plw == 2 ? 4 : (plw == 1 ? 2 : 1));
                        uint8_t A[16], B[16], R[16];
                        memcpy(A, &alo, 8); memcpy(A + 8, &ahi, 8);
                        memcpy(B, &blo, 8); memcpy(B + 8, &bhi, 8);
                        memset(R, 0, sizeof(R));
                        for (int i = 0; i < 16; i += lanesz) {
                            uint64_t av = 0, bv = 0;
                            for (int j = 0; j < lanesz; ++j) {
                                av |= (uint64_t)A[i + j] << (j * 8);
                                bv |= (uint64_t)B[i + j] << (j * 8);
                            }
                            uint64_t rv = pint_lane(pop, av, bv, plw);
                            for (int j = 0; j < lanesz; ++j)
                                R[i + j] = (uint8_t)(rv >> (j * 8));
                        }
                        memcpy(&rlo, R, 8); memcpy(&rhi, R + 8, 8);
                        break;
                    }
                    case FOP_PSHUFD: {
                        uint8_t imm = (uint8_t)((uint64_t)b->imm ^ mask);
                        uint32_t s[4];
                        s[0] = (uint32_t)(blo & 0xFFFFFFFFu);
                        s[1] = (uint32_t)(blo >> 32);
                        s[2] = (uint32_t)(bhi & 0xFFFFFFFFu);
                        s[3] = (uint32_t)(bhi >> 32);
                        uint32_t d[4] = {0};
                        for (int i = 0; i < 4; ++i)
                            d[i] = s[(imm >> (i * 2)) & 3];
                        /* 结果 128 位 = d[0..3] 四个 dword（rlo 低 64 + rhi 低 64） */
                        rlo = (uint64_t)d[0] | ((uint64_t)d[1] << 32);
                        rhi = (uint64_t)d[2] | ((uint64_t)d[3] << 32);
                        break;
                    }
                    case FOP_PACKSSDW: {
                        /* 两源各 2 个 dword（a 在 alo 低/高 32，b 在 blo 低/高 32），
                           各饱和打包成 1 个 word，依次填入结果低 64 位 4 个 word。 */
                        int32_t s[4];
                        s[0] = (int32_t)(alo & 0xFFFFFFFFu);
                        s[1] = (int32_t)(alo >> 32);
                        s[2] = (int32_t)(blo & 0xFFFFFFFFu);
                        s[3] = (int32_t)(blo >> 32);
                        int16_t w[4] = {0};
                        for (int i = 0; i < 4; ++i) {
                            int32_t v = s[i];
                            if (v > 32767) v = 32767; else if (v < -32768) v = -32768;
                            w[i] = (int16_t)v;
                        }
                        memcpy(&rlo, w, 8); rhi = 0;
                        break;
                    }
                    default: trap = 1; why = "未知 SSE 子操作码"; break;
                }
                if (trap) break;
                if (write_back) {
                    uint8_t out_w = (fop == FOP_F2I || fop == FOP_MOVX2G) ? iw : wb;
                    sse_write(v, b, b->a_kind, b->a_reg, out_w, mask,
                              rlo, rhi, &trap, &why);
                }
                break;
            }
            CS_CASE(IR_CMOV)
                if (eval_cc(b->cc & 0xF, v->flags)) { bb = RDB(); WRA(bb); }
                break;
            CS_CASE(IR_SETCC)
                WRA(eval_cc(b->cc & 0xF, v->flags) ? 1 : 0);
                break;
            CS_CASE(IR_ATOMIC)
                {
                uint8_t aw = b->width ? b->width : 64;
                if (aw != 32 && aw != 64) {
                    trap = 1; why = "原子指令仅支持 32/64 位操作数（8/16 位在子集外）";
                    break;
                }
                uint64_t addr = 0;
                int have_addr = 0;
                if (b->a_kind == OK_RIPREL) {
                    if (v->host_mode && v->runtime_base) {
                        addr = v->runtime_base + b->next_off
                             + (int64_t)((uint64_t)b->disp ^ mask);
                        have_addr = 1;
                    }
                } else if (b->a_kind == OK_MEM && b->a_reg != 255) {
                    addr = v->r[b->a_reg]
                         + (int64_t)((uint64_t)b->disp ^ mask);
                    have_addr = 1;
                }
                if (!have_addr) {
                    trap = 1; why = "原子指令目的地址无效（需基址或 RIP 相对）"; break;
                }
                unsigned al = (aw == 64) ? 8u : 4u;
                if (addr & (al - 1)) {
                    trap = 1; why = "原子指令目的地址未按操作数宽度对齐"; break;
                }
                uint8_t *ap;
                if (v->host_mode) {
                    /* 真实进程内存：直接对地址做 atomic RMW，跨线程才是真原子。
                       自定义 memfn 无法保证单次 RMW，明确拒绝而非退化成读写两步。 */
                    if (v->memfn && v->memfn != csvm_host_mem_direct) {
                        trap = 1; why = "自定义内存回调不支持原子 RMW"; break;
                    }
                    ap = (uint8_t *)(uintptr_t)addr;
                } else {
                    if (addr + al > VM_MEM_SIZE) {
                        trap = 1; why = "原子指令地址越出 VM 内存"; break;
                    }
                    ap = v->mem + addr;
                }
                uint64_t src = RDB();
                uint64_t msk = (aw == 64) ? ~(uint64_t)0 : 0xFFFFFFFFULL;
                uint64_t rax_slot = h->reg_map[X_RAX];
                /* 每条原子操作只发一次 __atomic builtin；SEQ_CST 与 x86 LOCK
                   语义一致。结果/标志按各指令的 x86 定义写回。 */
#define CS_ATOM_WRITEB(x) write_oper(v, b, b->b_kind, b->b_reg, aw, \
                                      (x), mask, &trap, &why)
#define CS_ATOM_FLAGS(res, old, rhs) do { \
                    uint64_t _r = (res), _a = (old), _b = (rhs); \
                    v->flags = calc_flags(_r, _a, _b, aw, 0, 0, v->flags); \
                } while (0)
#define CS_ATOM_BODY(T) do { \
                    T *tp = (T *)ap; T s = (T)src, oldv, resv; \
                    switch (b->exit_kind) { \
                    case AT_CMPXCHG: { \
                        T exp = (T)v->r[rax_slot]; \
                        int eq = __atomic_compare_exchange_n( \
                            tp, &exp, s, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); \
                        v->r[rax_slot] = (uint64_t)exp & msk; \
                        v->flags = calc_flags((uint64_t)((T)v->r[rax_slot] - s) & msk, \
                                              (uint64_t)v->r[rax_slot], s, aw, \
                                              1, 0, v->flags); \
                        v->flags = (v->flags & ~(uint32_t)F_ZF) | (eq ? F_ZF : 0); \
                        break; } \
                    case AT_XADD: \
                        oldv = __atomic_fetch_add(tp, s, __ATOMIC_SEQ_CST); \
                        resv = (T)(oldv + s); \
                        CS_ATOM_WRITEB((uint64_t)oldv & msk); \
                        CS_ATOM_FLAGS((uint64_t)resv & msk, oldv, s); break; \
                    case AT_XCHG: \
                        oldv = __atomic_exchange_n(tp, s, __ATOMIC_SEQ_CST); \
                        CS_ATOM_WRITEB((uint64_t)oldv & msk); break; \
                    case AT_ALU: { \
                        T rhs = s; uint64_t oldr = 0, resr = 0; \
                        switch (b->cc & 7) { \
                        case 0: oldr = __atomic_fetch_add(tp, rhs, __ATOMIC_SEQ_CST); resr = oldr + rhs; break; \
                        case 1: oldr = __atomic_fetch_or (tp, rhs, __ATOMIC_SEQ_CST); resr = oldr | rhs; break; \
                        case 4: oldr = __atomic_fetch_and(tp, rhs, __ATOMIC_SEQ_CST); resr = oldr & rhs; break; \
                        case 5: oldr = __atomic_fetch_sub(tp, rhs, __ATOMIC_SEQ_CST); resr = oldr - rhs; break; \
                        case 6: oldr = __atomic_fetch_xor(tp, rhs, __ATOMIC_SEQ_CST); resr = oldr ^ rhs; break; \
                        default: trap = 1; why = "原子 ALU 仅支持 ADD/OR/AND/SUB/XOR"; break; \
                        } \
                        if (!trap) CS_ATOM_FLAGS(resr & msk, oldr, rhs); break; } \
                    case AT_BIT: { \
                        T bit = (T)(1ULL << (src & (aw - 1))); \
                        oldv = (b->cc == 0) ? __atomic_fetch_or (tp, bit, __ATOMIC_SEQ_CST) \
                             : (b->cc == 1) ? __atomic_fetch_and(tp, (T)~bit, __ATOMIC_SEQ_CST) \
                                            : __atomic_fetch_xor(tp, bit, __ATOMIC_SEQ_CST); \
                        v->flags = (v->flags & ~(uint32_t)F_CF) \
                                 | (((oldv >> (src & (aw - 1))) & 1) ? F_CF : 0); \
                        break; } \
                    case AT_UNARY: { \
                        T cur = __atomic_load_n(tp, __ATOMIC_SEQ_CST), want; \
                        switch (b->cc & 7) { \
                        case 0: want = cur + 1; break;   /* INC (FF /0) */ \
                        case 1: want = cur - 1; break;   /* DEC (FF /1) */ \
                        case 2: want = ~cur;   break;   /* NOT (F7 /2) */ \
                        case 3: want = (T)(0 - cur); break; /* NEG (F7 /3) */ \
                        default: trap = 1; why = "原子一元仅支持 INC/DEC/NOT/NEG"; break; \
                        } \
                        while (!trap && !__atomic_compare_exchange_n( \
                                   tp, &cur, want, 1, __ATOMIC_SEQ_CST, \
                                   __ATOMIC_SEQ_CST)) { \
                            switch (b->cc & 7) { \
                            case 0: want = cur + 1; break; case 1: want = cur - 1; break; \
                            case 2: want = ~cur;   break; default: want = (T)(0 - cur); break; \
                            } \
                        } \
                        break; } \
                    default: trap = 1; why = "未知原子子操作码"; break; \
                    } \
                } while (0)
                if (aw == 64) CS_ATOM_BODY(uint64_t);
                else          CS_ATOM_BODY(uint32_t);
#undef CS_ATOM_BODY
#undef CS_ATOM_FLAGS
#undef CS_ATOM_WRITEB
                break;
                }
            CS_DEFAULT
                trap = 1; why = "未实现的逻辑 op"; *halt_out = 1; return;
