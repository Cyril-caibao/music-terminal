/* bootstub.c —— CyrilShield C 外壳引导器（v3.3.0 起，替代 Python boot.py）
 *
 * 设计：本文件编译成一个「模板 EXE」（native/out/bootstub.exe，随工具分发），
 * 每次构建把【加密配置块 + 加密载荷 + 尾表】作为 overlay 追加到模板副本尾部。
 * 构建期不需要任何编译器；多态性全部来自 per-build 的 overlay 数据
 * （随机 magic/salt/chunk/imm_xor/字段排列/操作码映射/垃圾指令字节码），
 * 与 Python 外壳的随机化维度一致。
 *
 * 语义严格对齐 vmgen.STUB_TEMPLATE（Python 版）：
 *   - 迷你 VM：16 个 64 位寄存器 + mem + flag + 22 个操作码；
 *     LOADB/STOREB 索引 & 0xFF；CMPR/CMPI 的 flag 为有符号差；
 *     LDI 的 imm 按有符号 32 位扩展到 64 位（与 Python 的负数 & MASK 等价）。
 *   - keystream = SHAKE256(key || salt || tag || counter_le64)，与 Python
 *     hashlib.shake_256 完全一致；分块异或等价于大整数异或。
 *   - 守卫：反调试（IsDebuggerPresent/CheckRemoteDebuggerPresent/
 *     NtQueryInformationProcess 7/30/31/硬件断点/单步计时）+ 反分析环境
 *     （进程**整名**匹配——v3.2.7 起，不再子串误伤合法软件、用户名/机器名、
 *     VM 驱动文件、规格、CPU 品牌、屏幕规格）。命中时弹窗提示后退出。
 *   - 释放：secure 模式优先 delete-on-close（磁盘不留稳定明文），失败回落
 *     常规临时目录；cleanup 在进程结束后删除。
 *
 * 已知边界（诚实边界）：
 *   - Python 对标层里依赖「源码注入」的能力（壳源混淆/运行时完整性自检/
 *     离线授权校验/构建清单）在 C 外壳暂未实现，报告中如实标注；
 *   - 模板的版本资源为固定内容，自定义版本资源待后续版本支持。
 *
 * 构建（zig cc，构建机一次性执行，产物随工具分发）：
 *   zig cc -target x86_64-windows-gnu -std=c11 -O2 -municode
 *         -Wl,--subsystem,windows src/bootstub.c -o out/bootstub.exe
 */
#include <windows.h>
#include <tlhelp32.h>
#include <shellapi.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ------------------------------------------------------------------ 常量 */
#define CS_OVERLAY_MAGIC   "CSOVLAY1"
#define CS_OVERLAY_VERSION 2u
#define CS_TAIL_SIZE       32u
#define CS_CONFIG_TAG      "CS-CONFIG-v1"
#define CS_DLL_TAG         "CS-DLL-v1"
#define CS_DLL_NAME        L"CyrilShield.CodeVM.dll"
#define CS_MAGIC_LEN       8u
#define CS_SALT_LEN        16u
#define CS_NONCE_LEN       16u
#define CS_KEY_LEN         32u
#define CS_NOPS            22u
#define CS_MAX_STEPS       50000000ull
#define CS_MAX_MEM         4096u
#define CS_MAX_PROG        (4u * 1024u * 1024u)

/* 操作码编号 = vmgen.OPCODES 固定顺序（配置里存的是 per-build 随机值） */
enum {
    OP_NOP, OP_LDI, OP_MOV, OP_ADDI, OP_ADDR, OP_SUBR, OP_XORI, OP_XORR,
    OP_SHLI, OP_SHRI, OP_ANDR, OP_LOADB, OP_STOREB, OP_CMPR, OP_CMPI,
    OP_JMP, OP_JZ, OP_JNZ, OP_JL, OP_JGE, OP_NATIVE, OP_HALT
};

/* 每构建配置（解密后） */
typedef struct {
    uint32_t guard_mode;
    uint32_t secure_temp;
    uint8_t  salt[CS_SALT_LEN];
    uint8_t  magic[CS_MAGIC_LEN];
    uint32_t chunk;
    uint32_t imm_xor;
    uint32_t key_off;
    uint32_t mem_size;
    uint8_t  forder[3];
    uint8_t  ops[CS_NOPS];
    uint32_t prog_len;
    uint8_t  prog_digest[32];
    uint8_t *prog;            /* 指向 config 内部，无需单独释放 */
} CsConfig;

/* 运行期载荷（解密后） */
typedef struct {
    uint64_t size;
    uint8_t  digest[32];
    uint32_t flags;
    char     name[256];
    char     args[1024];
    uint8_t *ct;              /* len = size - (magic8+mlen4+meta) */
    uint64_t ct_len;
} CsPayload;

/* ---------------------------------------------------------------- SHA-256 */
typedef struct {
    uint32_t h[8];
    uint64_t len;
    uint8_t  buf[64];
    size_t   buflen;
} Sha256;

static const uint32_t CS_K256[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};

static uint32_t cs_ror(uint32_t x, uint32_t n) { return (x >> n) | (x << (32 - n)); }

static void cs_sha256_init(Sha256 *s) {
    s->h[0]=0x6a09e667; s->h[1]=0xbb67ae85; s->h[2]=0x3c6ef372; s->h[3]=0xa54ff53a;
    s->h[4]=0x510e527f; s->h[5]=0x9b05688c; s->h[6]=0x1f83d9ab; s->h[7]=0x5be0cd19;
    s->len = 0; s->buflen = 0;
}

static void cs_sha256_block(Sha256 *s, const uint8_t *p) {
    uint32_t w[64], a, b, c, d, e, f, g, h;
    for (int i = 0; i < 16; i++)
        w[i] = ((uint32_t)p[i*4] << 24) | ((uint32_t)p[i*4+1] << 16) |
               ((uint32_t)p[i*4+2] << 8) | (uint32_t)p[i*4+3];
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = cs_ror(w[i-15],7) ^ cs_ror(w[i-15],18) ^ (w[i-15] >> 3);
        uint32_t s1 = cs_ror(w[i-2],17) ^ cs_ror(w[i-2],19) ^ (w[i-2] >> 10);
        w[i] = w[i-16] + s0 + w[i-7] + s1;
    }
    a=s->h[0]; b=s->h[1]; c=s->h[2]; d=s->h[3];
    e=s->h[4]; f=s->h[5]; g=s->h[6]; h=s->h[7];
    for (int i = 0; i < 64; i++) {
        uint32_t S1 = cs_ror(e,6) ^ cs_ror(e,11) ^ cs_ror(e,25);
        uint32_t ch = (e & f) ^ ((~e) & g);
        uint32_t t1 = h + S1 + ch + CS_K256[i] + w[i];
        uint32_t S0 = cs_ror(a,2) ^ cs_ror(a,13) ^ cs_ror(a,22);
        uint32_t mj = (a & b) ^ (a & c) ^ (b & c);
        uint32_t t2 = S0 + mj;
        h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
    }
    s->h[0]+=a; s->h[1]+=b; s->h[2]+=c; s->h[3]+=d;
    s->h[4]+=e; s->h[5]+=f; s->h[6]+=g; s->h[7]+=h;
}

static void cs_sha256_update(Sha256 *s, const void *data, size_t n) {
    const uint8_t *p = (const uint8_t *)data;
    s->len += n;
    while (n) {
        size_t take = 64 - s->buflen;
        if (take > n) take = n;
        memcpy(s->buf + s->buflen, p, take);
        s->buflen += take; p += take; n -= take;
        if (s->buflen == 64) { cs_sha256_block(s, s->buf); s->buflen = 0; }
    }
}

static void cs_sha256_final(Sha256 *s, uint8_t out[32]) {
    uint64_t bits = s->len * 8;
    uint8_t pad = 0x80;
    cs_sha256_update(s, &pad, 1);
    uint8_t z = 0;
    while (s->buflen != 56) cs_sha256_update(s, &z, 1);
    uint8_t lenb[8];
    for (int i = 0; i < 8; i++) lenb[i] = (uint8_t)(bits >> (56 - i * 8));
    cs_sha256_update(s, lenb, 8);
    for (int i = 0; i < 8; i++) {
        out[i*4]   = (uint8_t)(s->h[i] >> 24);
        out[i*4+1] = (uint8_t)(s->h[i] >> 16);
        out[i*4+2] = (uint8_t)(s->h[i] >> 8);
        out[i*4+3] = (uint8_t)(s->h[i]);
    }
}

static void cs_sha256(const void *data, size_t n, uint8_t out[32]) {
    Sha256 s; cs_sha256_init(&s);
    cs_sha256_update(&s, data, n);
    cs_sha256_final(&s, out);
}

/* --------------------------------------------------- SHAKE256 (Keccak-f1600) */
#define CS_KECCAK_ROUNDS 24
static const uint64_t CS_RC[24] = {
    0x0000000000000001ull, 0x0000000000008082ull, 0x800000000000808aull,
    0x8000000080008000ull, 0x000000000000808bull, 0x0000000080000001ull,
    0x8000000080008081ull, 0x8000000000008009ull, 0x000000000000008aull,
    0x0000000000000088ull, 0x0000000080008009ull, 0x000000008000000aull,
    0x000000008000808bull, 0x800000000000008bull, 0x8000000000008089ull,
    0x8000000000008003ull, 0x8000000000008002ull, 0x8000000000000080ull,
    0x000000000000800aull, 0x800000008000000aull, 0x8000000080008081ull,
    0x8000000000008080ull, 0x0000000080000001ull, 0x8000000080008008ull
};

static uint64_t cs_rotl64(uint64_t x, uint32_t n) {
    return n ? ((x << n) | (x >> (64 - n))) : x;
}

/* rho 偏移与 pi 链（经典 tiny-keccak 写法） */
static const int CS_ROT_C[24] = {
     1,  3,  6, 10, 15, 21, 28, 36, 45, 55,  2, 14,
    27, 41, 56,  8, 25, 43, 62, 18, 39, 61, 20, 44
};
static const int CS_PI_LN[24] = {
    10,  7, 11, 17, 18,  3,  5, 16,  8, 21, 24,  4,
    15, 23, 19, 13, 12,  2, 20, 14, 22,  9,  6,  1
};

static void cs_keccak_f(uint64_t st[25]) {
    for (int rnd = 0; rnd < CS_KECCAK_ROUNDS; rnd++) {
        /* theta */
        uint64_t bc[5];
        for (int i = 0; i < 5; i++)
            bc[i] = st[i] ^ st[i+5] ^ st[i+10] ^ st[i+15] ^ st[i+20];
        for (int i = 0; i < 5; i++) {
            uint64_t t = bc[(i+4)%5] ^ cs_rotl64(bc[(i+1)%5], 1);
            for (int j = 0; j < 25; j += 5) st[i+j] ^= t;
        }
        /* rho + pi（沿 pi 链旋转搬迁） */
        uint64_t tmp = st[1];
        for (int i = 0; i < 24; i++) {
            int j = CS_PI_LN[i];
            uint64_t nxt = st[j];
            st[j] = cs_rotl64(tmp, (uint32_t)CS_ROT_C[i]);
            tmp = nxt;
        }
        /* chi */
        for (int j = 0; j < 25; j += 5) {
            uint64_t row[5];
            for (int i = 0; i < 5; i++) row[i] = st[j+i];
            for (int i = 0; i < 5; i++)
                st[j+i] = row[i] ^ ((~row[(i+1)%5]) & row[(i+2)%5]);
        }
        /* iota */
        st[0] ^= CS_RC[rnd];
    }
}

/* SHAKE256 XOF：rate = 136 字节（SHAKE256 的标准速率） */
typedef struct { uint64_t st[25]; uint8_t buf[136]; size_t pos; int squeezing; } Shake256;

static void cs_shake_permute(Shake256 *s) {
    for (int i = 0; i < 17; i++) {
        uint64_t v;
        memcpy(&v, s->buf + i * 8, 8);
        s->st[i] ^= v;
    }
    cs_keccak_f(s->st);
    memset(s->buf, 0, 136);
    s->pos = 0;
}

static void cs_shake256_absorb(Shake256 *s, const void *data, size_t n) {
    const uint8_t *p = (const uint8_t *)data;
    while (n) {
        size_t take = 136 - s->pos;
        if (take > n) take = n;
        for (size_t i = 0; i < take; i++) s->buf[s->pos + i] ^= p[i];
        s->pos += take; p += take; n -= take;
        if (s->pos == 136) cs_shake_permute(s);
    }
}

/* 完成吸收（加 pad）后按需挤出。首次调用后进入 squeezing 态。 */
static void cs_shake256_squeeze(Shake256 *s, uint8_t *out, size_t n) {
    uint8_t block[136];
    if (!s->squeezing) {
        s->squeezing = 1;
        s->buf[s->pos] ^= 0x1f;      /* SHAKE256 域分隔 0x1F */
        s->buf[135] ^= 0x80;         /* 最终位 */
        cs_shake_permute(s);
    }
    while (n) {
        for (int i = 0; i < 17; i++)
            memcpy(block + i * 8, &s->st[i], 8);
        size_t take = n < 136 ? n : 136;
        memcpy(out, block, take);
        out += take; n -= take;
        if (n) cs_keccak_f(s->st);   /* 还要更多输出 → 再搅一次 */
    }
}

static void cs_shake256(const void *data, size_t n, uint8_t *out, size_t outn) {
    Shake256 s;
    memset(&s, 0, sizeof(s));
    cs_shake256_absorb(&s, data, n);
    cs_shake256_squeeze(&s, out, outn);
}

/* keystream = SHAKE256(key || salt || tag || counter_le64)，对齐 Python 版 */
static void cs_keystream(const uint8_t key[32], const uint8_t salt[16],
                         const char *tag, uint64_t counter,
                         uint8_t *out, size_t n) {
    size_t taglen = strlen(tag);
    size_t total = 32 + 16 + taglen + 8;
    uint8_t *seed = (uint8_t *)malloc(total);
    if (!seed) return;
    size_t o = 0;
    memcpy(seed + o, key, 32); o += 32;
    memcpy(seed + o, salt, 16); o += 16;
    memcpy(seed + o, tag, taglen); o += taglen;
    for (int i = 0; i < 8; i++) seed[o + i] = (uint8_t)(counter >> (8 * i));
    cs_shake256(seed, total, out, n);
    free(seed);
}

static void cs_xor_stream(uint8_t *buf, size_t n, const uint8_t *ks) {
    for (size_t i = 0; i < n; i++) buf[i] ^= ks[i];
}

/* ------------------------------------------------------------------ 守卫 */
static int cs_guard_mode = 0;

static int cs_proc_has_name(const char *needle) {
    /* Toolhelp32 枚举，整名匹配（v3.2.7 语义：不再子串误伤） */
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W e;
    e.dwSize = sizeof(e);
    int hit = 0;
    char needle2[300];
    snprintf(needle2, sizeof(needle2), "%s.exe", needle);
    if (Process32FirstW(snap, &e)) {
        do {
            char name[260];
            WideCharToMultiByte(CP_UTF8, 0, e.szExeFile, -1,
                                name, sizeof(name), NULL, NULL);
            /* 转小写 */
            for (char *q = name; *q; ++q)
                if (*q >= 'A' && *q <= 'Z') *q += 32;
            if (strcmp(name, needle) == 0 || strcmp(name, needle2) == 0) {
                hit = 1;
                break;
            }
        } while (Process32NextW(snap, &e));
    }
    CloseHandle(snap);
    return hit;
}

static int cs_debugger_present(void) {
    if (IsDebuggerPresent()) return 1;
    HANDLE proc = GetCurrentProcess();
    int remote = 0;
    if (CheckRemoteDebuggerPresent(proc, &remote) && remote) return 1;
    /* NtQueryInformationProcess 7/30/31 */
    typedef LONG (WINAPI *NtQIP)(HANDLE, ULONG, PVOID, ULONG, PULONG);
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (ntdll) {
        NtQIP q = (NtQIP)GetProcAddress(ntdll, "NtQueryInformationProcess");
        if (q) {
            ULONG_PTR dbgport = 0, dbghandle = 0;
            ULONG retlen = 0;
            if (q(proc, 7, &dbgport, sizeof(dbgport), &retlen) == 0 && dbgport)
                return 1;
            if (q(proc, 30, &dbghandle, sizeof(dbghandle), &retlen) == 0 && dbghandle)
                return 1;
            ULONG dbgflags = 1;
            if (q(proc, 31, &dbgflags, sizeof(dbgflags), &retlen) == 0 &&
                dbgflags == 0)
                return 1;
        }
    }
    /* 硬件断点 Dr0~Dr3 */
    CONTEXT ctx;
    memset(&ctx, 0, sizeof(ctx));
    ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    if (GetThreadContext(GetCurrentThread(), &ctx)) {
        if (ctx.Dr0 || ctx.Dr1 || ctx.Dr2 || ctx.Dr3) return 1;
    }
    /* 单步计时：确定性异或循环耗时异常放大 */
    {
        LARGE_INTEGER f, t0, t1;
        if (QueryPerformanceFrequency(&f) && f.QuadPart > 0) {
            volatile uint32_t acc = 0;
            QueryPerformanceCounter(&t0);
            for (int i = 0; i < 200000; i++) acc ^= (uint32_t)i;
            QueryPerformanceCounter(&t1);
            double ms = (double)(t1.QuadPart - t0.QuadPart) * 1000.0 /
                        (double)f.QuadPart;
            /* 对齐 Python：2 万次 <5ms，阈值 200ms；这里 20 万次，阈值 2000ms */
            if (ms > 2000.0) return 1;
        }
    }
    return 0;
}

static int cs_analysis_env(void) {
    static const char *TOOLS[] = {
        "ollydbg", "x64dbg", "x32dbg", "windbg", "ida", "ida64", "idaq",
        "scylla", "pestudio", "processhacker", "procexp", "procmon",
        "regmon", "filemon", "wireshark", "fiddler", "charles",
        "apimonitor", "cheatengine", "die", "detectiteasy", "petools",
        "importrec", "lordpe", "immunity", "vboxservice", "vboxtray",
        "vmtoolsd", "vmwareuser", "vmwaretray", "qemu-ga", "prl_cc",
        "prl_tools", "sandboxiedcomlaunch", "sbiesvc", "joeboxserver",
        "cuckoomon", "analyzer", "sandbox"
    };
    for (size_t i = 0; i < sizeof(TOOLS)/sizeof(TOOLS[0]); i++)
        if (cs_proc_has_name(TOOLS[i])) return 1;

    /* 用户名 / 计算机名含沙箱特征（子串，与 Python 版一致） */
    {
        char who[600] = {0};
        size_t off = 0;
        char buf[300];
        if (GetEnvironmentVariableA("USERNAME", buf, sizeof(buf)) &&
            (off = strlen(buf)) < 300) {
            memcpy(who, buf, off);
            who[off] = ' ';
            off++;
        }
        if (GetEnvironmentVariableA("COMPUTERNAME", buf, sizeof(buf)) &&
            off + strlen(buf) < sizeof(who)) {
            memcpy(who + off, buf, strlen(buf));
            off += strlen(buf);
        }
        for (char *q = who; *q; ++q)
            if (*q >= 'A' && *q <= 'Z') *q += 32;
        static const char *HINTS[] = {
            "sandbox", "malware", "virus", "sample", "cuckoo", "joe",
            "innotek", "virtualbox", "vmware", "qemu", "xen", "analyst", "lab"
        };
        for (size_t i = 0; i < sizeof(HINTS)/sizeof(HINTS[0]); i++)
            if (strstr(who, HINTS[i])) return 1;
    }

    /* 虚拟机驱动 / 客户机组件 */
    {
        static const wchar_t *VMFILES[] = {
            L"System32\\drivers\\VBoxGuest.sys",
            L"System32\\drivers\\vmmouse.sys",
            L"System32\\drivers\\vmhgfs.sys",
            L"System32\\vboxdisp.dll",
            L"System32\\vmGuestLib.dll"
        };
        wchar_t path[MAX_PATH];
        for (size_t i = 0; i < sizeof(VMFILES)/sizeof(VMFILES[0]); i++) {
            UINT r = GetSystemDirectoryW(path, MAX_PATH);
            if (!r) continue;
            lstrcatW(path, L"\\");
            lstrcatW(path, VMFILES[i]);
            if (GetFileAttributesW(path) != INVALID_FILE_ATTRIBUTES) return 1;
        }
    }

    /* 规格异常：<=1 核或系统盘 < 60GB */
    {
        SYSTEM_INFO si;
        GetSystemInfo(&si);
        DWORD cpu = si.dwNumberOfProcessors;
        if (cpu > 0 && cpu <= 1) return 1;
        wchar_t sysdir[MAX_PATH], root[4];
        UINT r = GetSystemDirectoryW(sysdir, MAX_PATH);
        if (r >= 3) {
            root[0] = sysdir[0]; root[1] = sysdir[1]; root[2] = sysdir[2];
            root[3] = 0;
            ULARGE_INTEGER total;
            if (GetDiskFreeSpaceExW(root, NULL, &total, NULL)) {
                if (total.QuadPart < 60ull * 1024ull * 1024ull * 1024ull)
                    return 1;
            }
        }
    }

    /* CPU 品牌特征 */
    {
        char brand[300] = {0};
        GetEnvironmentVariableA("PROCESSOR_IDENTIFIER", brand, sizeof(brand));
        for (char *q = brand; *q; ++q)
            if (*q >= 'A' && *q <= 'Z') *q += 32;
        static const char *BR[] = { "qemu", "virtual cpu", "vmware", "vbox",
                                    "xen", "kvm" };
        for (size_t i = 0; i < sizeof(BR)/sizeof(BR[0]); i++)
            if (strstr(brand, BR[i])) return 1;
    }

    /* 屏幕规格（无头分析机常为 800x600 以下） */
    if (GetSystemMetrics(SM_CXSCREEN) < 800 ||
        GetSystemMetrics(SM_CYSCREEN) < 600) return 1;
    return 0;
}

#ifdef CS_CONSOLE_DEBUG
#define cs_msgbox_utf8(text) do { fprintf(stderr, "[bootstub] %s\n", (text)); fflush(stderr); } while (0)
#define CS_TRACE(msg) do { fprintf(stderr, "[trace] %s\n", (msg)); fflush(stderr); } while (0)
#else
#define CS_TRACE(msg) do { (void)(msg); } while (0)   /* 生产版：阶段打点编译消除 */
static void cs_msgbox_utf8(const char *text) {
    wchar_t wtext[1024], wtitle[128];
    MultiByteToWideChar(CP_UTF8, 0, text, -1, wtext, 1024);
    MultiByteToWideChar(CP_UTF8, 0, "CyrilShield", -1, wtitle, 128);
    MessageBoxW(NULL, wtext, wtitle, MB_ICONERROR);
}
#endif

static int cs_guard_pass(void) {
    if (cs_guard_mode & 1) {
        if (cs_debugger_present()) return 0;
    }
    if (cs_guard_mode & 2) {
        if (cs_analysis_env()) return 0;
    }
    return 1;
}

/* --------------------------------------------------------------- overlay */
static uint8_t *cs_self_data = NULL;   /* 自身映像文件全文 */
static size_t   cs_self_len = 0;
static uint8_t *cs_cfg_raw = NULL;     /* 解密后的配置明文 */
static size_t   cs_cfg_raw_len = 0;
static uint8_t *cs_payload_blob = NULL;/* 载荷区（打包格式原文） */
static size_t   cs_payload_len = 0;
static uint8_t *cs_side_dll = NULL;    /* 内嵌的运行内核（虚拟化产物用） */
static size_t   cs_side_dll_len = 0;
static CsConfig cs_cfg;
static CsPayload cs_meta;

static void cs_cleanup(void) {
    free(cs_self_data);
    free(cs_cfg_raw);
    free(cs_payload_blob);
    free(cs_side_dll);
    free(cs_meta.ct);
}

static int cs_read_self(void) {
    wchar_t path[MAX_PATH];
    if (!GetModuleFileNameW(NULL, path, MAX_PATH)) return 0;
    HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, NULL,
                           OPEN_EXISTING, 0, NULL);
    if (f == INVALID_HANDLE_VALUE) return 0;
    LARGE_INTEGER sz;
    if (!GetFileSizeEx(f, &sz) || sz.QuadPart < 0x40 + (LONGLONG)CS_TAIL_SIZE) {
        CloseHandle(f);
        return 0;
    }
    cs_self_len = (size_t)sz.QuadPart;
    cs_self_data = (uint8_t *)malloc(cs_self_len);
    if (!cs_self_data) { CloseHandle(f); return 0; }
    DWORD got = 0, total = 0;
    while (total < cs_self_len &&
           ReadFile(f, cs_self_data + total, (DWORD)(cs_self_len - total),
                    &got, NULL) && got) {
        total += got;
    }
    CloseHandle(f);
    return total == cs_self_len;
}

static const uint8_t *cs_tail(void) {
    if (cs_self_len < CS_TAIL_SIZE) return NULL;
    const uint8_t *t = cs_self_data + cs_self_len - CS_TAIL_SIZE;
    if (memcmp(t, CS_OVERLAY_MAGIC, 8) != 0) return NULL;
    return t;
}

static int cs_parse_overlay(void) {
    const uint8_t *tail = cs_tail();
    if (!tail) return 0;
    uint32_t version, dll_len;
    uint64_t cfg_len, pl_len;
    memcpy(&version, tail + 8, 4);
    memcpy(&dll_len, tail + 12, 4);   /* v1 这里是保留字段，恒为 0 */
    memcpy(&cfg_len, tail + 16, 8);
    memcpy(&pl_len, tail + 24, 8);
    if (version < 2u) dll_len = 0;   /* 兼容旧格式 overlay */
    if (cfg_len > (1u << 30) || pl_len > (1u << 30) || dll_len > (1u << 30))
        return 0;
    size_t need = (size_t)(CS_NONCE_LEN + cfg_len + pl_len + dll_len);
    if (cfg_len < 64 || pl_len < 16 ||
        cs_self_len < CS_TAIL_SIZE + need)
        return 0;
    const uint8_t *nonce = cs_self_data + cs_self_len - CS_TAIL_SIZE - need;
    const uint8_t *cfg_enc = nonce + CS_NONCE_LEN;
    const uint8_t *pl = cfg_enc + cfg_len;
    const uint8_t *dll_enc = pl + pl_len;

    /* 解密配置块（nonce 派生流，防静态特征） */
    size_t ksn = (size_t)cfg_len;
    uint8_t *ks = (uint8_t *)malloc(ksn);
    if (!ks) return 0;
    size_t seedlen = CS_NONCE_LEN + strlen(CS_CONFIG_TAG);
    uint8_t *seed = (uint8_t *)malloc(seedlen);
    if (!seed) { free(ks); return 0; }
    memcpy(seed, nonce, CS_NONCE_LEN);
    memcpy(seed + CS_NONCE_LEN, CS_CONFIG_TAG, strlen(CS_CONFIG_TAG));
    cs_shake256(seed, seedlen, ks, ksn);
    free(seed);
    cs_cfg_raw = (uint8_t *)malloc(cfg_len);
    if (!cs_cfg_raw) { free(ks); return 0; }
    for (uint64_t i = 0; i < cfg_len; i++) cs_cfg_raw[i] = cfg_enc[i] ^ ks[i];
    free(ks);
    cs_cfg_raw_len = (size_t)cfg_len;

    /* 解析配置 */
    uint8_t *p = cs_cfg_raw;
    size_t left = cs_cfg_raw_len;
#define TAKE(dst, n) do { if (left < (n)) return 0; memcpy(dst, p, (n)); p += (n); left -= (n); } while (0)
    TAKE(&cs_cfg.guard_mode, 4);
    TAKE(&cs_cfg.secure_temp, 4);
    TAKE(cs_cfg.salt, CS_SALT_LEN);
    TAKE(cs_cfg.magic, CS_MAGIC_LEN);
    TAKE(&cs_cfg.chunk, 4);
    TAKE(&cs_cfg.imm_xor, 4);
    TAKE(&cs_cfg.key_off, 4);
    TAKE(&cs_cfg.mem_size, 4);
    TAKE(cs_cfg.forder, 3);
    TAKE(cs_cfg.ops, CS_NOPS);
    TAKE(&cs_cfg.prog_len, 4);
    TAKE(cs_cfg.prog_digest, 32);
    if (cs_cfg.prog_len == 0 || cs_cfg.prog_len > CS_MAX_PROG ||
        left < cs_cfg.prog_len)
        return 0;
    cs_cfg.prog = p;
#undef TAKE

    cs_payload_blob = (uint8_t *)malloc((size_t)pl_len);
    if (!cs_payload_blob) return 0;
    memcpy(cs_payload_blob, pl, (size_t)pl_len);
    cs_payload_len = (size_t)pl_len;

    /* v3.3.3 内嵌运行内核：载荷之后、尾表之前，独立 nonce 派生流混淆。
       PE 导入名固定为 CS_DLL_NAME，加载器只在 EXE 所在目录找它；引导器
       释放载荷时把这段字节一并写到同一临时目录，成品才能单文件启动。 */
    if (dll_len) {
        uint8_t *ks = (uint8_t *)malloc(dll_len);
        if (!ks) return 0;
        size_t seedlen = CS_NONCE_LEN + strlen(CS_DLL_TAG);
        uint8_t *seed = (uint8_t *)malloc(seedlen);
        if (!seed) { free(ks); return 0; }
        memcpy(seed, nonce, CS_NONCE_LEN);
        memcpy(seed + CS_NONCE_LEN, CS_DLL_TAG, strlen(CS_DLL_TAG));
        cs_shake256(seed, seedlen, ks, dll_len);
        free(seed);
        cs_side_dll = (uint8_t *)malloc(dll_len);
        if (!cs_side_dll) { free(ks); return 0; }
        for (uint32_t i = 0; i < dll_len; i++)
            cs_side_dll[i] = dll_enc[i] ^ ks[i];
        free(ks);
        cs_side_dll_len = dll_len;
    }

    cs_guard_mode = cs_cfg.guard_mode;
    return 1;
}

/* ------------------------------------------------------------- 迷你 VM */
static uint64_t cs_r[16];
static uint8_t *cs_mem = NULL;
static int64_t  cs_flag = 0;

static int cs_vm_native(int n);   /* 前置声明 */

static int cs_vm_run(int *integrity_failed) {
    /* 校验字节码完整性（对齐 Python：长度 + SHA256 摘要） */
    uint8_t dig[32];
    cs_sha256(cs_cfg.prog, cs_cfg.prog_len, dig);
    if (memcmp(dig, cs_cfg.prog_digest, 32) != 0) return -1;

    if (cs_cfg.key_off + CS_KEY_LEN > cs_cfg.mem_size ||
        cs_cfg.mem_size == 0 || cs_cfg.mem_size > CS_MAX_MEM)
        return -1;
    cs_mem = (uint8_t *)calloc(cs_cfg.mem_size, 1);
    if (!cs_mem) return -1;
    memset(cs_r, 0, sizeof(cs_r));
    cs_flag = 0;

    const uint8_t *prog = cs_cfg.prog;
    size_t total = cs_cfg.prog_len / 8;
    size_t pc = 0;
    unsigned long long steps = 0;
    while (pc < total) {
        if (++steps > CS_MAX_STEPS) return -2;   /* 步数超限 */
        uint8_t op = prog[pc*8];
        uint8_t b1 = prog[pc*8+1], b2 = prog[pc*8+2], b3 = prog[pc*8+3];
        uint32_t ix;
        memcpy(&ix, prog + pc*8 + 4, 4);
        pc++;
        uint8_t slots[3] = { b1, b2, b3 };
        int dst = slots[cs_cfg.forder[0]];
        int a   = slots[cs_cfg.forder[1]];
        int b   = slots[cs_cfg.forder[2]];
        uint32_t raw = ix ^ cs_cfg.imm_xor;
        int32_t simm = (int32_t)raw;
        /* 反向查表：只有 ops 里登记过的操作码值有效（对齐 Python INV.get） */
        int match = -1;
        for (int i = 0; i < (int)CS_NOPS; i++)
            if (cs_cfg.ops[i] == op) { match = i; break; }
        if (match < 0) return -3;                /* 非法操作码 */
        switch (match) {
        case OP_NOP: break;
        case OP_LDI: cs_r[dst] = (uint64_t)(int64_t)simm; break;
        case OP_MOV: cs_r[dst] = cs_r[a]; break;
        case OP_ADDI: cs_r[dst] += (uint64_t)(int64_t)simm; break;
        case OP_ADDR: cs_r[dst] = cs_r[a] + cs_r[b]; break;
        case OP_SUBR: cs_r[dst] = cs_r[a] - cs_r[b]; break;
        case OP_XORI: cs_r[dst] ^= (uint64_t)(int64_t)simm; break;
        case OP_XORR: cs_r[dst] = cs_r[a] ^ cs_r[b]; break;
        case OP_SHLI: cs_r[dst] <<= (int)(simm & 63); break;
        case OP_SHRI: cs_r[dst] >>= (int)(simm & 63); break;
        case OP_ANDR: cs_r[dst] = cs_r[a] & cs_r[b]; break;
        case OP_LOADB: cs_r[dst] = cs_mem[cs_r[a] & 0xFF]; break;
        case OP_STOREB: cs_mem[cs_r[a] & 0xFF] = (uint8_t)(cs_r[b] & 0xFF); break;
        case OP_CMPR: cs_flag = (int64_t)(cs_r[a] - cs_r[b]); break;
        case OP_CMPI: cs_flag = (int64_t)(cs_r[dst] - (uint64_t)(int64_t)simm); break;
        case OP_JMP: pc = (size_t)simm; break;
        case OP_JZ: if (cs_flag == 0) pc = (size_t)simm; break;
        case OP_JNZ: if (cs_flag != 0) pc = (size_t)simm; break;
        case OP_JL: if (cs_flag < 0) pc = (size_t)simm; break;
        case OP_JGE: if (cs_flag >= 0) pc = (size_t)simm; break;
        case OP_NATIVE: {
            int rc = cs_vm_native(simm);
            if (rc == -10) { *integrity_failed = 1; return 0; }  /* NATIVE4 */
            if (rc != 0) return -4;
            break;
        }
        case OP_HALT: return 0;
        default: return -3;
        }
        if ((int64_t)pc < 0 || pc > total) return -3;
    }
    return -5;   /* 字节码越界（与 Python 一致：没有 HALT 就报错） */
}

/* v3.3.3：函数级虚拟化产物的载荷 PE 导入 CyrilShield.CodeVM.dll，
   Windows 加载器只在 **EXE 所在目录** 找它。载荷被释放到独立临时目录，
   所以内嵌内核必须写到同一目录，否则 CreateProcess 会以 err=126 失败
   （旧版把 DLL 放在输出目录，而输出目录并不是载荷目录）。 */
static void cs_side_dll_path(const wchar_t *dir, wchar_t *out, size_t n) {
    swprintf(out, n, L"%s\\%s", dir, CS_DLL_NAME);
}

static int cs_write_side_dll(const wchar_t *dir) {
    if (!cs_side_dll || !cs_side_dll_len) return 1;   /* 未虚拟化：无附带文件 */
    wchar_t path[MAX_PATH];
    cs_side_dll_path(dir, path, MAX_PATH);
    HANDLE h = CreateFileW(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return 0;
    DWORD w = 0;
    int ok = WriteFile(h, cs_side_dll, (DWORD)cs_side_dll_len, &w, NULL)
             && w == cs_side_dll_len;
    CloseHandle(h);
    return ok;
}

static void cs_del_side_dll(const wchar_t *dir) {
    if (!cs_side_dll_len) return;
    wchar_t path[MAX_PATH];
    cs_side_dll_path(dir, path, MAX_PATH);
    DeleteFileW(path);
}

/* 释放：把明文写临时文件并 CreateProcess，等待退出返回码 */
static int cs_spawn_payload(void) {
    CS_TRACE("spawn begin");
    /* 参数：meta.args 空白分词 + flags&4 追加自身 argv */
    size_t argc = 0;
    char *argv[64];
    /* meta.args 分词（与 Python str.split() 一致：任意空白） */
    char *s = cs_meta.args;
    while (*s && argc < 62) {
        while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
        if (!*s) break;
        argv[argc++] = s;
        while (*s && *s != ' ' && *s != '\t' && *s != '\r' && *s != '\n') s++;
        if (*s) *s++ = '\0';
    }
    int forward = (cs_meta.flags & 4) != 0;
    int wargc = 0;
    LPWSTR *wargv = NULL;
    if (forward) {
        wargv = CommandLineToArgvW(GetCommandLineW(), &wargc);
        for (int i = 1; wargv && i < wargc && argc < 63; i++) {
            int need = WideCharToMultiByte(CP_UTF8, 0, wargv[i], -1,
                                           NULL, 0, NULL, NULL);
            if (need <= 0 || argc + 1 >= 64) break;
            char *conv = (char *)malloc(need);
            WideCharToMultiByte(CP_UTF8, 0, wargv[i], -1, conv, need,
                                NULL, NULL);
            argv[argc++] = conv;
        }
    }

    /* 释放文件名：basename(meta.name)，确保 .exe 后缀 */
    char name[256];
    const char *base = cs_meta.name;
    const char *q = cs_meta.name;
    for (; *q; ++q)
        if (*q == '/' || *q == '\\') base = q + 1;
    snprintf(name, sizeof(name), "%s", base && *base ? base : "payload.exe");
    if (strlen(name) < 4 ||
        strcmp(name + strlen(name) - 4, ".exe") != 0)
        strncat(name, ".exe", sizeof(name) - strlen(name) - 1);

    wchar_t wname[256];
    MultiByteToWideChar(CP_UTF8, 0, name, -1, wname, 256);

    /* 两级释放策略（与 Python 版语义一致）：
       ① secure 模式先试 delete-on-close；但写句柄保持打开期间，CreateProcess
          无法为该文件创建映像节（写句柄存在 → ERROR_SHARING_VIOLATION），
          失败则关闭句柄（系统自动删除）并回落 ②；
       ② 常规临时目录写入，进程结束后 cleanup（绝不运行期删文件）。
       Python 版的行为与此等价——它的 ① 一直在静默失败并走 ②。 */
    wchar_t tempdir[MAX_PATH], tmpbase[MAX_PATH];
    GetTempPathW(MAX_PATH, tmpbase);
    srand((unsigned)GetTickCount() ^ (unsigned)(uintptr_t)&wargc);
    HANDLE written = INVALID_HANDLE_VALUE;
    wchar_t exepath[MAX_PATH];
    int secure_tried = 0;
    for (int attempt = 0; attempt < 8 && written == INVALID_HANDLE_VALUE; attempt++) {
        swprintf(tempdir, MAX_PATH, L"%s_cs%06x", tmpbase, rand() & 0xFFFFFF);
        if (!CreateDirectoryW(tempdir, NULL)) continue;
        lstrcpyW(exepath, tempdir);
        lstrcatW(exepath, L"\\");
        lstrcatW(exepath, wname);
        if (cs_cfg.secure_temp && !secure_tried) {
            HANDLE h = CreateFileW(exepath, GENERIC_WRITE,
                                   FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                                   NULL, CREATE_NEW,
                                   FILE_FLAG_DELETE_ON_CLOSE | FILE_ATTRIBUTE_TEMPORARY,
                                   NULL);
            if (h != INVALID_HANDLE_VALUE) {
                DWORD w = 0;
                if (WriteFile(h, cs_meta.ct, (DWORD)cs_meta.ct_len, &w, NULL) &&
                    w == cs_meta.ct_len)
                    written = h;
                else
                    CloseHandle(h);
            }
            secure_tried = 1;
        }
        if (written == INVALID_HANDLE_VALUE) {
            HANDLE h = CreateFileW(exepath, GENERIC_WRITE, 0, NULL,
                                   CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
            if (h == INVALID_HANDLE_VALUE) continue;
            DWORD w = 0;
            if (WriteFile(h, cs_meta.ct, (DWORD)cs_meta.ct_len, &w, NULL) &&
                w == cs_meta.ct_len)
                written = h;   /* 常规路径：句柄仅用于确认写入，随后关闭 */
            else
                CloseHandle(h);
        }
    }
    int rc = 0;
    if (written == INVALID_HANDLE_VALUE) {
        rc = -1;
        if (wargv) LocalFree(wargv);
        return rc;
    }
    /* 命令行拼装：exe 加引号 + 参数逐个加引号 */
    wchar_t cmd[32768];
    wchar_t warg[1024];
    swprintf(cmd, 32768, L"\"%s\"", exepath);
    for (size_t i = 0; i < argc; i++) {
        MultiByteToWideChar(CP_UTF8, 0, argv[i], -1, warg, 1024);
        size_t L = lstrlenW(cmd);
        if (L + lstrlenW(warg) + 4 >= 32768) break;
        lstrcatW(cmd, L" \"");
        lstrcatW(cmd, warg);
        lstrcatW(cmd, L"\"");
    }
    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    memset(&pi, 0, sizeof(pi));
    int ok = 0;
    for (int stage = 0; stage < 2 && !ok; stage++) {
        if (stage == 1 && !cs_cfg.secure_temp) break;
        if (stage == 1) {
            /* secure 失败 → 关写句柄（触发删除）→ 回落常规写入 */
            CloseHandle(written);
            written = INVALID_HANDLE_VALUE;
            DeleteFileW(exepath);
            cs_del_side_dll(tempdir);
            RemoveDirectoryW(tempdir);
            HANDLE h = INVALID_HANDLE_VALUE;
            for (int attempt = 0; attempt < 8 && h == INVALID_HANDLE_VALUE; attempt++) {
                swprintf(tempdir, MAX_PATH, L"%s_cs%06x", tmpbase, rand() & 0xFFFFFF);
                if (!CreateDirectoryW(tempdir, NULL)) continue;
                lstrcpyW(exepath, tempdir);
                lstrcatW(exepath, L"\\");
                lstrcatW(exepath, wname);
                h = CreateFileW(exepath, GENERIC_WRITE, 0, NULL,
                                CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
                if (h == INVALID_HANDLE_VALUE) continue;
                DWORD w = 0;
                if (WriteFile(h, cs_meta.ct, (DWORD)cs_meta.ct_len, &w, NULL) &&
                    w == cs_meta.ct_len) {
                    CloseHandle(h);
                } else {
                    CloseHandle(h);
                    h = INVALID_HANDLE_VALUE;
                }
            }
            if (h == INVALID_HANDLE_VALUE) break;
            /* 重建 cmd（exepath 变了） */
            swprintf(cmd, 32768, L"\"%s\"", exepath);
            for (size_t i = 0; i < argc; i++) {
                MultiByteToWideChar(CP_UTF8, 0, argv[i], -1, warg, 1024);
                size_t L = lstrlenW(cmd);
                if (L + lstrlenW(warg) + 4 >= 32768) break;
                lstrcatW(cmd, L" \"");
                lstrcatW(cmd, warg);
                lstrcatW(cmd, L"\"");
            }
        }
        memset(&pi, 0, sizeof(pi));
        /* 在最终确定的 tempdir 里放好 DLL，再让加载器解析载荷的导入表。
           stage 1 回落时 tempdir 已重建，所以每个 stage 都要写一次。 */
        if (!cs_write_side_dll(tempdir)) {
            cs_msgbox_utf8("startup failed: 无法释放内嵌运行内核");
            rc = -1;
            break;
        }
        if (CreateProcessW(NULL, cmd, NULL, NULL, FALSE, 0, NULL,
                           tempdir, &si, &pi)) {
            ok = 1;
            CloseHandle(pi.hThread);
            WaitForSingleObject(pi.hProcess, INFINITE);
            DWORD code = 0;
            GetExitCodeProcess(pi.hProcess, &code);
            CloseHandle(pi.hProcess);
            rc = (int)code;
        }
    }
    /* cleanup（flags&2）：常规路径手动删；delete-on-close 已由系统处理 */
    if (cs_meta.flags & 2) {
        DeleteFileW(exepath);
        cs_del_side_dll(tempdir);
        RemoveDirectoryW(tempdir);
    }
    if (wargv) LocalFree(wargv);
    return rc;
}

static int cs_vm_native(int n) {
    switch (n) {
    case 0: {
        CS_TRACE("native0");
        /* 读取载荷（overlay 内）+ 解密元数据。密钥 = mem[KEY_OFF..+32] */
        const uint8_t *blob = cs_payload_blob;
        size_t blen = cs_payload_len;
        if (blen < CS_MAGIC_LEN + 4 ||
            memcmp(blob, cs_cfg.magic, CS_MAGIC_LEN) != 0)
            return -4;
        size_t p = CS_MAGIC_LEN;
        uint32_t mlen;
        memcpy(&mlen, blob + p, 4);
        p += 4;
        if (mlen > blen - p) return -4;
        uint8_t *meta = (uint8_t *)malloc(mlen);
        if (!meta) return -4;
        memcpy(meta, blob + p, mlen);
        {
            size_t kn = mlen;
            uint8_t *ks = (uint8_t *)malloc(kn);
            if (!ks) { free(meta); return -4; }
            cs_keystream(cs_mem + cs_cfg.key_off, cs_cfg.salt, "M", 0, ks, kn);
            cs_xor_stream(meta, kn, ks);
            free(ks);
        }
        size_t q = 0;
        memcpy(&cs_meta.size, meta + q, 8); q += 8;
        memcpy(cs_meta.digest, meta + q, 32); q += 32;
        memcpy(&cs_meta.flags, meta + q, 4); q += 4;
        uint32_t nlen; memcpy(&nlen, meta + q, 4); q += 4;
        if (nlen >= sizeof(cs_meta.name) || q + nlen > mlen) { free(meta); return -4; }
        memcpy(cs_meta.name, meta + q, nlen); cs_meta.name[nlen] = 0; q += nlen;
        uint32_t alen; memcpy(&alen, meta + q, 4); q += 4;
        if (alen >= sizeof(cs_meta.args) || q + alen > mlen) { free(meta); return -4; }
        memcpy(cs_meta.args, meta + q, alen); cs_meta.args[alen] = 0;
        free(meta);
        CS_TRACE("native0 meta ok");
        p += mlen;
        cs_meta.ct_len = blen - p;
        cs_meta.ct = (uint8_t *)malloc(cs_meta.ct_len ? cs_meta.ct_len : 1);
        if (!cs_meta.ct) return -4;
        memcpy(cs_meta.ct, blob + p, cs_meta.ct_len);
        /* 对齐 Python：native 0 的返回值 = 载荷密文长度，写入 r[0] —— 字节码
           用它作为解密循环的 total；漏掉这一步会让循环直接被 JGE 跳过 */
        cs_r[0] = cs_meta.ct_len;
        return 0;
    }
    case 1: {
        /* 分块解密：r0=off r1=ln r2=ctr，解密后 r0=ctr+1 */
        uint64_t off = cs_r[0], ln = cs_r[1], ctr = cs_r[2];
        if (off > cs_meta.ct_len) return 0;
        uint64_t end = off + ln;
        if (end > cs_meta.ct_len) end = cs_meta.ct_len;
        size_t seg = (size_t)(end - off);
        if (seg) {
            uint8_t *ks = (uint8_t *)malloc(seg);
            if (!ks) return -4;
            cs_keystream(cs_mem + cs_cfg.key_off, cs_cfg.salt, "P", ctr, ks, seg);
            cs_xor_stream(cs_meta.ct + off, seg, ks);
            free(ks);
        }
        cs_r[0] = ctr + 1;
        return 0;
    }
    case 2: {
        /* 完整性校验（flags&1 才启用）：长度 + SHA256 */
        if (!(cs_meta.flags & 1)) { cs_r[0] = 1; return 0; }
        uint8_t dig[32];
        cs_sha256(cs_meta.ct, cs_meta.ct_len, dig);
        cs_r[0] = (cs_meta.ct_len == cs_meta.size &&
                   memcmp(dig, cs_meta.digest, 32) == 0) ? 1 : 0;
        return 0;
    }
    case 3: {
        /* 释放并运行（返回退出码，对齐 Python：Popen.wait() 的返回值） */
        cs_r[0] = (uint64_t)(int64_t)cs_spawn_payload();
        return 0;
    }
    case 4:
        cs_msgbox_utf8("完整性校验失败：文件可能已损坏或被修改。");
        return -10;
    default:
        return -4;
    }
}

/* ------------------------------------------------------------------ main */
int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE hPrev, PWSTR cmd, int show) {
    (void)hInst; (void)hPrev; (void)cmd; (void)show;
    char err[512] = {0};

    CS_TRACE("read-self begin");
    if (!cs_read_self()) {
        cs_msgbox_utf8("startup failed: 无法读取自身文件（overlay 引导器要求完整文件）");
        return 0;
    }
    CS_TRACE("parse overlay begin");
    if (!cs_parse_overlay()) {
        cs_msgbox_utf8("startup failed: overlay 解析失败（文件不完整或已损坏）");
        cs_cleanup();
        return 0;
    }

    /* 守卫：命中则弹窗后退出（v3.2.7 语义，不再静默） */
    CS_TRACE("guard check begin");
    if (!cs_guard_pass()) {
        cs_msgbox_utf8("运行环境安全检查未通过，程序已停止。\n"
                       "若为误报，请重新生成保护副本并关闭"
                       "「反调试 / 反分析环境」选项。");
        cs_cleanup();
        return 0;
    }

    CS_TRACE("vm run begin");
    int integrity_failed = 0;
    int rc = cs_vm_run(&integrity_failed);
    if (rc != 0) {
        if (integrity_failed) {
            /* NATIVE 4 已弹窗 */
        } else if (rc == -2) {
            snprintf(err, sizeof(err), "startup failed: VM 步数超限");
            cs_msgbox_utf8(err);
        } else {
            snprintf(err, sizeof(err), "startup failed: VM 异常（%d）", rc);
            cs_msgbox_utf8(err);
        }
    }
    cs_cleanup();
    /* 与 Python 外壳一致：不管载荷退出码，外壳自身以 0 结束 */
    return 0;
}

#ifdef CS_CONSOLE_DEBUG
/* 控制台调试入口：走同一逻辑，错误打到 stderr 而非弹窗 */
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    return wWinMain(NULL, NULL, NULL, 0);
}
#endif
