/* CyrilShield L2 VM-exit 桥 —— 平台汇编上下文切换桩
 *
 * 解释器执行到 IR_CALLEXT（字节码外的原生调用）时，把 16 个 GPR（x86 编号，
 * 含真实 RSP）交给本桩。本桩负责真正的 native <-> VM 上下文切换：
 *
 *   1) 保存解释器现场：nonvolatile GPR + (Win x64) XMM6-15 + 原 RSP
 *   2) 建立受控宿主调用帧：16 字节对齐、Win x64 32 字节影子空间
 *   3) 从 VM 栈搬运栈参数（8 个 qword，覆盖到 12 个整数参数）
 *   4) 按目标 ABI 装载整数参数寄存器，call target
 *   5) 回写 RAX/RDX 到 GPR 数组，恢复解释器现场，返回 VM 继续执行
 *
 * CPU 的 RSP 在「解释器 C 栈」与「受控宿主调用帧」之间真实切换；VM 的逻辑
 * 栈（gpr[X_RSP]）作为参数源被读取，不被破坏。
 *
 * 第八批新增 csvm_default_exit_fpu：带 XMM0-7 参数搬运 + XMM0/XMM1 返回
 * 回读的第二套桩，配合 BC_FLAG_NEED_FPU 正确性闸门，修复「浮点参数跨
 * VM-exit 静默算错」。原 csvm_default_exit（仅 GPR）仍保留给纯整数场景。
 *
 * 明确属于 L3、本桩不做（见 docs/CODE-VM.md 第 6 节）：
 *   - 异常穿透 / 未注册 unwind info（目标函数抛异常无法跨本帧展开）
 *   - 回调再进 VM、多线程 VM 上下文
 *   - packed/AVX 向量参数、long double（XMM0/XMM1 之外的返回）
 *   - 主动修改 TEB/GS、伪造 SEH 链（本桩不碰 TEB，保持宿主原 SEH 链）
 *
 * 用文件级 GNU asm 而非 naked 函数：x86-64 上 GCC 不支持 naked，clang 支持，
 * 文件级 asm 在 GCC/clang（含 --target=x86_64-pc-windows-msvc）均可编。
 * MSVC cl 无 GNU asm，回落到纯 C 桩（仅前 4 整数参数、不切栈，能力降级）。
 */
#include <stdint.h>

#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))

#if defined(_WIN32)
/* ---------------------------------------------------- Windows x64 (MS ABI) --
 * 入参: RCX=ctx, RDX=target, R8=regs[16]
 * 参数: RCX/RDX/R8/R9 = gpr[1]/[2]/[8]/[9]；第5参数起在 VM 栈 gpr[RSP]+0x20
 * nonvolatile: RBX RBP RDI RSI R12-R15 + XMM6-15
 */
__asm__(
".intel_syntax noprefix\n"
".text\n"
".globl csvm_default_exit\n"
"csvm_default_exit:\n"
"    push rbx\n"
"    push rbp\n"
"    push rdi\n"
"    push rsi\n"
"    push r12\n"
"    push r13\n"
"    push r14\n"
"    push r15\n"
"    sub rsp, 160\n"                       /* XMM6-15 保存区 10*16 */
"    movdqu [rsp+0x00], xmm6\n"
"    movdqu [rsp+0x10], xmm7\n"
"    movdqu [rsp+0x20], xmm8\n"
"    movdqu [rsp+0x30], xmm9\n"
"    movdqu [rsp+0x40], xmm10\n"
"    movdqu [rsp+0x50], xmm11\n"
"    movdqu [rsp+0x60], xmm12\n"
"    movdqu [rsp+0x70], xmm13\n"
"    movdqu [rsp+0x80], xmm14\n"
"    movdqu [rsp+0x90], xmm15\n"
"    mov rbp, rsp\n"                       /* 保存区底 */
"    mov r12, rdx\n"                       /* target */
"    mov r13, r8\n"                        /* regs */
"    sub rsp, 160\n"                       /* 受控宿主调用帧 */
"    and rsp, -16\n"                       /* S = call 前 RSP，16 字节对齐 */
"    /* S+0x00..0x1f = 32B 影子空间；S+0x20.. = 栈参数 */\n"
"    mov rsi, [r13+32]\n"                  /* gpr[X_RSP] X_RSP=4 */
"    add rsi, 0x20\n"                      /* Win: 第5参数在 RSP_call+0x20 */
"    lea rdi, [rsp+0x20]\n"
"    mov rcx, 8\n"
"    cld\n"
"    rep movsq\n"                          /* 搬 8 个栈参数 */
"    mov rcx, [r13+8]\n"                   /* X_RCX=1 */
"    mov rdx, [r13+16]\n"                  /* X_RDX=2 */
"    mov r8,  [r13+64]\n"                  /* X_R8=8 */
"    mov r9,  [r13+72]\n"                  /* X_R9=9 */
"    call r12\n"                           /* 真正执行原生函数 */
"    mov [r13+0],  rax\n"                  /* X_RAX = 返回值 */
"    mov [r13+16], rdx\n"                  /* X_RDX = 第二返回寄存器 */
"    mov rsp, rbp\n"                       /* 切回解释器栈 */
"    movdqu xmm6,  [rsp+0x00]\n"
"    movdqu xmm7,  [rsp+0x10]\n"
"    movdqu xmm8,  [rsp+0x20]\n"
"    movdqu xmm9,  [rsp+0x30]\n"
"    movdqu xmm10, [rsp+0x40]\n"
"    movdqu xmm11, [rsp+0x50]\n"
"    movdqu xmm12, [rsp+0x60]\n"
"    movdqu xmm13, [rsp+0x70]\n"
"    movdqu xmm14, [rsp+0x80]\n"
"    movdqu xmm15, [rsp+0x90]\n"
"    add rsp, 160\n"
"    pop r15\n"
"    pop r14\n"
"    pop r13\n"
"    pop r12\n"
"    pop rsi\n"
"    pop rdi\n"
"    pop rbp\n"
"    pop rbx\n"
"    xor eax, eax\n"                       /* return 0 (成功) */
"    ret\n"
".att_syntax prefix\n"
);

/* 第八批：带 XMM 搬运的 Win x64 VM-exit 桩（修复浮点参数静默算错）。
 * RCX=ctx, RDX=target, R8=regs[16], R9=xmm[16][2]。
 * 把 xmm[0..3] 低 64 位装入 XMM0-3（Win x64 浮点参数与整数参数共用序号），
 * 调用后回读 XMM0/XMM1 到 xmm 数组，RAX/RDX 回 regs。 */
__asm__(
".intel_syntax noprefix\n"
".text\n"
".globl csvm_default_exit_fpu\n"
"csvm_default_exit_fpu:\n"
"    push rbx\n"
"    push rbp\n"
"    push rdi\n"
"    push rsi\n"
"    push r12\n"
"    push r13\n"
"    push r14\n"
"    push r15\n"
"    sub rsp, 160\n"
"    movdqu [rsp+0x00], xmm6\n"
"    movdqu [rsp+0x10], xmm7\n"
"    movdqu [rsp+0x20], xmm8\n"
"    movdqu [rsp+0x30], xmm9\n"
"    movdqu [rsp+0x40], xmm10\n"
"    movdqu [rsp+0x50], xmm11\n"
"    movdqu [rsp+0x60], xmm12\n"
"    movdqu [rsp+0x70], xmm13\n"
"    movdqu [rsp+0x80], xmm14\n"
"    movdqu [rsp+0x90], xmm15\n"
"    mov rbp, rsp\n"
"    mov r12, rdx\n"                       /* target */
"    mov r13, r8\n"                        /* regs */
"    mov r14, r9\n"                        /* xmm */
"    sub rsp, 160\n"
"    and rsp, -16\n"
"    mov rsi, [r13+32]\n"                  /* gpr[X_RSP]，第5参数在 +0x20 */
"    add rsi, 0x20\n"
"    lea rdi, [rsp+0x20]\n"
"    mov rcx, 8\n"
"    cld\n"
"    rep movsq\n"
"    movq xmm0, [r14+0x00]\n"
"    movq xmm1, [r14+0x10]\n"
"    movq xmm2, [r14+0x20]\n"
"    movq xmm3, [r14+0x30]\n"
"    mov rcx, [r13+8]\n"                   /* X_RCX=1 */
"    mov rdx, [r13+16]\n"                  /* X_RDX=2 */
"    mov r8,  [r13+64]\n"                  /* X_R8=8 */
"    mov r9,  [r13+72]\n"                  /* X_R9=9 */
"    call r12\n"
"    mov [r13+0],  rax\n"
"    mov [r13+16], rdx\n"
"    movq [r14+0x00], xmm0\n"              /* XMM0 返回值 */
"    movq [r14+0x10], xmm1\n"
"    mov rsp, rbp\n"
"    movdqu xmm6,  [rsp+0x00]\n"
"    movdqu xmm7,  [rsp+0x10]\n"
"    movdqu xmm8,  [rsp+0x20]\n"
"    movdqu xmm9,  [rsp+0x30]\n"
"    movdqu xmm10, [rsp+0x40]\n"
"    movdqu xmm11, [rsp+0x50]\n"
"    movdqu xmm12, [rsp+0x60]\n"
"    movdqu xmm13, [rsp+0x70]\n"
"    movdqu xmm14, [rsp+0x80]\n"
"    movdqu xmm15, [rsp+0x90]\n"
"    add rsp, 160\n"
"    pop r15\n"
"    pop r14\n"
"    pop r13\n"
"    pop r12\n"
"    pop rsi\n"
"    pop rdi\n"
"    pop rbp\n"
"    pop rbx\n"
"    xor eax, eax\n"
"    ret\n"
".att_syntax prefix\n"
);

#else
/* -------------------------------------------------- System V AMD64 (Linux) --
 * 入参: RDI=ctx, RSI=target, RDX=regs[16]
 * 参数: RDI/RSI/RDX/RCX/R8/R9 = gpr[7]/[6]/[2]/[1]/[8]/[9]；第7参数起在
 *       VM 栈 gpr[X_RSP]+0x00（SysV 无影子空间）
 * nonvolatile: RBX RBP R12-R15（XMM 全 volatile，无需保存）
 */
__asm__(
".intel_syntax noprefix\n"
".text\n"
".globl csvm_default_exit\n"
"csvm_default_exit:\n"
"    push rbx\n"
"    push rbp\n"
"    push r12\n"
"    push r13\n"
"    push r14\n"
"    push r15\n"
"    mov rbp, rsp\n"                       /* 保存区底 */
"    mov r12, rsi\n"                       /* target */
"    mov r13, rdx\n"                       /* regs */
"    sub rsp, 160\n"                       /* 受控宿主调用帧 */
"    and rsp, -16\n"                       /* S = call 前 RSP，16 字节对齐 */
"    /* SysV 无影子空间，第7参数在 [S+0x00] */\n"
"    mov rsi, [r13+32]\n"                  /* gpr[X_RSP] */
"    lea rdi, [rsp+0x00]\n"
"    mov rcx, 8\n"
"    cld\n"
"    rep movsq\n"                          /* 搬 8 个栈参数 */
"    mov rdi, [r13+56]\n"                  /* X_RDI=7 */
"    mov rsi, [r13+48]\n"                  /* X_RSI=6 */
"    mov rdx, [r13+16]\n"                  /* X_RDX=2 */
"    mov rcx, [r13+8]\n"                   /* X_RCX=1 */
"    mov r8,  [r13+64]\n"                  /* X_R8=8 */
"    mov r9,  [r13+72]\n"                  /* X_R9=9 */
"    xor eax, eax\n"                       /* AL=0：不使用向量变参寄存器 */
"    call r12\n"                           /* 真正执行原生函数 */
"    mov [r13+0],  rax\n"                  /* X_RAX = 返回值 */
"    mov [r13+16], rdx\n"                  /* X_RDX = 第二返回寄存器 */
"    mov rsp, rbp\n"                       /* 切回解释器栈 */
"    pop r15\n"
"    pop r14\n"
"    pop r13\n"
"    pop r12\n"
"    pop rbp\n"
"    pop rbx\n"
"    xor eax, eax\n"
"    ret\n"
".att_syntax prefix\n"
);

/* 第八批：带 XMM 搬运的 SysV AMD64 VM-exit 桩。
 * RDI=ctx, RSI=target, RDX=regs[16], RCX=xmm[16][2]。
 * 把 xmm[0..7] 低 64 位装入 XMM0-7（SysV 浮点参数独立编号），AL=8 声明
 * 使用向量寄存器；调用后回读 XMM0/XMM1 到 xmm 数组，RAX/RDX 回 regs。 */
__asm__(
".intel_syntax noprefix\n"
".text\n"
".globl csvm_default_exit_fpu\n"
"csvm_default_exit_fpu:\n"
"    push rbx\n"
"    push rbp\n"
"    push r12\n"
"    push r13\n"
"    push r14\n"
"    push r15\n"
"    mov rbp, rsp\n"
"    mov r12, rsi\n"                       /* target */
"    mov r13, rdx\n"                       /* regs */
"    mov r14, rcx\n"                       /* xmm */
"    sub rsp, 160\n"
"    and rsp, -16\n"
"    mov rsi, [r13+32]\n"                  /* gpr[X_RSP]，SysV 第7参数在 +0 */
"    lea rdi, [rsp+0x00]\n"
"    mov rcx, 8\n"
"    cld\n"
"    rep movsq\n"
"    movq xmm0, [r14+0x00]\n"
"    movq xmm1, [r14+0x10]\n"
"    movq xmm2, [r14+0x20]\n"
"    movq xmm3, [r14+0x30]\n"
"    movq xmm4, [r14+0x40]\n"
"    movq xmm5, [r14+0x50]\n"
"    movq xmm6, [r14+0x60]\n"
"    movq xmm7, [r14+0x70]\n"
"    mov rdi, [r13+56]\n"                  /* X_RDI=7 */
"    mov rsi, [r13+48]\n"                  /* X_RSI=6 */
"    mov rdx, [r13+16]\n"                  /* X_RDX=2 */
"    mov rcx, [r13+8]\n"                   /* X_RCX=1 */
"    mov r8,  [r13+64]\n"                  /* X_R8=8 */
"    mov r9,  [r13+72]\n"                  /* X_R9=9 */
"    mov eax, 8\n"                         /* AL=8 向量参数寄存器数 */
"    call r12\n"
"    mov [r13+0],  rax\n"
"    mov [r13+16], rdx\n"
"    movq [r14+0x00], xmm0\n"              /* XMM0 返回值 */
"    movq [r14+0x10], xmm1\n"
"    mov rsp, rbp\n"
"    pop r15\n"
"    pop r14\n"
"    pop r13\n"
"    pop r12\n"
"    pop rbp\n"
"    pop rbx\n"
"    xor eax, eax\n"
"    ret\n"
".att_syntax prefix\n"
);
#endif

#else
/* ----------------------------------------------------- 无 GNU asm 时回落 --
 * 纯 C 桩：只覆盖前 4 个整数参数、不切栈、不保存 XMM。仅作为极端工具链的
 * 兜底；注意 codevm.c 还依赖 __int128 与 GNU 内联 asm，原版 MSVC cl 无法
 * 编译完整内核，正式 Windows 构建请用 MinGW-w64 gcc（build.bat）或
 * build-win.sh 交叉产物。
 */
typedef uint64_t (*csvm_fn4)(uint64_t, uint64_t, uint64_t, uint64_t);
int csvm_default_exit(void *ctx, uint64_t target, uint64_t regs[16]) {
    (void)ctx;
    if (!target) return -1;
    csvm_fn4 fn = (csvm_fn4)(uintptr_t)target;
    regs[0] = fn(regs[1], regs[2], regs[8], regs[9]);  /* Win x64 前 4 参数 */
    return 0;
}
/* 无 GNU asm 的工具链无法安全搬运 XMM：明确返回失败，让解释器 TRAP，
   绝不「调用成功但浮点参数没搬」静默给出错答案。 */
int csvm_default_exit_fpu(void *ctx, uint64_t target,
                           uint64_t regs[16], uint64_t xmm[16][2]) {
    (void)ctx; (void)target; (void)regs; (void)xmm;
    return -1;
}
#endif
