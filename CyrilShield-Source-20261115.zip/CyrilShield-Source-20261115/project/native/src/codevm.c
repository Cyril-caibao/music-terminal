/* CyrilShield Code Virtualization Kernel — C11，零第三方依赖
 *
 * 链路：x86-64 机器码 -> 反汇编(raw) -> 语义提升(IR) -> 私有 ISA 字节码 -> 解释器
 *
 * 与 vmgen.py / dexvm.py 的区别（重要）：
 *   那些模块虚拟化的是「壳自己的引导链」，输入是构建期生成的固定序列；
 *   本文件虚拟化的是**目标函数真实机器码**，输入是从 ELF/PE 抽取的 x86 字节。
 *   这才是 VMP 意义上的「代码虚拟化」，尽管只覆盖受限子集。
 *
 * v2 集成层：宿主真实内存模式 + RIP 相对寻址 + MUL/DIV，供 PE/ELF
 * 集成器把目标函数头改写成 jmp VM stub 后接管执行。
 * v4（第七批）：FF/4 间接跳转 + 标量 SSE 子集 + XMM 寄存器文件。
 *   bc_t 扩到 40 字节（新增 src_off=指令起始字节偏移，供函数内间接跳转
 *   把宿主目标地址回填为 bc 索引，在 VM 内闭环）；bc_hdr_t.reserved 复用为
 *   原始机器码长度（判定间接跳转目标是否落在函数体内）。
 *   布局破坏性变更：CSVM_MAGIC 由 v2 bump 到 v4、CSVM_ABI_VERSION 1→2，
 *   旧 v2 字节码按魔数直接拒绝，避免被 40B 步长静默误读。
 * 明确不做：AMSI/ETW 补丁、进程注入、驱动、反 EDR、packed 浮点算术。
 */
#include "cs_codevm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stdint.h>

/* ---- v3.3.5：computed-goto 间接分派 ----------------------------------
 * GNU C / clang 都支持 labels-as-values（build.bat 的 MinGW-w64 gcc、
 * build-win.sh 的 clang、zig cc 同属此类），实际交付内核一律走这条：
 * 中心 switch 消失，分派表经 per-run 密钥逐 op 异或，.rdata 里不留明文
 * handler 地址表。只有不支持该扩展的编译器（MSVC cl）才退回中心 switch，
 * 用 -DCSVM_FORCE_SWITCH 可强制回退做对照测试（诚实标注，不虚标能力）。 */
#if (defined(__GNUC__) || defined(__clang__)) && !defined(CSVM_FORCE_SWITCH)
#  define CSVM_USE_CG 1
#endif
#if defined(CSVM_USE_CG)
static uintptr_t csvm_cg_mask(uint8_t op, uint64_t key) {
    uint64_t x = key ^ ((uint64_t)op * 0x9E3779B97F4A7C15ULL)
                     ^ ((uint64_t)op << 17);
    x ^= x >> 29; x *= 0xBF58476D1CE4E5B9ULL; x ^= x >> 32;
    return (uintptr_t)x;
}
#endif

/* VM-exit 异常安全网（信号机制）仅 POSIX 平台可用。Windows 交叉编译环境
   （clang + mingw 头）下 setjmp.h 可用，但 SEH 应走 Windows 自身机制，
   这里统一用桩实现保持 ABI 一致；真机 SEH 属诚实边界（见文档）。 */
#if !defined(_WIN32) && !defined(__MINGW32__) && !defined(CSVM_NO_SIGNAL_GUARD)
#define CSVM_SIGNAL_GUARD 1
#include <setjmp.h>
#include <signal.h>
#include <pthread.h>
#endif

/* 线程局部存储的存储类。MSVC 用 __declspec(thread)；clang / MinGW 不认该
   属性（报 unknown attribute 并**静默忽略**，线程局部变量会退化成进程共享
   全局——多线程上下文池与 guard 帧栈互相踩）。这里按编译器分派。
   限制：DLL 动态加载时 native TLS 不回溯已存在的线程，故本库应尽早加载；
   运行期再 LoadLibrary 时池会退化为共享（仍安全，仅复用率下降）。 */
#if defined(_MSC_VER)
#  define CSVM_TLS __declspec(thread)
#else
#  define CSVM_TLS __thread
#endif

/* 每线程 VM 上下文池：POSIX 用 pthread_key，Windows 用 FLS（FlsAlloc 允许
   线程退出回调，pthread_key 在 Windows 上不存在）。 */
#if (defined(_WIN32) || defined(__MINGW32__)) && !defined(CSVM_NO_CRT)
/* 需要真实 Windows 头与 kernel32 导入：MinGW（build.bat）与常规 MSVC 构建走这条；
   clang --target=windows-msvc + /noentry 的无 CRT 精简 DLL（build-win.sh）拿不到
   windows.h/Fls/VEH，退回 calloc 直通 + 安全网桩，行为与第八批一致（见文档边界）。 */
#include <windows.h>
#define CSVM_WIN_TLS 1
#define CSVM_VEH_GUARD 1     /* 第十批：Windows 异常安全网走 VEH */
#else
#include <pthread.h>
#define CSVM_TLS_POOL 1
#endif

/* clang --target=x86_64-pc-windows-msvc + lld-link /noentry 的自包含 DLL
   一旦使用 float/double，编译器会引用 _fltused 标记；该 DLL 没有 CRT 提供
   该符号，故用 CSVM_NO_CRT 精确限定后自定义。x86-64 上浮点运算本就走 SSE
   标量指令，不需要 CRT 浮点初始化。
   build.bat（MinGW-w64）链接的是完整 CRT，_fltused 由 CRT 提供；若这里再
   定义一次会重复符号。因此必须靠构建宏区分，不能只判断 _WIN32。 */
#if defined(_WIN32) && defined(CSVM_NO_CRT)
int _fltused = 0;
#endif

/* exit_trampoline.c 提供的平台默认 VM-exit 上下文切换桩（同库内链接，非导出）。
   第八批新增带 XMM 搬运的 fpu 桩：修复「浮点参数/返回跨 VM-exit 静默算错」。 */
extern int csvm_default_exit(void *ctx, uint64_t target, uint64_t regs[16]);
extern int csvm_default_exit_fpu(void *ctx, uint64_t target,
                                 uint64_t regs[16], uint64_t xmm[16][2]);

/* ------------------------------------------------------------------ 基础 */

/* x86-64 GPR 编号（Intel 顺序） */
enum { X_RAX=0, X_RCX, X_RDX, X_RBX, X_RSP, X_RBP, X_RSI, X_RDI,
       X_R8, X_R9, X_R10, X_R11, X_R12, X_R13, X_R14, X_R15 };

/* 标志位打包 */
#define F_ZF (1u<<0)
#define F_SF (1u<<1)
#define F_CF (1u<<2)
#define F_OF (1u<<3)
#define F_PF (1u<<4)
#define F_AF (1u<<5)
#define F_DF (1u<<6)   /* v5：方向标志，供 REP 字符串指令决定 RSI/RDI 增减 */

#define VM_MEM_SIZE   (64u*1024u)
#define VM_STACK_TOP  ((uint64_t)0xF000)
#define RET_SENTINEL  (~(uint64_t)0)
#define NOISE_SLOTS   32
#define OPC_NONE      0xFFu

typedef struct {
    uint64_t s;
} prng_t;

static uint64_t pr_next(prng_t *p) {
    uint64_t x = p->s;
    if (!x) x = 0x9e3779b97f4a7c15ULL;
    x ^= x >> 12; x ^= x << 25; x ^= x >> 27;
    p->s = x;
    return x * 0x2545F4914F6CDD1DULL;
}
static uint32_t pr_below(prng_t *p, uint32_t n) {
    return n ? (uint32_t)(pr_next(p) % n) : 0;
}
static void pr_shuffle8(prng_t *p, uint8_t *a, uint32_t n) {
    for (uint32_t i = n; i > 1; --i) {
        uint32_t j = pr_below(p, i);
        uint8_t t = a[i-1]; a[i-1] = a[j]; a[j] = t;
    }
}

static void set_err(char *err, size_t cap, const char *fmt, ...) {
    if (!err || !cap) return;
    va_list ap; va_start(ap, fmt);
    vsnprintf(err, cap, fmt, ap);
    va_end(ap);
}

/* --------------------------------------------------------------- 反汇编层 */

typedef struct {
    uint32_t off, len;
    uint8_t  opc, opc2;
    int      has_0f, has_66, has_f2, has_f3, has_rex, has_f0;
    int      rex_w, rex_r, rex_x, rex_b;
    int      has_modrm, mod, reg, rm;
    int      has_sib, sib_base, sib_index, sib_scale;
    int      has_disp;
    int64_t  disp;
    int      has_imm, imm_size;
    uint64_t imm;
    int64_t  simm;
    int      width;
    int      rip_rel;
    int      sib_nobase;   /* 第十批：SIB 且 mod=0 且 base=101 -> 无基址（绝对 disp32） */
    uint8_t  bytes[16];
} raw_t;

/* 本内核支持的指令所需立即数宽度（字节）。0 表示无立即数。 */
static int imm_size_for(const raw_t *r) {
    uint8_t o = r->opc;
    if (r->has_0f) {
        if (r->opc2 >= 0x80 && r->opc2 <= 0x8F) return 4; /* Jcc rel32 */
        if (r->opc2 == 0x70) return 1;                   /* pshufd imm8 */
        return 0;
    }
    if (o >= 0xB8 && o <= 0xBF) return r->rex_w ? 8 : 4;
    if (o >= 0x70 && o <= 0x7F) return 1;
    if (o >= 0xB0 && o <= 0xB7) return 1;
    switch (o) {
        case 0xEB: case 0x6A: case 0xA8: case 0xC6: case 0x80:
        case 0x83: case 0x6B: case 0xC1: case 0xC0: case 0xD4:
            return 1;
        case 0xE8: case 0xE9: case 0x81: case 0xC7: case 0x69:
        case 0xA9: case 0x3D: case 0x05: case 0x0D: case 0x15:
        case 0x1D: case 0x25: case 0x2D: case 0x35: case 0xC8:
            return 4;
        default: return 0;
    }
}

static int64_t read_simm(const uint8_t *p, int size) {
    if (size == 1) return (int8_t)p[0];
    if (size == 2) { int16_t v; memcpy(&v, p, 2); return v; }
    if (size == 8) { int64_t v; memcpy(&v, p, 8); return v; }
    int32_t v; memcpy(&v, p, 4); return v;
}

/* 解码单条指令；返回长度，0 表示失败。 */
static int decode_one(const uint8_t *buf, size_t n, uint32_t off,
                      raw_t *r, char *err, size_t cap) {
    memset(r, 0, sizeof(*r));
    r->off = off;
    size_t start = off, pos = off;
    int prefix_2e = 0;

    /* 前缀 */
    for (;;) {
        if (pos >= n) { set_err(err, cap, "偏移 %u: 前缀后截断", off); return 0; }
        uint8_t b = buf[pos];
        if (b >= 0x40 && b <= 0x4F) {
            r->has_rex = 1;
            r->rex_w = (b >> 3) & 1; r->rex_r = (b >> 2) & 1;
            r->rex_x = (b >> 1) & 1; r->rex_b = b & 1;
            pos++; continue;
        }
        if (b == 0x66) { r->has_66 = 1; pos++; continue; }
        if (b == 0xF2) { r->has_f2 = 1; pos++; continue; }
        if (b == 0xF3) { r->has_f3 = 1; pos++; continue; }
        if (b == 0xF0) { r->has_f0 = 1; pos++; continue; }  /* LOCK */
        if (b == 0x2E || b == 0x36 || b == 0x3E || b == 0x26 ||
            b == 0x64 || b == 0x65 || b == 0x67) {
            if (b == 0x2E) prefix_2e = 1;
            pos++; continue;
        }
        break;
    }
    if (pos >= n) { set_err(err, cap, "偏移 %u: 无操作码", off); return 0; }

    r->opc = buf[pos++];
    if (r->opc == 0x0F) {
        if (pos >= n) { set_err(err, cap, "偏移 %u: 0F 后截断", off); return 0; }
        r->has_0f = 1; r->opc2 = buf[pos++];
    }
    r->width = r->rex_w ? 64 : (r->has_66 ? 16 : 32);

    /* 判断是否需要 ModRM：白名单，只覆盖本内核支持的指令 */
    int need_modrm = 0;
    if (r->has_0f) {
        uint8_t o = r->opc2;
        int sse = (o >= 0x10 && o <= 0x17) || (o >= 0x28 && o <= 0x2F) ||
                  (o >= 0x50 && o <= 0x5F) || (o >= 0x6E && o <= 0x7F) ||
                  o == 0xD6 || o == 0xEF ||
                  /* 打包整数 SIMD + pshufd / packssdw（v9），全部带 ModRM */
                  o == 0xDB || o == 0xEB || o == 0xDF || o == 0xD4 ||
                  (o >= 0x70 && o <= 0x76) || (o >= 0xFC && o <= 0xFE) ||
                  (o >= 0xF8 && o <= 0xFB) || o == 0x6B;
        int atomic_0f = (o == 0xB0 || o == 0xB1 ||   /* CMPXCHG r/m8,r / r/m,r */
                         o == 0xC0 || o == 0xC1 ||   /* XADD */
                         o == 0xAB || o == 0xB3 || o == 0xBB); /* BTS/BTR/BTC */
        need_modrm = (o == 0xAF || (o >= 0x40 && o <= 0x4F) ||
                      (o >= 0x90 && o <= 0x9F) ||
                      (o >= 0xB6 && o <= 0xBF) || o == 0x1F || o == 0x1E ||
                      atomic_0f || sse);
    } else {
        switch (r->opc) {
            case 0x01: case 0x03: case 0x09: case 0x0B:
            case 0x21: case 0x23: case 0x29: case 0x2B:
            case 0x31: case 0x33: case 0x39: case 0x3B:
            case 0x85: case 0x89: case 0x8B: case 0x8D:
            case 0x81: case 0x83: case 0x80: case 0xC1: case 0xD1:
            case 0xD3: case 0xC0: case 0xC7: case 0xC6: case 0x69:
            case 0x6B: case 0xFF: case 0xF7: case 0xF6: case 0x8F:
            case 0x63:                          /* MOVSXD r64, r/m32 */
            case 0x86: case 0x87:               /* XCHG（隐含 LOCK） */
            case 0xFE:                          /* LOCK INC/DEC r/m8 */
                need_modrm = 1; break;
            default: break;
        }
    }

    if (need_modrm) {
        if (pos >= n) { set_err(err, cap, "偏移 %u: ModRM 截断", off); return 0; }
        uint8_t m = buf[pos++];
        r->has_modrm = 1;
        r->mod = m >> 6;
        r->reg = ((m >> 3) & 7) | (r->rex_r << 3);
        r->rm  = (m & 7);
        if (r->mod != 3) {
            if (r->rm == 4) {
                if (pos >= n) { set_err(err, cap, "偏移 %u: SIB 截断", off); return 0; }
                uint8_t s = buf[pos++];
                r->has_sib = 1;
                r->sib_scale = 1 << (s >> 6);
                r->sib_index = ((s >> 3) & 7) | (r->rex_x << 3);
                if (r->mod == 0 && (s & 7) == 5) {
                    /* x86-64：mod=00 + SIB base=101 表示「无基址」，地址 = index*scale + disp32。
                       REX.B 不改变这条规则（r13 也走无基址形式）。 */
                    r->sib_nobase = 1;
                    r->sib_base = 255;
                    if (pos + 4 > n) { set_err(err, cap, "偏移 %u: disp32 截断", off); return 0; }
                    r->disp = read_simm(buf + pos, 4); r->has_disp = 1; pos += 4;
                } else {
                    r->sib_base = (s & 7) | (r->rex_b << 3);
                }
            } else if (r->mod == 0 && r->rm == 5) {
                if (pos + 4 > n) { set_err(err, cap, "偏移 %u: RIP 相对 disp 截断", off); return 0; }
                r->disp = read_simm(buf + pos, 4); r->has_disp = 1; pos += 4;
                r->rm = 255; r->rip_rel = 1; /* 运行时按 base+next_off+disp 解析 */
            }
            if (r->mod == 1) {
                if (pos + 1 > n) { set_err(err, cap, "偏移 %u: disp8 截断", off); return 0; }
                r->disp = read_simm(buf + pos, 1); r->has_disp = 1; pos += 1;
            } else if (r->mod == 2) {
                if (pos + 4 > n) { set_err(err, cap, "偏移 %u: disp32 截断", off); return 0; }
                r->disp = read_simm(buf + pos, 4); r->has_disp = 1; pos += 4;
            }
        }
    }

    int isz = imm_size_for(r);
    if (isz) {
        if ((size_t)(pos + isz) > n) { set_err(err, cap, "偏移 %u: 立即数截断", off); return 0; }
        r->has_imm = 1; r->imm_size = isz;
        r->simm = read_simm(buf + pos, isz);
        memcpy(&r->imm, buf + pos, isz < 8 ? (size_t)isz : 8u);
        if (isz < 8) { /* 零填充高字节 */ }
        pos += isz;
    }

    r->len = (uint32_t)(pos - start);
    if (r->len > sizeof(r->bytes)) r->len = sizeof(r->bytes);
    memcpy(r->bytes, buf + start, r->len);
    (void)prefix_2e;
    return (int)(pos - start);
}

/* ------------------------------------------------------------ 语义提升 IR */

enum {
    IR_NOP=0, IR_MOV, IR_MOVZX, IR_MOVSX, IR_LEA,
    IR_ADD, IR_SUB, IR_XOR, IR_AND, IR_OR, IR_CMP, IR_TEST,
    IR_INC, IR_DEC, IR_NEG, IR_NOT, IR_IMUL, IR_IMUL3,
    IR_SHL, IR_SHR, IR_SAR, IR_ROL, IR_ROR,
    IR_PUSH, IR_POP, IR_JMP, IR_JCC, IR_CALL, IR_RET,
    IR_CMOV, IR_SETCC,
    IR_MUL, IR_IMUL1, IR_DIV, IR_IDIV, IR_CQO,
    IR_CALLEXT,               /* VM-exit：调用字节码外的原生函数（L1/L2 桥） */
    IR_JMPI,                  /* FF/4 间接跳转：函数内=VM 内闭环，函数外=tail-exit */
    IR_FSSE,                  /* 标量 SSE：子操作码存 bc_t.exit_kind(FOP_*) */
    IR_REP,                   /* v5：REP 字符串指令（movs/stos/cmps/scas） */
    IR_TAILEXIT,              /* v5：直接 jmp rel32 到 CFG 闭包外 -> VM-exit tail */
    IR_SETDF,                 /* v5：cld/std 设置方向标志 F_DF */
    IR_ATOMIC,                /* v3.3.5：LOCK 前缀原子 RMW */
    IR_TRAP, IR_HALT, IR_COUNT
};

/* IR_ATOMIC 子操作码（存 bc_t.exit_kind）；ALU 族的具体运算存 bc_t.cc
   （= ModRM.reg 扩展：0 ADD / 1 OR / 2 ADC / 3 SBB / 4 AND / 5 SUB /
   6 XOR / 7 CMP），位操作族的 cc = 0 BTS / 1 BTR / 2 BTC。 */
enum {
    AT_CMPXCHG=1, AT_XADD, AT_XCHG, AT_ALU, AT_BIT, AT_UNARY
};

/* IR_REP 子操作码（存 bc_t.rep_kind 低 7 位）；宽度存 bc_t.width，
   repz/repnz 存 bc_t.cc；bit7 表示带 REP 前缀（循环 RCX 次）。 */
enum {
    REP_MOVS=1, REP_STOS, REP_CMPS, REP_SCAS
};
#define REP_LOOP 0x80u
/* cc 的 rep 条件 */
#define REPCC_ALWAYS 0
#define REPCC_REPE   1        /* F3 + cmps/scas：ZF=1 继续 */
#define REPCC_REPNE  2        /* F2 + cmps/scas：ZF=0 继续 */

/* IR_FSSE 子操作码（存 bc_t.exit_kind）。标量 SS/SD + 整寄存器位运算，
 * packed 逐 lane 算术不在子集内。 */
enum {
    FOP_MOV=1, FOP_ADD, FOP_SUB, FOP_MUL, FOP_DIV, FOP_SQRT,
    FOP_MIN, FOP_MAX, FOP_AND, FOP_XOR,
    FOP_I2F, FOP_F2I, FOP_CVTSS2SD, FOP_CVTSD2SS, FOP_CMP,
    FOP_MOVG2X, FOP_MOVX2G,
    /* v9：打包整数 SIMD（packed lanes over 128-bit XMM） */
    FOP_PINT,        /* 通用打包整数运算，op+宽度编码在 ir->int_width 低字节 */
    FOP_PSHUFD,      /* 按 imm8 重排 4 个 dword */
    FOP_PACKSSDW     /* 4 个 dword 饱和打包为 4 个 word（高 64 位清零） */
};
/* FOP_PINT 的 int_width 编码：(op<<4) | 宽度码（0=B 1=W 2=D 3=Q） */
#define PINT_OP(x)   ((uint8_t)((x) >> 4))
#define PINT_LW(x)   ((uint8_t)((x) & 0xF))
enum {
    PINT_ADD=0, PINT_SUB, PINT_AND, PINT_OR, PINT_XOR, PINT_ANDN, PINT_CMPEQ
};
#define SRC_OFF_NONE 0xFFFFFFFFu   /* 垃圾指令/标签的 src_off 哨兵 */

enum { OK_NONE=0, OK_REG, OK_IMM, OK_MEM, OK_LABEL, OK_RIPREL, OK_XMM };

typedef struct {
    uint8_t  kind, width, reg, base, index, scale;
    int64_t  imm, disp;
} oper_t;

typedef struct {
    uint8_t  op, cc, width;
    uint32_t off, len;
    oper_t   a, b, c;
    uint32_t target_off;
    int32_t  target_idx;
    uint8_t  exit_kind;      /* CALLEXT/JMPI 目标类型；IR_FSSE 时存 FOP_* */
    uint8_t  int_width;      /* IR_FSSE：整数操作宽度 32/64（REX.W） */
    uint8_t  rep_kind;       /* IR_REP：REP_MOVS/STOS/CMPS/SCAS */
} ir_t;

static oper_t op_none(void) { oper_t o; memset(&o, 0, sizeof(o)); return o; }
static oper_t op_reg(uint8_t reg, uint8_t width) {
    oper_t o = op_none(); o.kind = OK_REG; o.reg = reg; o.width = width; return o;
}
static oper_t op_imm(int64_t v, uint8_t width) {
    oper_t o = op_none(); o.kind = OK_IMM; o.imm = v; o.width = width; return o;
}

/* 从 ModRM 构造 rm 操作数。返回 0 表示需要 TRAP（RIP 相对 / 未知寻址）。 */
static int mk_rm(const raw_t *r, oper_t *o, uint8_t width) {
    memset(o, 0, sizeof(*o));
    o->width = width;
    if (r->mod == 3) {
        o->kind = OK_REG;
        o->reg = (uint8_t)(r->rm | (r->rex_b << 3));
        return 1;
    }
    if (r->rm == 255) {
        if (!r->rip_rel) return 0;
        o->kind = OK_RIPREL;
        o->disp = r->has_disp ? r->disp : 0;
        return 1;
    }
    o->kind = OK_MEM;
    o->base = r->has_sib ? (uint8_t)r->sib_base : (uint8_t)(r->rm | (r->rex_b << 3));
    o->index = r->has_sib ? (uint8_t)r->sib_index : 255;
    o->scale = r->has_sib ? (uint8_t)r->sib_scale : 1;
    o->disp = r->has_disp ? r->disp : 0;
    /* SIB index=4 (无索引) 在 x86-64 下不用 REX.X 扩展 */
    if (r->has_sib && ((r->sib_index & 7) == 4) && !r->rex_x) o->index = 255;
    return 1;
}

/* XMM 操作数（reg 字段为 XMM 编号 0-15，不参与 GPR 槽置换） */
static oper_t op_xmm(uint8_t reg, uint8_t width) {
    oper_t o = op_none(); o.kind = OK_XMM; o.reg = reg; o.width = width; return o;
}
/* 同 mk_rm，但 mod==3 时 rm 解释为 XMM 寄存器（SSE 指令语义） */
static int mk_rm_xmm(const raw_t *r, oper_t *o, uint8_t width) {
    memset(o, 0, sizeof(*o));
    o->width = width;
    if (r->mod == 3) {
        o->kind = OK_XMM; o->reg = (uint8_t)(r->rm | (r->rex_b << 3)); return 1;
    }
    if (r->rm == 255) {
        if (!r->rip_rel) return 0;
        o->kind = OK_RIPREL; o->disp = r->has_disp ? r->disp : 0; return 1;
    }
    o->kind = OK_MEM;
    o->base = r->has_sib ? (uint8_t)r->sib_base : (uint8_t)(r->rm | (r->rex_b << 3));
    o->index = r->has_sib ? (uint8_t)r->sib_index : 255;
    o->scale = r->has_sib ? (uint8_t)r->sib_scale : 1;
    o->disp = r->has_disp ? r->disp : 0;
    if (r->has_sib && ((r->sib_index & 7) == 4) && !r->rex_x) o->index = 255;
    return 1;
}

static const char *ir_name(uint8_t op) {
    static const char *n[] = {
        "NOP","MOV","MOVZX","MOVSX","LEA","ADD","SUB","XOR","AND","OR",
        "CMP","TEST","INC","DEC","NEG","NOT","IMUL","IMUL3","SHL","SHR",
        "SAR","ROL","ROR","PUSH","POP","JMP","JCC","CALL","RET","CMOV",
        "SETCC","MUL","IMUL1","DIV","IDIV","CQO","CALLEXT","JMPI","FSSE",
        "REP","TAILEXIT","SETDF","ATOMIC","TRAP","HALT"
    };
    return op < IR_COUNT ? n[op] : "?";
}

/* 把一条 raw 指令提升为 1 条 IR（个别展开为多条时由调用方处理）。 */
static int lift_one(const raw_t *r, ir_t *ir, char *err, size_t cap) {
    memset(ir, 0, sizeof(*ir));
    ir->op = IR_TRAP; ir->width = (uint8_t)r->width;
    ir->off = r->off; ir->len = r->len; ir->target_idx = -1;
    uint8_t w = (uint8_t)r->width;
    uint8_t o = r->opc;

#define FAIL(...) do { set_err(err, cap, __VA_ARGS__); return 0; } while (0)
#define RM_ONLY(dst, src) do { if (!mk_rm(r, &(dst), w)) FAIL("偏移 %u: 不支持 RIP 相对寻址", r->off); \
                               (src) = op_reg((uint8_t)r->reg, w); } while (0)

    /* 多字节 NOP / ENDBR64 / 对齐填充：语义等价于空操作 */
    if (r->has_0f && r->opc2 == 0x1F) { ir->op = IR_NOP; return 1; }
    if (r->has_0f && r->opc2 == 0x1E && r->has_f3) { ir->op = IR_NOP; return 1; }
    if (o == 0x90) { ir->op = IR_NOP; return 1; }

    /* ---- v3.3.5：LOCK 前缀原子 RMW -------------------------------
     * 只接受「目的为内存、无索引寄存器」的形式：VM 需对真实/模拟内存
     * 做单次原子 RMW，带 index 的寻址无法在编译期静态绑定基址，明确拒绝
     * 而不是静默按非原子语义执行。XCHG 对内存操作数隐含 LOCK，故无需 F0。
     * 8/16 位原子在子集外（见 exec 侧 TRAP 说明）。 */
    if (r->has_f0 || (!r->has_0f && (o == 0x86 || o == 0x87))) {
        uint8_t sub = 0, cc = 0;
        int two_operand = 1;
        if (r->has_0f) {
            uint8_t o2 = r->opc2;
            if      (o2 == 0xB0 || o2 == 0xB1) sub = AT_CMPXCHG;
            else if (o2 == 0xC0 || o2 == 0xC1) sub = AT_XADD;
            else if (o2 == 0xAB || o2 == 0xB3 || o2 == 0xBB) {
                sub = AT_BIT; cc = (uint8_t)(o2 == 0xAB ? 0 : (o2 == 0xB3 ? 1 : 2));
            } else FAIL("偏移 %u: 不支持的 LOCK 0F %02X 原子指令", r->off, o2);
        } else if (o == 0x86 || o == 0x87) {
            sub = AT_XCHG;
        } else if (o == 0x80 || o == 0x81 || o == 0x83) {
            sub = AT_ALU; cc = (uint8_t)(r->reg & 7); two_operand = 0;
        } else if (o == 0xFE || o == 0xFF || o == 0xF6 || o == 0xF7) {
            sub = AT_UNARY; cc = (uint8_t)(r->reg & 7); two_operand = 0;
        } else if (o == 0x01 || o == 0x09 || o == 0x11 || o == 0x19 ||
                   o == 0x21 || o == 0x29 || o == 0x31 || o == 0x33) {
            static const uint8_t alu_cc[] = {0,1,2,3,4,5,6,7};
            uint8_t idx = (uint8_t)((o >> 3) & 7);
            sub = AT_ALU; cc = alu_cc[idx];
        } else {
            FAIL("偏移 %u: 不支持的 LOCK %02X 原子指令", r->off, o);
        }
        if (r->mod == 3) FAIL("偏移 %u: 原子指令目的必须是内存操作数", r->off);
        /* 字节形式（0x80/86/FE、0F B0/C0）不带 REX.W 也会是 byte 操作数，
           而 raw_t.width 默认 32；不按操作码纠正会把 8 位原子静默按 32 位
           执行（破坏相邻 3 字节）。16 位（66）保留识别，由运行期明确 TRAP。 */
        uint8_t aw = w;
        if (o == 0x80 || o == 0x86 || o == 0xFE ||
            (r->has_0f && (r->opc2 == 0xB0 || r->opc2 == 0xC0))) aw = 8;
        if (r->has_sib && r->sib_index != 255)
            FAIL("偏移 %u: 原子指令暂不支持带索引寄存器的寻址", r->off);
        if (!r->has_sib && (r->rm | (r->rex_b << 3)) == 255 && !r->rip_rel)
            FAIL("偏移 %u: 原子指令需要有效基址", r->off);
        oper_t rm;
        if (!mk_rm(r, &rm, aw)) FAIL("偏移 %u: 原子指令不支持该寻址", r->off);
        ir->op = IR_ATOMIC; ir->exit_kind = sub; ir->cc = cc; ir->width = aw;
        ir->a = rm;
        ir->b = two_operand ? op_reg((uint8_t)r->reg, aw) : op_imm(r->simm, aw);
        return 1;
    }

    if (r->has_0f) {
        uint8_t o2 = r->opc2;
        if (o2 == 0xAF) {                       /* IMUL r64, r/m64 */
            ir->op = IR_IMUL; ir->a = op_reg((uint8_t)r->reg, w);
            if (!mk_rm(r, &ir->b, w)) FAIL("偏移 %u: IMUL 不支持 RIP 相对", r->off);
            return 1;
        }
        if (o2 >= 0x40 && o2 <= 0x4F) {         /* CMOVcc r64, r/m64 */
            ir->op = IR_CMOV; ir->cc = o2 & 0xF;
            ir->a = op_reg((uint8_t)r->reg, w);
            if (!mk_rm(r, &ir->b, w)) FAIL("偏移 %u: CMOV 不支持 RIP 相对", r->off);
            return 1;
        }
        if (o2 >= 0x90 && o2 <= 0x9F) {         /* SETcc r/m8 */
            ir->op = IR_SETCC; ir->cc = o2 & 0xF; ir->width = 8;
            if (!mk_rm(r, &ir->a, 8)) FAIL("偏移 %u: SETcc 不支持 RIP 相对", r->off);
            return 1;
        }
        if (o2 >= 0xB6 && o2 <= 0xBF) {         /* MOVZX / MOVSX */
            ir->op = (o2 == 0xB6 || o2 == 0xB7) ? IR_MOVZX : IR_MOVSX;
            ir->a = op_reg((uint8_t)r->reg, w);
            if (!mk_rm(r, &ir->b, (o2 == 0xB6 || o2 == 0xBE) ? 8 : 16))
                FAIL("偏移 %u: MOVZX 不支持 RIP 相对", r->off);
            return 1;
        }
        if (o2 >= 0x80 && o2 <= 0x8F) {         /* Jcc rel32 */
            ir->op = IR_JCC; ir->cc = o2 & 0xF;
            ir->target_off = (uint32_t)((int64_t)r->off + r->len + r->simm);
            return 1;
        }
        {   /* ---- 标量 SSE 子集（第七批）----
             * 前缀：F3=SS(float32) F2=SD(float64) 66/无=packed(仅位运算/传送)
             * 约定 ir->a=目标操作数、ir->b=源操作数；fop 存 ir->exit_kind */
            uint8_t fop = 0, wc = 0, iw = (uint8_t)(r->rex_w ? 64 : 32);
            int store = 0, reg_gpr = 0, rm_gpr = 0;
            switch (o2) {
                case 0x10: case 0x11: fop = FOP_MOV; store = (o2 == 0x11); wc = 128; break;
                case 0x28: case 0x29: fop = FOP_MOV; store = (o2 == 0x29); wc = 128; break;
                case 0x6F: fop = FOP_MOV; store = 0; wc = 128; break; /* movdqu xmm, xmm/m */
                case 0x7F: fop = FOP_MOV; store = 1; wc = 128; break; /* movdqu xmm/m, xmm */
                case 0x2A: fop = FOP_I2F; rm_gpr = 1; break;      /* cvtsi2ss/sd */
                case 0x2C: case 0x2D: fop = FOP_F2I; reg_gpr = 1; break; /* cvtt*2si */
                case 0x2E: case 0x2F: fop = FOP_CMP; break;       /* ucomi/comi */
                case 0x51: fop = FOP_SQRT; break;
                case 0x54: fop = FOP_AND; wc = 128; break;
                case 0x57: fop = FOP_XOR; wc = 128; break;
                case 0x58: fop = FOP_ADD; break;
                case 0x59: fop = FOP_MUL; break;
                case 0x5A: fop = r->has_f3 ? FOP_CVTSS2SD : FOP_CVTSD2SS; break;
                case 0x5C: fop = FOP_SUB; break;
                case 0x5D: fop = FOP_MIN; break;
                case 0x5E: fop = FOP_DIV; break;
                case 0x5F: fop = FOP_MAX; break;
                case 0x6E: fop = FOP_MOVG2X; rm_gpr = 1; wc = iw; break;
                case 0x7E: fop = FOP_MOVX2G; reg_gpr = 1; wc = iw; break;
                case 0xD6: fop = FOP_MOV; wc = 128; break;          /* movq xmm,xmm */
                case 0xEF: fop = FOP_XOR; wc = 128; break;          /* pxor (清零惯用) */
                default: break;
            }
            /* ---- 打包整数 SIMD（v9：packed SIMD 子集）---- */
            {
                uint8_t pint_op = 0xFF, lw = 0, is_pint = 0;
                switch (o2) {
                    case 0xFC: pint_op=0; lw=0; is_pint=1; break; /* paddb */
                    case 0xFD: pint_op=0; lw=1; is_pint=1; break; /* paddw */
                    case 0xFE: pint_op=0; lw=2; is_pint=1; break; /* paddd */
                    case 0xD4: pint_op=0; lw=3; is_pint=1; break; /* paddq */
                    case 0xF8: pint_op=1; lw=0; is_pint=1; break; /* psubb */
                    case 0xF9: pint_op=1; lw=1; is_pint=1; break; /* psubw */
                    case 0xFA: pint_op=1; lw=2; is_pint=1; break; /* psubd */
                    case 0xFB: pint_op=1; lw=3; is_pint=1; break; /* psubq */
                    case 0xDB: pint_op=2; lw=3; is_pint=1; break; /* pand  (128) */
                    case 0xEB: pint_op=3; lw=3; is_pint=1; break; /* por */
                    case 0xDF: pint_op=5; lw=3; is_pint=1; break; /* pandn (PINT_ANDN) */
                    case 0x74: pint_op=6; lw=0; is_pint=1; break; /* pcmpeqb (PINT_CMPEQ) */
                    case 0x75: pint_op=6; lw=1; is_pint=1; break; /* pcmpeqw */
                    case 0x76: pint_op=6; lw=2; is_pint=1; break; /* pcmpeqd */
                    default: break;
                }
                if (is_pint) {
                    oper_t rg = op_xmm((uint8_t)r->reg, 128);
                    oper_t rm;
                    if (!mk_rm_xmm(r, &rm, 128)) FAIL("偏移 %u: 打包 SSE 不支持该寻址", r->off);
                    ir->op = IR_FSSE; ir->width = 128;
                    ir->exit_kind = FOP_PINT;
                    ir->int_width = (uint8_t)((pint_op << 4) | lw);
                    ir->a = rg; ir->b = rm;
                    return 1;
                }
                if (o2 == 0x70) {   /* pshufd xmm, xmm/m128, imm8 */
                    oper_t rg = op_xmm((uint8_t)r->reg, 128);
                    oper_t rm;
                    if (!mk_rm_xmm(r, &rm, 128)) FAIL("偏移 %u: pshufd 不支持该寻址", r->off);
                    ir->op = IR_FSSE; ir->width = 128; ir->exit_kind = FOP_PSHUFD;
                    /* imm8 经 c 操作数带走：compile_ir 会把它写入 b->imm(^mask) */
                    ir->c = op_imm(r->simm, 8);
                    ir->a = rg; ir->b = rm;
                    return 1;
                }
                if (o2 == 0x6B) {   /* packssdw xmm, xmm/m128 */
                    oper_t rg = op_xmm((uint8_t)r->reg, 128);
                    oper_t rm;
                    if (!mk_rm_xmm(r, &rm, 128)) FAIL("偏移 %u: packssdw 不支持该寻址", r->off);
                    ir->op = IR_FSSE; ir->width = 128; ir->exit_kind = FOP_PACKSSDW;
                    ir->a = rg; ir->b = rm;
                    return 1;
                }
            }
            if (!fop) FAIL("偏移 %u: 不支持的 0F %02X 指令(SSE 子集外)", r->off, o2);
            if (!wc) wc = r->has_f2 ? 64 : 32;   /* F2=double, 其余 float */
            oper_t rg = reg_gpr ? op_reg((uint8_t)r->reg, iw)
                                : op_xmm((uint8_t)r->reg, wc);
            oper_t rm;
            if (rm_gpr) { if (!mk_rm(r, &rm, iw)) FAIL("偏移 %u: SSE 不支持该寻址", r->off); }
            else        { if (!mk_rm_xmm(r, &rm, wc)) FAIL("偏移 %u: SSE 不支持该寻址", r->off); }
            ir->op = IR_FSSE;
            ir->width = wc;
            ir->exit_kind = fop;
            ir->int_width = iw;
            if (store) { ir->a = rm; ir->b = rg; }
            else       { ir->a = rg; ir->b = rm; }
            return 1;
        }
        FAIL("偏移 %u: 不支持的 0F %02X 指令", r->off, o2);
    }

    /* ---- 字符串指令（v5，REP 前缀）----
     * 0xA4/A5 MOVS, 0xA6/A7 CMPS, 0xAA/AB STOS, 0xAE/AF SCAS。
     * F3=REP/REPE, F2=REPNE；字节型固定 8 位，其余按 REX.W/66/默认
     * 得 64/16/32。隐式 RSI/RDI/RCX/AL..RAX，DF 决定方向。
     * LODS(0xAC/0xAD) 不在子集内，落到末尾明确 FAIL（不静默跳过）。 */
    if (o == 0xA4 || o == 0xA5 || o == 0xA6 || o == 0xA7 ||
        o == 0xAA || o == 0xAB || o == 0xAE || o == 0xAF) {
        uint8_t kind;
        switch (o) {
            case 0xA4: case 0xA5: kind = REP_MOVS; break;
            case 0xA6: case 0xA7: kind = REP_CMPS; break;
            case 0xAA: case 0xAB: kind = REP_STOS; break;
            default:              kind = REP_SCAS; break;  /* 0xAE/0xAF */
        }
        int byte_op = (o == 0xA4 || o == 0xA6 || o == 0xAA || o == 0xAE);
        ir->op = IR_REP;
        ir->rep_kind = kind;
        ir->width = byte_op ? 8 : (r->rex_w ? 64 : (r->has_66 ? 16 : 32));
        if (r->has_f3 || r->has_f2) ir->rep_kind |= REP_LOOP;
        if (kind == REP_CMPS || kind == REP_SCAS)
            ir->cc = r->has_f2 ? REPCC_REPNE : REPCC_REPE;
        else
            ir->cc = REPCC_ALWAYS;
        return 1;
    }
    if (o == 0xFC || o == 0xFD) {           /* cld / std */
        ir->op = IR_SETDF;
        ir->a = op_imm(o == 0xFD ? 1 : 0, 8);   /* 1=std 置 DF，0=cld 清 DF */
        return 1;
    }

    /* 一元 / 零操作数 */
    if (o == 0xC3) { ir->op = IR_RET; return 1; }
    if (o == 0x99) {                              /* CQO / CDQ：RDX = sign(RAX) */
        ir->op = IR_CQO; ir->width = w; return 1;
    }
    if (o == 0xC9) { ir->op = IR_NOP; return 1; }  /* LEAVE：纯计算函数里不接触帧 */
    /* x86-64 长模式：push/pop 默认 64 位操作数（0x50..0x57 / 0x58..0x5F），
       仅 66 前缀时为 16 位。不能用 rex_w 推断——这些短格式不带 REX.W，
       若沿用 width=32 会把 R64 高 32 位截断（栈参数/保存寄存器全错）。 */
    if (o >= 0x50 && o <= 0x57) {
        ir->width = r->has_66 ? 16 : 64;
        ir->op = IR_PUSH; ir->a = op_reg((uint8_t)(o - 0x50), ir->width); return 1;
    }
    if (o >= 0x58 && o <= 0x5F) {
        ir->width = r->has_66 ? 16 : 64;
        ir->op = IR_POP; ir->a = op_reg((uint8_t)(o - 0x58), ir->width); return 1;
    }
    if (o >= 0x70 && o <= 0x7F) {
        ir->op = IR_JCC; ir->cc = o & 0xF;
        ir->target_off = (uint32_t)((int64_t)r->off + r->len + r->simm);
        return 1;
    }
    if (o == 0xEB || o == 0xE9) {
        ir->op = IR_JMP;
        ir->target_off = (uint32_t)((int64_t)r->off + r->len + r->simm);
        return 1;
    }
    if (o == 0xE8) {
        ir->op = IR_CALL;
        ir->target_off = (uint32_t)((int64_t)r->off + r->len + r->simm);
        return 1;
    }
    if (o >= 0xB8 && o <= 0xBF) {                /* MOV reg, imm */
        ir->op = IR_MOV;
        ir->a = op_reg((uint8_t)((o - 0xB8) | (r->rex_b << 3)), w);
        ir->b = op_imm((int64_t)r->imm, w);
        return 1;
    }
    if (o == 0x8D) {                              /* LEA reg, mem */
        ir->op = IR_LEA;
        ir->a = op_reg((uint8_t)r->reg, w);
        if (!mk_rm(r, &ir->b, w)) FAIL("偏移 %u: LEA 不支持 RIP 相对", r->off);
        return 1;
    }
    if (o == 0x63) {                              /* MOVSXD r64, r/m32 */
        ir->op = IR_MOVSX; ir->width = 64;
        ir->a = op_reg((uint8_t)r->reg, 64);
        if (!mk_rm(r, &ir->b, 32)) FAIL("偏移 %u: MOVSXD 不支持该寻址", r->off);
        return 1;
    }

    /* 二元 rm <- reg / reg <- rm */
    static const struct { uint8_t opc; uint8_t irop; } bin[] = {
        {0x01,IR_ADD},{0x03,IR_ADD},{0x29,IR_SUB},{0x2B,IR_SUB},
        {0x31,IR_XOR},{0x33,IR_XOR},{0x21,IR_AND},{0x23,IR_AND},
        {0x09,IR_OR },{0x0B,IR_OR },{0x39,IR_CMP},{0x3B,IR_CMP},
        {0x85,IR_TEST},{0x89,IR_MOV},{0x8B,IR_MOV}
    };
    for (size_t i = 0; i < sizeof(bin)/sizeof(bin[0]); ++i) {
        if (bin[i].opc != o) continue;
        ir->op = bin[i].irop;
        /* x86 编码规律：opcode 低两位为 3 (..3 / ..B) 时 dst 是 reg，否则是 r/m */
        int to_reg = ((o & 3) == 3);
        if (to_reg) {
            ir->a = op_reg((uint8_t)r->reg, w);
            if (!mk_rm(r, &ir->b, w)) FAIL("偏移 %u: 不支持 RIP 相对", r->off);
        } else {
            if (!mk_rm(r, &ir->a, w)) FAIL("偏移 %u: 不支持 RIP 相对", r->off);
            ir->b = op_reg((uint8_t)r->reg, w);
        }
        return 1;
    }

    /* Group1: imm 到 rm */
    if (o == 0x81 || o == 0x83 || o == 0x80) {
        static const uint8_t grp[8] = {
            IR_ADD, IR_OR, IR_ADD, IR_SUB, IR_AND, IR_SUB, IR_XOR, IR_CMP
        };
        uint8_t sub = (uint8_t)(r->reg & 7);
        /* 0x81/0x83 的 /2 是 ADC、/3 是 SBB、/5 是 SUB，这里只映射语义等价的子集 */
        if (sub == 2 || sub == 3) FAIL("偏移 %u: 不支持 ADC/SBB group1", r->off);
        ir->op = grp[sub];
        if (!mk_rm(r, &ir->a, w)) FAIL("偏移 %u: 不支持 RIP 相对", r->off);
        ir->b = op_imm(r->simm, w);
        return 1;
    }
    if (o == 0xC7 || o == 0xC6) {                 /* MOV rm, imm */
        ir->op = IR_MOV;
        if (!mk_rm(r, &ir->a, w)) FAIL("偏移 %u: 不支持 RIP 相对", r->off);
        ir->b = op_imm(r->simm, w);
        return 1;
    }
    if (o == 0x69 || o == 0x6B) {                 /* IMUL r, rm, imm */
        ir->op = IR_IMUL3;
        ir->a = op_reg((uint8_t)r->reg, w);
        if (!mk_rm(r, &ir->b, w)) FAIL("偏移 %u: IMUL3 不支持 RIP 相对", r->off);
        ir->c = op_imm(r->simm, w);
        return 1;
    }
    if (o == 0xC1 || o == 0xD1 || o == 0xD3) {    /* 移位 / 循环移位 */
        static const uint8_t sh[8] = {
            IR_ROL, IR_ROR, IR_ROL, IR_ROR, IR_SHL, IR_SHR, IR_ROL, IR_SAR
        };
        uint8_t sub = (uint8_t)(r->reg & 7);
        ir->op = sh[sub];
        if (!mk_rm(r, &ir->a, w)) FAIL("偏移 %u: 移位不支持 RIP 相对", r->off);
        if (o == 0xC1) ir->b = op_imm((int64_t)(uint8_t)r->imm, 8);
        else if (o == 0xD1) ir->b = op_imm(1, 8);
        else ir->b = op_reg(X_RCX, 8);            /* D3: 移位计数在 CL */
        return 1;
    }
    if (o == 0xFF || o == 0xF7 || o == 0xF6) {
        uint8_t sub = (uint8_t)(r->reg & 7);
        if ((o == 0xF7 || o == 0xF6) && sub >= 4 && sub <= 7) {
            /* F6/F7 /4 MUL, /5 IMUL, /6 DIV, /7 IDIV：隐式 RDX:RAX / AX */
            uint8_t mw = (o == 0xF6) ? 8 : w;
            ir->op = (sub == 4) ? IR_MUL : (sub == 5) ? IR_IMUL1
                   : (sub == 6) ? IR_DIV : IR_IDIV;
            ir->width = mw;
            if (!mk_rm(r, &ir->b, mw))
                FAIL("偏移 %u: MUL/DIV 不支持该寻址", r->off);
            return 1;
        }
        if (o == 0xFF && (sub == 0 || sub == 1)) {
            ir->op = (sub == 0) ? IR_INC : IR_DEC;
            if (!mk_rm(r, &ir->a, w)) FAIL("偏移 %u: INC/DEC 不支持 RIP 相对", r->off);
            return 1;
        }
        if (o == 0xFF && sub == 6) {
            ir->op = IR_PUSH;
            ir->width = r->has_66 ? 16 : 64;   /* 长模式 push r/m 默认 64 位 */
            if (!mk_rm(r, &ir->a, ir->width)) FAIL("偏移 %u: PUSH 不支持 RIP 相对", r->off);
            return 1;
        }
        if (o == 0xF7 && (sub == 2 || sub == 3)) {
            ir->op = (sub == 2) ? IR_NOT : IR_NEG;
            if (!mk_rm(r, &ir->a, w)) FAIL("偏移 %u: NOT/NEG 不支持 RIP 相对", r->off);
            return 1;
        }
        if (o == 0xFF && sub == 2) {           /* CALL r/m64：间接外部调用 -> VM-exit */
            ir->op = IR_CALLEXT;
            if (!mk_rm(r, &ir->a, 64)) FAIL("偏移 %u: 间接调用不支持该寻址", r->off);
            if      (ir->a.kind == OK_RIPREL) ir->exit_kind = 2;  /* [rip+disp32] IAT 槽 */
            else if (ir->a.kind == OK_MEM)    ir->exit_kind = 3;  /* [base+idx*sc+disp] */
            else if (ir->a.kind == OK_REG)    ir->exit_kind = 4;  /* call reg */
            else FAIL("偏移 %u: 未知间接调用寻址", r->off);
            return 1;
        }
        if (o == 0xFF && sub == 4) {           /* JMP r/m64：FF/4 间接跳转 */
            ir->op = IR_JMPI;
            if (!mk_rm(r, &ir->a, 64)) FAIL("偏移 %u: 间接跳转不支持该寻址", r->off);
            if      (ir->a.kind == OK_RIPREL) ir->exit_kind = 2;  /* [rip+disp] 表槽 */
            else if (ir->a.kind == OK_MEM)    ir->exit_kind = 3;  /* [base+idx*sc+disp] */
            else if (ir->a.kind == OK_REG)    ir->exit_kind = 4;  /* jmp reg */
            else FAIL("偏移 %u: 未知间接跳转寻址", r->off);
            return 1;
        }
        FAIL("偏移 %u: 不支持的 group %02X /%u", r->off, o, sub);
    }
    /* 累加器短格式 ALU：op eAX, imm32（0x05 ADD / 0x0D OR / 0x25 AND /
       0x2D SUB / 0x35 XOR / 0x3D CMP / 0xA9 TEST）。gcc 常用 0x35 实现
       `x ^ 常量`。imm_size_for 已按 4 字节解码，这里补语义提升。
       0x15 ADC / 0x1D SBB 带进位，仍不支持。 */
    if (o == 0x05 || o == 0x0D || o == 0x25 || o == 0x2D || o == 0x35 ||
        o == 0x3D || o == 0xA9) {
        uint8_t alu;
        switch (o) {
            case 0x05: alu = IR_ADD;  break;
            case 0x0D: alu = IR_OR;   break;
            case 0x25: alu = IR_AND;  break;
            case 0x2D: alu = IR_SUB;  break;
            case 0x35: alu = IR_XOR;  break;
            case 0xA9: alu = IR_TEST; break;
            default:   alu = IR_CMP;  break;   /* 0x3D */
        }
        ir->op = alu;
        ir->a = op_reg(X_RAX, w); ir->b = op_imm(r->simm, w);
        return 1;
    }
    if (o == 0xF3 && r->has_f3) { ir->op = IR_NOP; return 1; }

    FAIL("偏移 %u: 不支持的操作码 %02X (字节 %02X %02X)", r->off, o,
         r->bytes[0], r->len > 1 ? r->bytes[1] : 0);
#undef FAIL
#undef RM_ONLY
}

/* ------------------------------------------------------ 私有 ISA 字节码层 */
/* 内存布局 bc_hdr_t/bc_t 与 v5 磁盘容器（seal/open/fetch）统一在
   csvm_container.h 唯一定义。本文件 include 后使用，避免两处布局漂移。 */
#include "csvm_container.h"

/* 逻辑字节码 op（与 IR 同序，末尾追加 JUNK） */
enum { BC_JUNK = IR_COUNT, BC_COUNT };

static int compile_ir(const ir_t *irs, uint32_t n_ir, uint64_t seed,
                      uint32_t code_span, uint32_t extra_flags,
                      uint8_t **out, size_t *out_len,
                      uint32_t *n_junk_out, char *err, size_t cap) {
    /* v5 能力标志：编译期扫描 IR，判定该字节码是否含浮点跨 VM-exit、
       REP 字符串指令、直接尾调用、多段 CFG。NEED_FPU 的正确性闸门在
       run_blob / 各入口执行，杜绝「编译成功、运行成功、答案错」。 */
    uint32_t flags = extra_flags;
    int has_fsse = 0, has_exit = 0;
    for (uint32_t i = 0; i < n_ir; ++i) {
        switch (irs[i].op) {
            case IR_REP:      flags |= BC_FLAG_REP; break;
            case IR_TAILEXIT: flags |= BC_FLAG_TAILEXIT; has_exit = 1; break;
            case IR_FSSE:     has_fsse = 1; break;
            case IR_CALLEXT: case IR_JMPI: has_exit = 1; break;
            default: break;
        }
    }
    /* 保守判定：只要函数用到 SSE（活跃 XMM）且会发生 VM-exit（外部调用 /
       间接尾调用 / 直接尾调用），就打 FPU_EXIT + NEED_FPU。宁可让非 fpu
       入口明确拒绝，也绝不静默漏搬 XMM 给出错答案。 */
    if (has_fsse && has_exit) flags |= BC_FLAG_FPU_EXIT | BC_FLAG_NEED_FPU;

    prng_t pr = { seed };
    bc_hdr_t h;
    memset(&h, 0, sizeof(h));
    memcpy(h.magic, CSVM_MAGIC, 8);
    h.version = CSVM_ABI_VERSION;
    h.seed = seed;
    h.imm_mask = pr_next(&pr) | 1u;
    h.n_ir = n_ir;
    h.reserved = code_span;  /* CFG 闭包 RVA 跨度：IR_JMPI 判定「闭包内」目标用 */

    /* opcode 全排列，取前 BC_COUNT 个作为随机映射 */
    uint8_t perm[256];
    for (int i = 0; i < 256; ++i) perm[i] = (uint8_t)i;
    pr_shuffle8(&pr, perm, 256);
    memset(h.dec_map, OPC_NONE, sizeof(h.dec_map));
    for (int i = 0; i < BC_COUNT; ++i) {
        h.opc_map[i] = perm[i];
        h.dec_map[perm[i]] = (uint8_t)i;
    }
    /* 槽位置换：32 个物理槽，前 16 个分配给逻辑 GPR */
    uint8_t slots[NOISE_SLOTS];
    for (int i = 0; i < NOISE_SLOTS; ++i) slots[i] = (uint8_t)i;
    pr_shuffle8(&pr, slots, NOISE_SLOTS);
    memcpy(h.reg_map, slots, 16);

    /* 估算容量：每条 IR 最多 3 条 bc（含随机垃圾） */
    uint32_t cap_n = n_ir * 3 + 16;
    if (cap_n > CSVM_MAX_INSN) { set_err(err, cap, "IR 指令过多"); return -1; }
    bc_t *bc = (bc_t *)calloc(cap_n, sizeof(bc_t));
    if (!bc) { set_err(err, cap, "内存不足"); return -1; }
    int32_t *ir_index = (int32_t *)malloc(sizeof(int32_t) * (n_ir + 1));
    if (!ir_index) { free(bc); set_err(err, cap, "内存不足"); return -1; }

    uint32_t n = 0, junk = 0;
    for (uint32_t i = 0; i < n_ir; ++i) {
        ir_index[i] = (int32_t)n;
        const ir_t *q = &irs[i];
        bc_t *b = &bc[n++];
        memset(b, 0, sizeof(*b));
        b->opc = h.opc_map[q->op < BC_COUNT ? q->op : IR_TRAP];
        b->cc = q->cc; b->width = q->width;
        b->a_kind = q->a.kind; b->b_kind = q->b.kind; b->c_kind = q->c.kind;
        b->a_reg = (q->a.kind == OK_REG) ? h.reg_map[q->a.reg & 15]
                 : (q->a.kind == OK_MEM) ? ((q->a.base == 255) ? 255 : h.reg_map[q->a.base & 15])
                 : (q->a.kind == OK_XMM) ? (q->a.reg & 15) : 0;
        b->b_reg = (q->b.kind == OK_REG) ? h.reg_map[q->b.reg & 15]
                 : (q->b.kind == OK_MEM) ? ((q->b.base == 255) ? 255 : h.reg_map[q->b.base & 15])
                 : (q->b.kind == OK_XMM) ? (q->b.reg & 15) : 0;
        b->c_reg = (q->c.kind == OK_REG) ? h.reg_map[q->c.reg & 15] : 0;
        b->src_width = (q->op == IR_FSSE) ? q->int_width : q->b.width;
        b->exit_kind = q->exit_kind;
        b->rep_kind  = q->rep_kind;      /* v5：REP 子类型（含 REP_LOOP 位） */
        b->next_off = q->off + q->len;
        b->src_off = q->off;
        if (q->a.kind == OK_IMM || q->a.kind == OK_LABEL)
            b->imm = (int64_t)((uint64_t)q->a.imm ^ h.imm_mask);
        else if (q->b.kind == OK_IMM || q->b.kind == OK_LABEL)
            b->imm = (int64_t)((uint64_t)q->b.imm ^ h.imm_mask);
        else if (q->c.kind == OK_IMM)
            b->imm = (int64_t)((uint64_t)q->c.imm ^ h.imm_mask);
        if (q->a.kind == OK_MEM || q->a.kind == OK_RIPREL) {
            b->disp = (int64_t)((uint64_t)q->a.disp ^ h.imm_mask);
            b->c_reg = (uint8_t)((q->a.kind == OK_RIPREL || q->a.index == 255)
                                 ? 255 : h.reg_map[q->a.index & 15]);
            b->cc = (uint8_t)(b->cc | ((q->a.scale & 0xF) << 4));
        } else if (q->b.kind == OK_MEM || q->b.kind == OK_RIPREL) {
            b->disp = (int64_t)((uint64_t)q->b.disp ^ h.imm_mask);
            b->c_reg = (uint8_t)((q->b.kind == OK_RIPREL || q->b.index == 255)
                                 ? 255 : h.reg_map[q->b.index & 15]);
            b->cc = (uint8_t)(b->cc | ((q->b.scale & 0xF) << 4));
        }

        /* 随机垃圾：写到噪声槽的 MOV，或纯 NOP。不改变任何有效槽与标志。 */
        uint32_t extra = pr_below(&pr, 3);
        for (uint32_t k = 0; k < extra; ++k) {
            bc_t *j = &bc[n++];
            memset(j, 0, sizeof(*j));
            j->src_off = SRC_OFF_NONE;
            j->opc = (k & 1) ? h.opc_map[BC_JUNK] : h.opc_map[IR_NOP];
            j->a_kind = OK_REG; j->a_reg = slots[16 + pr_below(&pr, 16)];
            j->b_kind = OK_REG; j->b_reg = slots[16 + pr_below(&pr, 16)];
            j->imm = (int64_t)(pr_next(&pr) ^ h.imm_mask);
            junk++;
        }
    }
    ir_index[n_ir] = (int32_t)n;

    /* 解析标签：IR 的目标索引 -> bc 索引；垃圾指令已在前面插入完毕 */
    for (uint32_t i = 0; i < n_ir; ++i) {
        const ir_t *q = &irs[i];
        if (q->op == IR_CALLEXT) {
            bc_t *b = &bc[ir_index[i]];
            if (q->exit_kind == 1)   /* 直接 rel32：目标 = runtime_base + (int32)imm */
                b->imm = (int64_t)((uint64_t)(uint32_t)q->target_off ^ h.imm_mask);
            /* 间接型：disp / next_off / a_reg 已在主循环写好，运行时解析 */
            continue;
        }
        if (q->op == IR_TAILEXIT) {
            /* 直接 jmp rel32 到 CFG 闭包外（gcc -O2 sibling call）。
               降级为 VM-exit tail：目标 = runtime_base + (int32)target_off，
               运行时以原生函数返回值作为整个 VM 的返回值终止。 */
            bc_t *b = &bc[ir_index[i]];
            b->imm = (int64_t)((uint64_t)(uint32_t)q->target_off ^ h.imm_mask);
            b->exit_kind = 1;
            continue;
        }
        if (q->op != IR_JMP && q->op != IR_JCC && q->op != IR_CALL) continue;
        if (q->target_idx < 0 || (uint32_t)q->target_idx > n_ir) {
            free(bc); free(ir_index);
            set_err(err, cap, "IR %u: 跳转目标 %u 越界（目标字节偏移 %u）",
                    i, q->target_idx, q->target_off);
            return -1;
        }
        bc_t *b = &bc[ir_index[i]];
        b->imm = (int64_t)((uint64_t)(uint32_t)ir_index[q->target_idx] ^ h.imm_mask);
        b->a_kind = OK_LABEL;
    }

    h.n_insn = n; h.n_junk = junk;
    /* 内存表示 [bc_hdr_t][bc_t[n]] 只是编译期中间态；磁盘产物改由 v5
       变长加密容器 seal（逐条按需解密 + 逐块 rec_mac + 头 hdr_mac），
       不再输出定长明文 + 整体 CRC。 */
    size_t mem_len = sizeof(bc_hdr_t) + (size_t)n * sizeof(bc_t);
    uint8_t *mem = (uint8_t *)malloc(mem_len);
    if (!mem) { free(bc); free(ir_index); set_err(err, cap, "内存不足"); return -1; }
    memcpy(mem, &h, sizeof(h));
    memcpy(mem + sizeof(h), bc, (size_t)n * sizeof(bc_t));
    free(bc); free(ir_index);

    uint8_t *blob = NULL; size_t blob_len = 0;
    int src = csvm_v5_seal(mem, mem_len, seed, flags, &blob, &blob_len);
    csvm_sec_zero(mem, mem_len); free(mem);
    if (src != 0) { set_err(err, cap, "v5 容器封装失败 (%d)", src); return -1; }
    *out = blob; *out_len = blob_len; *n_junk_out = junk;
    return 0;
}

/* -------------------------------------------------------------- 解释器层 */

typedef struct {
    uint64_t r[NOISE_SLOTS];
    uint64_t flags;
    uint8_t  mem[VM_MEM_SIZE];
    uint64_t steps;
    /* 宿主真实内存模式（PE/ELF 集成层使用） */
    int         host_mode;
    uint64_t    runtime_base;
    csvm_mem_fn memfn;
    void       *mem_ctx;
    uint32_t    callstack[256];
    int         csp;
    /* L2 VM-exit：宿主原生调用回调 */
    csvm_exit_fn exitfn;
    void        *exit_ctx;
    /* 第八批：浮点跨 VM-exit 的 XMM 搬运通道 + 强制正确性闸门 */
    csvm_exit_fpu_fn fpu_exitfn;
    void        *fpu_exit_ctx;
    int          need_fpu;
    /* 第七批：16 个 XMM 寄存器，每个 128 位 = [0]低64 + [1]高64 */
    uint64_t    xmm[16][2];
#if defined(CSVM_USE_CG)
    /* v3.3.5：本 run 私有的混淆分派表。每次 run 用不同 key 重新生成，
       首条指令在 exec_step 里懒初始化（标签地址只在函数内可取）。 */
    void       *cg_enc[BC_COUNT];
    uint64_t    cg_key;
    int         cg_ready;
#endif
} vm_t;

static uint64_t wmask(uint8_t w) {
    if (w >= 64) return ~(uint64_t)0;
    return (1ULL << w) - 1;
}
static uint64_t trim(uint64_t v, uint8_t w) { return v & wmask(w); }
static int parity8(uint64_t v) {
    int c = 0; uint8_t b = (uint8_t)v;
    while (b) { c ^= (b & 1); b >>= 1; }
    return !c; /* PF = 1 表示低字节 1 的个数为偶 */
}
static uint64_t calc_flags(uint64_t res, uint64_t a, uint64_t b,
                           uint8_t w, int is_sub, int keep_cf,
                           uint64_t old_flags) {
    uint64_t m = wmask(w), f = 0;
    res &= m; a &= m; b &= m;
    uint64_t cf = is_sub ? (a < b) : (res < a);
    uint64_t of = is_sub
        ? (((a ^ b) & (a ^ res)) >> (w - 1)) & 1
        : (((~(a ^ b)) & (a ^ res)) >> (w - 1)) & 1;
    if (keep_cf) { cf = (old_flags & F_CF) ? 1 : 0; }
    if (res == 0) f |= F_ZF;
    if ((res >> (w - 1)) & 1) f |= F_SF;
    if (cf) f |= F_CF;
    if (of) f |= F_OF;
    if (parity8(res)) f |= F_PF;
    if (((a ^ b ^ res) >> 4) & 1) f |= F_AF;
    return f;
}
static uint64_t logic_flags(uint64_t res, uint8_t w) {
    uint64_t m = wmask(w), f = 0;
    res &= m;
    if (res == 0) f |= F_ZF;
    if ((res >> (w - 1)) & 1) f |= F_SF;
    if (parity8(res)) f |= F_PF;
    return f; /* CF=OF=AF=0 */
}
static int eval_cc(uint8_t cc, uint64_t f) {
    int z = !!(f & F_ZF), s = !!(f & F_SF), c = !!(f & F_CF);
    int o = !!(f & F_OF), p = !!(f & F_PF);
    switch (cc & 0xF) {
        case 0: return o;            case 1: return !o;
        case 2: return c;            case 3: return !c;
        case 4: return z;            case 5: return !z;
        case 6: return c || z;       case 7: return !c && !z;
        case 8: return s;            case 9: return !s;
        case 10: return p;           case 11: return !p;
        case 12: return s != o;      case 13: return s == o;
        case 14: return z || (s != o); case 15: return !z && (s == o);
    }
    return 0;
}

static uint64_t load_mem(const vm_t *v, uint64_t addr, uint8_t w) {
    uint64_t x = 0;
    size_t n = (w >= 64) ? 8 : (w == 32 ? 4 : (w == 16 ? 2 : 1));
    if (v->host_mode) {
        if (!v->memfn || v->memfn(v->mem_ctx, addr, &x, n, 0) != 0) return 0;
        return x;
    }
    if (addr + n > VM_MEM_SIZE) return 0;
    memcpy(&x, v->mem + addr, n);
    return x;
}
static void store_mem(vm_t *v, uint64_t addr, uint64_t x, uint8_t w) {
    size_t n = (w >= 64) ? 8 : (w == 32 ? 4 : (w == 16 ? 2 : 1));
    if (v->host_mode) {
        if (v->memfn) v->memfn(v->mem_ctx, addr, &x, n, 1);
        return;
    }
    if (addr + n > VM_MEM_SIZE) return;
    memcpy(v->mem + addr, &x, n);
}

/* 计算内存操作数地址；0 成功 */
/* strict=1 用于真实内存读写（越界即 TRAP）；strict=0 用于 LEA（只算地址，
 * 不访问内存，地址超出 VM 内存窗口是正常的）。 */
static int mem_addr(const vm_t *v, const bc_t *b, uint8_t base_slot,
                    uint64_t mask, int strict, uint64_t *out) {
    if (b->a_kind == OK_RIPREL || b->b_kind == OK_RIPREL) {
        /* [rip+disp32]：rip = 运行时函数基址 + 本指令末尾偏移 */
        if (!v->host_mode || !v->runtime_base) return 0;
        int64_t d = (int64_t)((uint64_t)b->disp ^ mask);
        *out = v->runtime_base + b->next_off + (uint64_t)d;
        return 1;
    }
    uint8_t scale = (b->cc >> 4) & 0xF;
    uint64_t addr = (base_slot == 255) ? 0 : v->r[base_slot];
    if (b->c_reg != 255) addr += v->r[b->c_reg] * (scale ? scale : 1);
    addr = (uint64_t)((int64_t)addr + (int64_t)((uint64_t)b->disp ^ mask));
    if (strict && !v->host_mode && addr >= VM_MEM_SIZE) return 0;
    *out = addr; return 1;
}

static uint64_t read_oper(const vm_t *v, const bc_t *b, uint8_t kind,
                          uint8_t slot, uint8_t w, uint64_t mask,
                          int *trap, const char **why) {
    if (kind == OK_REG) return trim(v->r[slot], w);
    if (kind == OK_IMM || kind == OK_LABEL) return trim((uint64_t)b->imm ^ mask, w);
    if (kind == OK_MEM || kind == OK_RIPREL) {
        uint64_t a;
        if (!mem_addr(v, b, slot, mask, 1, &a)) { *trap = 1; *why = "内存地址越界"; return 0; }
        return trim(load_mem(v, a, w), w);
    }
    (void)why; return 0;
}

static void write_oper(vm_t *v, const bc_t *b, uint8_t kind, uint8_t slot,
                       uint8_t w, uint64_t val, uint64_t mask,
                       int *trap, const char **why) {
    if (kind == OK_REG) {
        /* x86-64：写 32 位寄存器会零扩展到 64 位 */
        v->r[slot] = (w >= 64) ? val : trim(val, w);
        return;
    }
    if (kind == OK_MEM || kind == OK_RIPREL) {
        uint64_t a;
        if (!mem_addr(v, b, slot, mask, 1, &a)) { *trap = 1; *why = "内存地址越界"; return; }
        store_mem(v, a, trim(val, w), w);
        return;
    }
    *trap = 1; *why = "写入目标不是寄存器或内存";
}

/* ---- 标量 SSE 执行 helpers（第七批）----
 * 位模式 <-> float/double 用 memcpy，避免严格别名与浮点环境依赖。 */
static float    as_float(uint32_t u)  { float f;    memcpy(&f, &u, 4); return f; }
static uint32_t f_bits(float f)       { uint32_t u; memcpy(&u, &f, 4); return u; }
static double   as_double(uint64_t u) { double d;   memcpy(&d, &u, 8); return d; }
static uint64_t d_bits(double d)      { uint64_t u; memcpy(&u, &d, 8); return u; }

/* 开方用 SSE 标量指令内联实现，自包含、不引用 libm（sandbox/Windows 交叉
   均无 -lm，且用户会在各种标准环境直接编译）。负数/NaN 由 sqrtsd/sqrtss
   自身按 IEEE 产生 NaN，与真实 SSE 指令完全一致。 */
static uint64_t hw_sqrt_bits(uint64_t u, int is32) {
    if (is32) {
        float x = as_float((uint32_t)u), r;
        __asm__("sqrtss %1, %0" : "=x"(r) : "x"(x));
        return f_bits(r);
    } else {
        double x = as_double(u), r;
        __asm__("sqrtsd %1, %0" : "=x"(r) : "x"(x));
        return d_bits(r);
    }
}

static void sse_read(const vm_t *v, const bc_t *b, uint8_t kind, uint8_t reg,
                     uint8_t wbits, uint64_t mask,
                     uint64_t *lo, uint64_t *hi, int *trap, const char **why) {
    *lo = 0; *hi = 0;
    if (kind == OK_XMM) { *lo = v->xmm[reg & 15][0]; *hi = v->xmm[reg & 15][1]; return; }
    if (kind == OK_REG) { *lo = v->r[reg]; return; }
    if (kind == OK_IMM) { *lo = (uint64_t)b->imm ^ mask; return; }
    if (kind == OK_MEM || kind == OK_RIPREL) {
        uint64_t addr;
        if (!mem_addr(v, b, reg, mask, 1, &addr)) { *trap = 1; *why = "SSE 内存地址越界"; return; }
        *lo = load_mem(v, addr, wbits >= 64 ? 64 : wbits);
        if (wbits >= 128) *hi = load_mem(v, addr + 8, 64);
        return;
    }
}
static void sse_write(vm_t *v, const bc_t *b, uint8_t kind, uint8_t reg,
                      uint8_t wbits, uint64_t mask, uint64_t lo, uint64_t hi,
                      int *trap, const char **why) {
    if (kind == OK_XMM) { v->xmm[reg & 15][0] = lo; v->xmm[reg & 15][1] = hi; return; }
    if (kind == OK_REG) { v->r[reg] = (wbits >= 64) ? lo : trim(lo, wbits); return; }
    if (kind == OK_MEM || kind == OK_RIPREL) {
        uint64_t addr;
        if (!mem_addr(v, b, reg, mask, 1, &addr)) { *trap = 1; *why = "SSE 写地址越界"; return; }
        store_mem(v, addr, lo, wbits >= 64 ? 64 : wbits);
        if (wbits >= 128) store_mem(v, addr + 8, hi, 64);
        return;
    }
    *trap = 1; *why = "SSE 写入目标非法";
}

/* v9：打包整数 SIMD 单 lane 运算（lw: 0=B 1=W 2=D 3=Q）。返回 lane 宽度的结果。
 * 元素字节数 = 1<<lw（B=1 W=2 D=4 Q=8），故位宽掩码 = (1<<(1<<lw))*8 位，
 * 仅 Q(lw=3) 用全 1（(1<<64) 在 64 位整数下为 UB，故特判）。 */
static uint64_t pint_lane(uint8_t op, uint64_t a, uint64_t b, uint8_t lw) {
    uint64_t m = (lw >= 3) ? ~(uint64_t)0 : ((1ULL << ((1u << lw) * 8u)) - 1);
    uint64_t ra = a & m, rb = b & m;
    switch (op) {
        case PINT_ADD:  return (ra + rb) & m;
        case PINT_SUB:  return (ra - rb) & m;
        case PINT_AND:  return ra & rb;
        case PINT_OR:   return ra | rb;
        case PINT_XOR:  return ra ^ rb;
        case PINT_ANDN: return (~ra) & rb;
        case PINT_CMPEQ: return (ra == rb) ? m : 0;
    }
    return 0;
}

/* ----------------------------------------------------------------
 * VM-exit 异常穿透（第九批 #36，仅 POSIX；Windows 走桩）
 * VM-exit 会把控制权交给宿主真实函数；若该宿主函数触发段错误 / 浮点异常 /
 * 非法指令（如解引用空指针、除零），默认会直接终止进程。这里在 VM-exit 调用
 * 外包裹一层信号安全网（sigsetjmp + 信号处理器），把这类宿主异常捕获为带
 * 原因的 TRAP，使 VM 优雅终止而非拖垮宿主进程。安全网用线程局部状态，
 * 多线程 VM 上下文各线程独立，互不干扰。
 * ---------------------------------------------------------------- */
#if defined(CSVM_SIGNAL_GUARD)

/* ---- 第九批（多线程上下文）VM-exit 异常安全网重写 ----
   旧实现两个多线程问题：
   ① 每次 VM-exit 做 8 次 sigaction 安装/还原 —— 外部调用越频繁越慢，
      且 csvm_old_sa[] 是进程级静态，两线程并发安装时互相覆盖「旧处理器」；
   ② csvm_in_exit 是线程局部的，没有 frame 栈，VM → 宿主函数 → VM 的嵌套
      场景下内层会直接跳过安全网。
   现在：
   · 安装/还原提到 run 级，用互斥 + 引用计数，进程内只装一次；
   · 每线程一个 frame 栈（可嵌套、可重入），故障只 longjmp 到本线程栈顶；
   · 本线程不在安全网内时，链回安装前保存的处理器 / 重新递送默认行为，
     不吞别的线程或宿主自己的异常。 */
typedef struct csvm_guard_frame {
    sigjmp_buf                jb;
    struct csvm_guard_frame  *prev;
} csvm_guard_frame_t;

static __thread csvm_guard_frame_t *csvm_tls_frame = NULL;
static __thread volatile int         csvm_tls_fault = 0;
static pthread_mutex_t csvm_guard_mu = PTHREAD_MUTEX_INITIALIZER;
static int             csvm_guard_refs = 0;
static int             csvm_guard_installed = 0;
static struct sigaction csvm_guard_old[4];
static const int       csvm_fault_sigs[4] = { SIGSEGV, SIGBUS, SIGFPE, SIGILL };

static void csvm_fault_handler(int sig, siginfo_t *si, void *uc) {
    if (csvm_tls_frame) {
        csvm_tls_fault = sig;
        siglongjmp(csvm_tls_frame->jb, sig);
    }
    /* 本线程不在安全网内：链回安装前的处理器；没有则恢复默认并重新递送。 */
    for (int i = 0; i < 4; ++i) {
        if (csvm_fault_sigs[i] != sig) continue;
        struct sigaction *old = &csvm_guard_old[i];
        if (old->sa_flags & SA_SIGINFO) {
            if (old->sa_sigaction && old->sa_sigaction != csvm_fault_handler) {
                old->sa_sigaction(sig, si, uc);
                return;
            }
        } else if (old->sa_handler && old->sa_handler != SIG_DFL &&
                   old->sa_handler != SIG_IGN) {
            old->sa_handler(sig);
            return;
        }
        break;
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

static void csvm_guard_run_begin(void) {
    pthread_mutex_lock(&csvm_guard_mu);
    if (++csvm_guard_refs == 1 && !csvm_guard_installed) {
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_sigaction = csvm_fault_handler;
        sa.sa_flags = SA_SIGINFO | SA_NODEFER;
        sigemptyset(&sa.sa_mask);
        for (int i = 0; i < 4; ++i)
            sigaction(csvm_fault_sigs[i], &sa, &csvm_guard_old[i]);
        csvm_guard_installed = 1;
    }
    pthread_mutex_unlock(&csvm_guard_mu);
}

static void csvm_guard_run_end(void) {
    pthread_mutex_lock(&csvm_guard_mu);
    if (csvm_guard_refs > 0 && --csvm_guard_refs == 0 && csvm_guard_installed) {
        for (int i = 0; i < 4; ++i)
            sigaction(csvm_fault_sigs[i], &csvm_guard_old[i], NULL);
        csvm_guard_installed = 0;
    }
    pthread_mutex_unlock(&csvm_guard_mu);
}

/* 关键：sigsetjmp 必须待在一个只干「进去/回来」两件事的独立函数里。
   之前的写法把 sigsetjmp 的返回值直接赋给 vm_do_exit 的局部变量，longjmp
   之后那些局部变量（rc / fault）按 C 标准是未定义的，实测会拿到信号号并
   走错分支。现在包裹函数只返回 0/故障标志，调用方不再依赖被 longjmp
   打断的局部状态。 */
__attribute__((noinline))
static int csvm_call_exit_gpr(csvm_exit_fn fn, void *ctx,
                              uint64_t target, uint64_t gpr[16], int *fault) {
    csvm_guard_frame_t fr;
    csvm_tls_fault = 0;
    fr.prev = csvm_tls_frame;
    csvm_tls_frame = &fr;
    if (sigsetjmp(fr.jb, 1) != 0) {
        csvm_tls_frame = fr.prev;
        *fault = 1;
        return 0;
    }
    int rc = fn(ctx, target, gpr);
    csvm_tls_frame = fr.prev;
    *fault = csvm_tls_fault ? 1 : 0;
    return rc;
}

__attribute__((noinline))
static int csvm_call_exit_fpu(csvm_exit_fpu_fn fn, void *ctx, uint64_t target,
                              uint64_t gpr[16], uint64_t xmm[16][2], int *fault) {
    csvm_guard_frame_t fr;
    csvm_tls_fault = 0;
    fr.prev = csvm_tls_frame;
    csvm_tls_frame = &fr;
    if (sigsetjmp(fr.jb, 1) != 0) {
        csvm_tls_frame = fr.prev;
        *fault = 1;
        return 0;
    }
    int rc = fn(ctx, target, gpr, xmm);
    csvm_tls_frame = fr.prev;
    *fault = csvm_tls_fault ? 1 : 0;
    return rc;
}

#elif defined(CSVM_VEH_GUARD)
/* ---- Windows 异常安全网（第十批引入；v3.2.4 真机验证后重写为 SEH __try/__except）----
   旧实现：进程级 VEH + 异常 CONTEXT 手工改写（Rip=恢复点、Rsp=帧快照）。
   真机首跑发现会挂死：手工把 Rsp 复位到 RtlCaptureContext 采样值与编译器
   实际的栈帧布局不对应，恢复点继续执行时反复触发同一异常，进程 100% CPU 假死。
   新实现：在 csvm_call_exit_gpr/fpu 里直接用 SEH __try/__except —— 异常帧
   挂在本函数自己的栈上、由操作系统按 .pdata/.xdata 正确展开，天然线程局部、
   天然可嵌套可重入，无需手工改写 CONTEXT，也不需要 VEH 安装/引用计数。
   捕获范围与旧版一致：AV / 非法指令 / 除零 / 特权指令。二次异常（栈溢出等）
   不在捕获范围，行为与 Linux 信号安全网一致。 */
#include <excpt.h>

static LONG csvm_seh_filter(DWORD code) {
    switch (code) {
        case EXCEPTION_ACCESS_VIOLATION:
        case EXCEPTION_ILLEGAL_INSTRUCTION:
        case EXCEPTION_INT_DIVIDE_BY_ZERO:
        case EXCEPTION_PRIV_INSTRUCTION:
            return EXCEPTION_EXECUTE_HANDLER;
        default:
            return EXCEPTION_CONTINUE_SEARCH;
    }
}

__attribute__((noinline))
static int csvm_call_exit_gpr(csvm_exit_fn fn, void *ctx,
                              uint64_t target, uint64_t gpr[16], int *fault) {
    int rc = 0;
    *fault = 0;
    __try {
        rc = fn(ctx, target, gpr);
    } __except (csvm_seh_filter(GetExceptionCode())) {
        *fault = 1;
        return 0;
    }
    return rc;
}

__attribute__((noinline))
static int csvm_call_exit_fpu(csvm_exit_fpu_fn fn, void *ctx, uint64_t target,
                              uint64_t gpr[16], uint64_t xmm[16][2], int *fault) {
    int rc = 0;
    *fault = 0;
    __try {
        rc = fn(ctx, target, gpr, xmm);
    } __except (csvm_seh_filter(GetExceptionCode())) {
        *fault = 1;
        return 0;
    }
    return rc;
}

static void csvm_guard_run_begin(void) { }   /* SEH：异常帧随调用栈自动装卸 */
static void csvm_guard_run_end(void) { }

#else  /* 其它平台：安全网桩 */
static void csvm_guard_run_begin(void) { }
static void csvm_guard_run_end(void) { }
static int csvm_call_exit_gpr(csvm_exit_fn fn, void *ctx,
                              uint64_t target, uint64_t gpr[16], int *fault) {
    *fault = 0;
    return fn(ctx, target, gpr);
}
static int csvm_call_exit_fpu(csvm_exit_fpu_fn fn, void *ctx, uint64_t target,
                              uint64_t gpr[16], uint64_t xmm[16][2], int *fault) {
    *fault = 0;
    return fn(ctx, target, gpr, xmm);
}
#endif /* CSVM_SIGNAL_GUARD */

/* 统一 VM-exit 分派（第八批）：按 need_fpu 选择 GPR 或 GPR+XMM 通道。
   含 BC_FLAG_NEED_FPU 的字节码只会走 fpu 分支，且 run_blob 入口已保证
   fpu_exitfn 非空；否则任何缺 XMM 搬运的路径都在入口被拒绝，绝不静默算错。 */
static int vm_do_exit(vm_t *v, const bc_hdr_t *h, uint64_t target,
                      int *trap, const char **why) {
    uint64_t gpr[16];
    for (int i = 0; i < 16; ++i) gpr[i] = v->r[h->reg_map[i]];
    int rc = 0, fault = 0;

    if (v->need_fpu) {
        uint64_t xmm[16][2];
        for (int i = 0; i < 16; ++i) {
            xmm[i][0] = v->xmm[i][0]; xmm[i][1] = v->xmm[i][1];
        }
        rc = csvm_call_exit_fpu(v->fpu_exitfn, v->fpu_exit_ctx, target,
                                gpr, xmm, &fault);
        for (int i = 0; i < 16 && !fault; ++i) {
            v->xmm[i][0] = xmm[i][0]; v->xmm[i][1] = xmm[i][1];
        }
        csvm_sec_zero(xmm, sizeof(xmm));
    } else if (!v->exitfn) {
        *trap = 1; *why = "未提供 VM-exit 回调"; return -1;
    } else {
        rc = csvm_call_exit_gpr(v->exitfn, v->exit_ctx, target, gpr, &fault);
    }

    if (fault) {
        *trap = 1;
        *why = "VM-exit 外部调用触发宿主异常（段错误/浮点/非法指令），已捕获为 TRAP";
        return -1;
    }
    if (rc != 0) { *trap = 1; *why = "VM-exit 原生调用失败"; return -1; }
    /* 全量回写：符合 x86 语义（volatile 被破坏、nonvolatile 由桩保留）。 */
    for (int i = 0; i < 16; ++i) v->r[h->reg_map[i]] = gpr[i];
    return 0;
}

/* ============================================================
 * 间接分派 + handler 变异（第九批落地，v3.2.4 强化）
 * 主执行体抽成 exec_step()；对每个受变异的逻辑 op 提供
 * 「标准 + 3 套噪声变体」共 4 套等价 handler，由各 build 的 seed 决定
 * 每个 op 选用哪套（每 op 2 bit 选择子，见 csvm_dispatch_mask），使
 * 每 build 的 handler 代码集合与分派组合都不同。
 * 噪声变体仅注入与真实状态无关的本地不透明计算（volatile，不会被
 * 优化删除），不触碰任何 VM 可见状态，因此绝对不改变语义。
 * ============================================================ */
#define RDA() read_oper(v, b, b->a_kind, b->a_reg, b->width, mask, &trap, &why)
#define RDB() read_oper(v, b, b->b_kind, b->b_reg, b->width, mask, &trap, &why)
#define WRA(x) write_oper(v, b, b->a_kind, b->a_reg, b->width, (x), mask, &trap, &why)
#define PUSHV(x) do { uint64_t _sp = v->r[h->reg_map[X_RSP]] - 8; \
                      v->r[h->reg_map[X_RSP]] = _sp; \
                      store_mem(v, _sp, (x), 64); } while (0)
#define POPV(dst) do { uint64_t _sp = v->r[h->reg_map[X_RSP]]; \
                       (dst) = load_mem(v, _sp, 64); \
                       v->r[h->reg_map[X_RSP]] = _sp + 8; } while (0)

typedef void (*csvm_hfn)(vm_t *v, const bc_t *b, const bc_hdr_t *h,
                         uint64_t mask, int *trap, const char **why,
                         uint32_t pc, uint32_t *next, int *halt,
                         int host_mode, const csvm_open_t *oc);

/* 主执行体：等价原 run_blob 内联 switch(lop)，抽成独立函数便于间接分派。
   v3.3.5 起操作码语义体统一放在 codevm_ops.inc，由两种分派共用：
     - GNU/clang（构建期与发布 DLL 的实际工具链）：computed-goto 间接分派，
       中心 switch 消失，分派表经 per-run 密钥异或后不在 .rdata 留明文地址；
     - 其余编译器（MSVC 等）：退回中心 switch（能力不虚标，见文档）。
   trap/why/next 为局部值；halt 经出参回写，next 在末尾回写。 */
static void exec_step(vm_t *v, const bc_t *b, const bc_hdr_t *h,
                     uint64_t mask, int *trap_out, const char **why_out,
                     uint32_t pc, uint32_t *next_out, int *halt_out,
                     int host_mode, const csvm_open_t *oc) {
    int trap = 0; const char *why = "";
    uint32_t next = pc + 1;
    const uint32_t n_insn = oc->fh.n_insn;
    uint8_t lop = h->dec_map[b->opc];
        uint8_t w = b->width ? b->width : 64;
        uint64_t a = 0, bb = 0, res = 0;
#if defined(CSVM_USE_CG)
    /* 标签地址表：designated initializer 保证下标 == 逻辑 op 枚举值。
       首次调用把地址发布到文件级表，供 run 初始化 per-run 混淆副本。 */
    static void *const cg_plain[BC_COUNT] = {
        [IR_NOP] = &&L_IR_NOP,
        [IR_MOV] = &&L_IR_MOV,
        [IR_MOVZX] = &&L_IR_MOVZX,
        [IR_MOVSX] = &&L_IR_MOVSX,
        [IR_LEA] = &&L_IR_LEA,
        [IR_ADD] = &&L_IR_ADD,
        [IR_SUB] = &&L_IR_SUB,
        [IR_XOR] = &&L_IR_XOR,
        [IR_AND] = &&L_IR_AND,
        [IR_OR] = &&L_IR_OR,
        [IR_CMP] = &&L_IR_CMP,
        [IR_TEST] = &&L_IR_TEST,
        [IR_INC] = &&L_IR_INC,
        [IR_DEC] = &&L_IR_DEC,
        [IR_NEG] = &&L_IR_NEG,
        [IR_NOT] = &&L_IR_NOT,
        [IR_IMUL] = &&L_IR_IMUL,
        [IR_IMUL3] = &&L_IR_IMUL3,
        [IR_SHL] = &&L_IR_SHL,
        [IR_SHR] = &&L_IR_SHR,
        [IR_SAR] = &&L_IR_SAR,
        [IR_ROL] = &&L_IR_ROL,
        [IR_ROR] = &&L_IR_ROR,
        [IR_PUSH] = &&L_IR_PUSH,
        [IR_POP] = &&L_IR_POP,
        [IR_JMP] = &&L_IR_JMP,
        [IR_JCC] = &&L_IR_JCC,
        [IR_CALL] = &&L_IR_CALL,
        [IR_RET] = &&L_IR_RET,
        [IR_CMOV] = &&L_IR_CMOV,
        [IR_SETCC] = &&L_IR_SETCC,
        [IR_MUL] = &&L_IR_MUL,
        [IR_IMUL1] = &&L_IR_IMUL1,
        [IR_DIV] = &&L_IR_DIV,
        [IR_IDIV] = &&L_IR_IDIV,
        [IR_CQO] = &&L_IR_CQO,
        [IR_CALLEXT] = &&L_IR_CALLEXT,
        [IR_JMPI] = &&L_IR_JMPI,
        [IR_FSSE] = &&L_IR_FSSE,
        [IR_REP] = &&L_IR_REP,
        [IR_TAILEXIT] = &&L_IR_TAILEXIT,
        [IR_SETDF] = &&L_IR_SETDF,
        [IR_TRAP] = &&L_IR_TRAP,
        [IR_HALT] = &&L_IR_HALT,
        [IR_ATOMIC] = &&L_IR_ATOMIC,
        [BC_JUNK] = &&L_BC_JUNK,
    };
    if (!v->cg_ready) {
        for (int i = 0; i < BC_COUNT; ++i)
            v->cg_enc[i] = (void *)((uintptr_t)cg_plain[i]
                                    ^ csvm_cg_mask((uint8_t)i, v->cg_key));
        v->cg_ready = 1;
    }
    if (lop >= BC_COUNT) goto L_default;   /* 越界 op 落到防御性 TRAP 分支 */
    /* 逐条随机化：enc[i] = plain[i] ^ mask(i, per-run key)，分派时再解回。
       静态 dump 拿不到明文跳转表；每条指令只做一次整数 mix。 */
    void *cg_target = (void *)((uintptr_t)v->cg_enc[lop]
                               ^ csvm_cg_mask(lop, v->cg_key));
    goto *cg_target;
    do {
#define CS_CASE(op) L_##op:
#define CS_DEFAULT  L_default:
#include "codevm_ops.inc"
#undef CS_CASE
#undef CS_DEFAULT
    } while (0);
#else
#define CS_CASE(op) case op:
#define CS_DEFAULT  default:
    switch (lop) {
#include "codevm_ops.inc"
    }
#undef CS_CASE
#undef CS_DEFAULT
#endif
    *trap_out = trap; *why_out = why; *next_out = next;
}

/* 噪声变体 handler（v3.2.4 起：每个受变异逻辑 op 有 3 套不同的噪声体）。
   注入与真实状态无关的本地不透明计算（volatile，编译器不会删除），使
   同一逻辑 op 在不同 build 里可落入 4 套（标准 + 3 噪声）代码体之一；
   噪声只读 pc / mask / 指针地址等入参派生值，绝不触碰任何 VM 可见状态，
   因此语义与标准版逐位等价。 */
static void exec_step(vm_t *v, const bc_t *b, const bc_hdr_t *h,
                      uint64_t mask, int *trap_out, const char **why_out,
                      uint32_t pc, uint32_t *next_out, int *halt_out,
                      int host_mode, const csvm_open_t *oc);

static void exec_op_noisy1(vm_t *v, const bc_t *b, const bc_hdr_t *h,
                           uint64_t mask, int *trap, const char **why,
                           uint32_t pc, uint32_t *next, int *halt,
                           int host_mode, const csvm_open_t *oc) {
    volatile uint64_t _d = (uint64_t)(uintptr_t)v ^ mask ^ (uint64_t)pc
                         ^ ((uint64_t)(uintptr_t)h << 3);
    (void)_d;
    exec_step(v, b, h, mask, trap, why, pc, next, halt, host_mode, oc);
}

/* 噪声变体 2：xorshift 游走（与标准版相同的语义，前置死代码不同） */
static void exec_op_noisy2(vm_t *v, const bc_t *b, const bc_hdr_t *h,
                           uint64_t mask, int *trap, const char **why,
                           uint32_t pc, uint32_t *next, int *halt,
                           int host_mode, const csvm_open_t *oc) {
    volatile uint64_t _d = ((uint64_t)pc + 0x9E3779B97F4A7C15ULL)
                         ^ (mask * 0xBF58476D1CE4E5B9ULL)
                         ^ ((uint64_t)(uintptr_t)b << 5);
    _d ^= _d << 13; _d ^= _d >> 7; _d ^= _d << 17;
    _d += (uint64_t)(uintptr_t)h;
    (void)_d;
    exec_step(v, b, h, mask, trap, why, pc, next, halt, host_mode, oc);
}

/* 噪声变体 3：乘加混合 + 双向字节旋转 */
static void exec_op_noisy3(vm_t *v, const bc_t *b, const bc_hdr_t *h,
                           uint64_t mask, int *trap, const char **why,
                           uint32_t pc, uint32_t *next, int *halt,
                           int host_mode, const csvm_open_t *oc) {
    volatile uint64_t _d = (mask ^ ((uint64_t)pc * 0x100000001B3ULL))
                         + ((uint64_t)(uintptr_t)v >> 3);
    _d *= 0xD6E8FEB86659FD93ULL;
    _d = (_d >> 41) | (_d << 23);
    _d ^= (uint64_t)(uintptr_t)oc ^ mask;
    (void)_d;
    exec_step(v, b, h, mask, trap, why, pc, next, halt, host_mode, oc);
}

static void (*const csvm_noisy_tab[4])(vm_t *, const bc_t *, const bc_hdr_t *,
                                       uint64_t, int *, const char **,
                                       uint32_t, uint32_t *, int *, int,
                                       const csvm_open_t *) = {
    exec_op_noisy1, exec_op_noisy2, exec_op_noisy3
};

/* 第九批（多线程上下文）：handler 分派不再驻留全局表。
   旧实现把「哪些逻辑 op 走噪声等价 handler」写进进程级 g_handlers[]，
   每次 run 用 blob 的 seed 重建 —— 两个线程跑不同 seed 的字节码时，
   函数指针被并发改写（数据竞争，形式上是 UB）。
   现在改为纯函数算一个 64 位选择子掩码（每逻辑 op 2 bit，0=标准 1..3=噪声
   变体），掩码只放 run_blob 的栈帧里：任何线程都不再写共享状态，
   同一 seed 选出同一组变体，与旧实现逐位等价。 */
/* splitmix64：确定性 PRNG，仅用于挑选 handler 变体（无共享状态）。 */
static uint64_t csvm_disp_rng(uint64_t *s) {
    uint64_t z = (*s += 0x9E3779B97F4A7C15ULL);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}

/* 每逻辑 op 2 bit：00=标准 handler，01/10/11 = 三套噪声变体之一。
   只覆盖 mutate_ops 列出的整数/逻辑类 op；其余 op（控制流、内存、SSE、
   VM-exit 等）恒走标准实现，避免在带副作用的路径上做任何额外工作。 */
static uint64_t csvm_dispatch_mask(uint64_t seed) {
    static const int mut_ops[] = {
        IR_ADD, IR_SUB, IR_XOR, IR_AND, IR_OR, IR_CMP, IR_TEST,
        IR_MOV, IR_INC, IR_DEC, IR_NOT, IR_NEG, IR_IMUL, IR_IMUL3
    };
    uint64_t mask = 0;
    uint64_t s = seed ^ 0xC5B17E1D2A3F4C09ULL;
    for (size_t i = 0; i < sizeof(mut_ops) / sizeof(mut_ops[0]); ++i) {
        int op = mut_ops[i];
        if (op < 0 || op > 31) continue;
        uint64_t rnd = csvm_disp_rng(&s);
        if (rnd & 1u) {                     /* 参与变异的概率与旧版一致（1/2） */
            uint64_t variant = (rnd >> 8) & 3u;
            if (!variant) variant = 1;      /* 参与变异即选 1..3（0 留给标准版） */
            mask |= variant << (op * 2);
        }
    }
    return mask;
}

/* ---- 第九批（多线程上下文）：每线程 VM 上下文池 ----
   vm_t 里带 64KB 沙箱内存 + XMM 文件，旧实现每 run 都 calloc/free 一次，
   高频调用时是 malloc 风暴。这里给每线程一个复用池：拿不到就新建，
   归还时擦除敏感字段再挂回本线程空闲链（最多 4 个）；线程退出由 pthread_key
   析构回收。嵌套 run（VM → 宿主函数 → VM）会自然再借一个，不会互相踩。 */
#define CSVM_CTX_POOL_MAX 4

typedef struct csvm_ctx_node {
    vm_t *v;
    struct csvm_ctx_node *next;
} csvm_ctx_node_t;

#if defined(CSVM_WIN_TLS)
/* ---- Windows 版每线程上下文池（第十批，对标 Linux 的 pthread_key 池）----
   与 POSIX 版同样的策略：每线程空闲链最多 4 个 vm_t，借用时只复位必要字段，
   归还时擦寄存器/XMM；线程退出由 FLS 回调释放链上剩余节点。
   为什么不用 __declspec(thread)：DLL 的动态 TLS 在老系统/动态加载场景有坑，
   FLS 明确带析构回调，行为与 pthread_key 对齐。 */
static DWORD csvm_fls_index = FLS_OUT_OF_INDEXES;
static volatile LONG csvm_fls_once = 0;
static CSVM_TLS csvm_ctx_node_t *csvm_tls_pool = NULL;
static CSVM_TLS int csvm_tls_pool_len = 0;
static CSVM_TLS int csvm_tls_borrowed = 0;

static void WINAPI csvm_pool_fls_dtor(void *p) {
    csvm_ctx_node_t *n = (csvm_ctx_node_t *)p;
    while (n) { csvm_ctx_node_t *nx = n->next; free(n->v); free(n); n = nx; }
}

static void csvm_pool_ensure(void) {
    if (InterlockedCompareExchange(&csvm_fls_once, 1, 0) == 0)
        csvm_fls_index = FlsAlloc(csvm_pool_fls_dtor);
}

static vm_t *csvm_ctx_acquire(void) {
    csvm_pool_ensure();
    vm_t *v = NULL;
    if (csvm_tls_pool) {
        csvm_ctx_node_t *n = csvm_tls_pool;
        csvm_tls_pool = n->next; csvm_tls_pool_len--;
        v = n->v; free(n);
        if (csvm_fls_index != FLS_OUT_OF_INDEXES)
            FlsSetValue(csvm_fls_index, csvm_tls_pool);
    } else {
        v = (vm_t *)calloc(1, sizeof(vm_t));
        if (!v) return NULL;
        if (csvm_fls_index != FLS_OUT_OF_INDEXES)
            FlsSetValue(csvm_fls_index, NULL);
    }
    memset(v->r, 0, sizeof(v->r));
    memset(v->xmm, 0, sizeof(v->xmm));
    v->flags = 0; v->steps = 0; v->host_mode = 0; v->runtime_base = 0;
    v->memfn = NULL; v->mem_ctx = NULL;
    v->callstack[0] = 0; v->csp = 0;
    v->exitfn = NULL; v->exit_ctx = NULL;
    v->fpu_exitfn = NULL; v->fpu_exit_ctx = NULL; v->need_fpu = 0;
    csvm_tls_borrowed++;
    return v;
}

static void csvm_ctx_release(vm_t *v) {
    if (!v) return;
    csvm_sec_zero(v->r, sizeof(v->r));
    csvm_sec_zero(v->xmm, sizeof(v->xmm));
    if (csvm_tls_borrowed > 0) csvm_tls_borrowed--;
    if (csvm_tls_pool_len < CSVM_CTX_POOL_MAX) {
        csvm_ctx_node_t *n = (csvm_ctx_node_t *)malloc(sizeof(*n));
        if (n) {
            n->v = v; n->next = csvm_tls_pool; csvm_tls_pool = n; csvm_tls_pool_len++;
            if (csvm_fls_index != FLS_OUT_OF_INDEXES)
                FlsSetValue(csvm_fls_index, csvm_tls_pool);
            return;
        }
    }
    free(v);
}
#elif defined(CSVM_TLS_POOL)
static pthread_key_t  csvm_pool_key;
static pthread_once_t csvm_pool_once = PTHREAD_ONCE_INIT;
static __thread csvm_ctx_node_t *csvm_tls_pool = NULL;
static __thread int csvm_tls_pool_len = 0;
static __thread int csvm_tls_borrowed = 0;

static void csvm_pool_dtor(void *p) {
    csvm_ctx_node_t *n = (csvm_ctx_node_t *)p;
    while (n) {
        csvm_ctx_node_t *nx = n->next;
        free(n->v); free(n); n = nx;
    }
}
static void csvm_pool_key_init(void) { pthread_key_create(&csvm_pool_key, csvm_pool_dtor); }

static vm_t *csvm_ctx_acquire(void) {
    pthread_once(&csvm_pool_once, csvm_pool_key_init);
    vm_t *v = NULL;
    if (csvm_tls_pool) {
        csvm_ctx_node_t *n = csvm_tls_pool;
        csvm_tls_pool = n->next; csvm_tls_pool_len--;
        v = n->v; free(n);
    } else {
        v = (vm_t *)calloc(1, sizeof(vm_t));
        if (!v) return NULL;
    }
    /* 只复位「每次 run 必须归零」的字段：寄存器文件 / 标志 / 步数 / XMM /
       上下文钩子。64KB 的 mem[] 不清零 —— 沙箱模式下 run_blob 会自己
       memset(mem)，宿主模式下 mem[] 根本不用。全量 memset 会让每次 run
       多花 ~8µs，短函数调用反而比 calloc 更慢（实测差距就在这里）。 */
    memset(v->r, 0, sizeof(v->r));
    memset(v->xmm, 0, sizeof(v->xmm));
    v->flags = 0; v->steps = 0; v->host_mode = 0; v->runtime_base = 0;
    v->memfn = NULL; v->mem_ctx = NULL;
    v->callstack[0] = 0; v->csp = 0;
    v->exitfn = NULL; v->exit_ctx = NULL;
    v->fpu_exitfn = NULL; v->fpu_exit_ctx = NULL; v->need_fpu = 0;
    csvm_tls_borrowed++;
    return v;
}

static void csvm_ctx_release(vm_t *v) {
    if (!v) return;
    /* 只擦敏感的小块（通用寄存器 + XMM）；大块 mem[] 留给下次 run 覆写。 */
    csvm_sec_zero(v->r, sizeof(v->r));
    csvm_sec_zero(v->xmm, sizeof(v->xmm));
    if (csvm_tls_borrowed > 0) csvm_tls_borrowed--;
    if (csvm_tls_pool_len < CSVM_CTX_POOL_MAX) {
        csvm_ctx_node_t *n = (csvm_ctx_node_t *)malloc(sizeof(*n));
        if (n) {
            n->v = v; n->next = csvm_tls_pool; csvm_tls_pool = n; csvm_tls_pool_len++;
            pthread_setspecific(csvm_pool_key, csvm_tls_pool);
            return;
        }
    }
    free(v);
}
#else
static void *csvm_ctx_acquire(void) { return calloc(1, sizeof(vm_t)); }
static void csvm_ctx_release(void *v) { free(v); }
#endif

static int run_blob_inner(const csvm_open_t *oc,
                    const uint64_t regs_in[16], uint64_t regs_out[16],
                    const uint64_t xmm_in[16][2], uint64_t xmm_out[16][2],
                    int host_mode, uint64_t runtime_base,
                    csvm_mem_fn memfn, void *mem_ctx,
                    csvm_exit_fn exitfn, void *exit_ctx,
                    csvm_exit_fpu_fn fpu_exitfn, void *fpu_exit_ctx,
                    char *err, size_t cap);

static int run_blob(const csvm_open_t *oc,
                    const uint64_t regs_in[16], uint64_t regs_out[16],
                    const uint64_t xmm_in[16][2], uint64_t xmm_out[16][2],
                    int host_mode, uint64_t runtime_base,
                    csvm_mem_fn memfn, void *mem_ctx,
                    csvm_exit_fn exitfn, void *exit_ctx,
                    csvm_exit_fpu_fn fpu_exitfn, void *fpu_exit_ctx,
                    char *err, size_t cap) {
    csvm_guard_run_begin();
    int rc = run_blob_inner(oc,
                    regs_in, regs_out, xmm_in, xmm_out, host_mode, runtime_base,
                    memfn, mem_ctx, exitfn, exit_ctx, fpu_exitfn, fpu_exit_ctx,
                    err, cap);
    csvm_guard_run_end();
    return rc;
}

static int run_blob_inner(const csvm_open_t *oc,
                    const uint64_t regs_in[16], uint64_t regs_out[16],
                    const uint64_t xmm_in[16][2], uint64_t xmm_out[16][2],
                    int host_mode, uint64_t runtime_base,
                    csvm_mem_fn memfn, void *mem_ctx,
                    csvm_exit_fn exitfn, void *exit_ctx,
                    csvm_exit_fpu_fn fpu_exitfn, void *fpu_exit_ctx,
                    char *err, size_t cap) {
    const bc_hdr_t *h = &oc->h;   /* v5 open 解密出的 meta（只读） */
    /* 正确性闸门：含浮点跨 VM-exit 的字节码必须同时具备 XMM 搬运通道与
       XMM 进出缓冲，否则明确拒绝，绝不返回错答案。 */
    uint64_t hmask = csvm_dispatch_mask(oc->fh.seed);
    int need_fpu = (oc->fh.flags & BC_FLAG_NEED_FPU) != 0;
    if (need_fpu && (!fpu_exitfn || !xmm_in || !xmm_out)) {
        set_err(err, cap, "该字节码含浮点参数跨 VM-exit，必须经带 XMM 通道的入口执行");
        return -8;
    }
    vm_t *v = (vm_t *)csvm_ctx_acquire();
    if (!v) { set_err(err, cap, "内存不足"); return -1; }
    for (int i = 0; i < 16; ++i) v->r[h->reg_map[i]] = regs_in[i];
    if (xmm_in)
        for (int i = 0; i < 16; ++i) {
            v->xmm[i][0] = xmm_in[i][0]; v->xmm[i][1] = xmm_in[i][1];
        }
    v->host_mode = host_mode;
    v->runtime_base = runtime_base;
    v->memfn = memfn;
    v->mem_ctx = mem_ctx;
    v->exitfn = exitfn;
    v->exit_ctx = exit_ctx;
    v->fpu_exitfn = fpu_exitfn;
    v->fpu_exit_ctx = fpu_exit_ctx;
    v->need_fpu = need_fpu;
#if defined(CSVM_USE_CG)
    /* 每次 run 换 key，复用 TLS 池里的 vm_t 也必须重建混淆表 */
    v->cg_key = h->imm_mask ^ oc->fh.seed ^ ((uint64_t)(uintptr_t)v << 7);
    v->cg_ready = 0;
    memset(v->cg_enc, 0, sizeof(v->cg_enc));
#endif
    if (!host_mode) {
        /* 沙箱模式：独立 64KB 内存 + 独立栈 + 入口返回哨兵 */
        v->r[h->reg_map[X_RSP]] = VM_STACK_TOP;
        memset(v->mem, 0, sizeof(v->mem));
        v->r[h->reg_map[X_RSP]] -= 8;
        store_mem(v, v->r[h->reg_map[X_RSP]], RET_SENTINEL, 64);
    }
    /* host 模式：RSP 直通真实栈，栈帧/参数/返回地址都在宿主内存里；
     * CALL/RET 走 v->callstack，不往真实栈压哨兵。 */

    uint64_t mask = h->imm_mask;
    const uint32_t n_insn = oc->fh.n_insn;
    uint32_t pc = 0;
    int trap = 0; const char *why = "";
    uint64_t steps = 0;
    bc_t cur; memset(&cur, 0, sizeof(cur));   /* v5：按需解密的栈上临时指令 */


    while (pc < n_insn) {
        if (++steps > 20000000ULL) { set_err(err, cap, "步数超限（可能死循环）"); csvm_ctx_release(v); return -2; }
        /* v5：指令体按 pc 按需解密到栈上临时 bc_t；磁盘上不留任何定长明文。 */
        if (csvm_v5_fetch(oc, pc, &cur, err, cap) != 0) { csvm_ctx_release(v); return -3; }
        const bc_t *b = &cur;
        uint8_t lop = h->dec_map[b->opc];
        uint32_t next = pc + 1;
        if (lop == OPC_NONE) { set_err(err, cap, "非法操作码 0x%02X @%u", b->opc, pc); csvm_ctx_release(v); return -3; }

        int halt = 0;
        {   /* handler 变异：每逻辑 op 2 bit 选 4 套等价体之一（0=标准 1..3=噪声）。
               只有 mut_ops 表里的整数/逻辑 op（值 < 32）会带非零选择子，
               其余 op（控制流/内存/SSE/VM-exit）恒走标准实现。 */
            uint64_t variant = (lop < 32) ? ((hmask >> (lop * 2)) & 3u) : 0u;
            if (variant)
                csvm_noisy_tab[variant - 1](v, b, h, mask, &trap, &why, pc, &next, &halt, host_mode, oc);
            else
                exec_step(v, b, h, mask, &trap, &why, pc, &next, &halt, host_mode, oc);
        }
        if (halt) goto done;
        if (trap) { set_err(err, cap, "VM TRAP @%u: %s", pc, why); csvm_ctx_release(v); return -6; }
        if (next >= n_insn && next != n_insn) {
            set_err(err, cap, "跳转越界 @%u -> %u", pc, next); csvm_ctx_release(v); return -7;
        }
        csvm_sec_zero(&cur, sizeof(cur));   /* 按需解密，用完即擦 */
        pc = next;
    }

done:
    csvm_sec_zero(&cur, sizeof(cur));
    for (int i = 0; i < 16; ++i) regs_out[i] = v->r[h->reg_map[i]];
    if (xmm_out)
        for (int i = 0; i < 16; ++i) {
            xmm_out[i][0] = v->xmm[i][0]; xmm_out[i][1] = v->xmm[i][1];
        }
    v->steps = steps;
    csvm_ctx_release(v);
    return 0;
#undef RDA
#undef RDB
#undef WRA
#undef PUSHV
#undef POPV
}

/* ---------------------------------------------------------------- 公共 ABI */

CSVM_API int csvm_compile(const uint8_t *code, size_t len, uint64_t seed,
                          uint8_t **out_bc, size_t *out_len,
                          char *err, size_t errcap) {
    /* 单段 = rva 0 的 CFG 闭包，统一走多段编译器，避免两份标签解析逻辑漂移。 */
    csvm_seg_t seg = { code, len, 0 };
    return csvm_compile_cfg(&seg, 1, seed, out_bc, out_len, err, errcap);
}

/* ---------------------------------------------------------------- CFG 闭包 */
/* 第八批第 2 项：把「函数必须是一段连续字节」改为「多段 CFG 闭包」。
   每段带真实 RVA；所有 IR 的 off / target_off / src_off / next_off 统一放在
   RVA 坐标空间，跨段跳转只要在闭包内就能闭环；闭包外的无条件直接 jmp 降级
   为 VM-exit tail（IR_TAILEXIT），解决 gcc -O2 sibling call；条件跳转到闭包
   外无法等价降级，明确报错并提示把目标段（如 .cold）作为附加 seg 传入。 */
CSVM_API int csvm_compile_cfg(const csvm_seg_t *segs, size_t nseg, uint64_t seed,
                              uint8_t **out_bc, size_t *out_len,
                              char *err, size_t errcap) {
    if (!segs || !nseg || nseg > CSVM_MAX_SEGS || !out_bc || !out_len) {
        set_err(err, errcap, "参数为空或段数非法（1..%u）", CSVM_MAX_SEGS); return -1;
    }
    *out_bc = NULL; *out_len = 0;
    size_t total_bytes = 0;
    /* 第九批：坐标原点取「所有段的最小 RVA」，段的 rva 按**有符号** 64 位解读，
       因此 .cold / .text.unlikely 落在主段之前（负 RVA）也能进同一闭包。
       注意运行期约定：多段 CFG 的 runtime_base 必须传 origin 对应的地址
       （= 镜像基址 + origin），单段（origin=0）调用方行为完全不变。 */
    int64_t origin = 0;
    int     origin_set = 0;
    for (size_t s = 0; s < nseg; ++s) {
        if (!segs[s].code || !segs[s].len) { set_err(err, errcap, "段 %zu 为空", s); return -1; }
        if (segs[s].len > CSVM_MAX_CODE || total_bytes + segs[s].len > CSVM_MAX_CODE) {
            set_err(err, errcap, "输入超过 1MB"); return -1;
        }
        int64_t sr = (int64_t)segs[s].rva;
        if (sr < -0x40000000LL || sr > 0x40000000LL) {
            set_err(err, errcap, "段 %zu 的 RVA 超出有符号 32 位坐标空间", s); return -1;
        }
        if (!origin_set || sr < origin) { origin = sr; origin_set = 1; }
        total_bytes += segs[s].len;
    }
    uint64_t span = 0;
    for (size_t s = 0; s < nseg; ++s) {
        int64_t sr = (int64_t)segs[s].rva;
        uint64_t base = (uint64_t)(sr - origin);
        if (base + segs[s].len > 0xFFFFFFFFull) {
            set_err(err, errcap, "段 %zu 归零后超出 32 位坐标空间（段跨度太大）", s); return -1;
        }
        if (base + segs[s].len > span) span = base + segs[s].len;
    }
    ir_t *irs = (ir_t *)calloc(total_bytes + 4, sizeof(ir_t));
    if (!irs) { set_err(err, errcap, "内存不足"); return -1; }
    uint32_t n = 0;
    for (size_t s = 0; s < nseg; ++s) {
        const uint8_t *code = segs[s].code;
        size_t len = segs[s].len;
        uint32_t base_rva = (uint32_t)((int64_t)segs[s].rva - origin);
        size_t pos = 0;
        while (pos < len) {
            raw_t r;
            int L = decode_one(code, len, (uint32_t)pos, &r, err, errcap);
            if (L <= 0) { free(irs); return -2; }
            if (!lift_one(&r, &irs[n], err, errcap)) { free(irs); return -3; }
            /* 段内字节偏移 -> 全局 RVA 坐标空间（单段 base_rva=0，完全等价） */
            irs[n].off = base_rva + irs[n].off;
            if (irs[n].op == IR_JMP || irs[n].op == IR_JCC || irs[n].op == IR_CALL)
                irs[n].target_off = (uint32_t)((uint64_t)irs[n].target_off + base_rva);
            pos += (size_t)L; n++;
            if (n > CSVM_MAX_INSN) { free(irs); set_err(err, errcap, "指令过多"); return -1; }
        }
    }
    for (uint32_t i = 0; i < n; ++i) {
        uint8_t op = irs[i].op;
        if (op != IR_JMP && op != IR_JCC && op != IR_CALL) continue;
        uint32_t t = irs[i].target_off;
        int32_t found = -1;
        for (uint32_t j = 0; j < n; ++j) if (irs[j].off == t) { found = (int32_t)j; break; }
        if (found < 0 && op == IR_CALL) {
            irs[i].op = IR_CALLEXT; irs[i].exit_kind = 1; irs[i].target_idx = 0;
            continue;
        }
        if (found < 0 && op == IR_JMP) {
            /* 无条件直接跳转闭包外：降级为 VM-exit tail，目标 RVA 保留在
               target_off，运行时 runtime_base + (int32)target_off 解析。 */
            irs[i].op = IR_TAILEXIT; irs[i].exit_kind = 1; irs[i].target_idx = 0;
            continue;
        }
        if (found < 0 && op == IR_JCC) {
            free(irs);
            set_err(err, errcap,
                "IR %u: 条件跳转目标 RVA %u 在 CFG 闭包外；请把目标代码段（如 .cold）作为附加 seg 传入",
                i, t);
            return -4;
        }
        irs[i].target_idx = found;
    }
    uint32_t junk = 0;
    uint32_t extra = (nseg > 1) ? BC_FLAG_CFG : 0u;
    int rc = compile_ir(irs, n, seed, (uint32_t)span, extra,
                        out_bc, out_len, &junk, err, errcap);
    free(irs);
    return rc;
}

/* 内部：打开 v5 容器并执行「非 fpu 入口」正确性闸门。
   allow_fpu=0 的入口遇到 BC_FLAG_NEED_FPU 明确拒绝，避免静默算错。 */
static int csvm_open_for_run(const uint8_t *bc, size_t len, csvm_open_t *oc,
                             int allow_fpu, char *err, size_t cap) {
    if (!bc || len < sizeof(csvm_file_hdr_t)) {
        set_err(err, cap, "字节码无效（不是 v5 加密容器）"); return -1;
    }
    if (csvm_v5_open(bc, len, oc, err, cap) != 0) return -1;
    if (!allow_fpu && (oc->fh.flags & BC_FLAG_NEED_FPU)) {
        csvm_v5_close(oc);
        set_err(err, cap,
            "该字节码含浮点参数跨 VM-exit，只允许 csvm_run_host_fpu 执行（拒绝静默算错）");
        return -9;
    }
    return 0;
}

CSVM_API int csvm_run_regs(const uint8_t *bc, size_t len,
                           const uint64_t regs_in[16], uint64_t regs_out[16],
                           char *err, size_t errcap) {
    if (!regs_in || !regs_out) { set_err(err, errcap, "参数为空"); return -1; }
    csvm_open_t oc;
    if (csvm_open_for_run(bc, len, &oc, 0, err, errcap) != 0) return -1;
    int rc = run_blob(&oc, regs_in, regs_out, NULL, NULL, 0, 0, NULL, NULL,
                      NULL, NULL, NULL, NULL, err, errcap);
    csvm_v5_close(&oc);
    return rc;
}

CSVM_API int csvm_host_mem_direct(void *ctx, uint64_t addr, void *buf,
                                  size_t n, int write) {
    (void)ctx;
    if (!buf || !n) return 0;
    /* 同进程 VM：绝对地址即宿主虚拟地址。生产实现应加映像/栈白名单。 */
    if (write) memcpy((void *)(uintptr_t)addr, buf, n);
    else memcpy(buf, (const void *)(uintptr_t)addr, n);
    return 0;
}

/* 唯一允许执行含 BC_FLAG_NEED_FPU 字节码的入口。need_fpu 时挂「带 XMM
   搬运」的默认桩（SysV / Win x64 汇编），传全 16×128 位 XMM 进出缓冲；
   自定义 GPR 回调或缺 XMM 缓冲一律明确拒绝，杜绝静默算错。 */
CSVM_API int csvm_run_host_fpu(const uint8_t *bc, size_t len,
                               const uint64_t regs_in[16], uint64_t regs_out[16],
                               const uint64_t xmm_in[16][2], uint64_t xmm_out[16][2],
                               uint64_t runtime_base,
                               csvm_mem_fn mem, void *mem_ctx,
                               csvm_exit_fn exitfn, void *exit_ctx,
                               char *err, size_t errcap) {
    if (!regs_in || !regs_out) { set_err(err, errcap, "参数为空"); return -1; }
    csvm_open_t oc;
    if (csvm_open_for_run(bc, len, &oc, 1, err, errcap) != 0) return -1;
    int need_fpu = (oc.fh.flags & BC_FLAG_NEED_FPU) != 0;
    csvm_exit_fpu_fn fpu_fn = NULL;
    void *fpu_ctx = NULL;
    csvm_exit_fn gpr_fn = exitfn;
    if (need_fpu) {
        if (exitfn || !xmm_in || !xmm_out) {
            csvm_v5_close(&oc);
            set_err(err, errcap,
                "含浮点跨 VM-exit 的字节码必须使用默认 XMM 桩且提供 xmm_in/out");
            return -9;
        }
        fpu_fn = csvm_default_exit_fpu;
        fpu_ctx = NULL;
    } else if (!gpr_fn) {
        gpr_fn = csvm_default_exit;
    }
    int rc = run_blob(&oc, regs_in, regs_out, xmm_in, xmm_out, 1, runtime_base,
                      mem ? mem : csvm_host_mem_direct, mem_ctx,
                      gpr_fn, exit_ctx, fpu_fn, fpu_ctx, err, errcap);
    csvm_v5_close(&oc);
    return rc;
}

CSVM_API int csvm_run_host_ex(const uint8_t *bc, size_t len,
                              const uint64_t regs_in[16], uint64_t regs_out[16],
                              uint64_t runtime_base,
                              csvm_mem_fn mem, void *mem_ctx,
                              csvm_exit_fn exitfn, void *exit_ctx,
                              char *err, size_t errcap) {
    if (!regs_in || !regs_out) { set_err(err, errcap, "参数为空"); return -1; }
    csvm_open_t oc;
    if (csvm_open_for_run(bc, len, &oc, 0, err, errcap) != 0) return -1;
    csvm_exit_fn fn = exitfn ? exitfn : csvm_default_exit;
    int rc = run_blob(&oc, regs_in, regs_out, NULL, NULL, 1, runtime_base,
                      mem ? mem : csvm_host_mem_direct, mem_ctx,
                      fn, exit_ctx, NULL, NULL, err, errcap);
    csvm_v5_close(&oc);
    return rc;
}

CSVM_API int csvm_run_host(const uint8_t *bc, size_t len,
                           const uint64_t regs_in[16], uint64_t regs_out[16],
                           uint64_t runtime_base,
                           csvm_mem_fn mem, void *mem_ctx,
                           char *err, size_t errcap) {
    return csvm_run_host_ex(bc, len, regs_in, regs_out, runtime_base,
                            mem, mem_ctx, NULL, NULL, err, errcap);
}

CSVM_API uint64_t csvm_enter(const uint8_t *bc, size_t len,
                              uint64_t slots[16], uint64_t runtime_base) {
    uint64_t rin[16], rout[16];
    memcpy(rin, slots, sizeof(rin));
    memset(rout, 0, sizeof(rout));
    char err[CSVM_ERR_CAP] = {0};
    int rc = csvm_run_host(bc, len, rin, rout, runtime_base,
                           NULL, NULL, err, sizeof(err));
    if (rc != 0) return rin[X_RAX];       /* 失败时保持进入时的 RAX，不伪造结果 */
    memcpy(slots, rout, sizeof(rout));
    return rout[X_RAX];
}

CSVM_API int csvm_run(const uint8_t *bc, size_t len,
                      const uint64_t *args, size_t nargs,
                      uint64_t *ret, char *err, size_t errcap) {
    uint64_t in[16] = {0}, out[16] = {0};
    static const uint8_t sysv[6] = { X_RDI, X_RSI, X_RDX, X_RCX, X_R8, X_R9 };
    if (nargs > 6) { set_err(err, errcap, "最多 6 个参数"); return -1; }
    for (size_t i = 0; i < nargs; ++i) in[sysv[i]] = args[i];
    int rc = csvm_run_regs(bc, len, in, out, err, errcap);
    if (rc == 0 && ret) *ret = out[X_RAX];
    return rc;
}

CSVM_API int csvm_disasm(const uint8_t *code, size_t len, char *out, size_t cap) {
    if (!out || !cap) return -1;
    size_t used = 0;
    int n = snprintf(out, cap, "off   len  IR        width  target\n");
    if (n > 0) used = (size_t)n;
    size_t pos = 0;
    while (pos < len && used < cap - 120) {
        raw_t r; char e[CSVM_ERR_CAP] = {0};
        int L = decode_one(code, len, (uint32_t)pos, &r, e, sizeof(e));
        if (L <= 0) {
            used += (size_t)snprintf(out + used, cap - used, "%04zx  --   %s\n", pos, e);
            break;
        }
        ir_t ir; char e2[CSVM_ERR_CAP] = {0};
        int ok = lift_one(&r, &ir, e2, sizeof(e2));
        /* 与 csvm_compile_cfg 的闭包解析保持一致：目标落在函数字节范围外的
           CALL -> CALLEXT（VM-exit 调用），无条件 JMP -> TAILEXIT（VM-exit
           tail）。如实显示，作为「原语已识别」的可见证据。 */
        int ext_call = ok && ir.op == IR_CALL && ir.target_off >= len;
        int ext_jmp  = ok && ir.op == IR_JMP  && ir.target_off >= len;
        int external = ext_call || ext_jmp;
        const char *nm = !ok ? "TRAP"
                       : ext_call ? "CALLEXT"
                       : ext_jmp  ? "TAILEXIT" : ir_name(ir.op);
        int branch = ok && (ir.op == IR_JMP || ir.op == IR_JCC || ir.op == IR_CALL);
        used += (size_t)snprintf(out + used, cap - used,
            "%04zx  %-3u  %-8s  %-5u  %s%s\n",
            pos, r.len, nm, r.width,
            branch ? (external ? "-> VM-exit " : "-> ") : "",
            ok ? "" : e2);
        if (!ok) used += (size_t)snprintf(out + used, cap - used, "      %s\n", e2);
        pos += (size_t)L;
    }
    return 0;
}

CSVM_API int csvm_stats(const uint8_t *bc, size_t len,
                        uint32_t *bc_insns, uint32_t *ir_insns,
                        uint32_t *junk_insns, uint64_t *seed_out) {
    csvm_open_t oc; char e[128];
    if (csvm_v5_open(bc, len, &oc, e, sizeof(e)) != 0) return -1;
    if (bc_insns)   *bc_insns   = oc.fh.n_insn;
    if (ir_insns)   *ir_insns   = oc.fh.n_ir;
    if (junk_insns) *junk_insns = oc.fh.n_junk;
    if (seed_out)   *seed_out   = oc.fh.seed;
    csvm_v5_close(&oc);
    return 0;
}

CSVM_API void csvm_free(void *p) { free(p); }
CSVM_API uint32_t csvm_abi_version(void) { return CSVM_ABI_VERSION; }
CSVM_API const char *csvm_version_string(void) {
    return "CyrilShield CodeVM 0.5 (x86-64 subset + CFG multi-seg + REP strings + FPU VM-exit + v5 encrypted container)";
}
