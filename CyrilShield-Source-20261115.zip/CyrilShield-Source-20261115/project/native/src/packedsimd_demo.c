/* CyrilShield —— 打包整数 SIMD 子集冷启动验证（System V / Linux）
 *
 * 用 gcc 真实编译 __m128i 打包整数运算（paddb/paddd/psubw/pand/por/pcmpeqb/
 * pshufd/packssdw），从独立 section 抽机器码 -> csvm_compile -> csvm_run_host，
 * 通过宿主真实内存读写 XMM；结果与原生 CPU 逐字节比对。
 *
 * 函数全部以「指针入参 + 内存读写 XMM」方式工作，避免 XMM 寄存器入参的调用约定
 * 差异，使验证聚焦于打包整数解释器本身。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#include "cs_codevm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <emmintrin.h>

/* 每个被测函数：in = 两个 __m128i；out = 一个 __m128i，全部走内存 */
__attribute__((used, noinline, noipa, section("pk_paddb")))
static void f_paddb(const __m128i *a, const __m128i *b, __m128i *o) {
    _mm_storeu_si128(o, _mm_add_epi8(_mm_loadu_si128(a), _mm_loadu_si128(b)));
}
__attribute__((used, noinline, noipa, section("pk_paddd")))
static void f_paddd(const __m128i *a, const __m128i *b, __m128i *o) {
    _mm_storeu_si128(o, _mm_add_epi32(_mm_loadu_si128(a), _mm_loadu_si128(b)));
}
__attribute__((used, noinline, noipa, section("pk_psubw")))
static void f_psubw(const __m128i *a, const __m128i *b, __m128i *o) {
    _mm_storeu_si128(o, _mm_sub_epi16(_mm_loadu_si128(a), _mm_loadu_si128(b)));
}
__attribute__((used, noinline, noipa, section("pk_pand")))
static void f_pand(const __m128i *a, const __m128i *b, __m128i *o) {
    _mm_storeu_si128(o, _mm_and_si128(_mm_loadu_si128(a), _mm_loadu_si128(b)));
}
__attribute__((used, noinline, noipa, section("pk_por")))
static void f_por(const __m128i *a, const __m128i *b, __m128i *o) {
    _mm_storeu_si128(o, _mm_or_si128(_mm_loadu_si128(a), _mm_loadu_si128(b)));
}
__attribute__((used, noinline, noipa, section("pk_pcmpeqb")))
static void f_pcmpeqb(const __m128i *a, const __m128i *b, __m128i *o) {
    _mm_storeu_si128(o, _mm_cmpeq_epi8(_mm_loadu_si128(a), _mm_loadu_si128(b)));
}
__attribute__((used, noinline, noipa, section("pk_pshufd")))
static void f_pshufd(const __m128i *a, const __m128i *b, __m128i *o) {
    (void)b;
    _mm_storeu_si128(o, _mm_shuffle_epi32(_mm_loadu_si128(a), 0x1B));
}
__attribute__((used, noinline, noipa, section("pk_packssdw")))
static void f_packssdw(const __m128i *a, const __m128i *b, __m128i *o) {
    _mm_storeu_si128(o, _mm_packs_epi32(_mm_loadu_si128(a), _mm_loadu_si128(b)));
}

extern const uint8_t __start_pk_paddb[], __stop_pk_paddb[];
extern const uint8_t __start_pk_paddd[], __stop_pk_paddd[];
extern const uint8_t __start_pk_psubw[], __stop_pk_psubw[];
extern const uint8_t __start_pk_pand[], __stop_pk_pand[];
extern const uint8_t __start_pk_por[], __stop_pk_por[];
extern const uint8_t __start_pk_pcmpeqb[], __stop_pk_pcmpeqb[];
extern const uint8_t __start_pk_pshufd[], __stop_pk_pshufd[];
extern const uint8_t __start_pk_packssdw[], __stop_pk_packssdw[];

static int check(const char *name, const uint8_t *code, size_t len,
                 const uint8_t *a, const uint8_t *b, const uint8_t *ref) {
    uint8_t *bc = NULL; size_t bcn = 0; char err[CSVM_ERR_CAP] = {0};
    int rc = csvm_compile(code, len, 0xC0FFEEu, &bc, &bcn, err, sizeof(err));
    if (rc != 0) { printf("  [%s] compile FAIL(%d): %s\n", name, rc, err); return -1; }
    uint8_t out[16] = {0}, vm_mem[64];
    memcpy(vm_mem + 0, a, 16);
    memcpy(vm_mem + 16, b, 16);
    memcpy(vm_mem + 32, out, 16);
    uint64_t stack[256] = {0}, rin[16] = {0}, rout[16] = {0};
    rin[7] = (uint64_t)(uintptr_t)(vm_mem + 0);   /* RDI = a */
    rin[6] = (uint64_t)(uintptr_t)(vm_mem + 16);  /* RSI = b */
    rin[2] = (uint64_t)(uintptr_t)(vm_mem + 32);  /* RDX = out */
    rin[4] = (uint64_t)(uintptr_t)&stack[128];
    rc = csvm_run_host(bc, bcn, rin, rout, (uint64_t)(uintptr_t)code,
                       NULL, NULL, err, sizeof(err));
    csvm_free(bc);
    if (rc != 0) { printf("  [%s] run FAIL(%d): %s\n", name, rc, err); return -1; }
    int ok = memcmp(vm_mem + 32, ref, 16) == 0;
    printf("  [%s] %s\n", name, ok ? "PASS" : "FAIL");
    if (!ok) {
        for (int i = 0; i < 16; ++i)
            printf("    vm[%2d]=%02x ref[%2d]=%02x\n", i, vm_mem[32+i], i, ref[i]);
        return -1;
    }
    return 0;
}

static uint8_t buf_a[16], buf_b[16], buf_ref[16];

int main(void) {
    int bad = 0;
    /* 用确定性的伪随机数据填充 */
    for (int i = 0; i < 16; ++i) { buf_a[i] = (uint8_t)(i*37+11); buf_b[i] = (uint8_t)(i*53+7); }

    /* 参考实现（逐 lane） */
    for (int i = 0; i < 16; ++i) buf_ref[i] = (uint8_t)(buf_a[i] + buf_b[i]);
    if (check("paddb", __start_pk_paddb, (size_t)(__stop_pk_paddb-__start_pk_paddb), buf_a, buf_b, buf_ref)) bad |= 1;
    for (int i = 0; i < 4; ++i) { int v=0; for(int j=0;j<4;j++) v += (int)buf_a[i*4+j]<<(j*8); for(int j=0;j<4;j++) v += (int)buf_b[i*4+j]<<(j*8); uint32_t r=(uint32_t)v; memcpy(buf_ref+i*4,&r,4); }
    if (check("paddd", __start_pk_paddd, (size_t)(__stop_pk_paddd-__start_pk_paddd), buf_a, buf_b, buf_ref)) bad |= 2;
    for (int i = 0; i < 8; ++i) { int16_t x=(int16_t)(buf_a[i*2]|buf_a[i*2+1]<<8), y=(int16_t)(buf_b[i*2]|buf_b[i*2+1]<<8); int16_t r=(int16_t)(x-y); memcpy(buf_ref+i*2,&r,2); }
    if (check("psubw", __start_pk_psubw, (size_t)(__stop_pk_psubw-__start_pk_psubw), buf_a, buf_b, buf_ref)) bad |= 4;
    for (int i = 0; i < 16; ++i) buf_ref[i] = buf_a[i] & buf_b[i];
    if (check("pand",  __start_pk_pand,  (size_t)(__stop_pk_pand -__start_pk_pand),  buf_a, buf_b, buf_ref)) bad |= 8;
    for (int i = 0; i < 16; ++i) buf_ref[i] = buf_a[i] | buf_b[i];
    if (check("por",   __start_pk_por,   (size_t)(__stop_pk_por  -__start_pk_por),   buf_a, buf_b, buf_ref)) bad |= 16;
    for (int i = 0; i < 16; ++i) buf_ref[i] = (buf_a[i]==buf_b[i]) ? 0xFF : 0x00;
    if (check("pcmpeqb", __start_pk_pcmpeqb, (size_t)(__stop_pk_pcmpeqb-__start_pk_pcmpeqb), buf_a, buf_b, buf_ref)) bad |= 32;
    /* pshufd 0x1B: imm=0b00_01_10_11，逐 dword 选择位 = (lane*2)&3：
       目标 dword0<-src3, dword1<-src2, dword2<-src1, dword3<-src0 */
    for (int i = 0; i < 16; ++i) {
        int lane = i / 4, within = i % 4;
        int src_lane = (0x1B >> (lane * 2)) & 3;
        buf_ref[i] = buf_a[src_lane * 4 + within];
    }
    if (check("pshufd", __start_pk_pshufd, (size_t)(__stop_pk_pshufd-__start_pk_pshufd), buf_a, buf_a, buf_ref)) bad |= 64;
    /* packssdw: 两源各 2 个 dword -> 4 个 word 饱和 */
    {
        int32_t s[4]; memcpy(s, buf_a, 8); memcpy(s+2, buf_b, 8);
        int16_t w[4] = {0};
        for (int i = 0; i < 4; ++i) { int32_t v=s[i]; if(v>32767)v=32767; else if(v<-32768)v=-32768; w[i]=(int16_t)v; }
        memcpy(buf_ref, w, 8); memset(buf_ref+8, 0, 8);
    }
    if (check("packssdw", __start_pk_packssdw, (size_t)(__stop_pk_packssdw-__start_pk_packssdw), buf_a, buf_b, buf_ref)) bad |= 128;

    printf("[packed-simd] RESULT=%s\n", bad ? "FAIL" : "PASS");
    return bad ? 1 : 0;
}
