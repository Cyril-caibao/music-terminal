/* Windows clang 交叉编译专用：补齐 MSVC 目标缺失的 __int128 除法 builtin。
 *
 * codevm.c 的 DIV/IDIV 用 128 位被除数（RDX:RAX）做除法，Linux 下由
 * compiler-rt 提供 __udivti3 / __divti3；--target=x86_64-pc-windows-msvc
 * 时 lld-link 找不到这些符号。本文件用移位-减法长除法实现，零依赖。
 *
 * 只在 native/build-win-dll.sh 里参与链接；Linux/macOS 构建不用它。
 */
typedef unsigned __int128 u128;
typedef __int128 i128;

static void cs_udivmod(u128 n, u128 d, u128 *q, u128 *r) {
    u128 qq = 0, rr = 0;
    if (d == 0) { *q = 0; *r = 0; return; }   /* 除零由调用方提前拦截 */
    for (int i = 127; i >= 0; --i) {
        rr = (rr << 1) | ((n >> i) & 1);
        if (rr >= d) { rr -= d; qq |= (u128)1 << i; }
    }
    *q = qq; *r = rr;
}

static u128 cs_abs128(i128 v) {
    return (v < 0) ? (~(u128)v + 1) : (u128)v;
}
static i128 cs_neg128(u128 v) {
    return (i128)(~v + 1);
}

u128 __udivti3(u128 n, u128 d) {
    u128 q, r; cs_udivmod(n, d, &q, &r); return q;
}
u128 __umodti3(u128 n, u128 d) {
    u128 q, r; cs_udivmod(n, d, &q, &r); return r;
}
u128 __udivmodti4(u128 n, u128 d, u128 *rem) {
    u128 q, r; cs_udivmod(n, d, &q, &r);
    if (rem) *rem = r;
    return q;
}
i128 __divti3(i128 n, i128 d) {
    int neg = (n < 0) ^ (d < 0);
    u128 q, r;
    cs_udivmod(cs_abs128(n), cs_abs128(d), &q, &r);
    return neg ? cs_neg128(q) : (i128)q;
}
i128 __modti3(i128 n, i128 d) {
    int neg = (n < 0);
    u128 q, r;
    cs_udivmod(cs_abs128(n), cs_abs128(d), &q, &r);
    return neg ? cs_neg128(r) : (i128)r;
}
