/* CyrilShield 第九批 —— 多线程 VM 上下文验证（System V / Linux）
 *
 * 本轮改造点（对应上一轮评审里「多线程上下文」这一条）：
 *   1) handler 分派表不再驻留进程级全局（原先每 run 用 blob seed 重建
 *      g_handlers[]，两线程跑不同 seed 时互为数据竞争）。改为纯函数算出
 *      32 位掩码，掩码只在本 run 的栈帧里。
 *   2) VM-exit 异常安全网从「每次 exit 装 8 次 sigaction」改为
 *      「每 run 装一次 + 互斥引用计数」，并给每线程一个 frame 栈，
 *      支持 VM → 宿主函数 → VM 的嵌套（可重入）。
 *   3) vm_t 改为每线程上下文池（借用/归还/擦除），嵌套 run 自动再借一个，
 *      线程退出由 pthread_key 析构回收。
 *
 * 验证项：
 *   A) 并发基础：8 线程 × 2000 次，两个不同 seed 的字节码交替跑，结果必须与原生一致
 *   B) 并发 VM-exit：高频外部调用（strlen）在 8 线程下同时进行
 *   C) 可重入：VM 里调外部函数，外部函数再进 VM（嵌套 run，同线程两层上下文）
 *   D) 故障隔离：一个线程的宿主回调触发段错误，被本线程安全网捕获成 TRAP，
 *      其余线程不受影响、进程不退出
 *   E) 并发编译：多线程同时对同一机器码 csvm_compile，互不干扰
 *   F) 吞吐：VM-exit 密集循环的 ops/s（与旧实现对比用外部基准跑）
 *
 * 诚实边界：这是 Linux 8 线程真并发验证；Windows 真机多线程仍需在用户机器上跑
 * （win_coldboot_verify.ps1 只覆盖单线程冷启动）。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#include "cs_codevm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <pthread.h>
#include <signal.h>
#include <time.h>

#define NTHREADS 8
#define N_BASIC  2000
#define N_EXIT   400
#define N_REENT  300

/* ---------- 目标函数（gcc -O2 真实机器码，独立 section） ---------- */
__attribute__((used, noinline, noipa, no_sanitize("thread"), section("cv_t_work")))
static uint64_t t_work(uint64_t x) { return (x * 3 + 7) ^ 0x5A5Au; }

__attribute__((used, noinline, noipa, no_sanitize("thread"), section("cv_t_ext")))
static uint64_t t_ext(const char *s) { return (uint64_t)strlen(s); }

__attribute__((used, noinline, noipa, no_sanitize("thread"), section("cv_t_inner")))
static uint64_t t_inner(uint64_t x) { return x * 11 + 3; }

/* gcc 会把它编成 call rel32（闭包外 -> IR_CALLEXT），供可重入测试拦截 */
__attribute__((used, noinline, noipa, no_sanitize("thread"), section("cv_t_reent")))
static uint64_t t_reent(uint64_t x) { return t_inner(x) + 1; }

extern const uint8_t __start_cv_t_work[],  __stop_cv_t_work[];
extern const uint8_t __start_cv_t_ext[],   __stop_cv_t_ext[];
extern const uint8_t __start_cv_t_inner[], __stop_cv_t_inner[];
extern const uint8_t __start_cv_t_reent[], __stop_cv_t_reent[];

static int    g_fail = 0;
static void ok(const char *name, int cond, const char *detail) {
    printf("  %-22s %s%s%s\n", name, cond ? "PASS" : "FAIL",
           detail && *detail ? "：" : "", detail ? detail : "");
    if (!cond) g_fail = 1;
}

/* ---------- 编译辅助 ---------- */
static uint8_t *compile_sec(const uint8_t *a, const uint8_t *b, uint64_t seed,
                            size_t *len) {
    size_t n = (size_t)(b - a);
    uint8_t *out = NULL; size_t olen = 0;
    char err[CSVM_ERR_CAP] = {0};
    if (csvm_compile(a, n, seed, &out, &olen, err, sizeof(err)) != 0) {
        printf("  compile 失败：%s\n", err);
        return NULL;
    }
    *len = olen;
    return out;
}


typedef struct {
    int      id;
    int      iters;
    int      errors;
    uint8_t *bc_a; size_t la;
    uint8_t *bc_b; size_t lb;
    uint8_t *bc_ext; size_t lext;
    uint8_t *bc_inner; size_t lin;
    uint8_t *bc_reent; size_t lreent;
} targ_t;

static uint64_t run_work(uint8_t *bc, size_t len, uint64_t x, int *rc) {
    uint64_t stack[64] = {0}, rin[16] = {0}, rout[16] = {0};
    char err[CSVM_ERR_CAP] = {0};
    rin[7] = x;                                  /* RDI */
    rin[4] = (uint64_t)(uintptr_t)&stack[24];    /* RSP：真实宿主栈 */
    int r = csvm_run_host(bc, len, rin, rout, (uint64_t)(uintptr_t)__start_cv_t_work,
                          NULL, NULL, err, sizeof(err));
    if (rc) *rc = r;
    if (r != 0 && rc) fprintf(stderr, "run err: %s\n", err);
    return rout[0];
}

static uint64_t run_ext(uint8_t *bc, size_t len, const char *s, int *rc) {
    uint64_t stack[64] = {0}, rin[16] = {0}, rout[16] = {0};
    char err[CSVM_ERR_CAP] = {0};
    rin[7] = (uint64_t)(uintptr_t)s;
    rin[4] = (uint64_t)(uintptr_t)&stack[24];
    int r = csvm_run_host(bc, len, rin, rout, (uint64_t)(uintptr_t)__start_cv_t_ext,
                          NULL, NULL, err, sizeof(err));
    if (rc) *rc = r;
    return rout[0];
}

/* ---------- C) 可重入：exitfn 拦截内层函数地址，再进 VM ---------- */
typedef struct { uint8_t *bc; size_t len; uint64_t base; } inner_ctx_t;

static int reent_exit(void *ctx, uint64_t target, uint64_t gpr[16]) {
    inner_ctx_t *ic = (inner_ctx_t *)ctx;
    if (target != (uint64_t)(uintptr_t)t_inner) return -1;
    uint64_t stack[64] = {0}, rout[16] = {0};
    uint64_t rin[16] = {0};
    char err[CSVM_ERR_CAP] = {0};
    rin[7] = gpr[7];                              /* 原样把参数转给内层 */
    rin[4] = (uint64_t)(uintptr_t)&stack[24];
    int rc = csvm_run_host(ic->bc, ic->len, rin, rout, ic->base,
                           NULL, NULL, err, sizeof(err));
    if (rc != 0) return -1;
    gpr[0] = rout[0];                             /* 结果回写给外层 VM */
    return 0;
}

/* ---------- D) 故障隔离：exitfn 主动踩空指针 ---------- */
static int boom_exit(void *ctx, uint64_t target, uint64_t gpr[16]) {
    (void)ctx; (void)target; (void)gpr;
    raise(SIGSEGV);                               /* 真实信号：模拟宿主函数踩空指针 */
    return -1;
}

/* ---------- 线程体 ---------- */
static void *th_basic(void *p) {
    targ_t *a = (targ_t *)p;
    for (int i = 0; i < a->iters; ++i) {
        uint64_t x = (uint64_t)a->id * 7919u + (uint64_t)i * 13u;
        int rc = 0;
        uint64_t got;
        if ((i + a->id) & 1)
            got = run_work(a->bc_b, a->lb, x, &rc);
        else
            got = run_work(a->bc_a, a->la, x, &rc);
        if (rc != 0 || got != t_work(x)) a->errors++;
    }
    return NULL;
}

static void *th_exit(void *p) {
    targ_t *a = (targ_t *)p;
    for (int i = 0; i < a->iters; ++i) {
        char buf[64];
        int n = (int)((i + a->id) % 31) + 1;
        for (int k = 0; k < n; ++k) buf[k] = (char)('a' + (k % 26));
        buf[n] = 0;
        int rc = 0;
        uint64_t got = run_ext(a->bc_ext, a->lext, buf, &rc);
        if (rc != 0 || got != (uint64_t)n) a->errors++;
    }
    return NULL;
}

static void *th_reent(void *p) {
    targ_t *a = (targ_t *)p;
    inner_ctx_t ic = { a->bc_inner, a->lin, (uint64_t)(uintptr_t)__start_cv_t_inner };
    for (int i = 0; i < a->iters; ++i) {
        uint64_t x = (uint64_t)a->id * 31u + (uint64_t)i;
        uint64_t stack[64] = {0}, rin[16] = {0}, rout[16] = {0};
        char err[CSVM_ERR_CAP] = {0};
        rin[7] = x;
        rin[4] = (uint64_t)(uintptr_t)&stack[24];
        int rc = csvm_run_host_ex(a->bc_reent, a->lreent, rin, rout,
                                  (uint64_t)(uintptr_t)__start_cv_t_reent,
                                  NULL, NULL, reent_exit, &ic,
                                  err, sizeof(err));
        if (rc != 0 || rout[0] != t_reent(x)) {
            a->errors++;
        }
    }
    return NULL;
}

static void *th_fault(void *p) {
    targ_t *a = (targ_t *)p;
    uint64_t stack[64] = {0}, rin[16] = {0}, rout[16] = {0};
    char err[CSVM_ERR_CAP] = {0};
    rin[7] = (uint64_t)(uintptr_t)"boom";
    rin[4] = (uint64_t)(uintptr_t)&stack[24];
    int rc = csvm_run_host_ex(a->bc_ext, a->lext, rin, rout,
                              (uint64_t)(uintptr_t)__start_cv_t_ext, NULL, NULL,
                              boom_exit, NULL, err, sizeof(err));
    if (rc != 0 && strstr(err, "宿主异常")) a->errors = 0;   /* 期望：被捕获 */
    else a->errors = 1;
    if (rc != 0) printf("  故障线程返回：rc=%d / %s\n", rc, err);
    return NULL;
}

/* ---------- E) 并发编译 ---------- */
typedef struct {
    const uint8_t *a, *b;
    uint64_t seed;
    uint8_t *out;
    size_t   len;
    int      fail;
} comp_t;

static void *th_compile(void *p) {
    comp_t *c = (comp_t *)p;
    char err[CSVM_ERR_CAP] = {0};
    size_t n = (size_t)(c->b - c->a);
    if (csvm_compile(c->a, n, c->seed, &c->out, &c->len, err, sizeof(err)) != 0) {
        c->fail = 1;
        fprintf(stderr, "并发编译失败：%s\n", err);
    }
    return NULL;
}

/* ---------- 吞吐 ---------- */
static double now_s(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

int main(void) {
    printf("==================================================================================\n");
    printf("CyrilShield 第九批 —— 多线程 VM 上下文（%d 线程 / Linux 真并发）\n", NTHREADS);
    printf("==================================================================================\n");

    size_t la = 0, lb = 0, lext = 0, lin = 0, lreent = 0;
    uint8_t *bc_a = compile_sec(__start_cv_t_work, __stop_cv_t_work, 7, &la);
    uint8_t *bc_b = compile_sec(__start_cv_t_work, __stop_cv_t_work, 9, &lb);
    uint8_t *bc_ext = compile_sec(__start_cv_t_ext, __stop_cv_t_ext, 11, &lext);
    uint8_t *bc_inner = compile_sec(__start_cv_t_inner, __stop_cv_t_inner, 13, &lin);
    uint8_t *bc_reent = compile_sec(__start_cv_t_reent, __stop_cv_t_reent, 17, &lreent);
    if (!bc_a || !bc_b || !bc_ext || !bc_inner || !bc_reent) {
        printf("  编译阶段失败，终止\n");
        return 1;
    }
    char d[128];
    snprintf(d, sizeof(d), "两 seed 容器 %zuB / %zuB，ext %zuB，reent %zuB",
             la, lb, lext, lreent);
    ok("COMPILE", 1, d);

    /* ---------- A) 并发基础：两种 seed 交替 ---------- */
    pthread_t th[NTHREADS]; targ_t args[NTHREADS];
    for (int i = 0; i < NTHREADS; ++i) {
        args[i] = (targ_t){ .id = i, .iters = N_BASIC,
                            .bc_a = bc_a, .la = la, .bc_b = bc_b, .lb = lb,
                            .bc_ext = bc_ext, .lext = lext,
                            .bc_inner = bc_inner, .lin = lin,
                            .bc_reent = bc_reent, .lreent = lreent };
        pthread_create(&th[i], NULL, th_basic, &args[i]);
    }
    int err = 0;
    for (int i = 0; i < NTHREADS; ++i) { pthread_join(th[i], NULL); err += args[i].errors; }
    snprintf(d, sizeof(d), "%d 次结果与原生一致（0 错误）", NTHREADS * N_BASIC);
    ok("PARALLEL-BASIC", err == 0, err ? "存在不一致" : d);

    /* ---------- B) 并发 VM-exit ---------- */
    for (int i = 0; i < NTHREADS; ++i) {
        args[i] = (targ_t){ .id = i, .iters = N_EXIT,
                            .bc_ext = bc_ext, .lext = lext,
                            .bc_inner = bc_inner, .lin = lin,
                            .bc_reent = bc_reent, .lreent = lreent };
        pthread_create(&th[i], NULL, th_exit, &args[i]);
    }
    err = 0;
    for (int i = 0; i < NTHREADS; ++i) { pthread_join(th[i], NULL); err += args[i].errors; }
    snprintf(d, sizeof(d), "%d 次并发 VM-exit 调 strlen 全部正确", NTHREADS * N_EXIT);
    ok("PARALLEL-EXIT", err == 0, err ? "有 VM-exit 结果错误" : d);

    /* ---------- C) 可重入：VM -> 宿主函数 -> VM ---------- */
    for (int i = 0; i < NTHREADS; ++i) {
        args[i] = (targ_t){ .id = i, .iters = N_REENT,
                            .bc_ext = bc_ext, .lext = lext,
                            .bc_inner = bc_inner, .lin = lin,
                            .bc_reent = bc_reent, .lreent = lreent };
        pthread_create(&th[i], NULL, th_reent, &args[i]);
    }
    err = 0;
    for (int i = 0; i < NTHREADS; ++i) { pthread_join(th[i], NULL); err += args[i].errors; }
    snprintf(d, sizeof(d), "%d 次嵌套 VM（外层 VM 内再进内层 VM）结果正确", NTHREADS * N_REENT);
    ok("REENTRANT", err == 0, err ? "嵌套 run 出错" : d);

    /* ---------- D) 故障隔离：1 个线程踩空指针，其余正常 ---------- */
#if defined(CSVM_NO_SIGNAL_GUARD)
    printf("  FAULT-ISOLATED         SKIP（本次构建关闭了信号安全网，故障用例不适用）\n");
#else
    targ_t bad = (targ_t){ .id = 99, .bc_ext = bc_ext, .lext = lext };
    pthread_create(&th[0], NULL, th_fault, &bad);
    for (int i = 1; i < NTHREADS; ++i) {
        args[i] = (targ_t){ .id = i, .iters = 200, .bc_ext = bc_ext, .lext = lext };
        pthread_create(&th[i], NULL, th_exit, &args[i]);
    }
    pthread_join(th[0], NULL);
    int other_err = 0;
    for (int i = 1; i < NTHREADS; ++i) { pthread_join(th[i], NULL); other_err += args[i].errors; }
    ok("FAULT-ISOLATED", bad.errors == 0 && other_err == 0,
       "故障线程被安全网捕获为 TRAP，其余 7 线程结果不受影响、进程存活");
#endif

    /* ---------- E) 并发编译：8 线程同时对同一机器码编译 ---------- */
    {
        pthread_t ct[8];
        comp_t cs[8];
        for (int i = 0; i < 8; ++i) {
            cs[i] = (comp_t){ .a = __start_cv_t_reent, .b = __stop_cv_t_reent,
                              .seed = 21, .out = NULL, .len = 0, .fail = 0 };
            pthread_create(&ct[i], NULL, th_compile, &cs[i]);
        }
        int cfail = 0; size_t first = 0;
        for (int i = 0; i < 8; ++i) {
            pthread_join(ct[i], NULL);
            cfail += cs[i].fail;
            if (i == 0) first = cs[i].len;
            else if (cs[i].len != first) cfail++;
        }
        snprintf(d, sizeof(d), "8 线程并发编译同一 seed 均成功且长度一致（%zuB）", first);
        ok("CONCURRENT-COMPILE", cfail == 0, cfail ? "并发编译不一致/失败" : d);
        for (int i = 0; i < 8; ++i) free(cs[i].out);
    }

    /* ---------- F) 吞吐 ---------- */
    {
        const int N = 20000;
        double t0 = now_s();
        int rc = 0;
        for (int i = 0; i < N; ++i) {
            char buf[16]; snprintf(buf, sizeof(buf), "abc%d", i % 7);
            run_ext(bc_ext, lext, buf, &rc);
        }
        double t1 = now_s();
        snprintf(d, sizeof(d), "%d 次 VM-exit / %.3fs = %.0f ops/s",
                 N, t1 - t0, (double)N / (t1 - t0));
        ok("EXIT-THROUGHPUT", 1, d);
    }

    printf("----------------------------------------------------------------------------------\n");
    printf("[thread] RESULT=%s\n", g_fail ? "FAIL" : "PASS");
    free(bc_a); free(bc_b); free(bc_ext); free(bc_inner); free(bc_reent);
    return g_fail ? 1 : 0;
}
