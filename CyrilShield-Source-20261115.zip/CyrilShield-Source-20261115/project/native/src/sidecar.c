/* CyrilShield Native Sidecar — 实现（C11，零第三方依赖）
 *
 * 只暴露只读的硬件/系统能力。所有采集失败都返回错误码并降级，
 * 绝不提权、绝不写系统状态、绝不接触其他进程地址空间。
 */
#ifndef _WIN32
#  ifndef _GNU_SOURCE
#    define _GNU_SOURCE 1   /* clock_gettime / strnlen / Dl_info：必须早于任何系统头 */
#  endif
#endif

#include "cyrilshield_native.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>
#  include <intrin.h>
#  include <sysinfoapi.h>
#else
#  include <unistd.h>
#  include <sys/stat.h>
#  include <sys/sysinfo.h>
#  include <sys/utsname.h>
#  include <dlfcn.h>
#  include <fcntl.h>
#endif

/* ------------------------------------------------------------------ SHA-256 */
typedef struct {
    uint32_t h[8];
    uint64_t len;
    uint8_t  buf[64];
    size_t   used;
} sha256_ctx;

static const uint32_t K256[64] = {
    0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,
    0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,
    0xe49b69c1u,0xefbe4786u,0x0fc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,
    0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x06ca6351u,0x14292967u,
    0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,
    0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,
    0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,
    0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u
};

#define ROR(x,n) (((x) >> (n)) | ((x) << (32-(n))))

static void sha256_block(sha256_ctx *c, const uint8_t *p) {
    uint32_t w[64], a, b, cc, d, e, f, g, h, t1, t2;
    int i;
    for (i = 0; i < 16; ++i)
        w[i] = ((uint32_t)p[i*4]<<24)|((uint32_t)p[i*4+1]<<16)|((uint32_t)p[i*4+2]<<8)|p[i*4+3];
    for (i = 16; i < 64; ++i) {
        uint32_t s0 = ROR(w[i-15],7)^ROR(w[i-15],18)^(w[i-15]>>3);
        uint32_t s1 = ROR(w[i-2],17)^ROR(w[i-2],19)^(w[i-2]>>10);
        w[i] = w[i-16]+s0+w[i-7]+s1;
    }
    a=c->h[0]; b=c->h[1]; cc=c->h[2]; d=c->h[3];
    e=c->h[4]; f=c->h[5]; g=c->h[6]; h=c->h[7];
    for (i = 0; i < 64; ++i) {
        uint32_t S1 = ROR(e,6)^ROR(e,11)^ROR(e,25);
        uint32_t ch = (e&f)^((~e)&g);
        uint32_t S0 = ROR(a,2)^ROR(a,13)^ROR(a,22);
        uint32_t mj = (a&b)^(a&cc)^(b&cc);
        t1 = h+S1+ch+K256[i]+w[i];
        t2 = S0+mj;
        h=g; g=f; f=e; e=d+t1; d=cc; cc=b; b=a; a=t1+t2;
    }
    c->h[0]+=a; c->h[1]+=b; c->h[2]+=cc; c->h[3]+=d;
    c->h[4]+=e; c->h[5]+=f; c->h[6]+=g; c->h[7]+=h;
}

static void sha256_init(sha256_ctx *c) {
    static const uint32_t H[8] = {
        0x6a09e667u,0xbb67ae85u,0x3c6ef372u,0xa54ff53au,
        0x510e527fu,0x9b05688cu,0x1f83d9abu,0x5be0cd19u
    };
    memcpy(c->h, H, sizeof(H)); c->len = 0; c->used = 0;
}
static void sha256_update(sha256_ctx *c, const void *data, size_t n) {
    const uint8_t *p = (const uint8_t*)data;
    c->len += n;
    while (n) {
        size_t take = 64 - c->used;
        if (take > n) take = n;
        memcpy(c->buf + c->used, p, take);
        c->used += take; p += take; n -= take;
        if (c->used == 64) { sha256_block(c, c->buf); c->used = 0; }
    }
}
static void sha256_final(sha256_ctx *c, uint8_t out[32]) {
    uint64_t bits = c->len * 8;
    uint8_t pad = 0x80;
    uint8_t zero = 0;
    uint8_t tail[8];
    int i;
    for (i = 0; i < 8; ++i) tail[i] = (uint8_t)(bits >> (56 - 8*i));
    sha256_update(c, &pad, 1);
    while (c->used != 56) sha256_update(c, &zero, 1);
    sha256_update(c, tail, 8);
    for (i = 0; i < 8; ++i) {
        out[i*4]   = (uint8_t)(c->h[i] >> 24);
        out[i*4+1] = (uint8_t)(c->h[i] >> 16);
        out[i*4+2] = (uint8_t)(c->h[i] >> 8);
        out[i*4+3] = (uint8_t)(c->h[i]);
    }
}
static void digest_bytes(const void *data, size_t n, uint8_t out[32]) {
    sha256_ctx c; sha256_init(&c); sha256_update(&c, data, n); sha256_final(&c, out);
}

/* ------------------------------------------------------------------ 状态 */
static char g_err[CSN_ERRBUF_LEN] = "ok";
static void seterr(const char *s) {
    strncpy(g_err, s, sizeof(g_err) - 1);
    g_err[sizeof(g_err)-1] = 0;
}
CSN_API int csn_last_error(char *buf, size_t n) {
    if (!buf || n == 0) return CSN_ERR_BADARG;
    strncpy(buf, g_err, n - 1); buf[n-1] = 0;
    return CSN_OK;
}
CSN_API int csn_abi_version(void) { return CSN_ABI_VERSION; }

CSN_API uint64_t csn_capabilities(void) {
    return CSN_CAP_HWID | CSN_CAP_TICKS | CSN_CAP_CPUID
         | CSN_CAP_SELFHASH | CSN_CAP_FILEHASH;
}

/* ------------------------------------------------------------------ 采集 */
#ifdef _WIN32
static void collect_machine(uint8_t out[16]) {
    char name[MAX_COMPUTERNAME_LENGTH + 1] = {0};
    DWORD n = sizeof(name) - 1;
    uint8_t d[32];
    if (!GetComputerNameA(name, &n)) n = 0;
    digest_bytes(name, n, d);
    memcpy(out, d, 16);
}
static void collect_volume(uint8_t out[8], uint32_t *flags) {
    DWORD serial = 0;
    char root[MAX_PATH] = {0};
    UINT t = GetSystemWindowsDirectoryA(root, MAX_PATH);
    if (t == 0 || t >= MAX_PATH) strcpy(root, "C:\\");
    if (strlen(root) >= 3) root[3] = 0;
    if (GetVolumeInformationA(root, NULL, 0, &serial, NULL, NULL, NULL, 0)) {
        memcpy(out, &serial, 4);
        memset(out + 4, 0, 4);
        *flags |= 1u;
    }
}
static void collect_cpu(char *buf, size_t n) {
    int regs[4] = {0};
    /* 用 union 保证 __cpuid 写入 int[12] 时的对齐，避免 char[] 强转的 UB */
    union { int r[12]; char c[49]; } brand;
    size_t i;
    __cpuid(regs, 0x80000000u);
    if ((unsigned)regs[0] >= 0x80000004u) {
        __cpuid(brand.r,      0x80000002u);
        __cpuid(brand.r + 4,  0x80000003u);
        __cpuid(brand.r + 8,  0x80000004u);
        brand.c[48] = 0;
        for (i = 0; i < 48 && brand.c[i]; ++i)
            if ((unsigned char)brand.c[i] < 0x20) brand.c[i] = ' ';
    } else {
        strcpy(brand.c, "Generic x64");
    }
    strncpy(buf, brand.c, n - 1); buf[n-1] = 0;
}
static void collect_os(char *buf, size_t n) {
    OSVERSIONINFOEXA v; ZeroMemory(&v, sizeof(v));
    v.dwOSVersionInfoSize = sizeof(v);
#pragma warning(push)
#pragma warning(disable:4996)
    if (GetVersionExA((OSVERSIONINFOA*)&v))
        snprintf(buf, n, "Windows %lu.%lu build %lu",
                 (unsigned long)v.dwMajorVersion, (unsigned long)v.dwMinorVersion,
                 (unsigned long)v.dwBuildNumber);
    else
        strncpy(buf, "Windows", n - 1);
#pragma warning(pop)
    buf[n-1] = 0;
}
static int collect_sys(uint32_t *cpus, uint64_t *mem_mb) {
    SYSTEM_INFO si; MEMORYSTATUSEX ms;
    GetSystemInfo(&si);
    *cpus = si.dwNumberOfProcessors;
    ms.dwLength = sizeof(ms);
    if (GlobalMemoryStatusEx(&ms)) *mem_mb = ms.ullTotalPhys / (1024*1024);
    return CSN_OK;
}
#else
static void collect_machine(uint8_t out[16]) {
    uint8_t d[32];
    unsigned char raw[128] = {0};
    size_t n = 0;
    FILE *f = fopen("/sys/class/dmi/id/product_uuid", "rb");
    if (f) { n = fread(raw, 1, sizeof(raw)-1, f); fclose(f); }
    if (!n) {
        char host[256] = {0};
        if (gethostname(host, sizeof(host)-1) != 0) strcpy(host, "unknown");
        n = strlen(host); memcpy(raw, host, n > 127 ? 127 : n);
        if (n > 127) n = 127;
    }
    digest_bytes(raw, n, d);
    memcpy(out, d, 16);
}
static void collect_volume(uint8_t out[8], uint32_t *flags) {
    struct stat st;
    memset(out, 0, 8);
    if (stat("/", &st) == 0) {
        uint64_t dev = (uint64_t)st.st_dev;
        memcpy(out, &dev, 8);
        *flags |= 1u;
    }
}
static void collect_cpu(char *buf, size_t n) {
    FILE *f = fopen("/proc/cpuinfo", "r");
    char line[256] = {0};
    strncpy(buf, "Generic", n - 1); buf[n-1] = 0;
    if (!f) return;
    while (fgets(line, sizeof(line), f)) {
        if (!strncmp(line, "model name", 10)) {
            char *p = strchr(line, ':');
            if (p) { p++; while (*p == ' ' || *p == '\t') p++;
                     p[strcspn(p, "\r\n")] = 0;
                     strncpy(buf, p, n - 1); buf[n-1] = 0; }
            break;
        }
    }
    fclose(f);
}
static void collect_os(char *buf, size_t n) {
    struct utsname u;
    char tmp[256];
    size_t k;
    if (uname(&u) == 0)
        snprintf(tmp, sizeof(tmp), "%s %s %s", u.sysname, u.release, u.machine);
    else
        snprintf(tmp, sizeof(tmp), "POSIX");
    k = strlen(tmp);
    if (k > n - 1) k = n - 1;
    memcpy(buf, tmp, k);
    buf[k] = 0;
}
static int collect_sys(uint32_t *cpus, uint64_t *mem_mb) {
    struct sysinfo si;
    long nc = sysconf(_SC_NPROCESSORS_ONLN);
    *cpus = nc > 0 ? (uint32_t)nc : 1;
    if (sysinfo(&si) == 0) *mem_mb = (uint64_t)si.totalram * (uint64_t)si.mem_unit / (1024*1024);
    return CSN_OK;
}
#endif

CSN_API int csn_probe_hwid(csn_hwid *out) {
    sha256_ctx c;
    uint32_t flags = 0;
    if (!out || out->size < sizeof(csn_hwid)) { seterr("bad hwid struct"); return CSN_ERR_BADARG; }
    memset(out, 0, sizeof(*out));
    out->size = sizeof(csn_hwid);
    collect_machine(out->machine);
    collect_volume(out->volume, &flags);
    collect_cpu(out->cpu, CSN_TEXT_LEN);
    collect_os(out->os, CSN_TEXT_LEN);
    collect_sys(&out->cpu_count, &out->mem_mb);
    out->flags = flags;
    sha256_init(&c);
    sha256_update(&c, out->machine, sizeof(out->machine));
    sha256_update(&c, out->volume, sizeof(out->volume));
    sha256_update(&c, out->cpu, strnlen(out->cpu, CSN_TEXT_LEN));
    sha256_update(&c, out->os, strnlen(out->os, CSN_TEXT_LEN));
    sha256_update(&c, &out->cpu_count, sizeof(out->cpu_count));
    sha256_final(&c, out->digest);
    seterr("ok");
    return CSN_OK;
}

CSN_API int csn_ticks(uint64_t *out) {
    if (!out) return CSN_ERR_BADARG;
#ifdef _WIN32
    {
        LARGE_INTEGER v;
        if (!QueryPerformanceCounter(&v)) { seterr("QPC failed"); return CSN_ERR_IO; }
        *out = (uint64_t)v.QuadPart;
    }
#else
    {
        struct timespec ts;
        if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) { seterr("clock failed"); return CSN_ERR_IO; }
        *out = (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
    }
#endif
    return CSN_OK;
}

CSN_API int csn_cpu_features(uint32_t *out) {
    if (!out) return CSN_ERR_BADARG;
#ifdef _WIN32
    {
        int r[4] = {0};
        __cpuid(r, 1);
        *out = (uint32_t)r[3];
    }
#else
    *out = 0;
#endif
    return CSN_OK;
}

CSN_API int csn_file_digest(const char *path, uint8_t out[CSN_DIGEST_LEN]) {
    sha256_ctx c;
    FILE *f;
    uint8_t buf[64 * 1024];
    size_t n;
    if (!path || !out) return CSN_ERR_BADARG;
    f = fopen(path, "rb");
    if (!f) { seterr("cannot open file"); return CSN_ERR_IO; }
    sha256_init(&c);
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) sha256_update(&c, buf, n);
    if (ferror(f)) { fclose(f); seterr("read error"); return CSN_ERR_IO; }
    fclose(f);
    sha256_final(&c, out);
    return CSN_OK;
}

CSN_API int csn_self_digest(uint8_t out[CSN_DIGEST_LEN]) {
    char path[1024] = {0};
#ifdef _WIN32
    HMODULE hm = NULL;
    if (!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                            (LPCSTR)&csn_abi_version, &hm)) {
        seterr("module handle failed"); return CSN_ERR_IO;
    }
    if (!GetModuleFileNameA(hm, path, (DWORD)sizeof(path))) {
        seterr("module path failed"); return CSN_ERR_IO;
    }
#else
    Dl_info info;
    if (!dladdr((void*)&csn_abi_version, &info) || !info.dli_fname) {
        seterr("dladdr failed"); return CSN_ERR_IO;
    }
    strncpy(path, info.dli_fname, sizeof(path) - 1);
#endif
    return csn_file_digest(path, out);
}
