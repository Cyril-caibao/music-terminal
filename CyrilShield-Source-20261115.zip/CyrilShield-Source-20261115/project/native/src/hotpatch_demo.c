/* CyrilShield 集成层验证：ELF 函数头 hotpatch -> VM stub -> 上下文切换
 *
 * 这是「最小可用集成」的可执行证明，对应里程碑第 2/3/4 步：
 *   1) 目标函数真实机器码在构建期被编译成私有 ISA 字节码（由 selftest_integration.py 完成）
 *   2) 运行时把目标函数头 5 字节改成 E9 rel32 -> jmp 到 VM trampoline
 *   3) trampoline 保存 16 个 GPR + FLAGS，调 C 内核 csvm_run_host，
 *      传入真实 RSP 与函数运行时地址（RIP 相对常量池据此解析）
 *   4) 冷启动后首次调用该函数即进入 VM，返回值与原生执行逐字节比对
 *
 * 与 PE 集成器的差异（诚实标注）：PE 里 stub 与新节区在同一映像内，用 5 字节
 * E9 即可；这里 trampoline 也在同一非 PIE 可执行映像内，同样是 5 字节 E9。
 * 未做：IAT/重定位/异常表（PE 侧由 peintegrate.c 处理）、TLS/多线程上下文、
 * 目标函数栈帧与 trampoline 保存区重叠（本样本是纯寄存器函数，不碰栈）。
 *
 * 明确不做：AMSI/ETW 补丁、进程注入、驱动、反 EDR。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1   /* mmap/mprotect：-std=c11 严格模式下 glibc 需显式开启 */
#endif
#include "cs_codevm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <unistd.h>

/* ---------------------------------------------------------------- 目标函数 */
static const uint64_t KT[8] = {
    0x9E3779B97F4A7C15ULL, 0xBF58476D1CE4E5B9ULL,
    0x94D049BB133111EBULL, 0xD6E8FEB86659FD93ULL,
    0x123456789ABCDEF0ULL, 0xFEDCBA9876543210ULL,
    0x0102030405060708ULL, 0x8877665544332211ULL,
};

__attribute__((noinline, visibility("default")))
uint64_t f_protected(uint64_t x, uint64_t d) {
    uint64_t a = x ^ KT[x & 7];
    uint64_t b = KT[(x >> 3) & 7];
    uint64_t q = a / d;
    uint64_t r = a % d;
    uint64_t m = q * b;
    uint64_t z = (q > r) ? (m + r) : (m ^ r);
    return z + KT[7] + x;
}

/* ------------------------------------------------------------ VM 上下文桥 */
static uint8_t  *g_bc = NULL;
static size_t    g_bc_len = 0;
static uint64_t  g_runtime_base = 0;
static uint64_t  g_vm_calls = 0;
static int       g_last_rc = 0;
static char      g_last_err[512] = {0};

extern void csvm_trampoline(void);

/* slots 顺序严格对应 x86 GPR 编号 0..15：
 * rax rcx rdx rbx rsp rbp rsi rdi r8 r9 r10 r11 r12 r13 r14 r15 */
uint64_t csvm_trampoline_c(uint64_t *slots) {
    uint64_t rin[16], rout[16];
    memcpy(rin, slots, sizeof(rin));
    memset(rout, 0, sizeof(rout));
    char err[512] = {0};
    int rc = csvm_run_host(g_bc, g_bc_len, rin, rout,
                           g_runtime_base, NULL, NULL, err, sizeof(err));
    g_vm_calls++;
    g_last_rc = rc;
    if (getenv("CSVM_DEBUG") && g_vm_calls <= 2) {
        fprintf(stderr,
                "DBG#%llu rc=%d x=0x%llx d=0x%llx rsp=0x%llx "
                "base=0x%llx -> rax=0x%llx err=%s\n",
                (unsigned long long)g_vm_calls, rc,
                (unsigned long long)rin[7], (unsigned long long)rin[6],
                (unsigned long long)rin[4],
                (unsigned long long)g_runtime_base,
                (unsigned long long)rout[0], err);
    }
    if (rc == 0) {
        /* 写回除 RAX 外的全部 GPR；RAX 由函数返回值直接交给汇编，
         * 避免「保存区回填是否被汇编正确读到」成为单点故障。 */
        for (int i = 1; i < 16; ++i) slots[i] = rout[i];
        slots[4] = rin[4];          /* RSP 由 trampoline 自己 addq 恢复 */
        slots[0] = rout[0];
        return rout[0];
    }
    snprintf(g_last_err, sizeof(g_last_err), "%s", err);
    return rin[0];                  /* 失败时保持进入时的 RAX */
}

/* 顶层汇编：16 GPR + FLAGS 全量保存 -> C 桥 -> 全量恢复 -> ret。
 * 152 字节保存区（16*8=128 + flags 8 + 16 对齐填充），保证 call 前 RSP 16 对齐。 */
__asm__(
".text\n"
".globl csvm_trampoline\n"
".type csvm_trampoline,@function\n"
"csvm_trampoline:\n"
"    subq $152, %rsp\n"
"    movq %rax,   0(%rsp)\n"
"    movq %rcx,   8(%rsp)\n"
"    movq %rdx,  16(%rsp)\n"
"    movq %rbx,  24(%rsp)\n"
"    leaq 152(%rsp), %rax\n"
"    movq %rax,  32(%rsp)\n"
"    movq %rbp,  40(%rsp)\n"
"    movq %rsi,  48(%rsp)\n"
"    movq %rdi,  56(%rsp)\n"
"    movq %r8,   64(%rsp)\n"
"    movq %r9,   72(%rsp)\n"
"    movq %r10,  80(%rsp)\n"
"    movq %r11,  88(%rsp)\n"
"    movq %r12,  96(%rsp)\n"
"    movq %r13, 104(%rsp)\n"
"    movq %r14, 112(%rsp)\n"
"    movq %r15, 120(%rsp)\n"
"    pushfq\n"
"    popq %rax\n"
"    movq %rax, 128(%rsp)\n"
"    movq %rsp, %rdi\n"
"    call csvm_trampoline_c@PLT\n"
"    movq %rax, 136(%rsp)\n"       /* 槽 17：暂存 VM 返回的 RAX */
"    movq 128(%rsp), %rax\n"       /* 借 RAX 恢复 FLAGS */
"    pushq %rax\n"
"    popfq\n"
"    movq   8(%rsp), %rcx\n"
"    movq  16(%rsp), %rdx\n"
"    movq  24(%rsp), %rbx\n"
"    movq  40(%rsp), %rbp\n"
"    movq  48(%rsp), %rsi\n"
"    movq  56(%rsp), %rdi\n"
"    movq  64(%rsp), %r8\n"
"    movq  72(%rsp), %r9\n"
"    movq  80(%rsp), %r10\n"
"    movq  88(%rsp), %r11\n"
"    movq  96(%rsp), %r12\n"
"    movq 104(%rsp), %r13\n"
"    movq 112(%rsp), %r14\n"
"    movq 120(%rsp), %r15\n"
"    movq 136(%rsp), %rax\n"       /* 最后恢复 RAX = VM 结果 */
"    addq $152, %rsp\n"
"    ret\n"
".size csvm_trampoline,.-csvm_trampoline\n"
);

/* ------------------------------------------------------------------ 主流程 */
static int load_bc(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return -1;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n <= 0) { fclose(f); return -1; }
    g_bc = (uint8_t *)malloc((size_t)n);
    if (!g_bc) { fclose(f); return -1; }
    if (fread(g_bc, 1, (size_t)n, f) != (size_t)n) { fclose(f); return -1; }
    fclose(f);
    g_bc_len = (size_t)n;
    return 0;
}

static void patch_entry(uint8_t *fn, uint8_t *stub) {
    long ps = sysconf(_SC_PAGESIZE);
    uintptr_t page = (uintptr_t)fn & ~(uintptr_t)(ps - 1);
    if (mprotect((void *)page, (size_t)ps * 2,
                 PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        perror("mprotect"); exit(2);
    }
    int64_t rel = (int64_t)(stub - (fn + 5));
    if (rel < INT32_MIN || rel > INT32_MAX) {
        fprintf(stderr, "stub 超出 rel32 范围，需要绝对跳转\n"); exit(2);
    }
    int32_t r32 = (int32_t)rel;
    fn[0] = 0xE9;
    memcpy(fn + 1, &r32, 4);
    __builtin___clear_cache((char *)fn, (char *)fn + 5);
}

static const uint64_t XS[] = {
    0ULL, 1ULL, 7ULL, 12345ULL, 0xFFFFFFFFFFFFFFFFULL,
    0x123456789ABCDEFULL, 999ULL, 1ULL << 63,
};
static const uint64_t DS[] = {
    1ULL, 7ULL, 97ULL, 3ULL, 13ULL, 0x9E37ULL, 0xFFFFFFFFFFFFFFFULL, 5ULL,
};

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "用法: %s <bytecode.csvm>\n", argv[0]); return 2; }
    if (load_bc(argv[1]) != 0) { fprintf(stderr, "读取字节码失败\n"); return 2; }
    g_runtime_base = (uint64_t)(uintptr_t)&f_protected;

    /* volatile 函数指针 + volatile 参数：阻止内联/常量折叠，保证真的 call 到该地址 */
    uint64_t (*volatile target)(uint64_t, uint64_t) = f_protected;
    const size_t n = sizeof(XS) / sizeof(XS[0]);
    uint64_t native[16];

    /* ---- 冷启动阶段 1：patch 之前，记录原生执行结果 ---- */
    for (size_t i = 0; i < n; ++i) {
        volatile uint64_t vx = XS[i], vd = DS[i];
        native[i] = target(vx, vd);
    }

    /* ---- 冷启动阶段 2：改写函数入口 ---- */
    patch_entry((uint8_t *)&f_protected, (uint8_t *)csvm_trampoline);

    /* ---- 冷启动阶段 3：同一调用点，现在进 VM ---- */
    int ok = 0;
    for (size_t i = 0; i < n; ++i) {
        volatile uint64_t vx = XS[i], vd = DS[i];
        uint64_t got = target(vx, vd);
        int good = (got == native[i]);
        ok += good;
        printf("case %zu  x=0x%016llx d=0x%016llx  native=0x%016llx  vm=0x%016llx  %s\n",
               i, (unsigned long long)XS[i], (unsigned long long)DS[i],
               (unsigned long long)native[i], (unsigned long long)got,
               good ? "OK" : "MISMATCH");
    }
    printf("VM_CALLS=%llu\n", (unsigned long long)g_vm_calls);
    printf("LAST_RC=%d LAST_ERR=%s\n", g_last_rc, g_last_err);
    printf("RESULT=%s %d/%zu\n", (ok == (int)n && g_vm_calls == n) ? "PASS" : "FAIL",
           ok, n);
    return (ok == (int)n && g_vm_calls == n) ? 0 : 1;
}
