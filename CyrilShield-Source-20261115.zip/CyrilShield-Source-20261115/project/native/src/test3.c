#define wWinMain bootstub_wWinMain_disabled
#include "bootstub.c"
#undef wWinMain
static void hex(const uint8_t *p, size_t n) {
    for (size_t i = 0; i < n; i++) printf("%02x", p[i]);
    printf("\n");
}
int main(void) {
    uint8_t seed[57];
    memcpy(seed, "0123456789abcdef0123456789abcdef", 32);
    memcpy(seed+32, "SALTsaltSALTsalt", 16);
    memcpy(seed+48, "M", 1);
    for (int i = 0; i < 8; i++) seed[48+1+i] = (uint8_t)i;
    uint8_t big[300];
    cs_shake256(seed, 57, big, 300);
    printf("tail "); hex(big + 200, 100);
    return 0;
}
