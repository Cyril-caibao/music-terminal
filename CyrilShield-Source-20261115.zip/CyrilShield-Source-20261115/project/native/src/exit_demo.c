/* L2 VM-exit 桥 —— 真实函数的端到端冷启动验证（System V / Linux）。
 *
 * 验证的正是用户评审指出的核心短板：「能不能虚拟化一个真实业务函数」。
 * 目标函数是 gcc -O2 真实编译出来的，内部 call 到外部函数。交给 C 内核虚拟化：
 *
 *   目标函数机器码 -> csvm_compile -> 外部 call 提升为 IR_CALLEXT
 *   -> csvm_run_host(host 真实内存模式) -> 命中 CALLEXT
 *   -> exit_trampoline.c 的 SysV 桩：切宿主栈 / 16B 对齐 / 保存 nonvolatile
 *      / 搬寄存器参数 + 栈参数 -> 真正 call 外部函数 -> 回写 RAX -> 回 VM
 *   -> 继续执行余下指令 -> 返回，与纯 C 参考实现逐字节比对
 *
 * 两个用例：
 *   A) 6 参数：全部走寄存器（RDI/RSI/RDX/RCX/R8/R9）
 *   B) 8 参数：第 7/8 参数走栈 —— 验证 L2 的 VM 栈 -> 宿主栈参数搬运
 *      （目标函数在真实宿主栈布置栈参数，桩从 gpr[X_RSP] 搬到受控调用帧）
 *
 * 外部函数内部递增 g_helper_calls，用来硬证明「VM 确实切回原生执行了」
 * （若 CALLEXT 未生效或目标解析错误，计数不会增长且结果不符）。
 *
 * 目标函数放独立 section，用 GNU ld 自动生成的 __start_/__stop_ 符号取字节。
 * runtime_base = section 真实地址；PIE 下相对偏移固定，故
 *   CALLEXT target = runtime_base + target_off == 外部函数真实地址。
 *
 * 明确不做（L3）：浮点/SSE 参数、异常穿透、间接跳转表、回调再进 VM。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#include "cs_codevm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static volatile uint64_t g_helper_calls = 0;

/* 外部被调函数 A：6 参数，全寄存器 */
__attribute__((noinline, noipa))
static uint64_t ext6(uint64_t a, uint64_t b, uint64_t c,
                     uint64_t d, uint64_t e, uint64_t f) {
    g_helper_calls++;
    return a + b * 2 + c * 3 + d * 4 + e * 5 + f * 6 + 0x1234u;
}
/* 外部被调函数 B：8 参数，g/h 走栈 */
__attribute__((noinline, noipa))
static uint64_t ext8(uint64_t a, uint64_t b, uint64_t c, uint64_t d,
                     uint64_t e, uint64_t f, uint64_t g, uint64_t h) {
    g_helper_calls++;
    return a * 1 + b * 2 + c * 3 + d * 4 + e * 5 + f * 6 + g * 7 + h * 8 + 0x4321u;
}

/* 目标函数 A（6 参数外部调用） */
__attribute__((used, noinline, noipa, section("vmcode")))
static uint64_t f_exit6(uint64_t x, uint64_t y) {
    uint64_t r = ext6(x, y, x ^ y, x + y, x * 3, y * 7);
    return r ^ 0x00ABCDEFu;
}
/* 目标函数 B（8 参数外部调用，含栈参数） */
__attribute__((used, noinline, noipa, section("vmcode8")))
static uint64_t f_exit8(uint64_t x, uint64_t y) {
    uint64_t r = ext8(x, y, x ^ y, x + y, x * 3, y * 7, x | y, y + 0x100);
    return r ^ 0x55AA55AAu;
}

extern const uint8_t __start_vmcode[],  __stop_vmcode[];
extern const uint8_t __start_vmcode8[], __stop_vmcode8[];

static uint64_t ref6(uint64_t x, uint64_t y) {
    uint64_t a=x,b=y,c=x^y,d=x+y,e=x*3,f=y*7;
    return (a + b*2 + c*3 + d*4 + e*5 + f*6 + 0x1234u) ^ 0x00ABCDEFu;
}
static uint64_t ref8(uint64_t x, uint64_t y) {
    uint64_t a=x,b=y,c=x^y,d=x+y,e=x*3,f=y*7,g=x|y,h=y+0x100;
    return (a + b*2 + c*3 + d*4 + e*5 + f*6 + g*7 + h*8 + 0x4321u) ^ 0x55AA55AAu;
}

static const uint64_t XS[] = {0, 1, 7, 0x1234, 0xDEADBEEFu,
                              0x9E3779B97F4A7C15ULL, 0xFFFFFFFFFFFFFFFFULL};
static const uint64_t YS[] = {0, 3, 11, 0x9876, 0x0BADF00Du,
                              0xBF58476D1CE4E5B9ULL, 0x0123456789ABCDEFULL};
#define NARGS (sizeof(XS)/sizeof(XS[0]))

/* 编译一段机器码并逐组比对；返回 0 全过 */
static int run_case(const char *name, const uint8_t *code, size_t len,
                    uint64_t (*ref)(uint64_t, uint64_t)) {
    printf("[exit_demo] %s @ %p, %zu 字节\n", name, (const void *)code, len);
    if (len < 8 || len > 4096) { fprintf(stderr, "  机器码长度异常\n"); return 2; }

    char err[CSVM_ERR_CAP] = {0};
    uint8_t *bc = NULL; size_t bc_len = 0;
    if (csvm_compile(code, len, 0xC0FFEEu, &bc, &bc_len, err, sizeof(err)) != 0) {
        fprintf(stderr, "  csvm_compile 失败: %s\n", err);
        char d[8192] = {0}; csvm_disasm(code, len, d, sizeof(d));
        fprintf(stderr, "%s\n", d);
        return 3;
    }
    /* 外部调用必须被识别为 CALLEXT，否则说明桥没接上 */
    char d[8192] = {0}; csvm_disasm(code, len, d, sizeof(d));
    if (!strstr(d, "CALLEXT")) {
        fprintf(stderr, "  反汇编未见 CALLEXT:\n%s\n", d);
        csvm_free(bc); return 4;
    }
    printf("  编译 %zu 字节字节码，外部调用已识别为 VM-exit\n", bc_len);
    /* 把反汇编里的 CALLEXT 行打印到 stdout，作为「VM-exit 原语已识别」的可见证据，
     * 也让上层自检能对 IR 清单做硬断言（而非只依赖一句中文描述）。 */
    {
        char *line = d;
        while (line && *line) {
            char *eol = strchr(line, '\n');
            if (eol) *eol = 0;
            if (strstr(line, "CALLEXT")) printf("    %s\n", line);
            if (!eol) break;
            line = eol + 1;
        }
    }

    int pass = 0, fail = 0;
    for (size_t i = 0; i < NARGS; ++i) {
        uint64_t stack[64];
        for (int k = 0; k < 64; ++k) stack[k] = 0;
        uint64_t rin[16] = {0}, rout[16] = {0};
        rin[7] = XS[i];                              /* RDI = x */
        rin[6] = YS[i];                              /* RSI = y */
        rin[4] = (uint64_t)(uintptr_t)&stack[24];   /* RSP：真实宿主栈，留足空间 */
        int rc = csvm_run_host(bc, bc_len, rin, rout,
                               (uint64_t)(uintptr_t)code,   /* runtime_base */
                               NULL, NULL, err, sizeof(err));
        uint64_t got = rout[0], want = ref(XS[i], YS[i]);
        if (rc == 0 && got == want) pass++;
        else {
            fail++;
            printf("  MISMATCH x=%llu y=%llu rc=%d got=0x%llX want=0x%llX err=%s\n",
                   (unsigned long long)XS[i], (unsigned long long)YS[i], rc,
                   (unsigned long long)got, (unsigned long long)want, err);
        }
    }
    csvm_free(bc);
    printf("  %s: %s %d/%d 一致\n", name, fail == 0 ? "PASS" : "FAIL",
           pass, pass + fail);
    return fail == 0 ? 0 : 1;
}

int main(void) {
    uint64_t before = g_helper_calls;
    int rc = 0;
    rc |= run_case("f_exit6 (6寄存器参数)", __start_vmcode,
                   (size_t)(__stop_vmcode - __start_vmcode), ref6);
    rc |= run_case("f_exit8 (含栈参数)", __start_vmcode8,
                   (size_t)(__stop_vmcode8 - __start_vmcode8), ref8);
    uint64_t calls = g_helper_calls - before;
    printf("[exit_demo] 外部函数被真实调用 %llu 次（期望 %zu）\n",
           (unsigned long long)calls, NARGS * 2);
    if (calls != NARGS * 2) {
        fprintf(stderr, "  VM-exit 未真正切回原生执行（计数不符）\n");
        rc |= 8;
    }
    printf("[exit_demo] RESULT=%s\n", rc == 0 ? "PASS" : "FAIL");
    return rc == 0 ? 0 : 1;
}
