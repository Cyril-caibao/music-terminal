/* CyrilShield 第八批 —— 独立验收项端到端验证（System V / Linux）
 *
 * 逐项复现用户第七批验收里点名、且要求「这次全做完」的问题：
 *   A) 浮点参数跨 VM-exit 静默算错：double f_pow(x,y)=pow(x,y)+1.0
 *      -> 必须得 9.0，不能得 3.0；非 fpu 入口必须明确拒绝而非给错答案。
 *   B) 直接 jmp rel32 尾调用（gcc -O2 sibling call）闭包外 -> IR_TAILEXIT。
 *   C) 同一个 sibling jmp，把被调函数机器码作为第二 seg 传入 CFG 闭包
 *      -> 跨段 VM 内闭环（模拟 .cold / 分裂函数），两种路径结果都与原生一致。
 *   D) REP 字符串指令 rep movsb / rep stosq（真实 gcc -O2 编出的 F3 A4 / F3 48 AB）。
 *   E) v5 变长加密容器：变长 padding、meta 密文、头/记录篡改拒绝、旧 v4 拒绝。
 *
 * 所有目标函数机器码都由 gcc -O2 真实编译，放独立 section，用 GNU ld 的
 * __start_/__stop_ 取字节；runtime_base 传 section 真实地址，host 真实内存
 * 模式下 RIP 相对 / 栈 / 外部调用全部走真实宿主。
 *
 * 诚实边界：这是 x86-64 受限子集的冷启动验证，不是商用 VMP；沙箱无 Windows
 * 真机，Windows 侧只验证到发布 DLL 导出收敛与 PE stub 字节，见 docs/CODE-VM.md。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#include "cs_codevm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

/* ================= A. 浮点参数跨 VM-exit ================= */
__attribute__((used, noinline, noipa, section("cv_pow")))
static double f_pow(double x, double y) {
    return pow(x, y) + 1.0;
}
extern const uint8_t __start_cv_pow[], __stop_cv_pow[];
static double ref_pow(double x, double y) { return pow(x, y) + 1.0; }

/* ============ B/C. sibling call 与 CFG 多段闭包 ============ */
__attribute__((used, noinline, noipa, section("cv_helper")))
static uint64_t cfg_helper(uint64_t x) { return x * 7 + 13; }
extern const uint8_t __start_cv_helper[], __stop_cv_helper[];

/* gcc -O2：return cfg_helper(x) 会优化成 jmp rel32（sibling call） */
__attribute__((used, noinline, noipa, section("cv_sibling")))
static uint64_t f_sibling(uint64_t x) { return cfg_helper(x); }
extern const uint8_t __start_cv_sibling[], __stop_cv_sibling[];

/* ================= D. REP 字符串指令 ================= */
__attribute__((used, noinline, noipa, section("cv_repmovs")))
static void f_repmovs(uint8_t *d, const uint8_t *s, size_t n) {
    __asm__ volatile("rep movsb" : "+D"(d), "+S"(s), "+c"(n) : : "memory");
}
extern const uint8_t __start_cv_repmovs[], __stop_cv_repmovs[];

__attribute__((used, noinline, noipa, section("cv_repstos")))
static void f_repstos(uint64_t *d, uint64_t v, size_t n) {
    __asm__ volatile("rep stosq" : "+D"(d), "+c"(n) : "a"(v) : "memory");
}
extern const uint8_t __start_cv_repstos[], __stop_cv_repstos[];

/* ================= E. 容器测试用整数函数 ================= */
__attribute__((used, noinline, noipa, section("cv_int")))
static uint64_t f_int(uint64_t a, uint64_t b) { return a * 3 + b + 7; }
extern const uint8_t __start_cv_int[], __stop_cv_int[];

/* ---------------------------------------------------------------- helpers */
static uint64_t d2u(double d)  { uint64_t u; memcpy(&u, &d, 8); return u; }
static double   u2d(uint64_t u){ double d; memcpy(&d, &u, 8); return d; }

static int show_ir(const char *name, const uint8_t *code, size_t len,
                   const char *want) {
    char d[16384] = {0};
    if (csvm_disasm(code, len, d, sizeof(d)) != 0) return -1;
    if (want && !strstr(d, want)) {
        printf("  [%s] 反汇编未见 %s:\n%s\n", name, want, d);
        return -1;
    }
    char buf[16384]; memcpy(buf, d, sizeof(buf));
    char *line = buf;
    while (line && *line) {
        char *eol = strchr(line, '\n');
        if (eol) *eol = 0;
        if (strstr(line, "CALLEXT") || strstr(line, "TAILEXIT") ||
            strstr(line, "REP") || strstr(line, "SETDF") || strstr(line, "FSSE"))
            printf("    %s\n", line);
        if (!eol) break;
        line = eol + 1;
    }
    return 0;
}

static int compile_seed(const char *name, const uint8_t *code, size_t len,
                        uint64_t seed, uint8_t **bc, size_t *bcn);

static int compile_one(const char *name, const uint8_t *code, size_t len,
                       uint8_t **bc, size_t *bcn) {
    return compile_seed(name, code, len, 0x5EED8u, bc, bcn);
}

static int compile_seed(const char *name, const uint8_t *code, size_t len,
                        uint64_t seed, uint8_t **bc, size_t *bcn) {
    char err[CSVM_ERR_CAP] = {0};
    int rc = csvm_compile(code, len, seed, bc, bcn, err, sizeof(err));
    if (rc != 0) {
        printf("  [%s] csvm_compile 失败(%d): %s\n", name, rc, err);
        char d[16384] = {0}; csvm_disasm(code, len, d, sizeof(d));
        printf("%s\n", d);
    }
    return rc;
}

/* host 整数执行：SysV RDI/RSI/RDX，真实宿主栈 */
static int run_int(const uint8_t *bc, size_t n, const uint8_t *base,
                   uint64_t a, uint64_t b, uint64_t c, uint64_t *out) {
    uint64_t stack[256]; memset(stack, 0, sizeof(stack));
    uint64_t rin[16] = {0}, rout[16] = {0};
    rin[7] = a; rin[6] = b; rin[2] = c;
    rin[4] = (uint64_t)(uintptr_t)&stack[128];
    char err[CSVM_ERR_CAP] = {0};
    int rc = csvm_run_host(bc, n, rin, rout,
                           (uint64_t)(uintptr_t)base, NULL, NULL, err, sizeof(err));
    if (rc != 0) printf("    run_int err: %s\n", err);
    *out = rout[0];
    return rc;
}

/* host FPU 执行：XMM0/XMM1 送入，XMM0 取回 */
static int run_fpu(const uint8_t *bc, size_t n, const uint8_t *base,
                   uint64_t x0, uint64_t x1, uint64_t *x0out) {
    uint64_t stack[256]; memset(stack, 0, sizeof(stack));
    uint64_t rin[16] = {0}, rout[16] = {0};
    uint64_t xin[16][2] = {{0}}, xout[16][2] = {{0}};
    xin[0][0] = x0; xin[1][0] = x1;
    rin[4] = (uint64_t)(uintptr_t)&stack[128];
    char err[CSVM_ERR_CAP] = {0};
    int rc = csvm_run_host_fpu(bc, n, rin, rout,
                               (const uint64_t (*)[2])xin, xout,
                               (uint64_t)(uintptr_t)base,
                               NULL, NULL, NULL, NULL, err, sizeof(err));
    if (rc != 0) printf("    run_fpu err: %s\n", err);
    *x0out = xout[0][0];
    return rc;
}

int main(void) {
    int bad = 0;
    uint8_t *bc = NULL; size_t bcn = 0;
    char err[CSVM_ERR_CAP] = {0};
    static const uint64_t XS[] = {
        0, 1, 7, 100, 0x1234u, 0xDEADBEEFu, 0xFFFFFFFFFFFFFFFFULL
    };
    const int NX = (int)(sizeof(XS) / sizeof(XS[0]));

    /* ================= A) 浮点跨 VM-exit ================= */
    printf("[v5] A) 浮点参数跨 VM-exit（修复 pow(2,3)+1 静默算错）\n");
    {
        size_t len = (size_t)(__stop_cv_pow - __start_cv_pow);
        if (compile_one("f_pow", __start_cv_pow, len, &bc, &bcn) == 0) {
            show_ir("f_pow", __start_cv_pow, len, "CALLEXT");
            const double AS[] = {2.0, 3.0, 1.5, 0.5, 10.0, -2.0};
            const double BS[] = {3.0, 2.0, 4.0, -1.0, 0.0, 3.0};
            int pass = 0, fail = 0;
            for (int i = 0; i < 6; ++i) {
                uint64_t got = 0;
                int rc = run_fpu(bc, bcn, __start_cv_pow,
                                 d2u(AS[i]), d2u(BS[i]), &got);
                double want = ref_pow(AS[i], BS[i]);
                if (rc == 0 && u2d(got) == want) pass++;
                else { fail++; printf("  FPU-EXIT MISMATCH pow(%.3g,%.3g)+1 rc=%d got=%.17g want=%.17g\n",
                        AS[i], BS[i], rc, u2d(got), want); }
            }
            printf("  FPU-EXIT: %s %d/6 与原生一致（pow(2,3)+1 = %g，不是 3.0）\n",
                   fail ? "FAIL" : "PASS", pass, ref_pow(2.0, 3.0));
            if (fail) bad |= 1;

            /* 非 fpu 入口必须明确拒绝，绝不静默返回 3.0 */
            uint64_t stack[256] = {0}, rin[16] = {0}, rout[16] = {0};
            rin[4] = (uint64_t)(uintptr_t)&stack[128];
            int rc = csvm_run_host(bc, bcn, rin, rout,
                                   (uint64_t)(uintptr_t)__start_cv_pow,
                                   NULL, NULL, err, sizeof(err));
            if (rc != 0 && strstr(err, "浮点")) {
                printf("  NON-FPU-REJECT: PASS 非 fpu 入口明确拒绝（rc=%d: %s）\n", rc, err);
            } else {
                printf("  NON-FPU-REJECT: FAIL rc=%d err=%s\n", rc, err);
                bad |= 2;
            }
            csvm_free(bc); bc = NULL;
        } else bad |= 1;
    }

    /* ================= B) 直接尾调用 TAILEXIT ================= */
    printf("[v5] B) 直接 jmp rel32 尾调用（gcc -O2 sibling call -> VM-exit tail）\n");
    {
        size_t len = (size_t)(__stop_cv_sibling - __start_cv_sibling);
        if (compile_one("f_sibling", __start_cv_sibling, len, &bc, &bcn) == 0) {
            show_ir("f_sibling", __start_cv_sibling, len, "TAILEXIT");
            int pass = 0, fail = 0;
            for (int i = 0; i < NX; ++i) {
                uint64_t got = 0;
                int rc = run_int(bc, bcn, __start_cv_sibling, XS[i], 0, 0, &got);
                uint64_t want = cfg_helper(XS[i]);
                if (rc == 0 && got == want) pass++;
                else { fail++; printf("  TAILEXIT MISMATCH x=%llu rc=%d got=%llu want=%llu\n",
                        (unsigned long long)XS[i], rc,
                        (unsigned long long)got, (unsigned long long)want); }
            }
            printf("  TAILEXIT: %s %d/%d 与原生一致\n",
                   fail ? "FAIL" : "PASS", pass, NX);
            if (fail) bad |= 4;
            csvm_free(bc); bc = NULL;
        } else bad |= 4;
    }

    /* ================= C) CFG 多段闭包 ================= */
    printf("[v5] C) CFG 多段闭包（同一 sibling jmp 改为跨段 VM 内闭环）\n");
    {
        size_t sib_len = (size_t)(__stop_cv_sibling - __start_cv_sibling);
        size_t hlp_len = (size_t)(__stop_cv_helper - __start_cv_helper);
        intptr_t diff = (intptr_t)(__start_cv_helper - __start_cv_sibling);
        const uint8_t *base;
        uint64_t rva_main, rva_helper;
        if (diff >= 0) {
            base = __start_cv_sibling; rva_main = 0; rva_helper = (uint64_t)diff;
        } else {
            base = __start_cv_helper; rva_main = (uint64_t)(-diff); rva_helper = 0;
        }
        csvm_seg_t segs[2] = {
            { __start_cv_sibling, sib_len, rva_main },
            { __start_cv_helper,  hlp_len, rva_helper },
        };
        int rc = csvm_compile_cfg(segs, 2, 0x5EED9u, &bc, &bcn, err, sizeof(err));
        if (rc == 0) {
            uint32_t a = 0, b2 = 0, c2 = 0; uint64_t s = 0;
            csvm_stats(bc, bcn, &a, &b2, &c2, &s);
            printf("  CFG-COMPILE: PASS 2 段闭包 n_insn=%u n_ir=%u rva_main=%llu rva_helper=%llu\n",
                   a, b2, (unsigned long long)rva_main, (unsigned long long)rva_helper);
            int pass = 0, fail = 0;
            for (int i = 0; i < NX; ++i) {
                uint64_t got = 0;
                int r2 = run_int(bc, bcn, base, XS[i], 0, 0, &got);
                uint64_t want = cfg_helper(XS[i]);
                if (r2 == 0 && got == want) pass++;
                else { fail++; printf("  CFG MISMATCH x=%llu rc=%d got=%llu want=%llu\n",
                        (unsigned long long)XS[i], r2,
                        (unsigned long long)got, (unsigned long long)want); }
            }
            printf("  CFG-MULTISEG: %s %d/%d 跨段闭环与原生一致\n",
                   fail ? "FAIL" : "PASS", pass, NX);
            if (fail) bad |= 8;
            csvm_free(bc); bc = NULL;
        } else {
            printf("  CFG-COMPILE: FAIL csvm_compile_cfg(%d): %s\n", rc, err);
            bad |= 8;
        }
    }

    /* ================= D) REP 字符串指令 ================= */
    printf("[v5] D) REP 字符串指令（rep movsb / rep stosq）\n");
    {
        size_t len = (size_t)(__stop_cv_repmovs - __start_cv_repmovs);
        if (compile_one("f_repmovs", __start_cv_repmovs, len, &bc, &bcn) == 0) {
            show_ir("f_repmovs", __start_cv_repmovs, len, "REP");
            uint8_t src[64], vm[64], ref[64];
            for (int i = 0; i < 64; ++i) src[i] = (uint8_t)(i * 7 + 3);
            memset(vm, 0, sizeof(vm)); memset(ref, 0, sizeof(ref));
            memcpy(ref, src, 37);
            uint64_t stack[256] = {0}, rin[16] = {0}, rout[16] = {0};
            rin[7] = (uint64_t)(uintptr_t)vm;
            rin[6] = (uint64_t)(uintptr_t)src;
            rin[2] = 37;                 /* SysV 第3参数 RDX，函数在码里转 RCX */
            rin[4] = (uint64_t)(uintptr_t)&stack[128];
            int rc = csvm_run_host(bc, bcn, rin, rout,
                                   (uint64_t)(uintptr_t)__start_cv_repmovs,
                                   NULL, NULL, err, sizeof(err));
            int ok = (rc == 0 && memcmp(vm, ref, 37) == 0);
            printf("  REP-MOVSB: %s rc=%d 前 8 字节 %02x%02x%02x%02x...\n",
                   ok ? "PASS" : "FAIL", rc, vm[0], vm[1], vm[2], vm[3]);
            if (!ok) { bad |= 16; printf("    err=%s\n", err); }
            csvm_free(bc); bc = NULL;
        } else bad |= 16;

        len = (size_t)(__stop_cv_repstos - __start_cv_repstos);
        if (compile_one("f_repstos", __start_cv_repstos, len, &bc, &bcn) == 0) {
            show_ir("f_repstos", __start_cv_repstos, len, "REP");
            uint64_t vm[16], ref[16];
            for (int i = 0; i < 16; ++i) { vm[i] = 0; ref[i] = 0xA5A5A5A5DEADBEEFULL; }
            uint64_t stack[256] = {0}, rin[16] = {0}, rout[16] = {0};
            rin[7] = (uint64_t)(uintptr_t)vm;
            rin[6] = 0xA5A5A5A5DEADBEEFULL;   /* RSI = 填充值，码里转 RAX */
            rin[2] = 11;
            rin[4] = (uint64_t)(uintptr_t)&stack[128];
            int rc = csvm_run_host(bc, bcn, rin, rout,
                                   (uint64_t)(uintptr_t)__start_cv_repstos,
                                   NULL, NULL, err, sizeof(err));
            int ok = (rc == 0 && memcmp(vm, ref, 11 * 8) == 0);
            printf("  REP-STOSQ: %s rc=%d vm[0]=0x%llX vm[10]=0x%llX\n",
                   ok ? "PASS" : "FAIL", rc,
                   (unsigned long long)vm[0], (unsigned long long)vm[10]);
            if (!ok) { bad |= 32; printf("    err=%s\n", err); }
            csvm_free(bc); bc = NULL;
        } else bad |= 32;
    }

    /* ================= E) v5 变长加密容器 ================= */
    printf("[v5] E) v5 变长加密容器（去明文 / 防篡改 / 旧格式拒绝）\n");
    {
        size_t len = (size_t)(__stop_cv_int - __start_cv_int);
        if (compile_one("f_int", __start_cv_int, len, &bc, &bcn) == 0) {
            /* v5 魔数 */
            int ok_magic = (memcmp(bc, "CSVM\x05\0\0\0", 8) == 0);
            printf("  V5-MAGIC: %s CSVM\\x05（ABI 3）\n", ok_magic ? "PASS" : "FAIL");
            if (!ok_magic) bad |= 64;

            /* 变长：不同 seed 编译长度不同（随机 padding/keystream） */
            uint8_t *bc2 = NULL; size_t n2 = 0;
            int r2 = csvm_compile(__start_cv_int, len, 0xABCDEF01u,
                                  &bc2, &n2, err, sizeof(err));
            int ok_var = (r2 == 0 && n2 != bcn);
            printf("  VARLEN: %s seed-A=%zuB seed-B=%zuB（定长明文已去除）\n",
                   ok_var ? "PASS" : "WARN", bcn, n2);
            if (r2 == 0) csvm_free(bc2);
            if (!ok_var) bad |= 128;

            /* 解析明文 file_hdr（仅头部明文，enc 区全密文） */
            uint32_t enc_off = 0, n_insn = 0;
            memcpy(&enc_off, bc + 20, 4);      /* csvm_file_hdr_t.enc_off */
            memcpy(&n_insn,  bc + 28, 4);      /* csvm_file_hdr_t.n_insn */
            uint32_t enc_head = 576u + 8u * n_insn;
            /* meta 已加密：enc 区不应出现明文 "CSVM\x05" */
            int plain = 0;
            for (size_t i = enc_off; i + 8 <= bcn; ++i)
                if (memcmp(bc + i, "CSVM\x05\0\0\0", 8) == 0) { plain = 1; break; }
            printf("  META-ENCRYPTED: %s（加密区未见明文 magic，CSVM_KS_CONST 不落盘）\n",
                   plain ? "FAIL" : "PASS");
            if (plain) bad |= 256;

            uint8_t *t = (uint8_t *)malloc(bcn);
            uint32_t a = 0, b2 = 0, c2 = 0; uint64_t s = 0;
            /* 头/meta 篡改 -> hdr_mac 拒绝 */
            memcpy(t, bc, bcn);
            t[enc_off + 300] ^= 0x5A;
            int rh = csvm_stats(t, bcn, &a, &b2, &c2, &s);
            printf("  TAMPER-HEADER: %s csvm_stats rc=%d（hdr_mac）\n",
                   rh != 0 ? "PASS" : "FAIL", rh);
            if (rh == 0) bad |= 512;

            /* 记录体篡改 -> rec_mac 在执行到该 pc 时拒绝 */
            memcpy(t, bc, bcn);
            if (enc_off + enc_head + 6 < bcn) {
                t[enc_off + enc_head + 6] ^= 0x5A;
                uint64_t out = 0;
                int rr = csvm_run(t, bcn, NULL, 0, &out, err, sizeof(err));
                printf("  TAMPER-RECORD: %s csvm_run rc=%d（rec_mac）\n",
                       rr != 0 ? "PASS" : "FAIL", rr);
                if (rr == 0) bad |= 1024;
            }

            /* 旧 v4 明文字节码按魔数拒绝 */
            memcpy(t, bc, bcn);
            memcpy(t, "CSVM\x04\0\0\0", 8);
            int rv = csvm_stats(t, bcn, &a, &b2, &c2, &s);
            printf("  REJECT-V4: %s csvm_stats rc=%d（旧 v4 作废）\n",
                   rv != 0 ? "PASS" : "FAIL", rv);
            if (rv == 0) bad |= 2048;

            free(t);
            csvm_free(bc); bc = NULL;
        } else bad |= 64;
    }

    /* ================= F) handler 变异（间接分派 + seed 选变体） ================= */
    printf("[v5] F) handler 变异：同函数不同 seed 编译 -> 不同 handler 集合，结果必须一致\n");
    {
        const uint8_t *code = __start_cv_int;
        size_t len = (size_t)(__stop_cv_int - __start_cv_int);
        uint8_t *bcA = NULL, *bcB = NULL; size_t nA = 0, nB = 0;
        if (compile_seed("f_int", code, len, 0xA1B2C3D4u, &bcA, &nA) == 0 &&
            compile_seed("f_int", code, len, 0x12345678u, &bcB, &nB) == 0) {
            printf("  HANDLER-COMPILE: PASS 两 seed 编译成功（nA=%zu nB=%zu）\n", nA, nB);
            int pass = 0, fail = 0;
            for (int i = 0; i < NX; ++i)
                for (int j = 0; j < NX; ++j) {
                    uint64_t gA = 0, gB = 0;
                    int rA = run_int(bcA, nA, __start_cv_int, XS[i], XS[j], 0, &gA);
                    int rB = run_int(bcB, nB, __start_cv_int, XS[i], XS[j], 0, &gB);
                    uint64_t want = f_int(XS[i], XS[j]);
                    if (rA == 0 && rB == 0 && gA == want && gB == want) pass++;
                    else {
                        fail++;
                        if (fail <= 3)
                            printf("  MUT MISMATCH a=%llu b=%llu rA=%d rB=%d gA=%llu gB=%llu want=%llu\n",
                                   (unsigned long long)XS[i], (unsigned long long)XS[j],
                                   rA, rB, (unsigned long long)gA, (unsigned long long)gB,
                                   (unsigned long long)want);
                    }
                }
            printf("  HANDLER-MUTATE: %s %d/%d 两 seed 的 handler 集合结果均与原生一致（变异不改变语义）\n",
                   fail ? "FAIL" : "PASS", pass, NX * NX);
            if (fail) bad |= 4096;
            csvm_free(bcA); csvm_free(bcB);
        } else bad |= 4096;
    }

    printf("[v5] RESULT=%s\n", bad == 0 ? "PASS" : "FAIL");
    return bad == 0 ? 0 : 1;
}
