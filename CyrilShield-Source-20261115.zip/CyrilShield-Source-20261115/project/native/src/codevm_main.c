/* CyrilShield CodeVM 命令行工具（调试 / 自检 / Windows 侧批处理用）
 *
 *   csvm disasm  <code.bin>
 *   csvm compile <code.bin> <seed> <out.csvm>
 *   csvm run     <out.csvm> [arg0 arg1 ...]      # 最多 6 个 uint64
 *   csvm stats   <out.csvm>
 *   csvm version
 *
 * Python 侧（cyrilshield/vmp/codevm.py）直接通过 ctypes 调共享库，本 CLI
 * 只是给不方便用 Python 的场合提供同一套 ABI 的入口。
 */
#include "cs_codevm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint8_t *read_file(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "无法打开: %s\n", path); return NULL; }
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long n = ftell(f);
    if (n < 0 || n > (long)CSVM_MAX_CODE * 8) { fclose(f); return NULL; }
    rewind(f);
    uint8_t *p = (uint8_t *)malloc((size_t)n + 1);
    if (!p) { fclose(f); return NULL; }
    if (n > 0 && fread(p, 1, (size_t)n, f) != (size_t)n) {
        free(p); fclose(f); return NULL;
    }
    fclose(f);
    p[n] = 0;
    *len = (size_t)n;
    return p;
}

static int write_file(const char *path, const uint8_t *p, size_t n) {
    FILE *f = fopen(path, "wb");
    if (!f) { fprintf(stderr, "无法写入: %s\n", path); return -1; }
    int ok = (fwrite(p, 1, n, f) == n);
    fclose(f);
    return ok ? 0 : -1;
}

static void usage(void) {
    printf("CyrilShield CodeVM %s\n"
           "  csvm disasm  <code.bin>\n"
           "  csvm compile <code.bin> <seed> <out.csvm>\n"
           "  csvm run     <out.csvm> [uint64 args...]\n"
           "  csvm stats   <out.csvm>\n"
           "  csvm version\n", csvm_version_string());
}

int main(int argc, char **argv) {
    if (argc < 2) { usage(); return 2; }
    const char *cmd = argv[1];

    if (!strcmp(cmd, "version")) {
        printf("%s (abi=%u)\n", csvm_version_string(), csvm_abi_version());
        return 0;
    }

    if (!strcmp(cmd, "disasm")) {
        if (argc < 3) { usage(); return 2; }
        size_t n = 0;
        uint8_t *code = read_file(argv[2], &n);
        if (!code) return 1;
        size_t cap = n * 96 + 4096;
        char *out = (char *)malloc(cap);
        int rc = csvm_disasm(code, n, out, cap);
        printf("%s", out);
        free(out); free(code);
        return rc == 0 ? 0 : 1;
    }

    if (!strcmp(cmd, "compile")) {
        if (argc < 5) { usage(); return 2; }
        size_t n = 0;
        uint8_t *code = read_file(argv[2], &n);
        if (!code) return 1;
        uint64_t seed = strtoull(argv[3], NULL, 0);
        uint8_t *bc = NULL; size_t blen = 0;
        char err[CSVM_ERR_CAP] = {0};
        int rc = csvm_compile(code, n, seed, &bc, &blen, err, sizeof(err));
        if (rc != 0) {
            fprintf(stderr, "编译失败: %s\n", err);
            free(code);
            return 3;
        }
        rc = write_file(argv[4], bc, blen);
        uint32_t a = 0, b = 0, c = 0; uint64_t s = 0;
        csvm_stats(bc, blen, &a, &b, &c, &s);
        printf("OK %s  code=%zuB bc=%zuB IR=%u BC=%u junk=%u seed=%llu\n",
               argv[4], n, blen, b, a, c, (unsigned long long)s);
        csvm_free(bc); free(code);
        return rc;
    }

    if (!strcmp(cmd, "run")) {
        if (argc < 3) { usage(); return 2; }
        size_t n = 0;
        uint8_t *bc = read_file(argv[2], &n);
        if (!bc) return 1;
        uint64_t args[6] = {0};
        size_t na = 0;
        for (int i = 3; i < argc && na < 6; ++i, ++na)
            args[na] = strtoull(argv[i], NULL, 0);
        uint64_t ret = 0;
        char err[CSVM_ERR_CAP] = {0};
        int rc = csvm_run(bc, n, args, na, &ret, err, sizeof(err));
        if (rc != 0) {
            fprintf(stderr, "执行失败(%d): %s\n", rc, err);
            free(bc); return 4;
        }
        printf("%llu 0x%016llx\n", (unsigned long long)ret,
               (unsigned long long)ret);
        free(bc);
        return 0;
    }

    if (!strcmp(cmd, "stats")) {
        if (argc < 3) { usage(); return 2; }
        size_t n = 0;
        uint8_t *bc = read_file(argv[2], &n);
        if (!bc) return 1;
        uint32_t a = 0, b = 0, c = 0; uint64_t s = 0;
        if (csvm_stats(bc, n, &a, &b, &c, &s) != 0) {
            fprintf(stderr, "不是有效的 csvm 字节码\n"); free(bc); return 5;
        }
        printf("BC=%u IR=%u junk=%u seed=%llu size=%zuB\n",
               a, b, c, (unsigned long long)s, n);
        free(bc);
        return 0;
    }

    usage();
    return 2;
}
