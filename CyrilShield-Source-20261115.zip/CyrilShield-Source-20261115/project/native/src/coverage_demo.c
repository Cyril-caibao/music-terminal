/* 第七批 —— FF/4 间接跳转 + 标量 SSE 的端到端冷启动验证（System V / Linux）。
 *
 * 验证的正是用户实测里点名的两条覆盖率缺口：
 *   1) FF/4 间接跳转：之前 jmp * / FF /4 明确拒绝「属 L3」。
 *      A) 尾调用 / 虚函数 / 函数指针：jmp reg 到函数外 -> VM-exit 到原生，
 *         以其 RAX 作为整个被虚拟化函数的返回值。
 *      B) switch 跳转表：gcc -O2 生成 lea 表基址 + movsxd 读 32 位表项 +
 *         add + jmp reg，目标落在函数字节范围内 -> 回填 bc 索引在 VM 内闭环。
 *   2) 标量 SSE：movss/movsd/movapd/mulss/mulsd/addss/addsd/subss/subsd/
 *      cvtsi2sd/cvttsd2si/pxor 等；double/float 参数经 XMM0/XMM1 送入，
 *      结果经 XMM0 取回，与原生函数逐位比对。
 *
 * 目标函数都是 gcc -O2 真实编译的机器码，放独立 section，用 GNU ld 自动
 * 生成的 __start_/__stop_ 符号取字节。runtime_base = section 真实地址；
 * host 真实内存模式下 RIP 相对 .rodata 常量/跳转表都能正确解析。
 *
 * 明确不做（L3 / 后续）：packed 逐 lane 浮点算术、VM-exit 传浮点参数、
 * 异常穿透 / unwind、回调再进 VM、多线程 VM 上下文、间接调用跳转表跨函数。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#include "cs_codevm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* ---------------------------------------------------------------- FF/4 尾调用 */
/* 被尾调用的真实外部函数（2 参数） */
__attribute__((noinline, noipa))
static uint64_t tail_helper(uint64_t a, uint64_t b) {
    return a * 3 + b + 7;
}
/* gcc -O2: endbr64; jmp rdx  (FF /4 = FF E2, exit_kind 4) */
__attribute__((used, noinline, noipa, section("cv_tail")))
static uint64_t f_tail(uint64_t a, uint64_t b, uint64_t (*fp)(uint64_t, uint64_t)) {
    return fp(a, b);
}
extern const uint8_t __start_cv_tail[], __stop_cv_tail[];

/* --------------------------------------------------------- FF/4 switch 跳转表 */
/* 8 个 case，gcc -O2 生成 .rodata 32 位相对偏移跳转表 + jmp reg */
__attribute__((used, noinline, noipa, section("cv_switch")))
static uint64_t f_switch(uint64_t x) {
    switch (x & 7) {
        case 0: return x + 11;
        case 1: return x * 3 + 1;
        case 2: return x ^ 0x5A;
        case 3: return x * x;
        case 4: return x - 7;
        case 5: return x + 0x1234;
        case 6: return x * 5 + 2;
        default: return ~x;
    }
}
extern const uint8_t __start_cv_switch[], __stop_cv_switch[];

static uint64_t ref_switch(uint64_t x) {
    switch (x & 7) {
        case 0: return x + 11;
        case 1: return x * 3 + 1;
        case 2: return x ^ 0x5A;
        case 3: return x * x;
        case 4: return x - 7;
        case 5: return x + 0x1234;
        case 6: return x * 5 + 2;
        default: return ~x;
    }
}

/* ------------------------------------------------------------------ SSE double */
__attribute__((used, noinline, noipa, section("cv_f64")))
static double f_f64(double a, double b) {
    double t = a * b + 3.25;
    t = t - b / 2.0;
    t = t * 1.5 + (double)(long)(a);   /* cvttsd2si + cvtsi2sd */
    return t;
}
extern const uint8_t __start_cv_f64[], __stop_cv_f64[];

static double ref_f64(double a, double b) {
    double t = a * b + 3.25;
    t = t - b / 2.0;
    t = t * 1.5 + (double)(long)(a);
    return t;
}

/* ------------------------------------------------------------------- SSE float */
__attribute__((used, noinline, noipa, section("cv_f32")))
static float f_f32(float a, float b) {
    return a * b + 1.5f - b / 4.0f;
}
extern const uint8_t __start_cv_f32[], __stop_cv_f32[];

static float ref_f32(float a, float b) {
    return a * b + 1.5f - b / 4.0f;
}

/* ---------------------------------------------------------------- 位转换帮助 */
static uint64_t d2u(double d) { uint64_t u; memcpy(&u, &d, 8); return u; }
static uint64_t f2u(float f)  { uint32_t u; memcpy(&u, &f, 4); return (uint64_t)u; }
static double   u2d(uint64_t u){ double d; memcpy(&d, &u, 8); return d; }

/* 编译一段机器码并确认包含期望的 IR 原语；返回 0 成功 */
static int compile_bc(const char *name, const uint8_t *code, size_t len,
                      const char *want_ir, uint8_t **bc_out, size_t *bc_len_out) {
    char err[CSVM_ERR_CAP] = {0};
    uint8_t *bc = NULL; size_t bc_len = 0;
    if (csvm_compile(code, len, 0x5EED7u, &bc, &bc_len, err, sizeof(err)) != 0) {
        fprintf(stderr, "[%s] csvm_compile 失败: %s\n", name, err);
        char d[16384] = {0}; csvm_disasm(code, len, d, sizeof(d));
        fprintf(stderr, "%s\n", d);
        return 2;
    }
    char d[16384] = {0}; csvm_disasm(code, len, d, sizeof(d));
    if (want_ir && !strstr(d, want_ir)) {
        fprintf(stderr, "[%s] 反汇编未见 %s:\n%s\n", name, want_ir, d);
        csvm_free(bc); return 3;
    }
    /* 把含关键 IR 的行打到 stdout，作为「原语已识别」的可见证据 */
    {
        char buf[16384]; memcpy(buf, d, sizeof(buf));
        char *line = buf;
        while (line && *line) {
            char *eol = strchr(line, '\n');
            if (eol) *eol = 0;
            if (strstr(line, "JMPI") || strstr(line, "FSSE") ||
                strstr(line, "CALLEXT") || strstr(line, "MOVSX"))
                printf("    %s\n", line);
            if (!eol) break;
            line = eol + 1;
        }
    }
    *bc_out = bc; *bc_len_out = bc_len;
    return 0;
}

/* host 模式执行（整数结果）：带真实宿主栈 */
static int run_int(const uint8_t *bc, size_t bc_len, const uint8_t *base,
                   uint64_t a, uint64_t b, uint64_t c, uint64_t *out) {
    uint64_t stack[256]; memset(stack, 0, sizeof(stack));
    uint64_t rin[16] = {0}, rout[16] = {0};
    rin[7] = a; rin[6] = b; rin[2] = c;               /* RDI/RSI/RDX */
    rin[4] = (uint64_t)(uintptr_t)&stack[128];        /* RSP 真实宿主栈 */
    char err[CSVM_ERR_CAP] = {0};
    int rc = csvm_run_host(bc, bc_len, rin, rout,
                           (uint64_t)(uintptr_t)base, NULL, NULL, err, sizeof(err));
    if (rc != 0) fprintf(stderr, "  run_int err: %s\n", err);
    *out = rout[0];
    return rc;
}

/* host 模式执行（浮点结果）：XMM0/XMM1 送入，XMM0 取回 */
static int run_fpu(const uint8_t *bc, size_t bc_len, const uint8_t *base,
                   uint64_t x0, uint64_t x1, uint64_t *x0out) {
    uint64_t stack[256]; memset(stack, 0, sizeof(stack));
    uint64_t rin[16] = {0}, rout[16] = {0};
    uint64_t xin[16][2] = {{0}}, xout[16][2] = {{0}};
    xin[0][0] = x0; xin[1][0] = x1;
    rin[4] = (uint64_t)(uintptr_t)&stack[128];
    char err[CSVM_ERR_CAP] = {0};
    int rc = csvm_run_host_fpu(bc, bc_len, rin, rout,
                               (const uint64_t (*)[2])xin, xout,
                               (uint64_t)(uintptr_t)base,
                               NULL, NULL, NULL, NULL, err, sizeof(err));
    if (rc != 0) fprintf(stderr, "  run_fpu err: %s\n", err);
    *x0out = xout[0][0];
    return rc;
}

int main(void) {
    int bad = 0;
    char err[CSVM_ERR_CAP] = {0};
    uint8_t *bc = NULL; size_t bc_len = 0;

    /* ---- 1. FF/4 尾调用（VM-exit 到原生）---- */
    printf("[coverage] A) FF/4 尾调用 jmp reg（目标在函数外 -> VM-exit）\n");
    if (compile_bc("f_tail", __start_cv_tail,
                   (size_t)(__stop_cv_tail - __start_cv_tail),
                   "JMPI", &bc, &bc_len) != 0) { bad |= 1; goto case_b; }
    {
        int pass = 0, fail = 0;
        const uint64_t XS[] = {0, 1, 7, 0x1234, 0xDEADBEEFu, 0xFFFFFFFFFFFFFFFFULL};
        const uint64_t YS[] = {3, 11, 0x9876, 0x0BADF00Du, 0x100, 0x0123456789ABCDEFULL};
        for (int i = 0; i < 6; ++i) {
            uint64_t got = 0;
            int rc = run_int(bc, bc_len, __start_cv_tail, XS[i], YS[i],
                             (uint64_t)(uintptr_t)&tail_helper, &got);
            uint64_t want = tail_helper(XS[i], YS[i]);
            if (rc == 0 && got == want) pass++;
            else { fail++; printf("  TAIL MISMATCH a=%llu b=%llu rc=%d got=0x%llX want=0x%llX\n",
                    (unsigned long long)XS[i], (unsigned long long)YS[i], rc,
                    (unsigned long long)got, (unsigned long long)want); }
        }
        printf("  FF4-TAIL: %s %d/6 与原生一致\n", fail ? "FAIL" : "PASS", pass);
        if (fail) bad |= 2;
    }
    csvm_free(bc); bc = NULL;

case_b:
    /* ---- 2. FF/4 switch 跳转表（函数内 -> VM 内闭环）---- */
    printf("[coverage] B) FF/4 switch 跳转表（目标在函数内 -> VM 内闭环）\n");
    if (compile_bc("f_switch", __start_cv_switch,
                   (size_t)(__stop_cv_switch - __start_cv_switch),
                   "JMPI", &bc, &bc_len) != 0) { bad |= 4; goto case_c; }
    {
        int pass = 0, fail = 0;
        const uint64_t XS[] = {0,1,2,3,4,5,6,7,8,9,0x10,0xFF,0x1234,
                               0x9E3779B97F4A7C15ULL, 0xFFFFFFFFFFFFFFF8ULL};
        for (size_t i = 0; i < sizeof(XS)/sizeof(XS[0]); ++i) {
            uint64_t got = 0;
            int rc = run_int(bc, bc_len, __start_cv_switch, XS[i], 0, 0, &got);
            uint64_t want = ref_switch(XS[i]);
            if (rc == 0 && got == want) pass++;
            else { fail++; printf("  SWITCH MISMATCH x=%llu rc=%d got=0x%llX want=0x%llX\n",
                    (unsigned long long)XS[i], rc,
                    (unsigned long long)got, (unsigned long long)want); }
        }
        printf("  JUMPTABLE: %s %d/%zu 与原生一致（8 case 全覆盖）\n",
               fail ? "FAIL" : "PASS", pass, sizeof(XS)/sizeof(XS[0]));
        if (fail) bad |= 8;
    }
    csvm_free(bc); bc = NULL;

case_c:
    /* ---- 3. SSE double（XMM0/XMM1 送入，XMM0 取回）---- */
    printf("[coverage] C) 标量 SSE double（mul/add/sub/div/cvtsi2sd/pxor + XMM0 返回）\n");
    if (compile_bc("f_f64", __start_cv_f64,
                   (size_t)(__stop_cv_f64 - __start_cv_f64),
                   "FSSE", &bc, &bc_len) != 0) { bad |= 16; goto case_d; }
    {
        int pass = 0, fail = 0;
        const double AS[] = {0.0, 1.0, -2.5, 3.14159, 1e10, -1e-8, 12345.678};
        const double BS[] = {1.0, 2.0, 0.5, -7.25, 3e-5, 4e8, -0.001};
        for (int i = 0; i < 7; ++i) {
            uint64_t got_bits = 0;
            int rc = run_fpu(bc, bc_len, __start_cv_f64,
                             d2u(AS[i]), d2u(BS[i]), &got_bits);
            uint64_t want_bits = d2u(ref_f64(AS[i], BS[i]));
            if (rc == 0 && got_bits == want_bits) pass++;
            else { fail++; printf("  F64 MISMATCH a=%.6g b=%.6g rc=%d got=%.17g want=%.17g\n",
                    AS[i], BS[i], rc, u2d(got_bits), u2d(want_bits)); }
        }
        printf("  SSE-F64: %s %d/7 逐位一致（XMM0 返回搬运）\n", fail ? "FAIL" : "PASS", pass);
        if (fail) bad |= 32;
    }
    csvm_free(bc); bc = NULL;

case_d:
    /* ---- 4. SSE float ---- */
    printf("[coverage] D) 标量 SSE float（mul/add/sub + XMM0 返回）\n");
    if (compile_bc("f_f32", __start_cv_f32,
                   (size_t)(__stop_cv_f32 - __start_cv_f32),
                   "FSSE", &bc, &bc_len) != 0) { bad |= 64; goto done; }
    {
        int pass = 0, fail = 0;
        const float AS[] = {0.f, 1.f, -2.5f, 3.14f, 1e6f, -1e-6f, 99.5f};
        const float BS[] = {1.f, 2.f, 0.5f, -7.25f, 3e-3f, 4e5f, -0.25f};
        for (int i = 0; i < 7; ++i) {
            uint64_t got_bits = 0;
            int rc = run_fpu(bc, bc_len, __start_cv_f32,
                             f2u(AS[i]), f2u(BS[i]), &got_bits);
            uint64_t want_bits = f2u(ref_f32(AS[i], BS[i]));
            if (rc == 0 && got_bits == want_bits) pass++;
            else { fail++; printf("  F32 MISMATCH a=%.6g b=%.6g rc=%d gotbits=0x%llX wantbits=0x%llX\n",
                    AS[i], BS[i], rc, (unsigned long long)got_bits,
                    (unsigned long long)want_bits); }
        }
        printf("  SSE-F32: %s %d/7 逐位一致\n", fail ? "FAIL" : "PASS", pass);
        if (fail) bad |= 128;
    }
    csvm_free(bc); bc = NULL;

done:
    (void)err;
    printf("[coverage] RESULT=%s\n", bad == 0 ? "PASS" : "FAIL");
    return bad == 0 ? 0 : 1;
}
