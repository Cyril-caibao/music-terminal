/* CyrilShield 第九批 —— Linux（ELF）程序加固入口的运行时侧
 *
 * 用法（由 cyrilshield/vmp/protect_elf.py 生成 payload 后）：
 *     LD_PRELOAD=libcsvm_elfhook.so CSVM_ELF_PAYLOAD=prog.csvmpayload ./prog
 *
 * 工作方式：
 *   1) 本 .so 的构造函数在 main 之前跑：读 payload（每个目标函数的 RVA +
 *      已编译好的 v5 私有 ISA 字节码），通过 dl_iterate_phdr 找到主程序基址；
 *   2) 在主程序 ±2GB 内 mmap 一页执行页，为每个目标函数写 13 字节 stub
 *      （movabs r10, meta; jmp r10 —— r10 是调用者保存寄存器，不作为参数）；
 *   3) 把目标函数入口 5 字节改成 E9 rel32 -> stub（有 endbr64 时保留它，从 +4 开始改）；
 *   4) 目标函数被调用时进 stub -> 共享 trampoline（16 GPR + FLAGS 全量保存）
 *      -> C 侧 csvm_run_host 以「函数真实地址」为 runtime_base 执行 VM
 *      -> 恢复寄存器并 ret。
 *
 * 与 PE 集成器的差异（诚实标注）：PE 是把 stub 和 .csvm 节区写进同一个映像；
 * 这里是「运行时挂钩」——原文件一个字节都不改，靠 LD_PRELOAD 在进程里改函数头。
 * 好处是不需要重写 ELF 程序头/节表；代价是必须有符号（或显式 RVA）且目标函数
 * 入口 5 字节内没有别的跳转落点。
 *
 * 明确不做：AMSI/ETW 补丁、进程注入、驱动、反 EDR。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#include "cs_codevm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <link.h>
#include <sys/mman.h>
#include <unistd.h>
#include <errno.h>

#define CSVM_ELF_MAGIC "CSVMELF1"

typedef struct {
    uint64_t        fn_off;       /* 相对主程序基址的 RVA */
    uint32_t        bc_len;
    uint32_t        flags;
    const uint8_t  *bc;           /* 指向 payload 内已编译的 v5 字节码 */
    uintptr_t       fn_addr;      /* 运行期真实地址 */
    uint64_t        calls;
    int             patched;      /* 0=未改 1=已改函数头 */
    unsigned char  *stub;         /* 该函数专属 stub 地址 */
} elf_meta_t;

static elf_meta_t *g_meta = NULL;
static size_t      g_nmeta = 0;
static const char *g_payload_path = NULL;
static uintptr_t   g_base = 0;
static unsigned char *g_stub_page = NULL;
static int         g_ready = 0;
static int         g_debug = 0;

/* ---------- payload 解析 ---------- */
static int load_payload(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "[csvm-elf] 打不开 payload：%s\n", path);
        return -1;
    }
    unsigned char hdr[12];
    if (fread(hdr, 1, 12, f) != 12 || memcmp(hdr, CSVM_ELF_MAGIC, 8) != 0) {
        fprintf(stderr, "[csvm-elf] payload 魔数不对\n");
        fclose(f);
        return -1;
    }
    uint32_t n = (uint32_t)hdr[8] | ((uint32_t)hdr[9] << 8) |
                 ((uint32_t)hdr[10] << 16) | ((uint32_t)hdr[11] << 24);
    if (n == 0 || n > 256) {
        fprintf(stderr, "[csvm-elf] 函数数非法：%u\n", n);
        fclose(f);
        return -1;
    }
    elf_meta_t *m = (elf_meta_t *)calloc(n, sizeof(*m));
    if (!m) { fclose(f); return -1; }
    for (uint32_t i = 0; i < n; ++i) {
        unsigned char e[16];
        if (fread(e, 1, 16, f) != 16) { fclose(f); free(m); return -1; }
        m[i].fn_off = (uint64_t)e[0] | ((uint64_t)e[1] << 8) | ((uint64_t)e[2] << 16) |
                      ((uint64_t)e[3] << 24) | ((uint64_t)e[4] << 32) |
                      ((uint64_t)e[5] << 40) | ((uint64_t)e[6] << 48) |
                      ((uint64_t)e[7] << 56);
        m[i].bc_len = (uint32_t)e[8] | ((uint32_t)e[9] << 8) |
                      ((uint32_t)e[10] << 16) | ((uint32_t)e[11] << 24);
        m[i].flags  = (uint32_t)e[12] | ((uint32_t)e[13] << 8) |
                      ((uint32_t)e[14] << 16) | ((uint32_t)e[15] << 24);
        m[i].calls = 0;
    }
    /* 所有字节码按顺序紧跟头部 */
    for (uint32_t i = 0; i < n; ++i) {
        unsigned char *blob = (unsigned char *)malloc(m[i].bc_len ? m[i].bc_len : 1);
        if (!blob || fread(blob, 1, m[i].bc_len, f) != m[i].bc_len) {
            fprintf(stderr, "[csvm-elf] 字节码被截断（第 %u 个）\n", i + 1);
            fclose(f); free(m); return -1;
        }
        m[i].bc = blob;
    }
    fclose(f);
    g_meta = m;
    g_nmeta = n;
    return 0;
}

/* ---------- 找主程序基址 ---------- */
struct base_ctx { uintptr_t base; int found; };
static int base_cb(struct dl_phdr_info *info, size_t sz, void *data) {
    (void)sz;
    struct base_ctx *c = (struct base_ctx *)data;
    if (info->dlpi_name == NULL || info->dlpi_name[0] == '\0') {
        c->base = (uintptr_t)info->dlpi_addr;
        c->found = 1;
        return 1;
    }
    return 0;
}
static uintptr_t main_base(void) {
    struct base_ctx c = { 0, 0 };
    dl_iterate_phdr(base_cb, &c);
    return c.base;
}

/* ---------- 在基址附近拿一页可执行内存 ---------- */
static unsigned char *map_near(uintptr_t base, size_t len) {
    static const long deltas[] = {
        0x08000000L, 0x10000000L, 0x18000000L, 0x20000000L, 0x30000000L,
        -0x08000000L, -0x10000000L, -0x18000000L, -0x20000000L
    };
    for (size_t i = 0; i < sizeof(deltas) / sizeof(deltas[0]); ++i) {
        uintptr_t hint = (uintptr_t)((long)base + deltas[i]);
        void *p = mmap((void *)hint, len, PROT_READ | PROT_WRITE | PROT_EXEC,
                       MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
        if (p != MAP_FAILED) return (unsigned char *)p;
    }
    void *p = mmap(NULL, len, PROT_READ | PROT_WRITE | PROT_EXEC,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) return NULL;
    /* 兜底：地址可能与主程序差 2GB 以上，此时 rel32 不可达，调用方会拒绝 */
    return (unsigned char *)p;
}

/* ---------- 共享 trampoline 用的 C 桥 ---------- */
uint64_t csvm_elf_enter(elf_meta_t *m, uint64_t *slots) {
    uint64_t rin[16], rout[16];
    char err[CSVM_ERR_CAP];
    memset(err, 0, sizeof(err));
    memcpy(rin, slots, sizeof(rin));
    memset(rout, 0, sizeof(rout));
    int rc = csvm_run_host(m->bc, m->bc_len, rin, rout,
                           (uint64_t)m->fn_addr, NULL, NULL, err, sizeof(err));
    if (g_debug && m->calls < 3)
        fprintf(stderr, "[csvm-elf] 入参 rdi=%llu rsi=%llu\n",
                (unsigned long long)slots[7], (unsigned long long)slots[6]);
    m->calls++;
    if (rc != 0) {
        static int warned = 0;
        if (!warned || g_debug) {
            warned = 1;
            fprintf(stderr, "[csvm-elf] VM 执行失败 rc=%d：%s（函数 RVA 0x%llx）\n",
                    rc, err, (unsigned long long)m->fn_off);
        }
        return slots[0];
    }
    memcpy(slots, rout, sizeof(rout));
    if (g_debug)
        fprintf(stderr, "[csvm-elf] VM 第 %llu 次调用，RVA 0x%llx → RAX=0x%llx\n",
                (unsigned long long)m->calls, (unsigned long long)m->fn_off,
                (unsigned long long)rout[0]);
    return rout[0];
}

/* 共享 trampoline：16 GPR + FLAGS 全量保存 -> C 桥 -> 全量恢复 -> ret。
   进入时 r10 = 该函数的 elf_meta_t*（stub 用 movabs 放进去的）。 */
__asm__(
".text\n"
".globl csvm_elf_trampoline\n"
".hidden csvm_elf_trampoline\n"
".type csvm_elf_trampoline,@function\n"
"csvm_elf_trampoline:\n"
"    subq $152, %rsp\n"
"    movq %rax,   0(%rsp)\n"
"    movq %rcx,   8(%rsp)\n"
"    movq %rdx,  16(%rsp)\n"
"    movq %rbx,  24(%rsp)\n"
"    leaq 152(%rsp), %rax\n"
"    movq %rax,  32(%rsp)\n"
"    movq %rbp,  40(%rsp)\n"
"    movq %rsi,  48(%rsp)\n"
"    movq %rdi,  56(%rsp)\n"
"    movq %r8,   64(%rsp)\n"
"    movq %r9,   72(%rsp)\n"
"    movq %r10,  80(%rsp)\n"
"    movq %r11,  88(%rsp)\n"
"    movq %r12,  96(%rsp)\n"
"    movq %r13, 104(%rsp)\n"
"    movq %r14, 112(%rsp)\n"
"    movq %r15, 120(%rsp)\n"
"    pushfq\n"
"    popq %rax\n"
"    movq %rax, 128(%rsp)\n"
"    movq  80(%rsp), %rdi\n"        /* rdi = meta */
"    movq %rsp, %rsi\n"             /* rsi = slots */
"    call csvm_elf_enter@PLT\n"
"    movq %rax, 136(%rsp)\n"
"    movq 128(%rsp), %rax\n"
"    pushq %rax\n"
"    popfq\n"
"    movq   8(%rsp), %rcx\n"
"    movq  16(%rsp), %rdx\n"
"    movq  24(%rsp), %rbx\n"
"    movq  40(%rsp), %rbp\n"
"    movq  48(%rsp), %rsi\n"
"    movq  56(%rsp), %rdi\n"
"    movq  64(%rsp), %r8\n"
"    movq  72(%rsp), %r9\n"
"    movq  80(%rsp), %r10\n"
"    movq  88(%rsp), %r11\n"
"    movq  96(%rsp), %r12\n"
"    movq 104(%rsp), %r13\n"
"    movq 112(%rsp), %r14\n"
"    movq 120(%rsp), %r15\n"
"    movq 136(%rsp), %rax\n"
"    addq $152, %rsp\n"
"    ret\n"
".size csvm_elf_trampoline,.-csvm_elf_trampoline\n"
);
extern void csvm_elf_trampoline(void);

/* ---------- 改一个函数头 ---------- */
static int patch_one(elf_meta_t *m) {
    uintptr_t fn = g_base + (uintptr_t)m->fn_off;
    unsigned char *stub = m->stub;
    /* stub（23 字节，全在 32 字节槽内）：
         movabs r10, meta_ptr      ; 49 BA imm64
         movabs r11, trampoline    ; 49 BB imm64
         jmp    r11                ; 41 FF E3
       r10 / r11 都是调用者保存寄存器、不是参数寄存器（参数是 rdi/rsi/rdx/rcx/r8/r9），
       目标函数的机器码不会依赖它们入参时的值，因此可以安全借用。 */
    static const uint64_t tramp = (uint64_t)(uintptr_t)&csvm_elf_trampoline;
    uint64_t meta_addr = (uint64_t)(uintptr_t)m;
    stub[0] = 0x49; stub[1] = 0xBA;
    for (int i = 0; i < 8; ++i) stub[2 + i] = (unsigned char)(meta_addr >> (8 * i));
    stub[10] = 0x49; stub[11] = 0xBB;
    for (int i = 0; i < 8; ++i) stub[12 + i] = (unsigned char)(tramp >> (8 * i));
    stub[20] = 0x41; stub[21] = 0xFF; stub[22] = 0xE3;

    /* 有 endbr64 就保留（间接调用仍合法），从 +4 开始改 */
    int skip = 0;
    if (m->flags & 1u) skip = 4;

    size_t pagesz = (size_t)sysconf(_SC_PAGESIZE);
    uintptr_t page = (fn + (uintptr_t)skip) & ~(uintptr_t)(pagesz - 1);
    if (mprotect((void *)page, pagesz * 2, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        fprintf(stderr, "[csvm-elf] mprotect 失败（RVA 0x%llx）：%s\n",
                (unsigned long long)m->fn_off, strerror(errno));
        return -1;
    }
    long rel = (long)((intptr_t)stub - (intptr_t)(fn + (uintptr_t)skip + 5));
    if (rel > 0x7FFFFFFFL || rel < -0x80000000L) {
        fprintf(stderr, "[csvm-elf] stub 距目标函数超出 ±2GB，放弃该函数（RVA 0x%llx）\n",
                (unsigned long long)m->fn_off);
        mprotect((void *)page, pagesz * 2, PROT_READ | PROT_EXEC);
        return -1;
    }
    unsigned char *p = (unsigned char *)(fn + (uintptr_t)skip);
    p[0] = 0xE9;
    p[1] = (unsigned char)((rel >> 0) & 0xFF);
    p[2] = (unsigned char)((rel >> 8) & 0xFF);
    p[3] = (unsigned char)((rel >> 16) & 0xFF);
    p[4] = (unsigned char)((rel >> 24) & 0xFF);
    mprotect((void *)page, pagesz * 2, PROT_READ | PROT_EXEC);
    __builtin___clear_cache(p, p + 5);
    m->fn_addr = fn;
    m->patched = 1;
    return 0;
}

static void csvm_elf_init(void) __attribute__((constructor));
static void csvm_elf_init(void) {
    g_payload_path = getenv("CSVM_ELF_PAYLOAD");
    if (!g_payload_path || !*g_payload_path) return;
    g_debug = getenv("CSVM_ELF_DEBUG") != NULL;
    if (load_payload(g_payload_path) != 0) return;
    g_base = main_base();

    size_t pagesz = (size_t)sysconf(_SC_PAGESIZE);
    size_t need = (g_nmeta * 32 + 4095) / 4096 * 4096;
    if (need < pagesz) need = pagesz;
    g_stub_page = map_near(g_base, need);
    if (!g_stub_page) {
        fprintf(stderr, "[csvm-elf] 分配 stub 页失败\n");
        return;
    }
    /* 每个 stub 自带 trampoline 的绝对地址，因此不依赖 .so 与 stub 页的距离 */
    int ok = 0;
    for (size_t i = 0; i < g_nmeta; ++i) {
        g_meta[i].stub = g_stub_page + i * 32;
        if (patch_one(&g_meta[i]) == 0) ok++;
    }
    g_ready = ok > 0;
    if (g_debug)
        fprintf(stderr, "[csvm-elf] 主程序基址 0x%lx，stub 页 %p，已挂钩 %d/%zu 个函数\n",
                (unsigned long)g_base, (void *)g_stub_page, ok, g_nmeta);
}

/* payload 里没指定入口时也允许手工查询：环境变量 CSVM_ELF_DUMP=1 打印状态 */
static void csvm_elf_fini(void) __attribute__((destructor));
static void csvm_elf_fini(void) {
    if (!g_meta) return;
    if (g_debug || getenv("CSVM_ELF_DUMP")) {
        for (size_t i = 0; i < g_nmeta; ++i)
            fprintf(stderr, "[csvm-elf] RVA 0x%llx：VM 调用 %llu 次，%s\n",
                    (unsigned long long)g_meta[i].fn_off,
                    (unsigned long long)g_meta[i].calls,
                    g_meta[i].patched ? "已挂钩" : "未挂钩");
    }
}
