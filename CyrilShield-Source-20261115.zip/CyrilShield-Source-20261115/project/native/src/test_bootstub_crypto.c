/* bootstub 密码学交叉验证：C 实现输出与 Python hashlib 比对 */
#define wWinMain bootstub_wWinMain_disabled
#include "bootstub.c"
#undef wWinMain

#include <inttypes.h>

static void hex(const uint8_t *p, size_t n) {
    for (size_t i = 0; i < n; i++) printf("%02x", p[i]);
    printf("\n");
}

int main(void) {
    /* SHA-256 向量 */
    uint8_t d[32];
    cs_sha256("abc", 3, d);
    printf("SHA256-abc ");
    hex(d, 32);
    cs_sha256("The quick brown fox jumps over the lazy dog", 43, d);
    printf("SHA256-fox ");
    hex(d, 32);

    /* SHAKE256 向量（模拟 keystream 种子结构） */
    uint8_t ks[64], seed[64];
    size_t sl = 0;
    memcpy(seed + sl, "0123456789abcdef0123456789abcdef", 32); sl += 32;  /* key */
    memcpy(seed + sl, "SALTsaltSALTsalt", 16); sl += 16;                      /* salt */
    memcpy(seed + sl, "M", 1); sl += 1;                                       /* tag */
    for (int i = 0; i < 8; i++) seed[sl + i] = (uint8_t)i; sl += 8;           /* ctr LE */
    cs_shake256(seed, sl, ks, 64);
    printf("SHAKE256-M0 ");
    hex(ks, 64);
    /* 长输出跨块挤出 */
    uint8_t big[300];
    cs_shake256(seed, sl, big, 300);
    printf("SHAKE256-300 ");
    hex(big + 256, 44);
    /* 空 keystream（n=0 场景靠调用方保护，这里验证短输出） */
    cs_shake256("x", 1, ks, 3);
    printf("SHAKE256-x3 ");
    hex(ks, 3);
    return 0;
}
