#pragma once
#include <stddef.h>
#include <stdarg.h>
int _vsnprintf(char *buf, size_t n, const char *fmt, va_list ap);
int _snprintf(char *buf, size_t n, const char *fmt, ...);
#define vsnprintf _vsnprintf
#define snprintf  _snprintf
