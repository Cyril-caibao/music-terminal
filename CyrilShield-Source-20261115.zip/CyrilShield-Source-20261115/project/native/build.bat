@echo off
chcp 65001 >nul
setlocal
set "ROOT=%~dp0"
set "OUT=%ROOT%out"
if not exist "%OUT%" mkdir "%OUT%"

rem 工具链说明（重要，别虚标）：
rem   codevm.c 用 __int128 实现 128 位乘除，用 GNU 内联 asm 实现 sqrtss/sqrtsd；
rem   exit_trampoline.c 是文件级 GNU asm 上下文切换桩。原版 MSVC cl 不支持
rem   __int128，也不支持 GNU asm，无法编译本内核。因此本脚本只走 MinGW-w64
rem   gcc（与 Linux build.sh 同构）。需要纯 MSVC COFF 产物请在 Linux / WSL
rem   跑 build-win.sh（clang + lld-link 交叉，已在沙箱验证，导出 13 个 csvm_*）。
rem   检测到只有 cl、没有 gcc 时会明确报错，不做「能编但能力降级」的假象。
rem   peintegrate.c 是纯标准 C11，任何 C 编译器都能编。

where gcc >nul 2>&1
if errorlevel 1 (
  echo 未找到 MinGW-w64 gcc。
  echo   - 安装 MinGW-w64 并把 gcc 加入 PATH 后重跑本脚本；或
  echo   - 在 Linux / WSL 里跑 build-win.sh 交叉产出 CyrilShield.CodeVM.dll。
  echo 原版 MSVC cl 无法编译本内核（__int128 + GNU asm），不再尝试。
  exit /b 1
)

echo [工具链] MinGW-w64 gcc

echo [1/4] CyrilShield.Native.dll  硬件侧载层
gcc -std=c11 -O2 -Wall -Wextra -D_GNU_SOURCE -shared -I"%ROOT%include" ^
    "%ROOT%src\sidecar.c" -o "%OUT%\CyrilShield.Native.dll" || goto :fail

echo [2/4] CyrilShield.CodeVM.dll  代码虚拟化内核 + L2 VM-exit 桩
rem codevm.c 强引用 csvm_default_exit，必须把 exit_trampoline.c 一起编进来；
rem 不定义 CSVM_NO_CRT —— MinGW 链接完整 CRT，_fltused 由 CRT 提供。
gcc -std=c11 -O2 -Wall -Wextra -D_GNU_SOURCE -shared -I"%ROOT%include" ^
    "%ROOT%src\codevm.c" "%ROOT%src\exit_trampoline.c" ^
    -o "%OUT%\CyrilShield.CodeVM.dll" || goto :fail

echo [3/4] csvm.exe  命令行工具（自包含内核，便于离线调试）
gcc -std=c11 -O2 -Wall -Wextra -D_GNU_SOURCE -I"%ROOT%include" ^
    "%ROOT%src\codevm.c" "%ROOT%src\exit_trampoline.c" "%ROOT%src\codevm_main.c" ^
    -o "%OUT%\csvm.exe" || goto :fail

echo [4/5] peintegrate.exe  PE 集成器（纯 C11，Windows 侧改写目标 PE）
gcc -std=c11 -O2 -Wall -Wextra -I"%ROOT%include" ^
    "%ROOT%src\peintegrate.c" -o "%OUT%\peintegrate.exe" || goto :fail

echo [5/5] win_thread_demo.exe  第十批 Windows 多线程上下文自测（TLS 池 + VEH）
gcc -std=c11 -O2 -Wall -Wextra -I"%ROOT%include" ^
    "%ROOT%src\win_thread_demo.c" -L"%OUT%" -lCyrilShield.CodeVM ^
    -o "%OUT%\win_thread_demo.exe" || goto :fail

echo.
echo 完成：%OUT%
echo   CyrilShield.Native.dll   硬件侧载层
echo   CyrilShield.CodeVM.dll   代码虚拟化内核 + exit_trampoline.c（Python 侧自动加载）
echo   csvm.exe                 命令行工具
echo   peintegrate.exe          PE 集成器（vmp\integration.py 在 Windows 上查找此文件）
echo.
echo 请把两个 DLL 与 peintegrate.exe 放在 main.py 同目录，Python 侧会自动加载并校验摘要。
echo 自检：python selftest_codevm.py   /   python selftest_integration.py
echo   Windows 多线程上下文：out\win_thread_demo.exe（期望最后一行 RESULT=PASS）
endlocal
exit /b 0

:fail
echo 构建失败。
endlocal
exit /b 1
