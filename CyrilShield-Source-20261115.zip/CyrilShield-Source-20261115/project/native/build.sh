#!/usr/bin/env bash
# 构建原生层（开发/自检用）。Windows 目标请用 build.bat 或 build-win.sh。
# 产出：
#   out/libcyrilshield_native.so   硬件侧载层
#   out/libcyrilshield_codevm.so   代码虚拟化 C 内核（真·目标机器码 -> 私有 ISA）
#                                  + L2 VM-exit 汇编上下文切换桩
#   out/csvm                       同 ABI 的命令行工具
#   out/peintegrate                PE 集成器（新节区 + 函数头改写）
#   out/hotpatch_demo              ELF 函数头 hotpatch 集成验证
#   out/pe_stub_verify             在 Linux 上真实执行 PE stub
#   out/exit_demo                  L2 VM-exit 桥：真实函数调外部 API 冷启动验证
#   out/coverage_demo              FF/4 间接跳转 + 标量 SSE 冷启动验证
#   out/v5_demo                    第八批：FPU VM-exit / TAILEXIT / CFG 多段 /
#                                 REP 字符串 / v5 加密容器端到端验证
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/out"
mkdir -p "$OUT"
CC_BIN="${CC:-cc}"
CFLAGS="-std=c11 -O2 -Wall -Wextra -D_GNU_SOURCE -I$ROOT/include"

echo "[1/11] 硬件侧载层 libcyrilshield_native.so"
$CC_BIN $CFLAGS -fPIC -fvisibility=hidden -shared \
    "$ROOT/src/sidecar.c" -o "$OUT/libcyrilshield_native.so" -ldl

echo "[2/11] 代码虚拟化内核 + L2 VM-exit 桩 libcyrilshield_codevm.so"
$CC_BIN $CFLAGS -fPIC -fvisibility=hidden -shared \
    "$ROOT/src/codevm.c" "$ROOT/src/exit_trampoline.c" \
    -o "$OUT/libcyrilshield_codevm.so"

echo "[3/11] csvm 命令行工具"
$CC_BIN $CFLAGS "$ROOT/src/codevm_main.c" \
    -L"$OUT" -lcyrilshield_codevm -Wl,-rpath,"$OUT" -o "$OUT/csvm"

echo "[4/11] PE 集成器 peintegrate"
$CC_BIN $CFLAGS "$ROOT/src/peintegrate.c" -o "$OUT/peintegrate"

echo "[5/11] ELF hotpatch 集成验证 hotpatch_demo"
$CC_BIN $CFLAGS -fPIE -pie -fcf-protection=none \
    "$ROOT/src/hotpatch_demo.c" -L"$OUT" -lcyrilshield_codevm \
    -Wl,-rpath,"$OUT" -o "$OUT/hotpatch_demo"

echo "[6/11] PE stub 执行验证 pe_stub_verify"
$CC_BIN $CFLAGS -fPIE -pie "$ROOT/src/pe_stub_verify.c" \
    -L"$OUT" -lcyrilshield_codevm -Wl,-rpath,"$OUT" -o "$OUT/pe_stub_verify"

echo "[7/11] L2 VM-exit 桥验证 exit_demo"
$CC_BIN $CFLAGS -fPIE -pie -fcf-protection=none \
    "$ROOT/src/exit_demo.c" -L"$OUT" -lcyrilshield_codevm \
    -Wl,-rpath,"$OUT" -o "$OUT/exit_demo"

echo "[8/11] FF/4 间接跳转 + 标量 SSE 验证 coverage_demo"
$CC_BIN $CFLAGS -fPIE -pie -fcf-protection=none \
    "$ROOT/src/coverage_demo.c" -L"$OUT" -lcyrilshield_codevm \
    -Wl,-rpath,"$OUT" -o "$OUT/coverage_demo"

echo "[9/11] 第八批 v5 端到端验证 v5_demo（FPU/TAILEXIT/CFG/REP/容器）"
$CC_BIN $CFLAGS -fPIE -pie -fcf-protection=none \
    "$ROOT/src/v5_demo.c" -L"$OUT" -lcyrilshield_codevm \
    -Wl,-rpath,"$OUT" -o "$OUT/v5_demo" -lm

echo "[10/12] 第九批 Linux 加固入口运行时 libcsvm_elfhook.so"
$CC_BIN $CFLAGS -fPIC -fvisibility=hidden -shared -rdynamic \
    "$ROOT/src/elf_hook.c" -L"$OUT" -lcyrilshield_codevm \
    -Wl,-rpath,"$OUT" -o "$OUT/libcsvm_elfhook.so" -ldl

echo "[11/12] 第九批 多线程 VM 上下文验证 thread_demo"
$CC_BIN $CFLAGS -fPIE -pie -fcf-protection=none -pthread \
    "$ROOT/src/thread_demo.c" -L"$OUT" -lcyrilshield_codevm \
    -Wl,-rpath,"$OUT" -o "$OUT/thread_demo"

echo "[12/12] 校验导出符号"
if command -v nm >/dev/null 2>&1; then
  nm -D --defined-only "$OUT/libcyrilshield_codevm.so" | grep -E "csvm_(compile|compile_cfg|run|run_host|run_host_ex|run_host_fpu|enter|disasm|stats)" || true
  nm "$OUT/libcyrilshield_codevm.so" | grep -E "csvm_default_exit" || true
  nm -D --defined-only "$OUT/libcyrilshield_native.so" | grep -E "csn_(abi_version|probe_hwid|self_digest)" || true
fi
echo "完成：$OUT"
