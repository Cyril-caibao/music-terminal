/* CyrilShield CodeVM — v5 字节码容器（第八批：抗提取）
 *
 * 设计目标（对应用户「抗提取 0 分」评审）：
 *   1) 变长：每条指令独立编码、随机 padding，磁盘上不再有 40B 定长步长；
 *   2) 加密：指令体按「字节绝对偏移」派生的 keystream 逐字节 XOR，明文不落盘；
 *   3) 按需解密：装载时只解出 meta/索引表，指令体在执行到该 pc 时才解密到
 *      栈上临时 bc_t，用完 sec_zero 擦除；
 *   4) 逐块完整性：每条记录带 rec_mac（绑定 pc，防篡改 / 防重排 / 防复制），
 *      meta/索引表由 hdr_mac 保护；不再用「整体 CRC」；
 *   5) 密钥分片：keystream 混入编译期常量 CSVM_KS_CONST（在运行时 DLL 代码里，
 *      不随 .csvm 段落盘），只 dump 数据段无法直接还原。
 *
 * 诚实边界：这仍是**对称混淆**，不是密码学保密——有 DLL 就能拿到常量，
 * 有 seed 就能重放 keystream。它抬高的是「静态 dump → 直接喂自带反编译器 →
 * 拿到完整 IR 清单」这条路的成本；真正强度还要靠去导出（发布版 DLL 不带
 * csvm_disasm/compile）+ handler 间接分派 + 后续白盒。见 docs/CODE-VM.md 第 8 节。
 *
 * 内存表示（codevm.c 的 compile_ir / run_blob 仍用）保持不变：
 *   [ bc_hdr_t 576B ][ bc_t[n] 40B each ]
 * 磁盘表示（本文件产出）与之不同，靠 v5_seal / v5_open / v5_fetch 转换。
 *
 * 零第三方依赖，C11；static 函数，被 codevm.c 单编译单元 #include。
 */
#ifndef CSVM_CONTAINER_H
#define CSVM_CONTAINER_H

#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* ------------------------------------------------------------ 内存表示 ---- */
/* bc_hdr_t(576B) / bc_t(40B) 在此**唯一定义**，codevm.c 直接 include 本头，
   不再自行定义，避免两处布局漂移。改变布局 = 破坏性 ABI 变更，必须 bump magic。
   bc_t.rep_kind 复用第七批的 pad[1] 字节（IR_REP 子类型），布局仍是 40B。 */
#pragma pack(push, 1)
typedef struct {
    uint8_t  magic[8];
    uint32_t version, n_insn, n_ir, n_junk;
    uint64_t seed, imm_mask;
    uint8_t  opc_map[256];
    uint8_t  dec_map[256];
    uint8_t  reg_map[16];
    uint32_t crc;
    uint32_t reserved;
} bc_hdr_t;

typedef struct {
    uint8_t  opc;
    uint8_t  a_kind, a_reg, b_kind, b_reg, c_kind, c_reg;
    uint8_t  cc, width;
    uint8_t  src_width;
    uint8_t  exit_kind;      /* CALLEXT/JMPI 目标类型；IR_FSSE 时存 FOP_* */
    uint8_t  rep_kind;       /* IR_REP 子类型（原第七批 pad[1]） */
    uint32_t next_off;       /* 指令末尾的 RVA（RIP 相对用） */
    uint32_t src_off;        /* 指令起始的 RVA（IR_JMPI 回填 / CFG 用） */
    uint32_t pad2;
    int64_t  imm;
    int64_t  disp;
} bc_t;

/* 磁盘明文头（磁盘上这些字段是明文，其余全密文） */
typedef struct {
    uint8_t  magic[8];       /* "CSVM\x06\0\0\0" */
    uint32_t version;        /* 3 */
    uint32_t flags;          /* BC_FLAG_* */
    uint32_t total_size;     /* 整个 blob 字节数 */
    uint32_t enc_off;        /* 加密区起始（= sizeof(csvm_file_hdr_t) 对齐到 16） */
    uint32_t enc_size;       /* 加密区长度 */
    uint32_t n_insn;
    uint32_t n_ir;
    uint32_t n_junk;
    uint64_t seed;
    uint32_t hdr_mac;        /* 保护本头(除本字段) + meta + 两张索引表的密文 */
    uint8_t  salt[16];
    uint8_t  reserved[24];
} csvm_file_hdr_t;
#pragma pack(pop)
_Static_assert(sizeof(bc_t) == 40, "bc_t must be 40 bytes");
_Static_assert(sizeof(bc_hdr_t) == 576, "bc_hdr_t must be 576 bytes");
_Static_assert(sizeof(csvm_file_hdr_t) == 92, "csvm_file_hdr_t must be 92 bytes");

/* 字节码能力标志（只写进 csvm_file_hdr_t.flags；运行时从 oc->fh.flags 读，
   bc_hdr_t.reserved 专用于 clen/RVA 跨度，二者互不干扰） */
#define BC_FLAG_ENCRYPTED   (1u << 0)
#define BC_FLAG_FPU_EXIT    (1u << 1)  /* 含「浮点参数/返回跨 VM-exit」的外部调用 */
#define BC_FLAG_CFG         (1u << 2)  /* 多段 CFG 闭包编译产物 */
#define BC_FLAG_NEED_FPU    (1u << 3)  /* 只能用带 XMM 通道的入口执行 */
#define BC_FLAG_REP         (1u << 4)  /* 含字符串指令 */
#define BC_FLAG_TAILEXIT    (1u << 5)  /* 含直接尾调用 -> VM-exit tail */

/* keystream 混入的编译期常量（只存在于 DLL/.so 代码里，不落 .csvm 段）。
   每次交付可改，改变后旧字节码整体作废。 */
#define CSVM_KS_CONST  0xC391A7E15B0D42F9ULL

/* ------------------------------------------------------------ 小工具 ---- */
static void csvm_sec_zero(void *p, size_t n) {
    volatile uint8_t *q = (volatile uint8_t *)p;
    while (n--) *q++ = 0;
}

/* 按「8 字节绝对偏移块」派生 64 位 keystream，可随机访问任意 offset */
static uint64_t csvm_ks64(uint64_t seed, const uint8_t salt[16], uint64_t off) {
    uint64_t s0, s1;
    memcpy(&s0, salt, 8);
    memcpy(&s1, salt + 8, 8);
    uint64_t blk = off >> 3;
    uint64_t k = seed ^ CSVM_KS_CONST ^ (blk * 0x9E3779B97F4A7C15ULL)
                 ^ s0 ^ (s1 * 0xBF58476D1CE4E5B9ULL);
    k += 0x9E3779B97F4A7C15ULL;
    k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ULL;
    k = (k ^ (k >> 27)) * 0x94D049BB133111EBULL;
    return k ^ (k >> 31);
}
static void csvm_xor_stream(uint8_t *p, size_t n, uint64_t seed,
                            const uint8_t salt[16], uint64_t abs_off) {
    for (size_t i = 0; i < n; ++i) {
        uint64_t o = abs_off + i;
        uint64_t k = csvm_ks64(seed, salt, o);
        p[i] ^= (uint8_t)(k >> ((o & 7) * 8));
    }
}
static uint32_t csvm_fnv(const uint8_t *p, size_t n, uint32_t h) {
    for (size_t i = 0; i < n; ++i) { h ^= p[i]; h *= 0x01000193u; }
    return h;
}
/* 记录 MAC：绑定 seed + pc + 内容，防重排 / 复制 / 篡改 */
static uint32_t csvm_rec_mac(uint64_t seed, const uint8_t salt[16],
                             uint32_t pc, const uint8_t *p, size_t n) {
    uint32_t h = 0x811c9dc5u ^ (uint32_t)(seed ^ (seed >> 32)) ^ (pc * 0x9E3779B9u);
    h = csvm_fnv(p, n, h);
    return csvm_fnv(salt, 16, h) ^ (uint32_t)(seed >> 17);
}

/* 可复现的 keystream PRNG（仅用于 padding 字节，不影响语义） */
static uint64_t csvm_pad_rand(uint64_t *s) {
    uint64_t x = (*s += 0x9E3779B97F4A7C15ULL);
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}

/* ------------------------------------------------------------ 装载上下文 ---- */
typedef struct {
    const uint8_t *blob;        /* 磁盘 blob（外部持有，不复制） */
    size_t         blob_len;
    csvm_file_hdr_t fh;
    bc_hdr_t       h;           /* 解密出的 meta（用完擦除） */
    uint32_t      *rec_off;     /* n_insn 条记录相对 enc 区起始的偏移 */
    uint32_t      *src_off;     /* n_insn 条指令的 src_off（IR_JMPI 回填用） */
    uint32_t       rec_base;    /* 记录流相对 enc 区起始的偏移 */
} csvm_open_t;

/* ------------------------------------------------------------ seal ---- */
/* 输入：内存 blob = [bc_hdr_t][bc_t[n]]；输出：v5 加密变长磁盘 blob。
   flags 由编译器根据 IR 分析结果传入。返回 0 成功，<0 失败。 */
static int csvm_v5_seal(const uint8_t *mem, size_t mem_len, uint64_t seed,
                        uint32_t flags, uint8_t **out, size_t *out_len) {
    *out = NULL; *out_len = 0;
    if (!mem || mem_len < sizeof(bc_hdr_t) + sizeof(bc_t)) return -1;
    bc_hdr_t h; memcpy(&h, mem, sizeof(h));
    const bc_t *bc = (const bc_t *)(const void *)(mem + sizeof(bc_hdr_t));
    uint32_t n = h.n_insn;
    if (!n || (size_t)n > (1u << 20)) return -2;
    if (mem_len < sizeof(bc_hdr_t) + (size_t)n * sizeof(bc_t)) return -3;

    /* 加密区布局：[meta 576B][rec_off 4n][src_off 4n][记录流] */
    uint32_t idx_bytes = 8u * n;
    uint32_t enc_head = (uint32_t)sizeof(bc_hdr_t) + idx_bytes;
    /* 每条记录：[vlen:u8][padpre:u8][padpost:u8][padpre + vlen + padpost 字节][mac:u32]
       先算总长 */
    uint64_t pr = seed ^ 0x5DEECE66DULL ^ CSVM_KS_CONST;
    uint32_t *vlen = (uint32_t *)malloc(sizeof(uint32_t) * n);
    uint8_t  *ppre = (uint8_t *)malloc(n), *ppost = (uint8_t *)malloc(n);
    if (!vlen || !ppre || !ppost) { free(vlen); free(ppre); free(ppost); return -4; }
    size_t rec_total = 0;
    for (uint32_t i = 0; i < n; ++i) {
        const uint8_t *raw = (const uint8_t *)&bc[i];
        int last = -1;
        for (int k = (int)sizeof(bc_t) - 1; k >= 0; --k) if (raw[k]) { last = k; break; }
        uint32_t vl = (uint32_t)(last + 1);
        if (vl < 8) vl = 8;                       /* 至少含 opc/字段头 */
        vlen[i] = vl;
        ppre[i]  = (uint8_t)(csvm_pad_rand(&pr) & 7);
        ppost[i] = (uint8_t)(csvm_pad_rand(&pr) & 7);
        rec_total += 3u + ppre[i] + vl + ppost[i] + 4u;
    }
    size_t enc_size = (size_t)enc_head + rec_total;
    size_t enc_off  = (sizeof(csvm_file_hdr_t) + 15) & ~(size_t)15;
    size_t total    = enc_off + enc_size;

    uint8_t *blob = (uint8_t *)calloc(1, total);
    uint8_t *enc  = (uint8_t *)malloc(enc_size);
    if (!blob || !enc) { free(blob); free(enc); free(vlen); free(ppre); free(ppost); return -5; }

    csvm_file_hdr_t fh; memset(&fh, 0, sizeof(fh));
    memcpy(fh.magic, "CSVM\x06\0\0\0", 8);
    fh.version = 4; fh.flags = flags | BC_FLAG_ENCRYPTED;
    fh.total_size = (uint32_t)total;
    fh.enc_off = (uint32_t)enc_off; fh.enc_size = (uint32_t)enc_size;
    fh.n_insn = n; fh.n_ir = h.n_ir; fh.n_junk = h.n_junk; fh.seed = seed;
    for (int i = 0; i < 16; ++i) fh.salt[i] = (uint8_t)(csvm_pad_rand(&pr) >> (i * 3 & 56));

    /* meta：清掉 crc（v5 不用整体 CRC），写回 magic/version 供装载端复核。
       reserved 原样透传：它专供解释器作 clen / RVA 闭包跨度，绝不能塞 flag
       （flags 已单独存于 fh.flags，运行时从 oc->fh.flags 读取）。 */
    h.crc = 0;
    memcpy(h.magic, "CSVM\x06\0\0\0", 8);
    h.version = 4;
    memcpy(enc, &h, sizeof(h));
    uint32_t *ro = (uint32_t *)(void *)(enc + sizeof(bc_hdr_t));
    uint32_t *so = ro + n;
    uint32_t cur = enc_head;
    for (uint32_t i = 0; i < n; ++i) {
        ro[i] = cur;
        so[i] = bc[i].src_off;
        cur += 3u + ppre[i] + vlen[i] + ppost[i] + 4u;
    }
    /* 记录流 */
    for (uint32_t i = 0; i < n; ++i) {
        uint8_t *rec = enc + ro[i];
        uint32_t vl = vlen[i];
        rec[0] = (uint8_t)(vl > 255 ? 255 : vl);  /* vl<=40，恒 <=255 */
        rec[1] = ppre[i];
        rec[2] = ppost[i];
        uint8_t *body = rec + 3;
        for (uint32_t k = 0; k < ppre[i]; ++k) body[k] = (uint8_t)csvm_pad_rand(&pr);
        memcpy(body + ppre[i], &bc[i], vl);
        for (uint32_t k = 0; k < ppost[i]; ++k)
            body[ppre[i] + vl + k] = (uint8_t)csvm_pad_rand(&pr);
        uint32_t body_n = 3u + ppre[i] + vl + ppost[i];
        uint32_t mac = csvm_rec_mac(seed, fh.salt, i, rec, body_n);
        uint8_t m4[4]; m4[0] = (uint8_t)mac; m4[1] = (uint8_t)(mac >> 8);
        m4[2] = (uint8_t)(mac >> 16); m4[3] = (uint8_t)(mac >> 24);
        memcpy(rec + body_n, m4, 4);
    }
    /* 整段加密区按绝对偏移 XOR（meta/索引/记录一起） */
    csvm_xor_stream(enc, enc_size, seed, fh.salt, 0);
    memcpy(blob + enc_off, enc, enc_size);

    /* hdr_mac 覆盖 file_hdr(除 hdr_mac 字段本身) + 加密区头部密文(meta+索引表) */
    fh.hdr_mac = 0;
    uint32_t hm = csvm_fnv((const uint8_t *)&fh, sizeof(fh), 0x811c9dc5u);
    hm = csvm_fnv(blob + enc_off, enc_head, hm);
    fh.hdr_mac = hm ^ (uint32_t)(seed ^ (seed >> 32));
    memcpy(blob, &fh, sizeof(fh));

    csvm_sec_zero(enc, enc_size);
    free(enc); free(vlen); free(ppre); free(ppost);
    *out = blob; *out_len = total;
    return 0;
}

/* ------------------------------------------------------------ open ---- */
/* 校验磁盘 blob、解密 meta/索引表。指令体保持密文，由 v5_fetch 按需解密。
   返回 0 成功；<0 失败并把原因写入 err。 */
static int csvm_v5_open(const uint8_t *blob, size_t len, csvm_open_t *oc,
                        char *err, size_t errcap) {
    memset(oc, 0, sizeof(*oc));
    if (!blob || len < sizeof(csvm_file_hdr_t) + sizeof(bc_hdr_t)) {
        if (err) snprintf(err, errcap, "字节码过短");
            return -1;
    }
    csvm_file_hdr_t fh; memcpy(&fh, blob, sizeof(fh));
    if (memcmp(fh.magic, "CSVM\x06\0\0\0", 8) != 0) {
        if (err) snprintf(err, errcap, "魔数不匹配（需要 v5 加密字节码；v4 及更早作废）");
        return -2;
    }
    if (fh.version != 4 || !(fh.flags & BC_FLAG_ENCRYPTED)) {
        if (err) snprintf(err, errcap, "版本/格式不匹配");
            return -3;
    }
    if (fh.total_size != len || (size_t)fh.enc_off + fh.enc_size != len) {
        if (err) snprintf(err, errcap, "长度字段不自洽");
            return -4;
    }
    uint32_t n = fh.n_insn;
    if (!n || n > (1u << 20) ||
        (size_t)fh.enc_size < sizeof(bc_hdr_t) + 8ull * n) {
        if (err) snprintf(err, errcap, "指令数/加密区非法");
            return -5;
    }
    /* hdr_mac */
    csvm_file_hdr_t chk = fh; chk.hdr_mac = 0;
    uint32_t hm = csvm_fnv((const uint8_t *)&chk, sizeof(chk), 0x811c9dc5u);
    uint32_t enc_head = (uint32_t)sizeof(bc_hdr_t) + 8u * n;
    hm = csvm_fnv(blob + fh.enc_off, enc_head, hm);
    if ((hm ^ (uint32_t)(fh.seed ^ (fh.seed >> 32))) != fh.hdr_mac) {
        if (err) snprintf(err, errcap, "头/meta 完整性校验失败（被篡改）");
            return -6;
    }
    /* 解密 enc 区头部到临时缓冲，取 meta + 两张索引表 */
    uint8_t *tmp = (uint8_t *)malloc(enc_head);
    if (!tmp) { if (err) snprintf(err, errcap, "内存不足"); return -7; }
    memcpy(tmp, blob + fh.enc_off, enc_head);
    csvm_xor_stream(tmp, enc_head, fh.seed, fh.salt, 0);
    memcpy(&oc->h, tmp, sizeof(bc_hdr_t));
    if (memcmp(oc->h.magic, "CSVM\x06\0\0\0", 8) != 0 || oc->h.version != 4) {
        csvm_sec_zero(tmp, enc_head); free(tmp);
        if (err) snprintf(err, errcap, "meta 魔数损坏");
            return -8;
    }
    oc->rec_off = (uint32_t *)malloc(sizeof(uint32_t) * n);
    oc->src_off = (uint32_t *)malloc(sizeof(uint32_t) * n);
    if (!oc->rec_off || !oc->src_off) {
        free(oc->rec_off); free(oc->src_off);
        csvm_sec_zero(tmp, enc_head); free(tmp);
        if (err) snprintf(err, errcap, "内存不足");
            return -9;
    }
    memcpy(oc->rec_off, tmp + sizeof(bc_hdr_t), sizeof(uint32_t) * n);
    memcpy(oc->src_off, tmp + sizeof(bc_hdr_t) + sizeof(uint32_t) * n,
           sizeof(uint32_t) * n);
    /* 校验记录偏移表仍在加密区内（防越界读） */
    for (uint32_t i = 0; i < n; ++i) {
        if (oc->rec_off[i] < enc_head || (size_t)oc->rec_off[i] + 7 > fh.enc_size) {
            free(oc->rec_off); free(oc->src_off); oc->rec_off = oc->src_off = NULL;
            csvm_sec_zero(tmp, enc_head); free(tmp);
            if (err) snprintf(err, errcap, "记录偏移表越界");
                return -10;
        }
    }
    csvm_sec_zero(tmp, enc_head); free(tmp);
    oc->blob = blob; oc->blob_len = len; oc->fh = fh;
    oc->rec_base = enc_head;
    return 0;
}

static void csvm_v5_close(csvm_open_t *oc) {
    if (!oc) return;
    csvm_sec_zero(&oc->h, sizeof(oc->h));
    if (oc->rec_off) { free(oc->rec_off); oc->rec_off = NULL; }
    if (oc->src_off) { free(oc->src_off); oc->src_off = NULL; }
    memset(oc, 0, sizeof(*oc));
}

/* ------------------------------------------------------------ fetch ---- */
/* 按需解密第 pc 条指令到 out（栈上临时 bc_t）。返回 0 成功；<0 失败。 */
static int csvm_v5_fetch(const csvm_open_t *oc, uint32_t pc, bc_t *out,
                         char *err, size_t errcap) {
    if (!oc || pc >= oc->fh.n_insn) { if (err) snprintf(err, errcap, "pc 越界"); return -1; }
    uint32_t ro = oc->rec_off[pc];
    const uint8_t *enc_rec = oc->blob + oc->fh.enc_off + ro;
    size_t avail = oc->fh.enc_size - ro;
    /* 头 3 字节：vlen / padpre / padpost 也是加密的，先解出来 */
    uint8_t hdr[3]; memcpy(hdr, enc_rec, 3);
    csvm_xor_stream(hdr, 3, oc->fh.seed, oc->fh.salt, ro);
    uint32_t vl = hdr[0], ppre = hdr[1], ppost = hdr[2];
    if (!vl || vl > sizeof(bc_t) || ppre > 7 || ppost > 7) {
        if (err) snprintf(err, errcap, "记录 @%u 头字段非法", pc);
            return -2;
    }
    uint32_t body_n = 3u + ppre + vl + ppost;
    if ((size_t)body_n + 4 > avail) { if (err) snprintf(err, errcap, "记录越界"); return -3; }
    uint8_t buf[3 + 40 + 7 + 7 + 4];
    memcpy(buf, enc_rec, body_n + 4);
    csvm_xor_stream(buf, body_n + 4, oc->fh.seed, oc->fh.salt, ro);
    /* rec_mac 校验（绑定 pc） */
    uint32_t got = (uint32_t)buf[body_n] | ((uint32_t)buf[body_n + 1] << 8) |
                   ((uint32_t)buf[body_n + 2] << 16) | ((uint32_t)buf[body_n + 3] << 24);
    uint32_t want = csvm_rec_mac(oc->fh.seed, oc->fh.salt, pc, buf, body_n);
    if (got != want) {
        csvm_sec_zero(buf, sizeof(buf));
        if (err) snprintf(err, errcap, "指令 @%u 完整性校验失败（篡改/重排/复制）", pc);
        return -4;
    }
    memset(out, 0, sizeof(*out));
    memcpy(out, buf + 3 + ppre, vl);       /* 尾部零自动由 memset 补齐 */
    csvm_sec_zero(buf, sizeof(buf));
    return 0;
}

#endif /* CSVM_CONTAINER_H */
