/* CyrilShield Native Sidecar — 稳定 C ABI（不依赖 CPython C-API）
 *
 * 定位：与 Python 应用同目录部署、由应用显式 LoadLibrary/dlopen 并校验的
 *       原生伴随库（side-car），唯一职责是把「Python 解释层无法直接触达的
 *       硬件/系统能力」以只读、白名单的方式暴露出来。
 *
 * 明确不做：内核驱动、进程注入、DLL 劫持/白利用、AMSI/ETW 补丁、
 *           禁用安全产品、任何用于隐藏行为的手段。
 *
 * 目标平台：Windows x64。Linux 分支仅用于开发期编译与自检回落，
 *           不属于产品级多平台交付。
 */
#ifndef CYRILSHIELD_NATIVE_H
#define CYRILSHIELD_NATIVE_H

#include <stdint.h>
#include <stddef.h>

#ifdef _WIN32
#  define CSN_API __declspec(dllexport)
#else
#  define CSN_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define CSN_ABI_VERSION      1
#define CSN_OK               0
#define CSN_ERR_UNSUPPORTED (-1)
#define CSN_ERR_BADARG      (-2)
#define CSN_ERR_IO          (-3)
#define CSN_ERR_DENIED      (-4)

/* 能力位：Python 侧按位检查，缺失能力自动降级到纯 Python 参考后端 */
#define CSN_CAP_HWID        (1u << 0)
#define CSN_CAP_TICKS       (1u << 1)
#define CSN_CAP_CPUID       (1u << 2)
#define CSN_CAP_SELFHASH    (1u << 3)
#define CSN_CAP_FILEHASH    (1u << 4)

#define CSN_DIGEST_LEN      32
#define CSN_TEXT_LEN        64
#define CSN_ERRBUF_LEN      256

typedef struct csn_hwid {
    uint32_t size;                       /* 由调用方填 sizeof(csn_hwid) */
    uint32_t flags;                      /* 实际采集到的字段掩码 */
    uint8_t  machine[16];                /* 机器标识的规范化摘要 */
    uint8_t  volume[8];                  /* 系统卷序列号（小端） */
    char     cpu[CSN_TEXT_LEN];
    char     os[CSN_TEXT_LEN];
    uint32_t cpu_count;
    uint64_t mem_mb;
    uint8_t  digest[CSN_DIGEST_LEN];     /* 以上全部字段的 SHA-256 */
} csn_hwid;

/* ABI / 能力 */
CSN_API int      csn_abi_version(void);
CSN_API uint64_t csn_capabilities(void);

/* 硬件指纹：只读采集，不需要管理员权限，不访问其他进程 */
CSN_API int      csn_probe_hwid(csn_hwid *out);

/* 高精度单调时钟（用于完整性校验的时间窗，非反调试计时攻击） */
CSN_API int      csn_ticks(uint64_t *out);

/* CPU 特性字（CPUID 或 /proc/cpuinfo 等价） */
CSN_API int      csn_cpu_features(uint32_t *out);

/* 文件 SHA-256：供完整性链与构建清单使用 */
CSN_API int      csn_file_digest(const char *path, uint8_t out[CSN_DIGEST_LEN]);

/* 侧载库自身摘要：Python 侧在加载后立即校验，防止被同名 DLL 替换 */
CSN_API int      csn_self_digest(uint8_t out[CSN_DIGEST_LEN]);

/* 最近一次错误文本 */
CSN_API int      csn_last_error(char *buf, size_t n);

#ifdef __cplusplus
}
#endif
#endif /* CYRILSHIELD_NATIVE_H */
