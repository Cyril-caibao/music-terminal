/* CyrilShield Code Virtualization Kernel — 公共 ABI
 *
 * 真·目标代码虚拟化：x86-64 机器码 -> 语义提升 IR -> 私有 ISA 字节码 -> C 解释器。
 * 与「壳引导链 VM」（vmgen.py / dexvm.py）是两条不同的链路，本文件只管前者。
 *
 * 设计立场：面向使用者自己拥有合法权利的程序，提高逆向门槛。
 * 不含 AMSI/ETW 补丁、进程注入、驱动、反 EDR 等主动规避手段。
 *
 * ---- 版本史 ----------------------------------------------------------------
 * v2 集成层：宿主真实内存模式 + RIP 相对 + MUL/DIV。
 * v3 L2 VM-exit 桥：目标函数调字节码外原生函数提升为 IR_CALLEXT，平台汇编桩
 *    完成 native<->VM 上下文切换（Win x64 / SysV，整数+栈参数）。
 * v4（第七批）：FF/4 间接跳转（函数内闭环 / 函数外 tail-exit）+ 标量 SSE 子集
 *    + 16×128 位 XMM 寄存器文件 + csvm_run_host_fpu；bc_t 32B→40B、magic→\x04、ABI→2。
 * v5（第八批）—— 针对独立验收指出的 4 类问题：
 *    (1) 正确性：修复「浮点参数跨 VM-exit 静默算错」。含 CALLEXT+FSSE 的字节码
 *        编译期打 BC_FLAG_NEED_FPU；只允许带 XMM 通道的 fpu 入口执行，且 fpu 入口
 *        挂带 XMM 搬运的默认桩；非 fpu 入口遇该标志明确拒绝，绝不返回错答案。
 *    (2) 覆盖率·结构性：新增 csvm_compile_cfg 接受多代码片（主段 + .cold / sibling
 *        段），坐标统一为 RVA；直接 jmp rel32 到闭包外降级为 VM-exit tail
 *        （IR_TAILEXIT），解决 gcc -O2 sibling call 与函数分裂硬失败。
 *    (3) 覆盖率·指令：REP 字符串指令子集（rep movs/stos/cmps/scas，DF=0 前向）。
 *    (4) 抗提取：字节码改 v5 变长加密容器（逐条按需解密 + 逐块 rec_mac + 头
 *        hdr_mac），发布版 DLL 去除分析接口导出，解释器 handler 间接分派。
 *    字节码格式破坏性变更：magic \x04→\x05、ABI 2→3；旧 v4 及更早按魔数拒绝。
 *
 * 仍是受限子集 / 诚实边界：packed 逐 lane 浮点、AVX/VEX/YMM、系统调用、
 * DF=1 反向字符串、异常穿透 / 完整链式 unwind、回调再进 VM、SEH/TLS/CFG、
 * 白盒密码学强度均未达商用 VMP。packed 整数 SSE2、LOCK 原子子集、
 * Windows 多线程上下文与真机冷启动已落地（见 VMP-EXE-PARITY 第九/十二批）。
 * 变长加密是「对称混淆」抬高静态 dump 成本，不是密码学保密：静态
 * cg_plain[] 标签表与 keystream 常量仍可提取（第十三批实测）。
 * 这不是完整 VMP。范围见 docs/CODE-VM.md。
 */
#ifndef CS_CODEVM_H
#define CS_CODEVM_H

#include <stdint.h>
#include <stddef.h>

/* 发布版 Windows DLL（build-win.sh）用 -DCSVM_NO_AUTOEXPORT 关掉
   __declspec(dllexport)，改由链接器 /export: 白名单精确控制导出：只保留
   运行入口，去掉 csvm_compile / disasm / stats / run / run_regs 等分析接口，
   使「dump 出 .csvm 段 -> 调自带反编译器拿 IR 清单」这条路失效。
   开发版 Linux .so（build.sh）不带该宏，保留全部导出供自检 / CLI 使用。 */
#if defined(_WIN32)
#  if defined(CSVM_NO_AUTOEXPORT)
#    define CSVM_API
#  else
#    define CSVM_API __declspec(dllexport)
#  endif
#else
#  define CSVM_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* C ABI 版本。第八批字节码改 v5 加密容器 + 新增 csvm_compile_cfg，整体 2→3。
 * cyrilshield/vmp/codevm.py 的封装会校验此值。 */
#define CSVM_ABI_VERSION 4u
/* 字节码格式版本写在 magic[4]。每次布局/容器变更必须 +1：
 *   v2 = bc_t 32B（next_off，RIP 相对）
 *   v3 = 仅语义扩展（IR_CALLEXT 复用 pad 字节），布局未变，未 bump
 *   v4 = bc_t 40B（src_off，FF/4 + SSE/XMM）
 *   v5 = 磁盘改为变长加密容器（csvm_container.h），内存 bc_t 仍 40B 但由
 *        csvm_compile 产出的 blob 不再是 [bc_hdr_t][bc_t[n]] 明文结构。
 * 旧 v2/v4 明文字节码按魔数直接拒绝，禁止与本版解释器混用。 */
#define CSVM_MAGIC       "CSVM\x06\0\0\0"
#define CSVM_MAX_CODE    (1u << 20)
#define CSVM_MAX_INSN    (1u << 16)
#define CSVM_ERR_CAP     512

/* 单段编译（等价于 segs={ {code,len,0} } 的 csvm_compile_cfg）。输出为 v5 加密
 * 容器 blob；用 csvm_free 释放。 */
CSVM_API int csvm_compile(const uint8_t *code, size_t len, uint64_t seed,
                          uint8_t **out_bc, size_t *out_len,
                          char *err, size_t errcap);

/* CFG 闭包多段编译（第八批）。每段描述一段真实机器码及其在目标映像里的 RVA
 * （相对将传给运行入口的 runtime_base / image_base）。主段 rva 通常填 0，
 * 附加段（.cold、sibling-call 目标等）rva 填「该段首字节相对主段首字节的
 * 真实地址差」。编译器把所有段的 IR 放在同一 RVA 坐标空间，跳转/间接跳转/
 * RIP 相对目标按 RVA 解析，从而允许跨段闭环。段数 1..CSVM_MAX_SEGS。 */
typedef struct {
    const uint8_t *code;
    size_t         len;
    uint64_t       rva;
} csvm_seg_t;
#define CSVM_MAX_SEGS 16u

CSVM_API int csvm_compile_cfg(const csvm_seg_t *segs, size_t nseg, uint64_t seed,
                              uint8_t **out_bc, size_t *out_len,
                              char *err, size_t errcap);

/* 沙箱模式执行（64KB 独立内存 + 独立栈）。args 按 SysV AMD64 传入，返回 RAX。
 * 用于自检；真实集成请用 csvm_run_host。 */
CSVM_API int csvm_run(const uint8_t *bc, size_t len,
                      const uint64_t *args, size_t nargs,
                      uint64_t *ret, char *err, size_t errcap);

/* 通用入口：调用者按目标 ABI 自行填 16 个 GPR（x86 编号 0=RAX..15=R15）。
 * Windows x64：把 RCX/RDX/R8/R9 填到编号 1/2/8/9，32B 影子空间由 stub 负责。 */
CSVM_API int csvm_run_regs(const uint8_t *bc, size_t len,
                           const uint64_t regs_in[16], uint64_t regs_out[16],
                           char *err, size_t errcap);

/* 宿主内存访问回调。write=0 读，write=1 写；返回 0 成功，非 0 表示越界并 TRAP。 */
typedef int (*csvm_mem_fn)(void *ctx, uint64_t addr, void *buf,
                           size_t n, int write);

CSVM_API int csvm_host_mem_direct(void *ctx, uint64_t addr, void *buf,
                                  size_t n, int write);

/* 集成层主入口：宿主真实内存模式。runtime_base 传 RVA 空间的基址（PE =
 * ImageBase + 目标函数 RVA；多段编译时 = 主段首字节真实地址）。RSP 直通真实栈、
 * CALL/RET 走独立 VM 调用栈、RIP 相对按 RVA 解析常量池。 */
CSVM_API int csvm_run_host(const uint8_t *bc, size_t len,
                           const uint64_t regs_in[16], uint64_t regs_out[16],
                           uint64_t runtime_base,
                           csvm_mem_fn mem, void *mem_ctx,
                           char *err, size_t errcap);

/* L2 VM-exit 回调：命中字节码外原生调用时，把 16 个 GPR 交给宿主完成真实调用。
 * 返回 0 成功，非 0 触发 TRAP。 */
typedef int (*csvm_exit_fn)(void *ctx, uint64_t target, uint64_t regs[16]);

/* 带 XMM 搬运的 VM-exit 回调（第八批）。除 16 个 GPR 外，还传 16×128 位 XMM
 * 寄存器文件，供桩把 XMM0-7 参数装到物理寄存器、调用后回读 XMM0 返回值。
 * 用于「浮点参数跨 VM-exit」场景，杜绝静默算错。 */
typedef int (*csvm_exit_fpu_fn)(void *ctx, uint64_t target,
                                uint64_t regs[16], uint64_t xmm[16][2]);

/* 可注入自定义 VM-exit 回调的通用入口。exitfn=NULL 时用平台默认桩。 */
CSVM_API int csvm_run_host_ex(const uint8_t *bc, size_t len,
                              const uint64_t regs_in[16], uint64_t regs_out[16],
                              uint64_t runtime_base,
                              csvm_mem_fn mem, void *mem_ctx,
                              csvm_exit_fn exitfn, void *exit_ctx,
                              char *err, size_t errcap);

/* 带 XMM 寄存器文件的宿主入口（第七批）。xmm_in/out 为 16×128 位。
 * 第八批：对含 BC_FLAG_NEED_FPU 的字节码，本入口挂「带 XMM 搬运」的默认
 * VM-exit 桩（SysV/Win 汇编），能正确调用带浮点参数/返回的外部函数；这是唯一
 * 允许执行该类字节码的入口，其它入口（csvm_run_host / csvm_enter / csvm_run /
 * csvm_run_regs / csvm_run_host_ex）遇该标志明确拒绝，避免静默算错。
 * 注意：csvm_enter / 当前 PE stub 仍只搬 GPR，浮点返回值进 PE 产物需 stub 汇编
 * 同步改造；含 FPU_EXIT 的字节码不应用于 csvm_enter 路径。见 docs/CODE-VM.md。 */
CSVM_API int csvm_run_host_fpu(const uint8_t *bc, size_t len,
                               const uint64_t regs_in[16], uint64_t regs_out[16],
                               const uint64_t xmm_in[16][2], uint64_t xmm_out[16][2],
                               uint64_t runtime_base,
                               csvm_mem_fn mem, void *mem_ctx,
                               csvm_exit_fn exitfn, void *exit_ctx,
                               char *err, size_t errcap);

/* PE/ELF 集成 stub 用的精简入口：4 个参数全走寄存器（Win x64: RCX/RDX/R8/R9）。
 * slots 是 16 个 GPR 的进出缓冲区；返回 VM 的 RAX。
 * 内部包办 csvm_run_host 的 9 参数细节、宿主内存回调与错误降级。遇含
 * BC_FLAG_NEED_FPU 的字节码会拒绝执行（返回进入时的 RAX，不伪造结果）。 */
CSVM_API uint64_t csvm_enter(const uint8_t *bc, size_t len,
                              uint64_t slots[16], uint64_t runtime_base);

CSVM_API int csvm_disasm(const uint8_t *code, size_t len,
                         char *out, size_t cap);
CSVM_API int csvm_stats(const uint8_t *bc, size_t len,
                        uint32_t *bc_insns, uint32_t *ir_insns,
                        uint32_t *junk_insns, uint64_t *seed_out);
CSVM_API void     csvm_free(void *p);
CSVM_API uint32_t csvm_abi_version(void);
CSVM_API const char *csvm_version_string(void);

#ifdef __cplusplus
}
#endif
#endif /* CS_CODEVM_H */
