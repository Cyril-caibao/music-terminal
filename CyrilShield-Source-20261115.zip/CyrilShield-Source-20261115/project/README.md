# CyrilShield

Windows 本地的 exe / apk 保护工具：**图标提取 · UPX 加壳 · VM 虚拟壳 · APK 加固**。

界面是本地网页（`127.0.0.1` + 随机端口 + 随机令牌），用 Edge / Chrome 开成无边框窗口，全程不联网、不上传任何文件。

![界面](docs/screenshot.png)

## 功能

| 功能 | 输入 | 输出 | 说明 |
|---|---|---|---|
| **图标提取** | `.exe` `.dll` `.scr` `.cpl` `.ocx` | ICO / PNG | 从资源段直接解析，按尺寸和色深分组导出，支持 PNG 压缩图标与 AND 掩码合成 |
| **UPX 加壳** | `.exe` | 压缩后的 exe | 内置 UPX 5.3.0，支持 1–9 级 / `--best` / `--brute` / LZMA，可压缩图标资源、保留重定位 |
| **VM 引导壳** | `.exe` | 自带解释器的 exe | 把**壳自己的引导链**（密钥派生 → 逐片解封 → 完整性判定）编译成自定义字节码，由内置虚拟机执行；每次构建随机化指令编号、字段排列、模块符号名。**业务 EXE 是整块加密后运行时还原，并未被翻译成私有指令集** |
| **目标代码虚拟化**（C 内核 + PE 集成 + L2 VM-exit + FF/4 + 标量 SSE + 字符串 + FPU 跨 exit + CFG 闭包 + 多函数批量，EXE） | `.exe` | 改写后的 exe（+ 同目录 DLL） | 把指定函数的机器码翻译进私有 ISA，函数头 5 字节改成 `jmp` 到新 `.csvm` 节区的 VM stub；第六批补 L2 VM-exit 桥（VM 内可调外部真实函数），第七批补 `FF /4` 间接跳转与标量 SSE，第八批补 **VM-exit 浮点参数搬运（修掉静默算错 Bug）/ CFG 多段闭包 / `rep movsb/stos` 字符串指令 / 多函数批量 + SDK 标注 / v5 变长加密容器 / 发布 DLL 导出收敛到 8 入口**。已接入 `vmgen.build()`，**默认关闭、需填函数 RVA 与长度或批量清单**，运行内核（发布版 8 导出）由 `vmgen.build()` **自动部署到成品同目录**。受限子集（packed SIMD / AVX / 原子 / VM-exit 异常仍缺，**抗提取层不完整：handler 仍是中心 `switch` 直派、未做变异**），详见 [CODE-VM.md](docs/CODE-VM.md) |
| **APK 加固** | `.apk` `.xapk` `.apks` | 已重签名 apk | dex 跨文件乱序分片加密 + 引导链 VM 虚拟化 + 壳运行时解密注入类加载器；可选签名绑定与反调试，详见 [APK 安全说明](docs/APK-SECURITY-NOTES.md) |
| **ELF 加固（Linux）** | ELF64 可执行 / `.so` | `*.csvmpayload` + `LD_PRELOAD` 挂钩 | 函数级虚拟化，**原文件不改一个字节**：界面里扫描符号、勾选函数即生成 payload，运行时由 `libcsvm_elfhook.so` 接管被选中的函数。需未 strip（或用 RVA:长度），超出内核指令子集的函数单独跳过并给出原因 |
| **运行时守卫**（VM 壳） | `.exe` | 同上 | 可选反调试 / 反分析环境检测 + 缩短明文落盘窗口的加固释放；默认关闭，详见 [安全说明](docs/SECURITY-NOTES.md) |
| **保护能力矩阵**（EXE） | `.exe` | 同上 | 引导链虚拟化 / 变异 / 常量加密 / 导入保护 / 完整性链 / 离线授权 / 水印 / SDK 标记 / 多态 / 降误报，详见 [能力矩阵与真实差距](docs/VMP-EXE-PARITY.md) |

## 保护能力矩阵（EXE 专用）

> **定位澄清**：这里是**能力项覆盖**（把 VMP 的功能清单逐项做出可运行、可自测的实现），
> **不是单点强度对标**。第五批新增 **C11 目标代码虚拟化内核 + PE 集成层**，
> 第六批补 **L2 VM-exit 桥**（VM 内可调外部真实函数，含寄存器/栈参数搬运、
> Win x64 影子空间与 16B 对齐、nonvolatile GPR 与 XMM6-15 保存恢复），
> 第七批补 **`FF /4` 间接跳转（尾调用 / switch 跳转表）与标量 SSE 基础子集**，
> 第八批补 **VM-exit 浮点参数搬运、CFG 多段闭包、`rep movsb/stos` 字符串指令、
> 多函数批量 + SDK 标注、v5 变长加密容器、发布 DLL 导出收敛到 8 入口**：
> 能把真实 x86-64 机器码翻译进私有 ISA，改写 PE 函数头为 `jmp` VM stub，并接入
> `vmgen.build()`。**启用后指定函数的代码确实进 VM，能跑带外部调用、栈参数、
> 浮点 XMM 参数与返回、尾调用、跳转表、标量浮点、字符串指令与跨段尾调用的普通函数**；
> 但该能力默认关闭、需显式选函数（或批量清单）、指令子集仍受限（packed SIMD / AVX /
> 原子、VM-exit 异常仍缺），L2 桥不含 Windows SEH / TEB / 回调（Linux 侧异常捕获与多线程上下文已在第九批补齐），未启用时产物
> 仍是「引导链 VM + 抽取式加固」，解密后的原始 EXE 仍会落盘再拉起。**抗提取层有进展
> 但仍不完整（诚实标注）**：v5 变长加密容器 + 发布 DLL 去导出已做，但 **handler 仍是
> 中心 `switch` 直派、未做多套等价变形 / 逐条随机化加密**，与 VMProtect / Themida
> 这类成品不是一类东西。
> 第五/六/七批已补上「PE 函数入口改写 + 运行时上下文切换 + L2 VM-exit 桥 +
> FF/4 间接跳转 + 标量 SSE」并接入主构建链（`selftest_integration.py` 15/15），
> 但仍是 **默认关闭、单函数、受限子集** 的可运行集成原型；驱动级不落地、字节码
> 加密 / 变长、handler 变形、多函数选择、Windows 异常/TLS、真机多线程冷启动
> 仍未做，因此**未实现对标**，见 [CODE-VM.md](docs/CODE-VM.md) 第 6 节
> （能力矩阵维持 `partial`）。

能力清单：引导链虚拟化、代码变异、常量加密、导入表保护、反调试 / 反分析环境
（5 + 6 类探针，默认关闭）、双分块完整性链、离线授权与 HWID 绑定、水印、
SDK 标记、多态构建指纹、UPX 压缩，以及**降低误报**（合法版本资源 +
误报风险审计 + 可复现构建清单）。「免杀强度」按**降低加壳产物误报与静态特征命中**
实现，不含针对安全产品的主动规避或行为隐藏。

底层用**原生侧载层**（C11 / 稳定 C ABI）让 Python 侧安全访问硬件能力：显式加载 +
自身摘要校验 + 能力门 + 缺件自动降级，不装驱动、不提权、不注入。

- [原生侧载架构](docs/NATIVE-SIDECAR.md)
- [能力矩阵与真实差距](docs/VMP-EXE-PARITY.md)
- [误报与实现边界](docs/AV-COMPATIBILITY.md)
- 自检：`python selftest_vmp.py`（25 项，全部与 EXE 侧相关）、
  `python selftest_integration.py`（15 项，含 FF/4 + SSE + 字节码 v4）

## 运行

```bash
python main.py
```

需要 Python 3.10+。窗口会自动打开；加 `--no-browser` 只起服务，`--port=8765` 固定端口。

依赖按功能分档，缺了只会降级对应能力，不会影响其他功能：

```bash
pip install -r requirements.txt   # Pillow（PNG 导出）+ PyInstaller（VM 壳后端）
```

**APK 加固需要的外部工具**（程序自动探测，顺序为 `ANDROID_HOME` → `ANDROID_SDK_ROOT` → `%LOCALAPPDATA%\Android\Sdk` → `~/Android/Sdk` → `C:\Android\Sdk`）：

- JDK 11+ 的 `javac` / `keytool` / `java`
- Android SDK `build-tools` 的 `d8` / `apksigner` / `zipalign`
- `platforms\android-XX\android.jar`

缺任何一项时，侧栏会显示「Android 工具链缺失」，加固按钮会直接报错说明缺什么。

## 打包成独立 EXE

```bash
python -m PyInstaller --onefile --windowed --noupx --name CyrilShield ^
  --icon "assets/app.ico" ^
  --add-binary "tools/upx.exe;tools" ^
  --add-data "cyrilshield/web;cyrilshield/web" ^
  --add-data "assets/app.ico;assets" ^
  --hidden-import=PIL.Image --hidden-import=PIL.ImageTk main.py
```

也可以直接双击 `重建EXE.bat`。产物在 `dist/`，约 28 MB，**单文件**：图标提取和 UPX 加壳不需要目标机器装任何东西。

## 便携版（APK 加固也不需要装 SDK）

```bash
python build_portable.py            # 单文件，约 93 MB
python build_portable.py --onedir   # 目录版，启动更快
python build_portable.py --refresh  # 重新从本机 JDK / SDK 生成 toolchain/
```

`toolchain/` 由本机 JDK 用 `jlink` 裁出精简运行时（`java.base / jdk.compiler / jdk.zipfs / java.logging / java.xml`），再拷入 build-tools 的四个可执行体和 `android.jar`，共约 104 MB。程序优先使用自带的这套工具链，找不到才回落到系统安装。

`toolchain/` 不入库（见 `.gitignore`），需要时用 `--refresh` 现生成。

## 自检

```bash
python selftest.py                # 用系统 notepad.exe 作样本
python selftest.py path\to.apk    # 额外跑 APK 相关检查
```

覆盖 PE 解析、图标提取、UPX 打包/测试/脱壳、VM 字节码与多态随机化、运行时守卫（掩码 / 注入源码 / 运行时放行 / stub 完整性）、载荷容器封装、AXML 往返一致性、APK 结构解析与加固构建，以及 **APK 引导链 VM（编译 / 乱序分片还原 / 篡改拒绝 / 多态 / 双端一致性 / 壳源码生成与指纹消除）**。缺少对应环境时该项标记 `SKIP`，不会假装通过。守卫与 VM 相关的检查不依赖 Windows，任何平台都会实际执行。

## 项目结构

```
main.py                启动入口
selftest.py            自检脚本
build_portable.py      便携版构建（生成 toolchain/ 并打包）
cyrilshield/
  pe.py                PE 头 / 节区 / 资源目录解析（纯 Python，不依赖 Win32 API）
  upx.py               内置 UPX 的定位与调用
  vmgen.py             VM 字节码生成与虚拟壳编译
  apk.py               APK 解析、加固、重打包签名
  axml.py              二进制 AndroidManifest.xml 读写
  _stream.py           HMAC-SHA256 计数器流加密与载荷容器
  server.py            本地 HTTP 服务与接口
  web/                 界面（原生 HTML/CSS/JS，无框架）
tools/upx.exe          内置 UPX（GPL，见 tools/UPX-LICENSE.txt）
assets/app.ico         程序图标
tests/sample.apk       自测用样本
```

## APK 加固做了什么

1. 解析二进制 `AndroidManifest.xml`，把 `android:name` 指向注入的壳类（随机包名 + 随机类名），移除 `android:debuggable`，可选关闭 `allowBackup`
2. 全部 `classes*.dex` 拼成一条流后**跨文件乱序切片**（片边界不落在 dex 边界上），每片用独立 nonce + 独立子密钥以 HMAC-SHA256 计数器流加密，写入随机命名的 `assets/xx/yy.dat`
3. 把「密钥派生 → 逐片解封 → 原序重排 → SHA-256 判定」编译成**自定义字节码**，连同通用解释器一起编译进壳 dex；操作码、寄存器槽位、常量池、垃圾指令每次构建随机
4. 生成壳 Application：`attachBaseContext` 由 VM 解出分片、重组并切回各 dex，用 direct buffer 交给 `InMemoryDexClassLoader`，随后擦除 Java 堆里的全部明文副本
5. 用 `Instrumentation.newApplication` 重建你原来的 Application 并接管框架侧实例，所以 `getApplication()` 返回的仍是你的类
6. `zipalign` 4 字节对齐后重新签名（`minSdk < 24` 时自动补 v1 签名）

几个刻意为之的细节：

- **载荷没有固定文件头**：格式是 `[密文 | nonce(16) | tag(8)]`，密文从第 0 字节开始，扫描器拿不到 `PS` 之类的魔数特征
- **乱序分片**：第 i 个 asset 装原序第几片，只写在 VM 的 `EMIT` 立即数里；静态拿到一堆 `.dat` 既不知道拼回顺序，也不知道从哪切回 dex
- **引导链虚拟化**：壳 dex 里不再有可直读的 `key()` / `sub()` / `unseal()` 调用链，只剩一个通用解释器和几段数据；Python 侧编译器与 Java 侧解释器语义严格对称，且已双端验证
- **壳自身去指纹**：方法名每次随机，`dexElements` / `pathList` 等反射字符串 XOR 编码，不再留固定特征
- **内存明文擦除**：分片、拼接缓冲、切分后的 dex 副本在交给 ART 后逐一律零（direct buffer 那份是 ART 必需输入，仍存在）
- **类名不落明文**：真实 Application 类名以异或掩码的 `byte[]` 形式存在，运行时解码
- **签名块名随机**：`apksigner` 用密钥别名命名 v1 签名块，默认密钥库的别名是随机生成的
- **v4 签名关闭**：避免额外吐一个没人用的 `.idsig` 旁路文件

可选的**签名绑定（防重打包）、反调试 / 反注入框架、反模拟器**默认全部关闭，误报风险与适用边界见
[`APK 安全说明`](docs/APK-SECURITY-NOTES.md)。

> 边界要说清：虚拟化的是**壳自己的引导逻辑**，不是业务 dex 的 Dalvik 字节码。
> 把任意 APK 的业务代码整体接管需要完整反汇编器 + ART 侧解释器 + 全指令语义覆盖，
> 是 VMP 级工程，本项目不做。详见上面那份文档的第 2、3、5 节。

首次使用会在 `%LOCALAPPDATA%\CyrilShield\` 生成自签名密钥库（口令 `cyrilshield2026`），足够自测和内部使用。**正式发布请换用你自己的密钥库**，并在界面上填写路径与口令。

## 适用范围

这个工具做的是**对自己程序的保护**：加密、完整性校验、反篡改、类名与路径混淆。请只用于你拥有合法权利的程序。

VM 虚拟壳另提供三组**可选、默认关闭**（加固临时释放默认开启）的运行时能力，详见
[`CyrilShield/docs/SECURITY-NOTES.md`](docs/SECURITY-NOTES.md)：

| 能力 | 作用 | 默认 |
|---|---|---|
| 反调试 | 检测调试器 / 单步 / 调试端口，命中则静默退出 | 关 |
| 反分析环境 | 检测虚拟机 / 沙箱 / 逆向工具进程 | 关 |
| 加固临时释放 | 缩短解密载荷在磁盘上的明文驻留窗口 | 开 |

它们只提高动态分析的入门门槛，**不承诺「免杀」，也不承诺躲过任何检测**。
反调试与反分析环境属于启发式判断，可能误伤虚拟桌面、云主机、企业终端，分发前请先用自己的样本验证。

仍然**不包含也不会实现**：杀软 / EDR 对抗、AMSI 或 ETW 打补丁、进程注入 / 进程镂空
（这是实现"真·内存加载 / 不落地"的前提）、驱动、持久化等隐蔽或规避性手段。
加密与混淆能提高静态分析门槛，但挡不住内存 dump——上面这份文档解释了具体原因与边界。

APK 侧同样提供三组**可选、默认关闭**的运行时守卫：签名证书绑定（防重打包）、
反调试 / 反注入框架、反模拟器；明文内存擦除与引导链虚拟化默认开启。
命中守卫时静默不加载，检测逻辑异常一律放行。详见
[`APK 安全说明`](docs/APK-SECURITY-NOTES.md)。

## 注意

- **加壳会使原签名失效。** 本工具会用自带密钥重新签名，安装前请先卸载旧版本（签名不同无法覆盖升级）
- **抽取式加固有固有特征**：`classes.dex` 被抽空、真正代码藏在 assets 里，这类模式本身是可检测的，部分应用商店和加固检测会报警
- 处理第三方程序可能违反其许可协议和相关法律，请只用于你拥有合法权利的程序

## 许可

代码可自由使用和修改。内置的 `tools/upx.exe` 遵循 GPL v2+，许可证见 `tools/UPX-LICENSE.txt`。

### Linux 程序加固入口（第十批）

界面上是侧栏的 **ELF 加固** 页：拖入 ELF64 可执行文件或 `.so`，它会列出可保护函数，
勾选后生成 `*.csvmpayload`（原文件不改一个字节，运行时由 `LD_PRELOAD` 接管）。
命令行等价用法：

```bash
python3 -m cyrilshield.vmp.protect_elf ./prog --list      # 列出可保护函数（需未 strip）
python3 -m cyrilshield.vmp.protect_elf ./prog f_secret    # 生成 ./prog.csvmpayload
LD_PRELOAD=./native/out/libcsvm_elfhook.so \
CSVM_ELF_PAYLOAD=./prog.csvmpayload ./prog                 # 运行时挂钩，原文件不改
```

内核指令子集有限，某个函数遇到不认识的指令时会**单独跳过并给出原因**
（偏移 + 字节），其余函数照常写入 payload；直接运行 CLI 与界面行为一致。

LSB 侧多线程上下文（TLS 池 / 异常安全网 / 可重入 / 故障隔离）已实测；
Windows 侧同结构代码（FLS + VEH）已写入 `native/src/codevm.c`，
真机自测脚本为 `native/src/win_thread_demo.c`（`build.bat` 第 5 步产出 `out\win_thread_demo.exe`），
沙箱无 Windows 工具链，**未编译未真机验证**。细节见 `CHANGES-第十批-Windows与ELF入口.md`。
