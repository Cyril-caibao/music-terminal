# -*- coding: utf-8 -*-
"""代码虚拟化 **集成层** 端到端自检。

判据不是「能生成字节码」，而是「产物里目标代码真的进 VM，且返回值与原生一致」：

  1) C 内核宿主真实内存模式：DIV/IDIV/MUL/IMUL/CQO/RIP 相对，与 CPU 逐字节一致
  2) ELF 函数头 5 字节 E9 改写 -> trampoline 上下文切换 -> 冷启动 8/8
  3) 真实 Windows PE32+ 改写：新 .csvm 节区 + 导入表 + 函数头 jmp stub
  4) 集成器产出的 Windows x64 stub 字节，在真实 CPU 上执行 8/8
  5) 发布版 CyrilShield.CodeVM.dll 只导出 8 个运行入口（去分析接口）
  6) vmgen.py 主构建链已接入 PE 集成层
  7) 第七批 FF/4 间接跳转（尾调用 + switch 跳转表）与标量 SSE 冷启动比对
  8) 第八批：FPU VM-exit 正确性（pow(2,3)+1=9，非 fpu 入口明确拒绝）、
     TAILEXIT 直接尾调用、CFG 多段闭包、REP 字符串指令、v5 变长加密容器
  9) 多函数批量改写（共享 1 个 .csvm 节区 + 1 个 IAT）+ SDK 标注清单
 10) Windows 真机冷启动验证链脚本齐备（沙箱无真机，诚实边界）

运行：python selftest_integration.py
依赖：gcc / clang / lld-link / llvm-lib / llvm-readobj / objdump；缺则相关项 SKIP。
"""
from __future__ import annotations

import ctypes
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cyrilshield.vmp import codevm as cv
from cyrilshield.vmp import integration as integ

ROOT = os.path.dirname(os.path.abspath(__file__))
NATIVE = os.path.join(ROOT, "native")
OUT = os.path.join(NATIVE, "out")

TESTS = []
NAMES = {
    "t_build": "原生层构建（Linux + Windows 交叉）",
    "t_host_memory": "宿主内存模式 DIV/MUL/RIP 相对",
    "t_elf_hotpatch": "ELF 函数头改写 + 冷启动",
    "t_pe_protect": "真实 PE32+ 改写为 VM stub",
    "t_pe_structure": "PE 节表/导入表/导出/函数头",
    "t_pe_stub_disasm": "stub 反汇编 RIP 目标核对",
    "t_pe_stub_exec": "Windows stub 在 CPU 上真实执行",
    "t_windows_dll": "发布版 DLL 导出收敛（8 个运行入口）",
    "t_vmexit": "L2 VM-exit 桥（真实函数调外部 API）",
    "t_ff4_sse": "第七批 FF/4 间接跳转 + 标量 SSE",
    "t_bc_format": "v6 变长加密容器 / ABI 4 / 旧版本拒绝",
    "t_v5_demo": "第八批 v5 端到端（FPU/TAILEXIT/CFG/REP/容器）",
    "t_thread_ctx": "第九批 多线程 VM 上下文（8 线程/可重入/故障隔离）",
    "t_elf_entry": "第十批 Linux ELF 加固入口（挂钩 + 与原生逐位一致）",
    "t_elf_ui_entry": "ELF 入口 UI 链路（符号过滤 + 逐函数跳过）",
    "t_batch": "多函数批量 + SDK 标注",
    "t_windows_coldboot": "Windows 真机冷启动验证链",
    "t_checksum": "PE CheckSum 重算且与独立实现一致",
    "t_vmgen_wired": "vmgen.py 主构建链接入集成层",
    "t_no_python_kernel": "Python 侧无虚拟化内核逻辑",
    "t_regression": "既有自检回归（codevm / vmp）",
}


def test(fn):
    TESTS.append((fn, NAMES.get(fn.__name__, fn.__name__)))
    return fn


def _have(*tools):
    # 本文件的样本一律是 Linux x86-64 ELF / .so（-fPIC -shared + nm + ELF 函数头
    # 改写）。Windows 上即便 PATH 里有 gcc，也不是同一 ABI —— 例如 Free Pascal
    # 自带的 i386-Win32 gcc 2.95 会编出无法加载的产物（WinError 193）。
    # 所以非 Linux 直接判「缺工具链」，让整组用例如实 SKIP，而不是误报失败；
    # Windows 侧真机链路请跑 native/tools/win_coldboot_verify.ps1。
    if sys.platform != "linux":
        return False
    return all(subprocess.run(["which", t], capture_output=True).returncode == 0
               for t in tools)


class LinuxToolchainMissing(Exception):
    """Env 样本依赖 Linux 侧 build.sh 产物，非 Linux 时整组用例 SKIP。"""


class Env:
    def __init__(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="csvm_integ_")
        self.d = self.tmp.name
        self.pe = b""
        self.new_pe = b""
        self.report = {}
        self.stub = b""
        self.func_rva = 0x1000
        self.func_size = 0
        self.have_win = False
        self.skip_reason = ""

    def setup(self):
        if sys.platform != "linux":
            self.skip_reason = ("非 Linux：样本依赖 build.sh 产出的 Linux .so / ELF "
                                "可执行文件；Windows 侧请跑 "
                                "native/tools/win_coldboot_verify.ps1")
            raise LinuxToolchainMissing(self.skip_reason)
        subprocess.run([os.path.join(NATIVE, "build.sh")], check=True,
                       capture_output=True, text=True)
        self.have_win = _have("clang", "lld-link", "llvm-lib", "llvm-readobj")
        if self.have_win:
            subprocess.run([os.path.join(NATIVE, "build-win.sh")], check=True,
                           capture_output=True, text=True)
            win = os.path.join(OUT, "win_target.dll")
            self.pe = open(win, "rb").read()
            # .text VirtualSize 就是唯一函数的长度
            ep = struct.unpack_from("<I", self.pe, 0x3C)[0]
            nsec = struct.unpack_from("<H", self.pe, ep + 6)[0]
            osz = struct.unpack_from("<H", self.pe, ep + 20)[0]
            for i in range(nsec):
                o = ep + 24 + osz + i * 40
                nm = self.pe[o:o + 8].rstrip(b"\0")
                vs = struct.unpack_from("<I", self.pe, o + 8)[0]
                if nm == b".text":
                    self.func_size = vs
            self.new_pe, self.report = integ.protect_pe(
                self.pe, self.func_rva, self.func_size, seed=0x5EED)
            raw = int(self.report["section_raw_off"], 16)
            self.stub = self.new_pe[raw:raw + self.report["stub_size"]]

    def close(self):
        self.tmp.cleanup()


E = Env()


@test
def t_build():
    if not _have("gcc"):
        return "SKIP", "缺 gcc"
    try:
        E.setup()
    except LinuxToolchainMissing as exc:
        return "SKIP", str(exc)
    needed = ["libcyrilshield_codevm.so", "peintegrate", "hotpatch_demo",
              "pe_stub_verify", "exit_demo", "coverage_demo", "v5_demo"]
    for n in needed:
        assert os.path.isfile(os.path.join(OUT, n)), n
    return (f"10 项 Linux 产物就绪（含第七批 coverage_demo + 第八批 v5_demo）；"
            f"Windows 交叉={'可用' if E.have_win else 'SKIP'}")


@test
def t_host_memory():
    if not _have("gcc"):
        return "SKIP", "缺 gcc"
    so = os.path.join(E.d, "libintegr.so")
    subprocess.run(["gcc", "-O2", "-fPIC", "-shared", "-fcf-protection=none",
                    "-o", so, os.path.join(NATIVE, "samples", "integration.c")],
                   check=True, capture_output=True)
    vm = cv.get_codevm()
    lib = ctypes.CDLL(so)
    l2 = ctypes.CDLL(vm.path)
    u64 = ctypes.c_uint64
    l2.csvm_run_host.argtypes = [ctypes.c_void_p, ctypes.c_size_t,
                                 ctypes.POINTER(u64), ctypes.POINTER(u64),
                                 u64, ctypes.c_void_p, ctypes.c_void_p,
                                 ctypes.c_char_p, ctypes.c_size_t]
    l2.csvm_run_host.restype = ctypes.c_int
    RDI, RSI, RAX, RSP = 7, 6, 0, 4
    stack = ctypes.create_string_buffer(65536)
    sp = ctypes.addressof(stack) + 32768

    def run_host(bc, a, b, base):
        i, o = (u64 * 16)(), (u64 * 16)()
        i[RDI], i[RSI], i[RSP] = a, b, sp
        err = ctypes.create_string_buffer(512)
        buf = ctypes.create_string_buffer(bc)
        rc = l2.csvm_run_host(buf, len(bc), i, o, base, None, None, err, 512)
        assert rc == 0, err.value.decode(errors="replace")
        return o[RAX]

    cases = [
        ("f_protected", [(0, 1), (1, 7), (12345, 97), (2**64 - 1, 3),
                         (0x123456789ABCDEF, 0x9E37), (999, 13), (2**63, 7)], False),
        ("f_mulhi", [(1, 1), (0, 0), (2**64 - 1, 2**64 - 1),
                     (0x123456789ABCDEF, 0xFEDCBA)], False),
        ("f_idiv", [(100, 7), (-100, 7), (100, -7), (-100, -7), (2**63 - 1, 3)], True),
        ("f_imulhi", [(1, 1), (-1, 1), (2**63 - 1, 3), (-(2**63), 2)], True),
    ]
    total = ok = 0
    for name, args, signed in cases:
        code = cv.extract_elf_function(so, name)
        fn = getattr(lib, name)
        fn.restype = ctypes.c_int64 if signed else ctypes.c_uint64
        fn.argtypes = [ctypes.c_int64 if signed else ctypes.c_uint64] * 2
        base = ctypes.cast(fn, ctypes.c_void_p).value
        bc = vm.compile(code, seed=0xBEEF)
        for a, b in args:
            want = fn(a, b) & ((1 << 64) - 1)
            got = run_host(bc, a & ((1 << 64) - 1), b & ((1 << 64) - 1), base)
            ok += (got == want)
            total += 1
    assert ok == total, f"{ok}/{total}"
    return f"{total}/{total} 与 CPU 一致（DIV/IDIV/MUL/IMUL/CQO/RIP 相对全部覆盖）"


@test
def t_elf_hotpatch():
    if sys.platform != "linux":
        return "SKIP", "hotpatch_demo 是 Linux ELF 可执行文件，非 Linux 无法冷启动"
    demo = os.path.join(OUT, "hotpatch_demo")
    code = cv.extract_elf_function(demo, "f_protected")
    bc = cv.get_codevm().compile(code, seed=0x5EED)
    p = os.path.join(E.d, "hotpatch.csvm")
    open(p, "wb").write(bc)
    r = subprocess.run([demo, p], capture_output=True, text=True, timeout=60)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "RESULT=PASS" in r.stdout, r.stdout
    n = re.search(r"VM_CALLS=(\d+)", r.stdout)
    assert n and int(n.group(1)) == 8, r.stdout
    return "函数头 5 字节 E9 改写 -> 冷启动 8/8 与原生一致，VM_CALLS=8"


@test
def t_pe_protect():
    if not E.have_win:
        return "SKIP", "缺 Windows 交叉工具链"
    assert len(E.new_pe) > len(E.pe)
    assert E.report["patched_head"].startswith("e9")
    assert E.report["section"] == ".csvm"
    assert E.report["relocations_added"] == 0
    assert E.report["bc_bytes"] > 0 and "TRAP" not in E.report["ir_listing"]
    return (f"PE {len(E.pe)}B -> {len(E.new_pe)}B；函数头 "
            f"{E.report['orig_head']} -> {E.report['patched_head']}；"
            f"新增 {E.report['section']} @ {E.report['section_rva']}")


@test
def t_pe_structure():
    if not E.have_win:
        return "SKIP", "缺 Windows 交叉工具链"
    d, rep = E.new_pe, E.report
    ep = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, ep + 6)[0]
    osz = struct.unpack_from("<H", d, ep + 20)[0]
    opt = ep + 24
    assert nsec == 3, nsec
    assert struct.unpack_from("<I", d, opt + 56)[0] == 0x4000
    imp_rva = struct.unpack_from("<I", d, opt + 112 + 8)[0]
    iat_rva = struct.unpack_from("<I", d, opt + 112 + 96)[0]
    assert iat_rva == int(rep["iat_rva"], 16)
    sec_off = opt + osz
    names = [d[sec_off + i * 40:sec_off + i * 40 + 8].rstrip(b"\0").decode()
             for i in range(nsec)]
    assert ".csvm" in names, names
    # 函数头 E9 目标 = stub RVA
    fo = int(rep["func_file_off"], 16)
    rel = struct.unpack_from("<i", d, fo + 1)[0]
    assert d[fo] == 0xE9
    assert int(rep["func_rva"], 16) + 5 + rel == int(rep["stub_rva"], 16)
    # 字节码魔数落在新节区
    raw = int(rep["section_raw_off"], 16)
    bc_off = int(rep["bc_rva"], 16) - int(rep["section_rva"], 16)
    assert d[raw + bc_off:raw + bc_off + 4] == b"CSVM"
    # 导入表指向 DLL 名
    desc = raw + (imp_rva - int(rep["section_rva"], 16))
    name_rva = struct.unpack_from("<I", d, desc + 12)[0]
    name_off = raw + (name_rva - int(rep["section_rva"], 16))
    assert b"CyrilShield.CodeVM.dll" in d[name_off:name_off + 40]
    return "3 节区 / SizeOfImage / Import+IAT 目录 / E9 目标 / CSVM 魔数 / DLL 名全部正确"


@test
def t_pe_stub_disasm():
    if not E.have_win:
        return "SKIP", "缺 Windows 交叉工具链"
    p = os.path.join(E.d, "stub.bin")
    open(p, "wb").write(E.stub)
    r = subprocess.run(
        ["objdump", "-D", "-b", "binary", "-m", "i386:x86-64",
         "--adjust-vma=" + str(int(E.report["stub_rva"], 16)), p],
        capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    txt = r.stdout
    want = [E.report["bc_rva"], E.report["func_rva"], E.report["iat_rva"]]
    for key in ("bc_rva", "func_rva", "iat_rva"):
        target = int(E.report[key], 16)
        found = re.search(r"#\s+0x%x\b" % target, txt)
        assert found, f"{key}=0x{target:X} 未出现在 stub 反汇编里"
    return (f"stub {len(E.stub)}B 反汇编：3 个 RIP 目标 "
            f"({', '.join(want)}) 全部正确")


@test
def t_pe_stub_exec():
    if not E.have_win:
        return "SKIP", "缺 Windows 交叉工具链"
    sp = os.path.join(E.d, "stub.bin")
    open(sp, "wb").write(E.stub)
    bp = os.path.join(E.d, "pe.csvm")
    # 从改写后的 PE 直接取回字节码
    raw = int(E.report["section_raw_off"], 16)
    bc_off = int(E.report["bc_rva"], 16) - int(E.report["section_rva"], 16)
    open(bp, "wb").write(E.new_pe[raw + bc_off:raw + bc_off + E.report["bc_bytes"]])
    exe = os.path.join(OUT, "pe_stub_verify")
    args = [exe, sp, bp, str(E.report["disp_bc_off"]),
            str(E.report["disp_func_off"]), str(E.report["disp_iat_off"])]
    r = subprocess.run(args, capture_output=True, text=True, timeout=60)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "RESULT=PASS" in r.stdout, r.stdout
    return "集成器生成的 Windows x64 stub 在真实 CPU 上执行 8/8 与参考一致"


@test
def t_windows_dll():
    if not E.have_win:
        return "SKIP", "缺 Windows 交叉工具链"
    p = os.path.join(OUT, "CyrilShield.CodeVM.dll")
    assert os.path.isfile(p)
    r = subprocess.run(["llvm-readobj", "--coff-exports", p],
                       capture_output=True, text=True)
    names = re.findall(r"Name:\s*(\S+)", r.stdout)
    assert "csvm_enter" in names, r.stdout[:300]
    imp = subprocess.run(["llvm-readobj", "--coff-imports", p],
                         capture_output=True, text=True)
    assert "msvcrt.dll" in imp.stdout
    assert "csvm_run_host_ex" in names, "DLL 未导出可注入 VM-exit 回调的入口"
    assert "csvm_run_host_fpu" in names, "DLL 未导出 XMM 全量进出的 FPU 入口"
    # 第八批抗提取：发布版只留 8 个运行入口，分析/构建接口一律不导出
    n = len([x for x in names if x.startswith("csvm_")])
    assert n == 8, f"发布版导出数应为 8，实得 {n}: {names}"
    for bad in ("csvm_compile", "csvm_compile_cfg", "csvm_disasm",
                "csvm_stats", "csvm_run", "csvm_run_regs"):
        assert bad not in names, f"发布 DLL 仍导出分析接口 {bad}"
    return (f"发布版 PE32+ DLL {os.path.getsize(p)}B，只导出 8 个运行入口；"
            "csvm_compile/compile_cfg/disasm/stats/run/run_regs 全部不导出，"
            "静态 dump 者拿不到自带反编译器；仅依赖系统 msvcrt.dll")


@test
def t_vmexit():
    """L2 VM-exit 桥：真实 gcc 函数里调外部 API，冷启动比对原生结果。"""
    if not _have("gcc"):
        return "SKIP", "缺 gcc"
    exe = os.path.join(OUT, "exit_demo")
    assert os.path.isfile(exe), "exit_demo 未构建"
    r = subprocess.run([exe], capture_output=True, text=True, timeout=120)
    out = r.stdout
    assert "RESULT=PASS" in out and r.returncode == 0, f"exit_demo:\n{out}\n{r.stderr}"
    assert "CALLEXT" in out, "外部调用未被识别为 VM-exit 原语"
    m = re.search(r"外部函数被真实调用 (\d+) 次", out)
    assert m and int(m.group(1)) == 14, "外部函数未被真正切回原生调用"
    assert "f_exit8 (含栈参数): PASS 7/7" in out, "栈参数（L2 上下文切换）未通过"
    return "6/8 参数两个真实函数各 7/7 与原生一致，外部函数被真调 14 次（寄存器+栈参数均正确）"


@test
def t_ff4_sse():
    """第七批：FF/4 间接跳转 + 标量 SSE，gcc -O2 真实函数端到端比对。"""
    if not _have("gcc"):
        return "SKIP", "缺 gcc"
    exe = os.path.join(OUT, "coverage_demo")
    assert os.path.isfile(exe), "coverage_demo 未构建"
    r = subprocess.run([exe], capture_output=True, text=True, timeout=120)
    out = r.stdout
    assert r.returncode == 0 and "RESULT=PASS" in out, f"coverage_demo:\n{out}\n{r.stderr}"
    for token in ("JMPI", "FSSE", "MOVSX"):
        assert token in out, f"反汇编未见 {token}（IR 证据缺失）"
    assert "FF4-TAIL: PASS 6/6" in out, "尾调用（函数外目标 VM-exit）未通过"
    assert "JUMPTABLE: PASS 15/15" in out, "switch 跳转表（函数内目标 VM 内闭环）未通过"
    assert "SSE-F64: PASS 7/7" in out, "标量 double 未逐位一致"
    assert "SSE-F32: PASS 7/7" in out, "标量 float 未逐位一致"
    return ("FF/4 尾调用 6/6、switch 跳转表 15/15、标量 SSE double/float 各 7/7 "
            "与原生一致（XMM0 返回逐位搬运）")


@test
def t_bc_format():
    """v5 变长加密容器 + v3.3.5 魔数 v6 / ABI 4 双 bump（新增 IR_ATOMIC）。"""
    if not os.path.isfile(os.path.join(OUT, "libcyrilshield_codevm.so")):
        return "SKIP", "缺已构建的 C 内核"
    vm = cv.get_codevm()
    code = bytes.fromhex("4889f8c3")           # mov rax,rdi; ret
    bc = vm.compile(code, seed=0xC0DE)
    assert bc[:4] == b"CSVM" and bc[4] == 6, f"magic 非 v6: {bc[:8]!r}"
    lib = ctypes.CDLL(vm.path)
    lib.csvm_abi_version.restype = ctypes.c_uint32
    assert lib.csvm_abi_version() == 4, "C ABI 版本未同步 bump 到 4"
    assert vm.run(bc, [7]) == 7, "v5 字节码无法执行"
    # 变长：不同 seed 编译长度不同（随机 padding/keystream），不再是 40B 定长明文
    bc2 = vm.compile(code, seed=0xC0DF)
    assert len(bc) != len(bc2), "v5 容器未随 seed 变长（疑似仍是定长明文）"
    # meta 已加密：加密区内不应出现明文 magic
    enc_off = struct.unpack_from("<I", bc, 20)[0]
    assert b"CSVM\x06\0\0\0" not in bc[enc_off:], "meta 明文落盘"
    # 旧 v4 魔数：必须按魔数拒绝，不能被当作 v5 误读
    old = bytearray(bc)
    old[4] = 4
    try:
        vm.run(bytes(old), [7])
    except cv.CodeVMError as exc:
        assert "魔数" in str(exc), str(exc)
    else:
        raise AssertionError("旧 v4 字节码未被拒绝")
    # 头/meta 篡改：hdr_mac 拒绝
    head = bytearray(bc)
    head[enc_off + 300] ^= 0x5A
    try:
        vm.stats(bytes(head))
    except cv.CodeVMError:
        pass
    else:
        raise AssertionError("头/meta 篡改未被 hdr_mac 拒绝")
    # 记录体篡改：执行到该 pc 时 rec_mac 拒绝
    n_insn = struct.unpack_from("<I", bc, 28)[0]
    enc_head = 576 + 8 * n_insn
    rec = bytearray(bc)
    rec[enc_off + enc_head + 6] ^= 0x5A
    try:
        vm.run(bytes(rec), [7])
    except cv.CodeVMError:
        pass
    else:
        raise AssertionError("记录体篡改未被 rec_mac 拒绝")
    return ("magic v6 / ABI 4 / 变长加密容器（逐条按需解密 + hdr_mac + rec_mac）；"
            "旧 v4 按魔数拒绝；头/记录篡改分别被 hdr_mac/rec_mac 拒绝")


@test
def t_checksum():
    """PE CheckSum 字段被真正重算（不再是 0），且与独立实现一致。"""
    if not E.have_win:
        return "SKIP", "缺 Windows 交叉工具链（无 win_target.dll）"
    pe = E.pe
    opt = struct.unpack_from("<I", pe, 0x3C)[0] + 24
    # 改写后的产物重新走一遍 protect_pe，取 CheckSum
    new, rep = integ.protect_pe(pe, E.func_rva, E.func_size, seed=0xABCD)
    off = opt + 64
    field = struct.unpack_from("<I", new, off)[0]
    assert field != 0, "CheckSum 仍为 0（虚标未修）"
    buf = bytearray(new)
    struct.pack_into("<I", buf, off, 0)
    s = 0
    i = 0
    while i + 1 < len(buf):
        s += buf[i] | (buf[i + 1] << 8)
        s = (s & 0xFFFF) + (s >> 16)
        i += 2
    if i < len(buf):
        s += buf[i]
        s = (s & 0xFFFF) + (s >> 16)
    s = (s & 0xFFFF) + (s >> 16)
    calc = (s + len(buf)) & 0xFFFFFFFF
    assert field == calc, f"CheckSum 不自洽: 0x{field:08X} != 0x{calc:08X}"
    return f"CheckSum=0x{field:08X} 非 0 且与 CheckSumMappedFile 等价算法一致；report 同步输出"


@test
def t_vmgen_wired():
    from cyrilshield import vmgen
    o = vmgen.VMOptions(virtualize=True, vm_func_rva=0x1000, vm_func_size=0x49)
    assert o.virtualize and o.vm_func_rva == 0x1000
    assert "virtualization" in vmgen.VMResult.__dataclass_fields__
    src = open(vmgen.__file__, encoding="utf-8").read()
    assert "from .vmp import integration" in src, "vmgen.py 未引用集成层"
    assert "integration.protect_pe" in src
    # 编排层端到端（不依赖 PyInstaller，只测字节变换）
    if E.have_win:
        new, rep = integ.protect_pe(E.pe, E.func_rva, E.func_size, seed=7)
        assert len(new) > len(E.pe) and rep["section"] == ".csvm"
    return "VMOptions/VMResult 字段齐全，vmgen.build() 在打包前调用 protect_pe() 改写载荷"


@test
def t_no_python_kernel():
    for f in (integ.__file__, cv.__file__):
        src = open(f, encoding="utf-8").read()
        for banned in ("decode_one", "lift_one", "run_blob", "eval_cc"):
            assert banned not in src, f"{os.path.basename(f)} 出现内核逻辑: {banned}"
    return "integration.py / codevm.py 只有 ABI 封装与文件编排，无反汇编/IR/解释器"


@test
def t_v5_demo():
    """第八批：用户点名的 4 类问题 + 抗提取容器，真实 gcc 机器码端到端。"""
    if not _have("gcc"):
        return "SKIP", "缺 gcc"
    exe = os.path.join(OUT, "v5_demo")
    assert os.path.isfile(exe), "v5_demo 未构建"
    r = subprocess.run([exe], capture_output=True, text=True, timeout=120)
    out = r.stdout
    assert r.returncode == 0 and "[v5] RESULT=PASS" in out, f"v5_demo:\n{out}\n{r.stderr}"
    for token in (
        "FPU-EXIT: PASS 6/6", "pow(2,3)+1 = 9", "NON-FPU-REJECT: PASS",
        "TAILEXIT: PASS 7/7", "CFG-COMPILE: PASS", "CFG-MULTISEG: PASS 7/7",
        "REP-MOVSB: PASS", "REP-STOSQ: PASS", "V5-MAGIC: PASS",
        "VARLEN: PASS", "META-ENCRYPTED: PASS", "TAMPER-HEADER: PASS",
        "TAMPER-RECORD: PASS", "REJECT-V4: PASS",
    ):
        assert token in out, f"v5_demo 缺证据: {token}\n{out}"
    return ("浮点跨 VM-exit pow(2,3)+1=9（非 3.0）且非 fpu 入口明确拒绝；"
            "TAILEXIT/多段 CFG 各 7/7；REP movsb/stosq；v5 变长加密容器"
            "变长 + meta 密文 + 头/记录篡改拒绝 + 旧 v4 拒绝")


@test
def t_batch():
    """第八批第 5 项：一次批量改写多个函数，共享 1 个 .csvm 节区 + 1 个 IAT。"""
    if not E.have_win:
        return "SKIP", "缺 Windows 交叉工具链（无 win_multi.dll）"
    p = os.path.join(OUT, "win_multi.dll")
    assert os.path.isfile(p), "win_multi.dll 未构建"
    data = open(p, "rb").read()
    rr = subprocess.run(["llvm-readobj", "--coff-exports", p],
                        capture_output=True, text=True)
    rvas = sorted(int(m, 16) for m in
                  re.findall(r"RVA:\s*(0x[0-9A-Fa-f]+)", rr.stdout))[:2]
    assert len(rvas) == 2, rr.stdout[:300]
    ep = struct.unpack_from("<I", data, 0x3C)[0]
    nsec = struct.unpack_from("<H", data, ep + 6)[0]
    sec_off = ep + 24 + struct.unpack_from("<H", data, ep + 20)[0]
    va = ro = rs = None
    for i in range(nsec):
        o = sec_off + 40 * i
        if data[o:o + 8].rstrip(b"\0") == b".text":
            vs, va, rs, ro = struct.unpack_from("<IIII", data, o + 8)
            break
    assert va is not None
    funcs = []
    for rva in rvas:
        start = ro + (rva - va)
        end = data.find(b"\xC3", start, start + min(rs, 64))
        assert end > start, f"RVA 0x{rva:X} 找不到 ret"
        funcs.append((rva, end - start + 1))
    from cyrilshield.vmp import sdk
    manifest = sdk.protection_manifest(sdk.scan_markers(
        "from cyrilshield.vmp.sdk import protect\n"
        "@protect(scope='vm', mutation=3)\ndef f_a(x):\n    return x\n"))
    new, rep = integ.protect_pe_batch(data, funcs, seed=0x5EED,
                                      sdk_manifest=manifest,
                                      on_line=lambda _s: None)
    assert rep["batch"] is True and rep["functions"] == len(funcs)
    assert rep["sections"] == nsec + 1, "应只新增 1 个 .csvm 节区（共享）"
    items = rep["items"]
    assert len(items) == len(funcs)
    stubs = [int(it["stub_rva"], 16) for it in items]
    bcrvas = [int(it["bc_rva"], 16) for it in items]
    assert len(set(stubs)) == len(funcs) and len(set(bcrvas)) == len(funcs), \
        "每个函数应有独立 stub 与字节码"
    assert rep["sdk_manifest"].get("count", 0) >= 1, "SDK 标注清单未写入报告"
    for (rva, _sz), stub in zip(funcs, stubs):
        fo = None
        for i in range(rep["sections"]):
            o = sec_off + 40 * i
            nvs, nva, nrs, nro = struct.unpack_from("<IIII", new, o + 8)
            if nva <= rva < nva + max(nvs, nrs):
                fo = nro + (rva - nva)
                break
        assert fo is not None and new[fo] == 0xE9, f"RVA 0x{rva:X} 函数头未改写"
        rel = struct.unpack_from("<i", new, fo + 1)[0]
        assert (rva + 5 + rel) & 0xFFFFFFFF == stub, \
            f"RVA 0x{rva:X} 未跳到自己的 stub"
    return (f"{len(funcs)} 个真实函数共享 1 个 .csvm 节区（节区数 {nsec}→"
            f"{rep['sections']}）与 1 个 IAT，两处 E9 各指向独立 stub，"
            "SDK 标注清单已入报告")


@test
def t_windows_coldboot():
    """第八批第 6 项：Windows 真机冷启动验证链（沙箱无真机，诚实边界）。"""
    p = os.path.join(NATIVE, "tools", "win_coldboot_verify.ps1")
    assert os.path.isfile(p), "缺失 Windows 真机冷启动验证脚本"
    src = open(p, encoding="utf-8").read()
    for token in ("LoadLibrary", "GetProcAddress", "csvm_enter",
                  "COLDBOOT", "CyrilShield.CodeVM.dll", "RESULT=",
                  "csvm_disasm", ".csvm"):
        assert token in src, f"验证脚本缺 {token}"
    return ("win_coldboot_verify.ps1 齐备：真机 LoadLibrary 冷启动 + 原生/VM "
            "结果逐项比对 + .csvm/导入表/去导出复核；沙箱无 Windows 真机，"
            "本项只验证脚本齐备，真机执行需用户在本机运行（诚实边界）")


@test
def t_thread_ctx():
    """第九批：多线程 VM 上下文 —— 并发执行 / 并发 VM-exit / 可重入 / 故障隔离。
    Windows 真机侧（v3.2.4）：用 zig cc 静态编 win_thread_demo.exe 并实跑 4 项。"""
    if os.name == "nt":
        zig = shutil.which("zig") or (r"D:\zig\zig.exe" if os.path.isfile(r"D:\zig\zig.exe") else None)
        if not zig:
            return "SKIP", "Windows 无 zig/MinGW 工具链"
        src_root = os.path.dirname(os.path.abspath(__file__))
        exe = os.path.join(OUT, "win_thread_demo.exe")
        r = subprocess.run(
            [zig, "cc", "-target", "x86_64-windows-gnu", "-std=c11", "-O2",
             "-fms-extensions",
             "-I", os.path.join(src_root, "native", "include"),
             os.path.join(src_root, "native", "src", "win_thread_demo.c"),
             os.path.join(src_root, "native", "src", "codevm.c"),
             os.path.join(src_root, "native", "src", "exit_trampoline.c"),
             "-o", exe],
            capture_output=True, text=True, timeout=180)
        assert r.returncode == 0, f"win_thread_demo 编译失败:\n{r.stderr[-800:]}"
        r = subprocess.run([exe], capture_output=True, text=True, timeout=180)
        out = r.stdout
        assert r.returncode == 0 and "[win-thread] RESULT=PASS" in out, \
            f"win_thread_demo:\n{out}\n{r.stderr}"
        for token in ("[1] 单线程池复用 2000 次：2000 正确 / 0 错",
                      "[2] 8 线程 × 2000 次：8 线程全过 / 0 失败",
                      "[3] 8 线程并发 VM-exit 3200 次：8 线程全过 / 0 失败",
                      "[4] 故障隔离：8 项通过 / 0 项失败"):
            assert token in out, f"win_thread_demo 缺证据: {token}\n{out}"
        return ("Windows 真机（zig cc / MinGW CRT）：TLS 上下文池复用 2000 次；"
                "8 线程 × 2000 次两 seed 容器交替全对；8 线程并发 VM-exit 3200 次"
                "（宿主函数真实调用 3200 次、返回值回填校验）；1 线程 VM-exit 里 AV "
                "被 SEH 安全网捕获为 TRAP，其余线程不受影响；真机 PASS")
    if not _have("gcc"):
        return "SKIP", "缺 gcc"
    exe = os.path.join(OUT, "thread_demo")
    assert os.path.isfile(exe), "thread_demo 未构建"
    r = subprocess.run([exe], capture_output=True, text=True, timeout=180)
    out = r.stdout
    assert r.returncode == 0 and "[thread] RESULT=PASS" in out, f"thread_demo:\n{out}\n{r.stderr}"
    for token in ("PARALLEL-BASIC         PASS", "PARALLEL-EXIT          PASS",
                  "REENTRANT              PASS", "FAULT-ISOLATED         PASS",
                  "CONCURRENT-COMPILE     PASS", "EXIT-THROUGHPUT        PASS"):
        assert token in out, f"thread_demo 缺证据: {token}\n{out}"
    assert "16000 次结果与原生一致" in out
    return ("8 线程 × 2000 次两 seed 交替执行全部正确；8 线程并发 VM-exit 3200 次正确；"
            "嵌套 VM（VM→宿主→VM）2400 次正确；单线程故障被安全网捕获为 TRAP 且其余 7 线程不受影响；"
            "并发编译一致；分派表去全局 + 每线程上下文池（含吞吐数据）")


@test
def t_elf_entry():
    """第十批：Linux 程序加固打包入口 —— 符号发现 -> 编译 -> 运行时挂钩 -> 结果与原生一致。"""
    if not _have("gcc"):
        return "SKIP", "缺 gcc"
    hook = os.path.join(OUT, "libcsvm_elfhook.so")
    assert os.path.isfile(hook), "libcsvm_elfhook.so 未构建"
    tmp = tempfile.mkdtemp(prefix="csvm_elf_")
    src = os.path.join(tmp, "demo.c")
    with open(src, "w") as f:
        f.write("""
#include <stdio.h>
#include <stdint.h>
__attribute__((noinline,noipa)) uint64_t f_secret(uint64_t x, uint64_t y){
    uint64_t a = x * 3 + 7; uint64_t b = y % 7;
    return (a ^ b) + 0x1234;
}
__attribute__((noinline,noipa)) uint64_t f_sum(const uint64_t *p, int n){
    uint64_t s = 0;
    for (int i = 0; i < n; ++i) { if (p[i] & 1) s += p[i]; else s ^= p[i]; }
    return s ^ (uint64_t)n;
}
int main(void){
    uint64_t buf[16]; for (int i = 0; i < 16; ++i) buf[i] = (uint64_t)(i * 37 + 11);
    uint64_t s = 0;
    for (uint64_t i = 0; i < 6; ++i) s += f_secret(i, i + 1);
    printf("%llu %llu\\n", (unsigned long long)s, (unsigned long long)f_sum(buf, 16));
    return 0;
}
""")
    exe = os.path.join(tmp, "demo")
    subprocess.run(["gcc", "-O2", "-fcf-protection=full", src, "-o", exe],
                   check=True, capture_output=True)
    native = subprocess.run([exe], capture_output=True, text=True, timeout=60).stdout.strip()
    payload = exe + ".csvmpayload"
    pr = subprocess.run([sys.executable, "-m", "cyrilshield.vmp.protect_elf",
                         exe, "f_secret", "f_sum", "-o", payload],
                        cwd=ROOT, capture_output=True, text=True, timeout=120)
    assert pr.returncode == 0, pr.stderr[-400:]
    assert "2 个函数" in pr.stdout
    env = dict(os.environ, LD_PRELOAD=hook, CSVM_ELF_PAYLOAD=payload, CSVM_ELF_DUMP="1")
    rr = subprocess.run([exe], capture_output=True, text=True, timeout=120, env=env)
    assert rr.returncode == 0, f"加固后运行失败：{rr.stderr[-400:]}"
    got = rr.stdout.strip()
    assert got == native, f"加固结果与原生不一致：VM={got} 原生={native}"
    assert "已挂钩" in rr.stderr, "没有挂钩成功"
    calls = [int(m) for m in re.findall(r"VM 调用 (\d+) 次", rr.stderr)]
    assert calls and sum(calls) >= 7, f"VM 调用次数不足：{calls}"
    return (f"2 个函数（含 endbr64 保留）挂钩成功、VM 调用 {sum(calls)} 次；"
            f"输出与原生逐字节一致：{native}")


@test
def t_regression():
    res = []
    for name in ("selftest_codevm.py", "selftest_vmp.py"):
        p = os.path.join(ROOT, name)
        r = subprocess.run([sys.executable, p], capture_output=True,
                           text=True, timeout=300)
        m = re.search(r"合计\s+\d+\s+项：通过\s+(\d+).*?失败\s+(\d+)", r.stdout)
        assert m, f"{name}: {r.stdout[-300:]}"
        res.append(f"{name}={m.group(1)}通过/{m.group(2)}失败")
        assert m.group(2) == "0", f"{name} 有失败项"
    return "、".join(res)


@test
def t_elf_ui_entry():
    """ELF 入口 UI 链路：符号过滤 + 逐函数跳过 + payload 结构（跨平台）。"""
    from cyrilshield.vmp import protect_elf
    sample = os.path.join(OUT, "libcsvm_elfhook.so")
    if not os.path.isfile(sample):
        return "SKIP", "缺 Linux 侧样本 libcsvm_elfhook.so"
    d = protect_elf.inspect(sample)
    assert d["arch"] == "x86-64", d["arch"]
    assert not d["stripped"], "样本应带符号表"
    names = [f["name"] for f in d["functions"]]
    assert names, "未解析出任何函数符号"
    # 关键回归：未定义导入（st_shndx==0）不能被当作可保护函数
    bogus = [n for n in names if "@" in n and n.split("@")[0] in
             ("getenv", "free", "fread", "fclose", "snprintf", "sigaction")]
    assert not bogus, f"未定义导入混进函数清单：{bogus[:5]}"
    assert d["protectable"] >= 1, "没有可编译函数"

    out = os.path.join(E.d, "elf_probe.csvmpayload")
    ok_name = next(f["name"] for f in d["functions"] if f["ok"])
    # 一个必然超子集的 RVA（pushfq），验证「跳过而非整批失败」
    r = protect_elf.protect(sample, [ok_name], ["0x19f0:221"], out)
    assert r["count"] >= 1, "正常函数未能写入 payload"
    assert os.path.getsize(out) == r["payload_size"]
    with open(out, "rb") as f:
        assert f.read(8) == protect_elf.MAGIC
    skipped = len(r["skipped"])
    return (f"解析 {len(names)} 个函数符号（已滤掉未定义导入），"
            f"{ok_name} 编译成功，{skipped} 个超子集函数被单独跳过；"
            f"payload {r['payload_size']}B 以 CSVMELF1 开头")


def main():
    ok = skip = fail = 0
    width = max(len(n) for _, n in TESTS)
    print("=" * 82)
    print("CyrilShield 代码虚拟化集成层 — 端到端自检")
    print("=" * 82)
    try:
        for fn, name in TESTS:
            try:
                r = fn()
                if isinstance(r, tuple) and r[0] == "SKIP":
                    skip += 1
                    print(f"[SKIP] {name.ljust(width)}  {r[1]}")
                else:
                    ok += 1
                    print(f"[ OK ] {name.ljust(width)}  {r}")
            except Exception as exc:
                fail += 1
                print(f"[FAIL] {name.ljust(width)}  {type(exc).__name__}: {exc}")
    finally:
        E.close()
    print("-" * 82)
    print(f"合计 {len(TESTS)} 项：通过 {ok}，跳过 {skip}，失败 {fail}")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
