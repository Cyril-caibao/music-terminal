# -*- coding: utf-8 -*-
# 由 CyrilShield 生成：合法版本资源，用于降低加壳产物的误报
VSVersionInfo(
  ffi=FixedFileInfo(
    filevers=(3, 3, 5, 0),
    prodvers=(3, 3, 5, 0),
    mask=0x3f, flags=0x0,
    OS=0x40004, fileType=0x1, subtype=0x0, date=(0, 0)
  ),
  kids=[
    StringFileInfo([
      StringTable('040904b0', [
        StringStruct('CompanyName', 'CyrilShield'),
        StringStruct('FileDescription', 'Local EXE protection tool'),
        StringStruct('FileVersion', '3.3.5.0'),
        StringStruct('InternalName', 'CyrilShield'),
        StringStruct('LegalCopyright', 'Copyright (C) 2026 CyrilShield'),
        StringStruct('OriginalFilename', 'CyrilShield.exe'),
        StringStruct('ProductName', 'CyrilShield'),
        StringStruct('ProductVersion', '3.3.5.0')
      ])
    ]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])
  ]
)
