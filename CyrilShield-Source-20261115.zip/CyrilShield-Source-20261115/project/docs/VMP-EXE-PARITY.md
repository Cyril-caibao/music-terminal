# EXE 侧保护能力矩阵与实现边界

> **范围**：仅 Windows x64 PE 链路。安卓（`apk.py` / `axml.py` / `dexvm.py`）不在本次对标范围内，本次未改动一行。
> **排除项**：按用户要求，VMP 的「多平台矩阵」明确不做。
> **立场**：面向使用者自己拥有合法权利的程序，提高逆向与篡改门槛。「免杀强度」严格实现为**降低加壳产物的误报与静态特征命中**，见 [AV-COMPATIBILITY.md](AV-COMPATIBILITY.md)。
> **状态刷新**：矩阵与差距表已刷新至 **v3.3.5**（v3.2.4 handler 变异 / Windows SEH / 真机多线程、v3.3.3 内核单文件内嵌、v3.3.4 自动函数发现、v3.3.5 computed-goto 间接分派 + LOCK 原子子集 + unwind 元数据）。详见第 4 节、第十一批与第十二批对照。

## 0. 定位澄清（先读这一段）

本文标题里的「对标」指的是**功能清单逐项对齐**，即把 VMP 的能力项各做出一个
可运行、可自测的实现，**不是单点强度等价**。三个必须说清的事实：

1. **第五批把目标代码虚拟化接进产物，第六批补上 L2 VM-exit 桥，第七批补上
   `FF /4` 间接跳转与标量 SSE 基础子集，第八批补齐 VM-exit 浮点参数搬运、
   CFG 多段闭包、`rep movsb/stos` 字符串指令、多函数批量 + SDK 标注、v5 变长
   加密容器与发布 DLL 导出收敛，仍是可运行集成原型**。
   `vmgen.make_program()` 生成的仍是**固定语义的引导字节码序列**（壳 VM）。
   C 内核 `native/src/codevm.c` + PE 集成器 `peintegrate.c` 能把**真实目标
   x86-64 机器码**翻译进私有 ISA，改写 PE 函数头 5 字节为 `jmp` 到新 `.csvm`
   节区的 VM stub；`native/src/exit_trampoline.c` 让 VM 内的函数通过
   `IR_CALLEXT` 调用外部真实函数（Win x64 / SysV 上下文切换，整数参数 + 栈
   参数 + **浮点 XMM**）；第七/八批 `IR_JMPI` / `IR_FSSE` / `IR_REP` / `IR_TAILEXIT`
   让尾调用、switch 跳转表、标量浮点、字符串指令与跨段尾调用也能进 VM
   （`csvm_run_host_fpu` 全量进出 XMM）。`vmgen.build()` 在加密打包前调用
   `vmp/integration.protect_pe()` / `protect_pe_batch()` 完成改写。**启用后指定
   函数的代码确实进 VM**（见 [CODE-VM.md](CODE-VM.md) 第 6 节）。v3.3.4 起可
   勾选「自动发现函数」，由典型序言候选 + C 内核逐窗口编译验证自动给出函数
   边界，不必再手填 RVA 清单。但该能力**默认关闭**、指令子集仍受限
   （packed 整数 SSE2 与 LOCK 原子子集已补；仍缺 packed 逐 lane 浮点 /
   AVX-VEX / 完整异常穿透）；v3.2.4 已补 Windows `__try/__except` 安全网与
   8 线程真机实测，v3.3.5 已补 computed-goto 间接分派、per-run 异或分派
   副本、LOCK 原子子集与 stub 的 `.pdata`/`UNWIND_INFO`。**抗提取层有进展
   但仍不完整**：v5 变长加密容器 + 发布 DLL 导出收敛 + 4 选 1 handler 噪声
   变体已做；但静态标签数组仍留在 `.rdata`（第十三批实测 46 个连续明文
   指针）、按 pc 独立密钥未做、handler 变体仍是「前置不透明计算」、
   仅凭 blob 即可离线全量还原指令流（第十三批实测 7/7 条）。
   **未启用时交付 EXE 里目标代码依然不进 VM**，且即便启用也远非 VMP 的全量
   虚拟化，「已对标 VMP」仍不成立。
2. **解密后的数据流仍有落盘取货口，但不是「零成本」**。C / Python 外壳的
   载荷 EXE 主力路径已用 `FILE_FLAG_DELETE_ON_CLOSE | FILE_ATTRIBUTE_TEMPORARY`
   （`native/src/bootstub.c` / `antitamper.py`），磁盘上没有可随手复制的稳定
   文件；但同目录侧载的运行内核 DLL 仍是常规写盘、secure 失败会回落「跑完
   再删」，且解密后**完整原始 PE 明文仍连续存在于进程内存**。盯 minifilter、
   抓内存 dump、在 `CreateProcess` 前后下断点仍能取到；`tools/parity_audit.py`
   的 A5 把这几项做成了静态事实断言。要做到「磁盘与内存都不留完整映像」，
   缺的是驱动级 / 全内存态执行方案，本项目**明确不做**（见 SECURITY-NOTES 第五节）。
3. **因此准确定位**是「引导链 VM + 抽取式加固 + 保护能力套件 + 受限目标代码
   虚拟化」，防护量级接近早期商用壳基础版，与 VMProtect / Themida / 商用
   Dex-VMP 不是一类产品。

第五/六/七/八批已补齐 x86-64 反汇编 + 语义提升 + 私有 ISA 编译器 + 运行时
native⇄VM 上下文切换 + L2 VM-exit 桥 + `FF /4` 间接跳转与标量 SSE 基础子集 +
VM-exit 浮点参数 + CFG 多段闭包 + 字符串指令 + 多函数批量 + v5 变长加密容器 +
发布 DLL 导出收敛；v3.2.4 补 4 选 1 handler 噪声变体与 Windows SEH 安全网 +
8 线程真机实测，v3.3.4 补**多函数自动发现**（可不再手填 RVA 清单）。但只覆盖
**受限子集、默认关闭**；要做到 VMP 级「任意函数全量虚拟化」，仍缺指令全集
（packed 逐 lane 浮点 / AVX-VEX / x87 / 部分字节宽 TEST / 完整链式 unwind
与异常穿透 VM 帧）。`tools/parity_audit.py` 的 A6 在 3 份真实 PE 上实测
**直接编译通过率 53.5% / 53.5% / 52.5%**，并给出逐条拒绝原因清单——
「差一个量级」从此有可复跑的数字。抗提取层已做 computed-goto 间接分派 /
加密容器 / 去导出 / 噪声变体，但静态标签表、按 pc 独立密钥、跨 handler
等价指令重写、counterfeit 控制流仍未做（见第十三批）。
要做到真·不落地，缺的是驱动级或全内存态执行方案，本项目**明确不做**。
下表的 `状态` 列描述的是「本能力项有无可运行实现」，**不代表该单项达到
VMP 的强度**。

## 1. 对标矩阵

由 `cyrilshield.vmp.parity_report()` 实时生成（前端结果区也可展开查看）。

| key | VMP 能力项 | 状态 | 落地模块 | 说明 |
|---|---|---|---|---|
| `virtualization` | 代码虚拟化（目标 x86 → 自定义字节码 VM） | **`partial`** | `native/src/codevm.c`, `native/src/peintegrate.c`, `native/src/exit_trampoline.c`, `native/src/coverage_demo.c`, `native/src/v5_demo.c`, `vmp/integration.py`, `vmgen.py` | 第五批接入 PE 集成链路；第六批补 **L2 VM-exit 桥**（`IR_CALLEXT`，Win x64 / SysV 上下文切换）；第七批补 **`FF /4` 间接跳转**（尾调用 / switch 跳转表）与**标量 SSE 基础子集**；第八批补 **VM-exit 浮点参数**（XMM0-7/0-3 搬运，修掉静默算错 Bug）、**CFG 多段闭包**、**`rep movsb/stos` 字符串指令**、**多函数批量 + SDK 标注**、**v5 变长加密容器 / ABI 3**、**发布 DLL 导出收敛到 8 运行入口**，字节码升级 v5 / ABI 3。启用后指定函数确实进 VM，能跑带外部调用、栈参数、浮点参数与 XMM 返回、尾调用、跳转表、标量浮点、字符串指令与跨段尾调用的普通函数；**但仍默认关闭、受限子集（缺 packed 逐 lane 浮点 / AVX-VEX / 完整异常穿透；packed 整数 SSE2 与 LOCK 原子子集已有）**；v3.2.4 已补 **Windows `__try/__except` 异常安全网**（替换会挂死的 VEH 手工改 CONTEXT）与 **8 线程真机实测**（池复用 2000 次 / 8 线程两 seed 交替 / 3200 次并发 VM-exit / 故障隔离 8/8 全 PASS），TEB / 回调仍不在 L2 桥覆盖范围；第九批补 **Linux/POSIX 多线程 VM 上下文**（分派表去全局 + 每 run 一次信号安全网 + 每线程 frame 栈可重入 + 每线程上下文池），8 线程 16000 次交替执行 / 3200 次并发 VM-exit / 2400 次嵌套 VM 全过，ThreadSanitizer 无竞争，旧实现在同场景直接崩溃；**抗提取层不完整**：v5 容器 + 去导出 + 4 选 1 handler 噪声变体（v3.2.4）+ computed-goto 间接分派与 per-run 异或分派副本（v3.3.5）已做；但静态标签数组仍在 `.rdata`、按 pc 独立密钥与跨 handler 等价指令重写未做（第十三批实测 FAIL）。v3.3.3 运行内核已内嵌进单文件成品（无需同目录 DLL）；v3.3.4 补 **自动函数发现**（序言候选 + C 内核逐窗口编译验证边界，可替代手填清单）。详见 CODE-VM.md 第 6 节 |
| `mutation` | 代码变异 / 等价替换 | `implemented` | `vmp/obfuscation.py` | 死代码块、大整数异或分裂、常量编码，每次构建不同 |
| `string_encryption` | 字符串与常量加密 | `implemented` | `vmp/obfuscation.py` | 加盐 + 标签派生密钥流编码，stub 里只剩 base85 串 |
| `import_protection` | 导入表保护 | `implemented` | `vmp/obfuscation.py` | 编码名 + `importlib` 延迟解析 |
| `anti_debug` | 反调试 | `strengthened` | `antitamper.py` | 5 类探针：基础 API / 远程调试 / 调试端口与对象 / **硬件断点 Dr0-Dr3** / 单步计时 |
| `anti_vm` | 反虚拟机 / 反沙箱 | `strengthened` | `antitamper.py` | 6 类判据：进程 / 用户名 / 虚拟化驱动 / 规格 / **CPU 品牌** / **显示规格** |
| `memory_protection` | 内存保护 / 抗 dump | `partial` | `vmp/memory.py` | 分块独立解密、用完即擦、delete-on-close；真·不落地需驱动级方案，本项目不做 |
| `integrity` | 完整性自校验 | `strengthened` | `vmp/integrity.py` | 双分块哈希链（4096 / 7777）+ 交叉校验 + 壳内运行时自校验 |
| `licensing` | 授权 / HWID / 到期 / 功能位 | `implemented` | `vmp/license.py`, `native_bridge.py` | HMAC-SHA256 离线许可，不联网、不激活 |
| `watermark` | 水印 | `implemented` | `vmp/license.py`, `vmp/compat.py` | 随 `--add-data` 打进包 + 构建清单；独立 PE 支持 overlay 嵌入 |
| `sdk_markers` | SDK 标记选择保护范围 | `implemented` | `vmp/sdk.py` | 装饰器 + AST 静态扫描，生成保护范围清单 |
| `compression` | 加壳压缩 | `implemented` | `upx.py` | 内置 UPX 5.3.0 |
| `polymorphism` | 多态 | `strengthened` | `vmp/polymorph.py` | opcode / 槽位 / 符号名 / 盐 / 编码串全随机，输出构建指纹并自检互异 |
| `av_compatibility` | （本项目扩展）降低误报 | `implemented` | `vmp/compat.py` | `--version-file` 版本资源、图标沿用、熵/节名/W^X 审计、申诉清单 |

状态含义：`implemented` = 已落地可自测；`strengthened` = 本轮在既有基础上增强；`partial` = 有工程实现但受架构边界限制，无法等价商业壳。

## 2. 架构与数据流

### 构建期（`vmgen.build`）

```
输入 PE
  ├─ make_plan / make_program      随机 opcode、槽位、寄存器角色、垃圾指令
  ├─ _make_vmp_context
  │    ├─ integrity.make_plan     对 VM 字节码算双哈希链
  │    └─ license.issue          签发 HMAC 离线许可（可选 HWID 绑定）
  ├─ _vmp_postprocess（stub 源码）
  │    ├─ obfuscation.obfuscate_stub
  │    │    · seal 占位符（MAGIC/SALT/PROG/PAYLOAD/TITLE/DIGEST）
  │    │    · 大整数异或分裂 · 死代码块 · 动态解析片段
  │    ├─ antitamper.bootstrap_source   守卫压缩编码注入
  │    └─ _inject_before_main
  │         · 分块内存保护函数 · SDK 范围清单
  │         · 完整性链校验 · 离线许可校验
  ├─ compat.version_file_source   → --version-file（RT_VERSION）
  ├─ cs_manifest.json             → --add-data（水印/完整性/申诉清单）
  ├─ [可选] integration.protect_pe  启用目标代码虚拟化时：改写函数头 / 新增 .csvm
  └─ PyInstaller onefile 编译
        └─ compat.av_compat_audit → 误报风险评分
```

### 运行期（外壳）

```
启动 → 守卫检查（默认关闭/异常放行） → 完整性链校验 → 离线许可校验
     → VM 解释器逐条执行字节码 → 分块解密载荷（用完即擦）
     → delete-on-close 释放 → CreateProcess 原程序 → 清理

改写后的目标函数（启用虚拟化时）：
  call f → 函数头 E9 → .csvm stub → csvm_enter → 解释器
        → 命中 IR_CALLEXT → exit_trampoline 切宿主栈 → call 外部真实函数
        → 回写 GPR → 回 VM → RET（返回值与原生一致）
        → 命中 IR_JMPI → 函数内目标按 src_off 回填 bc 索引（VM 内闭环）
                        / 函数外目标 VM-exit tail（RAX 即返回值）
        → 命中 IR_FSSE → VM 内 XMM 寄存器文件运算（csvm_run_host_fpu 进出）
```

## 3. 底层架构：侧载接入 Python

见 [NATIVE-SIDECAR.md](NATIVE-SIDECAR.md)。要点：Python 不提权，把硬件访问委托给
显式加载并校验摘要的原生伴随库（C11 / 稳定 C ABI / 能力门 / 失败降级）。

## 4. 与商业 VMP 的真实差距（不回避）

| 项 | 现状 |
|---|---|
| 任意函数级 x86/x64 虚拟化 | **部分实现（受限子集）**。第五~八批已能改写单个或批量真实函数进 VM，支持外部调用（L2 VM-exit）、`FF /4` 尾调用与 switch 跳转表、标量 SSE 浮点、**VM-exit 浮点参数**、`rep movsb/stos` 字符串指令、CFG 跨段闭包；v3.2.4 补 Windows SEH 异常安全网与 8 线程真机实测，v3.3.4 补自动函数发现（无需手填清单）。仍默认关闭；v3.3.5 已覆盖 32/64 位 LOCK 原子 RMW 子集与 stub 的 .pdata/UNWIND_INFO（带 EH 处理器函数自动跳过），packed SIMD / AVX、完整链式异常展开仍未覆盖，离「任意函数」与商业 VMP 全量虚拟化仍差一个数量级 |
| 抗提取 / 字节码形态 | **有进展但不完整（诚实标注）**。第八批完成 v5 变长加密容器（逐条按需解密 + hdr_mac + rec_mac + 随 seed 变长）+ 发布 DLL 导出收敛到 8 个运行入口；v3.2.4 补每逻辑 op 4 选 1 的 handler 噪声变体（标准 + 3 套等价不透明计算，seed 逐 op 选择），v3.3.3 把运行内核内嵌进单文件成品。v3.3.5 用 `.inc` 共享语义体把中心 switch 换成 computed-goto，**运行时**分派副本逐 run 异或。**第十三批实测修正**：静态 `cg_plain[]` 标签数组仍整表留在 `.rdata`（46 个连续明文代码指针），「静态 dump 不再有明文 handler 地址表」这句此前是错的；且 seed/salt 明文存于文件头、keystream 常量随源码公开，纯脚本即可**仅凭 blob 离线还原 7/7 条指令**。**仍未做**：跨 handler 等价指令重写、按 pc 独立密钥、counterfeit 控制流。整段拷贝型提取成立 |
| 真·不落地 / 抗内核 dump | **未实现**。需要驱动或进程镂空级方案，属于本项目明确边界外 |
| .NET / ARM64 / macOS / Linux | **明确排除**（用户指定） |
| Windows 真机验证 | **已实跑（v3.2.4 起）**。`win_thread_demo` 本机 zig cc → x86_64-windows-gnu 实测 `RESULT=PASS`：池复用 2000 次、8 线程 × 2000 次两 seed 交替、3200 次并发 VM-exit、SEH 故障隔离 8/8；v3.3.3 / v3.3.4 另有 `tools_test_333.py` / `tools_test_334.py` 真机 E2E（单文件内核释放、自动发现产物 `rc=0`）。`native/tools/win_coldboot_verify.ps1` 的 LoadLibrary 冷启动脚本保留供复核 |
| 商业化强度 | VMP 是十余年积累的产品；本轮做到的是**能力项齐全 + 架构可扩展 + 全部可自测**，不代表单点强度等价 |

## 5. 使用

**Web UI**：VM 页面新增「VMP 对标层（EXE）」卡片，可开关对标层、配置产品/公司/版本、
启用离线授权（密钥、到期日、目标 HWID）、生成版本资源与申诉清单；另有「目标代码
虚拟化（C 内核 · PE 集成）」卡片填函数 RVA 与长度。结果区展示已启用能力数、
误报审计评分、常量加密处数、死块数、授权状态，并可展开完整对标矩阵。

**API**：`POST /api/vm` 的 `opts` 增加

```json
{
  "vmpEnabled": true,
  "vmpConfig": {
    "mutation_level": 2,
    "product_name": "My App",
    "company_name": "My Corp",
    "file_version": "1.2.3.4",
    "av_compatibility": true,
    "licensing": true,
    "license_secret": "...",
    "license_expires": "2027-12-31",
    "extras": { "license_hwid": "" }
  }
}
```

返回结果增加 `vmp`：`capabilities` / `obfuscation` / `av_score` / `av_issues` /
`integrity_root` / `license` / `parity`。

**自检**：

```bash
python selftest_codevm.py                  # 10 项，C 内核
python selftest_vmp.py                     # 25 项，全部与 EXE 侧相关
python selftest_integration.py             # 19 项（12 通过 / 7 跳过），含 FF/4+SSE / 字节码 v5 容器 / FPU 跨 VM-exit / CFG 多段 / REP / L2 VM-exit / PE CheckSum / 多函数批量 / 真机冷启动验证链
python selftest.py tools/upx.exe           # 原有全量自检（守卫用例全绿）
```

## 6. 本次新增文件

| 路径 | 作用 |
|---|---|
| `native/include/cyrilshield_native.h` | 侧载层 C ABI |
| `native/include/cs_codevm.h` | 代码虚拟化内核 C ABI（v2 宿主内存 / v3 L2 VM-exit / v4 FF-SSE / **v5 字符串+CFG+FPU+变长容器，ABI 3**） |
| `native/src/sidecar.c` | 侧载层实现（内嵌 SHA-256，零依赖） |
| `native/src/codevm.c` | 代码虚拟化内核：反汇编 → IR → 私有 ISA → 解释器；`IR_CALLEXT` / `IR_JMPI` / `IR_FSSE` / `IR_REP` / `IR_TAILEXIT` / `IR_SETDF` / XMM 文件 |
| `native/src/codevm_main.c` | `csvm` CLI |
| `native/src/peintegrate.c` | PE32+ 集成器（新 `.csvm` 节区 / 导入表 / 函数头 `E9` / CheckSum 重算） |
| `native/src/hotpatch_demo.c` | ELF hotpatch + 上下文切换 + 冷启动 |
| `native/src/pe_stub_verify.c` | 在 Linux 上真实执行生成的 Windows x64 stub |
| `native/src/exit_trampoline.c` | **L2 VM-exit 桥**：Win x64 / SysV 汇编上下文切换桩；`csvm_default_exit`（GPR）/`csvm_default_exit_fpu`（XMM0-7/0-3 搬运 + XMM0 返回） |
| `native/src/exit_demo.c` | **L2 端到端验证**（6 / 8 参数真实函数调外部函数） |
| `native/src/coverage_demo.c` | **第七批端到端验证**：FF/4 尾调用 + switch 跳转表 + 标量 SSE double/float |
| `native/src/win_int128.c` | Windows clang 交叉补 `__udivti3` / `__divti3` |
| `native/win_shim/*` | 最小 CRT 头 + `msvcrt.def`（零 SDK 依赖交叉编译） |
| `native/samples/*.c` | 真实编译样本（reference / integration / win_target） |
| `native/build.sh` / `build-win.sh` / `build.bat` | Linux（10 步）/ 交叉（发布 DLL 只导 8 个运行入口）/ Windows 原生构建 |
| `native/out/*` | 预编译 Linux 工具 + 真实 Windows DLL / LIB |
| `cyrilshield/native_bridge.py` | Python 桥接 + 能力门 + 降级 |
| `cyrilshield/vmp/__init__.py` | 能力矩阵 / `VMPProfile` / 对标报告 |
| `cyrilshield/vmp/compat.py` | 误报审计 / 版本资源 / 清单 |
| `cyrilshield/vmp/integrity.py` | 双哈希链 + 壳内自校验 |
| `cyrilshield/vmp/license.py` | 离线授权 / HWID / 水印 |
| `cyrilshield/vmp/obfuscation.py` | 常量加密 / 变异 / 动态解析 |
| `cyrilshield/vmp/memory.py` | 分块解密 / 即时擦除 |
| `cyrilshield/vmp/polymorph.py` | 多态构建指纹 |
| `cyrilshield/vmp/sdk.py` | SDK 标记扫描 |
| `cyrilshield/vmp/codevm.py`, `vmp/integration.py` | Python 编排（ABI 封装 / PE 集成编排，无内核逻辑） |
| `selftest_codevm.py`, `selftest_vmp.py`, `selftest_integration.py` | 内核 / 能力层 / 集成层自检 |

**修改**：`vmgen.py`（对标层 + 虚拟化接线 + `--version-file` + 构建清单）、
`antitamper.py`（探针增强）、`server.py`、`web/index.html`、`web/app.js`、
`重建EXE.bat`、`README.md`、`CyrilShield/README.md`、`CHANGES.md`。

## 第九批对照：多线程上下文（新增）

| 能力 | 商业 VMP | 本项目 | 差距 |
|---|---|---|---|
| 每线程独立 VM 上下文 | 有（线程池 + 线程局部状态） | **有**（借用/归还/擦除 + pthread_key 回收，嵌套自动再借） | 无（本项已对齐） |
| 并发 VM-exit | 有 | **有**（run 级安装 + 引用计数 + 每线程 frame 栈；v3.2.4 Windows `__try/__except` 安全网） | 无（本项已对齐） |
| 可重入（VM→宿主→VM） | 有 | **有**（frame 栈嵌套，2400 次实测） | 无 |
| 分派表线程安全 | 有 | **有**（去全局，纯函数掩码） | 无 |
| 真机多线程冷启动 | 有 | **已验证**（v3.2.4 本机 8 线程实测 `RESULT=PASS`） | 无（本项已对齐） |

## 第十一批对照：自动函数发现（v3.3.4）

| 能力 | 商业 VMP | 本项目 | 差距 |
|---|---|---|---|
| 自动识别可保护函数 | 有（符号 / 启发式 / 过程分析） | **有（启发式）**：典型 x64 序言候选 + C 内核逐窗口编译验证，末条 IR 必须是 `RET` / `TAILEXIT` / `HALT` 才采纳 | 无 PDB / 符号表解析，边界是启发式；生产仍建议反汇编复核 |
| 免手填 RVA 清单 | 有 | **有**：Web UI 勾选「自动发现函数」+ 上限 1~64，统计写进报告 `auto_discover` | 无 |
| 压缩壳输入兼容 | — | **有**：packed 节区（`SizeOfRawData=0`）直接跳过并如实报告 | 无 |
| 失败降级 | 有 | **有**：无候选时跳过函数级虚拟化、保留 VM 外壳；单函数编译失败逐函数降级 | 无 |
| 任意函数全量虚拟化 | 有 | **未达成**：仍默认关闭、指令子集受限（第十三批实测直接编译通过率 52.5~53.5%） | packed 逐 lane 浮点 / AVX-VEX / 完整链式 unwind 仍缺；packed 整数 SSE2 与 LOCK 原子子集已有 |

实现：`vmp/integration.discover_pe_functions()`、`vmgen.VMOptions.vm_auto_discover`、
`server.py` / `web/index.html` / `web/app.js` 接线；回归脚本 `tools_test_334.py`。
对用户此前手填 `1000:49` 的 Portable 输入，自动发现给出 `0x1000 / 47`
（自动裁掉尾部 int3 填充与下一函数前缀），与 v3.3.2 尾部容试算出的真实边界一致。

**诚实边界**：序言是启发式，不是符号表；自动发现用于快速评估与演示，
把虚拟化的门槛从「会用 IDA 查 RVA」降到「勾一个框」，但不改变
「默认关闭、受限子集、非 VMP 强度」的基本定位。


---

## 第十二批对照：间接分派 / 原子 / 异常展开（v3.3.5）

| 能力 | 商业 VMP | 本实现 | 剩余差距 |
| --- | --- | --- | --- |
| 中心 switch 消除 | 有（threaded/computed-goto） | **有**：`codevm_ops.inc` 共享 case 体，GNU/clang 下 `goto *enc[lop]` 间接分派；MSVC 回退 switch | 未做跨 handler 等价指令重写 |
| 分派表静态不可读 | 有 | **部分**：运行时 `cg_enc[]` 逐 run 异或，但静态 `cg_plain[]` 仍在 `.rdata`（第十三批实测 46 个连续明文指针） | 静态标签表未去除；按 pc 逐条独立密钥未做 |
| handler 多态 | 有 | **有**：4 选 1 噪声变体（v3.2.4）+ 间接分派（v3.3.5） | 变体仍是「前置不透明计算」，非等价指令序列 |
| LOCK 原子指令 | 有 | **有（子集）**：CMPXCHG / XADD / XCHG / ADD / OR / AND / SUB / XOR / BTS / BTR / BTC / INC / DEC / NOT / NEG，单次 `__atomic` RMW | 8/16 位、带 index 寻址、非对齐、自定义内存回调明确拒绝 |
| 原子语义 | 有 | 宿主真实内存模式对**真地址**原子（跨线程真原子）；沙箱模式对 VM 内存原子 | VM 内模拟内存不等于进程共享内存 |
| 异常展开元数据 | 有 | **有（子集）**：stub 共享 UNWIND_INFO（8 个 SAVE_NONVOL + ALLOC_LARGE）、原 .pdata 保留 + stub RUNTIME_FUNCTION、dd[3] 重定向 | call 期间额外 ±32 影子空间未做链式展开 |
| 带 EH 函数处理 | 有 | **自动跳过**：只筛 `EHANDLER/UHANDLER/CHAININFO` 标志，普通 .pdata 函数照常虚拟化 | 不把可展开函数变成不可展开函数，但也不虚拟化它们 |
| 字节码 ABI | — | 魔数 `CSVM\x06` / ABI 4（新增 `IR_ATOMIC`），旧字节码按魔数拒绝 | 破坏性变更，旧产物需重新构建 |

实现：`native/src/codevm_ops.inc`（新增）、`native/src/codevm.c`、
`native/src/peintegrate.c`、`native/include/cs_codevm.h` /
`csvm_container.h`、`vmp/integration.py`、`vmp/codevm.py`、
`server.py`、`web/app.js`；回归脚本 `tools_test_335.py`（24 项）。
三份原生产物用 `zig cc -fms-extensions` 重编，发布版仍保持 8 导出白名单。

**诚实边界**：computed-goto 消灭的是「单一中心分派点」这一静态特征，不是
抗动态调试；原子子集覆盖常见编译器 atomic / 自旋锁编码，不覆盖全部 LOCK
形式；unwind 子集保证 stub 有合法展开元数据、原异常表不被破坏，但**不宣称
异常能穿透 VM 帧被原函数的 handler 捕获**——这类函数直接跳过虚拟化。

---

## 第十三批对照：外部评审逐条核验 + 攻击者视角基线（v3.3.5 之后的审计，未发版）

> 评审给了 4 条差距。全部对着代码与实际交付的二进制核过一遍，不做全盘认领，
> 也不空口否认。**结论：2 条已过时、1 条方向对但描述失真、1 条属实**，
> 并在核验过程中查出**两处比评审更严重的自报失真**。

### 13.1 逐条核验

| # | 评审原话（摘要） | 核验结论 | 依据 |
| --- | --- | --- | --- |
| 1 | 「packed SIMD / AVX / 完整异常展开没有 → 做不到任意函数全量虚拟化，只能挑子集、默认关闭」 | **部分过时，结论属实** | packed **整数** SSE2 已实现并验证（`packedsimd_demo.c`：`paddb/w/d/q`、`psub*`、`pand/por/pandn`、`pcmpeq*`、`pshufd`、`packssdw`；`codevm.c:597-637` 的 `FOP_PINT` / `FOP_PSHUFD` / `FOP_PACKSSDW`）；**原子**已于 v3.3.5 落地（`IR_ATOMIC`，`codevm.c:341/528/1591`）；异常展开**元数据**已生成（`peintegrate.c` 共享 UNWIND_INFO + 原 `.pdata` 保留）。仍缺的是 **packed 逐 lane 浮点、AVX/VEX/YMM、完整链式 unwind 与异常穿透 VM 帧**（带 EH 的函数直接跳过）。`vmgen.VMOptions.vm_auto_discover=False`、`vmp_config` 默认空 → 「默认关闭」属实。「任意函数全量虚拟化做不到」属实 |
| 2 | 「没做逐条（per-pc）独立加密，整段内存仍可拷贝提取；handler 只是前置不透明计算变体，不是跨 handler 等价指令重写」 | **属实（含精确口径）** | 已有的是 v5 变长容器：每条记录独立长度 / 随机 padding / **按绝对偏移切片的同一条全局 keystream** / 按 pc 绑定的 `rec_mac` / 运行时按需解密到栈并擦除（`csvm_container.h:171-237,340-372`）。**没有**的是「每条指令独立派生的密钥」：`fh.seed` 与 `salt` 明文写在文件头，`CSVM_KS_CONST` 是随源码公开的固定常量 → 纯脚本即可仅凭 blob 离线还原全部指令（A3 实测 7/7）。handler 变体 `exec_op_noisy1/2/3`（`codevm.c:1625-1670`）确实只是算一个 `volatile` 哑值后调用**同一个** `exec_step`，不是等价指令序列重写 |
| 3 | 「明文落 `%TEMP%`，盯临时目录零成本拿原文件；没驱动级 / 进程镂空，这是明确边界」 | **方向属实，「零成本」已过时；后半是红线** | C 外壳载荷 EXE 主力路径用 `FILE_FLAG_DELETE_ON_CLOSE \| FILE_ATTRIBUTE_TEMPORARY`（`bootstub.c:814-817`），Python 外壳同理（`antitamper.py:331-337`）；但**侧载运行 DLL 仍是常规写盘**（`cs_write_side_dll`）、secure 失败有常规回落、解密后完整明文连续存在进程内存。驱动 / 进程镂空 / 反射加载明确不做（`SECURITY-NOTES.md` 第五节、`RED-TEAM-ROE.md` 第一节），不是「待补功能」而是定位选择 |
| 4 | 「没做过针对 IDA、模拟执行器、脱壳工具的对抗测试」 | **属实，且代价已经显现** | 原有 `selftest*` / `tools_test_*` 全是功能性回归，没有一项从攻击者视角检查交付二进制。本次补 `tools/parity_audit.py` 后**第一次**扫 DLL，就发现第十二批写的「`.rdata` 无明文地址表」不成立 |

### 13.2 自动化基线 `tools/parity_audit.py`

刻意**不 import 项目自身的 `cyrilshield` 包**：攻击者拿到的是交付的 DLL 与 PE，
不是源码编排层。脚本直接 `ctypes` 调 `csvm_compile` / `csvm_run`、自解析 PE
导出表与 `.pdata`，覆盖率部分放隔离子进程（内核若在某片段崩溃不会带走主审计，
且崩溃本身记为一条发现）。

```bash
python tools/parity_audit.py --json .lab/parity_audit.json
```

| 检查 | 结果 | 实测 |
| --- | --- | --- |
| A1 发布运行 DLL 导出白名单 | **PASS** | `runtime.dll` 8 个运行入口，无 `compile/disasm/stats/run/run_regs`；构建期 DLL 14 个导出但仅用于构建 |
| A2 `.rdata` 明文分派地址表 | **FAIL** | 113 个落在 `.text` 的代码指针，其中 **46 个连续**排列（`.rdata` 偏移 `0x23b0`）＝ `codevm.c:1546` 的 `static void *const cg_plain[BC_COUNT]`。computed-goto 异或的是运行时副本 `cg_enc[]`，**静态源表原封不动** |
| A3 仅凭 blob 离线还原字节码 | **FAIL** | 1038B / 7 条探针字节码：读明文 `seed`+`salt`，复现 keystream，meta 校验通过、**7/7 条记录全部解出**。对应评审第 2 条「整段可拷贝提取」 |
| A4 完整性链 | **PASS** | 未篡改探针返回 `RAX=42`；头 `salt` / meta 索引表 / 指令记录体三处单字节翻转分别被 `hdr_mac` / `rec_mac` 拒绝 |
| A5 临时释放姿态 | **INFO** | 载荷 EXE delete-on-close = True；侧载 DLL = **False**；回落常规写盘 = True；内存完整明文 = True |
| A6 任意函数可虚拟化率 | **INFO** | 真实 PE 的 `.pdata` 中 `flags=0`、8~512B 函数，不做尾部重试、不自动裁边界：`hello42.exe` 107/200（**53.5%**）、`peintegrate.exe` 107/200（**53.5%**）、`bootstub.exe` 105/200（**52.5%**）。拒绝原因 Top：`0xDB`(x87)、`0x84`(TEST r/m8,r8)、`0F C5`(pextrw)、`group F6 /0`(TEST r/m8,imm8)、`0F 0B`(UD2)、`0xCC`(int3 填充) |

> A6 口径说明：直接用原始 `.pdata` 区间，含函数间 `int3` 对齐填充，因此比
> 生产链路（`_strip_tail_padding` + 逐函数降级）严格；它的价值是**把「差一个
> 量级」变成可复跑的百分比和一份具体的补指令清单**，不是最终保护成功率。
> 本文所有 A2/A3 结论都是对着 `native/out/` 里**已交付的二进制**实测，
> 不是读源码推断。

### 13.3 由此产生的处置顺序（诚实版）

1. **先修自报失真**（本批已做）：删掉「`.rdata` 无明文地址表」「原子缺」
   「无 computed-goto」「packed SIMD 缺」等过时表述，改为实测口径。
   声称与交付物不符，比能力不足更危险。
2. **A2 是真 bug，优先于补指令**：把 `cg_plain[]` 从「静态明文指针数组」
   改成运行时由 `base + 加密 delta` 重建，去掉 `.rdata` 的连续地址表；
   A3 配套把 `seed` 从明文头移出、keystream 常量改为每次构建注入。
   **注意**：这两项只抬高静态提取成本，**不宣称解决整段拷贝 / 内存 dump**——
   密钥与密文同在一个交付包里，对称混淆的极限就在这里。
3. **A6 给出的清单是①的最短路径**：`0x84` / `F6 /0` / `0xCC` / `0F 0B`
   都是低成本指令，补完可把通过率明显推高；packed 浮点与 AVX/VEX 是
   真正的工程量。仍不建议为了「默认开启」放宽安全闸门。
4. **④只能靠积累，不能靠一次补完**：把 A1~A6 纳入每次构建的必跑项，
   后续再逐步加入反汇编器 / 模拟器视角的用例。IDA / 脱壳工具的对抗经验
   是十余年迭代，本批只是 Level-0 基线，**不宣称等价**。
5. **③的红线不变**：不做驱动、进程镂空、反射加载、EDR 对抗。
   能做的是继续缩短明文窗口（含侧载 DLL 的 delete-on-close 与回落路径），
   以及如实告知「内存里存在完整明文」这一架构事实。

**本批产物**：`tools/parity_audit.py`（新增，6 项检查）、
`.lab/parity_audit.json` / `.lab/parity_audit.txt`（本次实测报告）、
`docs/VMP-EXE-PARITY.md` 第十三批、上述文档失真修订、
`cyrilshield/vmp/__init__.py` 能力矩阵文案与 `cyrilshield/vmp/integration.py`
模块说明（两者已同步到 `Terminal-Windows` 两处插件副本，SHA256 一致）、
`native/include/cs_codevm.h` 边界注释修订、`CHANGES.md` 未发版章节。
动工前快照：`D:\CyrilShield_backup_20261115_v335`（389,527,604B / 7223 条目）。

