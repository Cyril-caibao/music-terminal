# 目标代码虚拟化内核（C11 研究原型）

> **先说结论**：C 内核补齐了「**真实目标机器码 → 私有 ISA → VM 执行**」这条链路的
> **可运行原型**；第五批接进 PE 产物，第六批补上 **L2 VM-exit 桥**，第七批补上
> **`FF /4` 间接跳转与标量 SSE 基础子集**，第八批补齐 **VM-exit 浮点参数搬运**、
> **CFG 多段闭包**、**`rep movsb/stos` 字符串指令**、**多函数批量 + SDK 标注**，
> 以及**抗提取层的第一块拼图**（变长加密字节码容器 + 发布 DLL 导出收敛）。
> 但**仍不是 VMP 成品**：解释器 handler 已有「标准 + 3 套噪声变体」的
> seed 驱动变异分派（v3.2.4 强化，见第 9 节），但仍无逐 handler 重写 /
> 指令级等价变形；Windows SEH 异常穿透已换 SEH `__try/__except` 安全网
> 并在真机过 4/4 多线程自测（v3.2.4），packed SIMD/AVX、真机冷启动自动化
> 仍缺。能力矩阵里 `virtualization` 仍标 `partial`。第 6 节逐条列出差距。

## 1. 它和之前的 VM 不是一回事

| | 壳引导链 VM（`vmgen.py` / `dexvm.py`） | 本 C 内核（`native/src/codevm.c`） |
|---|---|---|
| 输入 | 构建期生成的**固定语义序列**（密钥派生 → 解封 → 判定） | 从目标程序 `.text` 抽出的**真实 x86-64 机器码** |
| 输出 | 引导逻辑的字节码 | 目标函数逻辑的私有 ISA 字节码 |
| 业务载荷 | 整块加密，运行时还原后**原生执行** | 被翻译进 VM，由**解释器执行** |
| 性质 | 壳 VM / 引导链虚拟化 | VMP 意义上的目标代码虚拟化（受限子集） |

此前 README 里「把 x86 指令翻译成自定义字节码」那句不符合 `vmgen.py` 的实现，
已在上一轮校准。本内核是**另外新建**的一条链路，不是把旧文案改回来。

## 2. 分工：内核全 C，Python 只做编排与界面

| 层 | 文件 | 职责 |
|---|---|---|
| C 内核 | `native/src/codevm.c` | 反汇编、语义提升、IR、私有 ISA 编译器（多态）、VM 解释器、标志位、内存与栈、CRC、`IR_CALLEXT` VM-exit、`IR_JMPI` 间接跳转、`IR_FSSE` 标量 SSE + XMM 寄存器文件 |
| C ABI | `native/include/cs_codevm.h` | 稳定导出（ABI v3）：`csvm_compile` / **`csvm_compile_cfg`**（按 CFG 多段闭包编译）/ `csvm_run_host` / `csvm_run_host_ex` / **`csvm_run_host_fpu`**（带 XMM 通道，搬运浮点参数与 XMM 返回）/ `csvm_enter`；发布 DLL 只导 **8 个运行入口**（`csvm_compile/disasm/stats/run/run_regs` 不导出，见 §6.4） |
| C CLI | `native/src/codevm_main.c` | `csvm disasm/compile/run/stats`，与 Python 共用同一 ABI |
| VM-exit 桩 | `native/src/exit_trampoline.c` | 文件级 GNU asm：Windows x64 / System V AMD64 两套 native⇄VM 上下文切换；`csvm_default_exit`（只搬 GPR）/ **`csvm_default_exit_fpu`**（额外搬运 XMM0-7/0-3 与 XMM0 返回，无 asm 时显式拒绝回落） |
| 构建 | `native/build.sh` / `build-win.sh` / `build.bat` | 产出 `.so` / `.dll` / CLI / `peintegrate` / demos |
| Python 编排 | `cyrilshield/vmp/codevm.py`, `vmp/integration.py` | 加载共享库、传参、取结果、生成 UI 构建报告；**不含任何虚拟化逻辑** |
| 自检 | `selftest_codevm.py`, `selftest_integration.py`, `native/src/coverage_demo.c`, `native/src/exit_demo.c`, `native/src/v5_demo.c` | 内核 10/10；集成 **19 项（12 通过 / 7 跳过，跳过全为无 Windows 交叉工具链或无真机）**（含 FF/4 + SSE、字节码 v5 容器、FPU 跨 VM-exit、CFG 多段、REP、L2 VM-exit、PE CheckSum、多函数批量、多线程上下文、真机冷启动验证链） |

Python 侧**不做**反汇编、IR 提升、opcode 映射或解释执行。找不到 C 内核时明确抛
`CodeVMUnavailable`，由前端显示「C 内核未构建」，**不会**用 Python 悄悄模拟一个假 VM。

## 3. 四步链路

1. **反汇编**：解码 REX / `0F` 转义 / ModRM / SIB / disp / imm，产出 `raw_t`。
   多字节 NOP、`cs nopw`、`ENDBR64` 等对齐填充归约为 `NOP`。
2. **语义提升 IR**：把 x86 指令归一成平台无关 IR（`MOV/LEA/ADD/SUB/XOR/AND/OR/
   CMP/TEST/IMUL/SHL/SHR/SAR/ROL/ROR/INC/DEC/NEG/NOT/PUSH/POP/JMP/JCC/
   CALL/RET/CMOVcc/SETcc/MOVZX/MOVSX/MOVSXD`）。内部相对跳转目标解析成 IR 标签；
   **目标落在函数字节范围外的 `CALL` 提升为 `IR_CALLEXT`（VM-exit 原语）**；
   **`FF /4` 间接跳转提升为 `IR_JMPI`**；**标量 SSE 提升为 `IR_FSSE`**。
   不支持的语义返回带**字节偏移 + 原始字节**的错误，不静默吞掉。
3. **私有 ISA 编译 + 多态**：IR → 定长 **40 字节**字节码指令（`bc_t`，含 `src_off` /
   `next_off` / `rep_kind` / `width` / `flags`），每条记 `src_off` 供 `IR_JMPI` 回填、
   RIP 相对寻址、`BC_FLAG_*` 标记语义。多条 bc 再封进 **v5 变长加密容器**：
   - 逐条（逐块）按需解密，对称 keystream 由 `CSVM_CONST_*` 派生（混淆用，非密码学保密）
   - 头部 `hdr_mac` 与每条 `rec_mac`：篡改头部或任意一条记录都分别被拒
   - 容器随 seed 变长（不再是定长明文），旧 v4 字节码按魔数直接拒绝
   - 每次构建随机化：操作码排列、GPR→物理槽置换、64 位立即数/disp 掩码、垃圾指令
4. **解释执行**：C 实现的寄存器文件、标志位（ZF/SF/CF/OF/PF/AF，**含 v5 方向标志
   `F_DF`** 供 REP 字符串指令）、宿主真实内存模式（RSP 直通真实栈、RIP 相对常量池）、
   独立 VM 调用栈、`CALL/RET` 哨兵、条件码求值、32 位写入零扩展、16×128 位 XMM
   寄存器文件。命中 `IR_CALLEXT` 时导出 16 个 GPR，经 `csvm_exit_fn` 回调切到宿主栈
   真正调用外部函数，回写后再进 VM；命中 `IR_JMPI` 时按目标地址分流（见第 4 节）；
   命中 `IR_REP` 时在 VM 内循环搬 `RCX` 次（`F_DF` 决定 ±，`width` 决定元素字节数）；
   命中 `IR_TAILEXIT` 时按直接 `jmp rel32` 走 VM-exit tail（把 RAX 交还宿主）。

### 字节码格式版本（重要）

第七批 `bc_t` 由 32B 扩到 **40B**（新增 `src_off`），第八批在 40B 之上再包 **v5 变长
加密容器**（`csvm_file_hdr_t` 92B，头部 576B 为 `bc_hdr_t` 元数据区）。布局破坏性变更
使 `CSVM_MAGIC` 由 `CSVM\x04` bump 到 **`CSVM\x05`**、`CSVM_ABI_VERSION` 由 2 → **3**，
Python 编排层 `codevm.py` 同步校验 ABI=3。**旧的 v4 字节码会被魔数校验直接拒绝
（`selftest_integration.py::t_bc_format` 有硬断言），必须用本版工具重新编译**。`bc_hdr_t`
的 `reserved` 复用为原始机器码长度，供 `IR_JMPI` 判定跳转目标是否落在函数体内；
`BC_FLAG_CFG` 标记多段 CFG 闭包产物，`BC_FLAG_NEED_FPU` 标记只能经带 XMM 通道的
入口执行。容器处于 v5 之后，字节码整体不再是固定步长的可 dump 明文。

## 4. 当前支持的指令子集

| 类别 | 覆盖 |
|---|---|
| 数据传送 | `MOV r/m,r` / `MOV r,r/m` / `MOV r,imm32/64` / `MOV r/m,imm` / `MOVZX` / `MOVSX` / **`MOVSXD r64,r/m32`** / `LEA` / **`movd`/`movq` GPR↔XMM** |
| 算术 | `ADD` `SUB` `MUL` `IMUL` `DIV` `IDIV` `CQO/CDQ` `INC` `DEC` `NEG`（含累加器短格式 `05/0D/25/2D/35/3D/A9`） |
| 逻辑 / 比较 | `XOR` `AND` `OR` `TEST` `CMP` `NOT`（含 `81/83` group1 立即数形式） |
| 移位 | `SHL` `SHR` `SAR` `ROL` `ROR`（imm8 / 1 / CL） |
| 栈 | `PUSH` `POP` `LEAVE`（长模式默认 64 位操作数） |
| 控制流 | `JMP` 全 `Jcc` / `CMOVcc` / `SETcc` / 函数内 `CALL` / `RET` / **`FF /4` 间接跳转** / **直接 `jmp rel32` 跨 CFG 段尾调用（`IR_TAILEXIT` → VM-exit tail）** |
| 寻址 | RIP 相对 `[rip+disp32]`、SIB（`scale` 含 8）、`[rsp+disp]` 读写宿主内存 |
| CFG 多段闭包 | `csvm_compile_cfg`：按函数字节 + 所有内部跳转目标做闭包切片，允许跨段 / 跨节；落在闭包外的 `jmp` 降级为 `IR_TAILEXIT` VM-exit tail，`BC_FLAG_CFG` 标记 |
| VM-exit | `IR_CALLEXT`：目标在函数字节范围外的 `call rel32` / `call [rip+disp32]`（IAT 槽）/ `call [mem]` / `call reg`（`FF /2`）→ 切回原生执行再返回 VM |
| 间接跳转 | `IR_JMPI`（`FF /4`）：目标落在函数**字节范围内**（switch 跳转表 / 间接分支）按 `runtime_base + src_off` 映射回 bc 索引，**在 VM 内闭环**；落在函数**外**（尾调用 / 虚函数返回 / 函数指针）走 VM-exit 到原生并终止 VM，返回其 `RAX` |
| 字符串指令 | `rep movsb/movsw/movsd/movsq`（`REP_MOVS`）、`rep stosb/w/d/q`（`REP_STOS`）；`cld/std` 设置方向标志 `F_DF`，VM 内循环 `RCX` 次、`width` 决定元素字节数；`BC_FLAG_REP` 标记 |
| 标量 SSE | `movss/movsd/movaps/movups`、`addss/addsd/subss/subsd/mulss/mulsd/divss/divsd/sqrtss/sqrtsd`、`cvtsi2ss/cvtsi2sd/cvttss2si/cvttsd2si/cvtss2sd/cvtsd2ss`、`pxor/xorps/andps/ucomiss/ucomisd/movq/movd`；VM 内 `uint64_t xmm[16][2]`；`csvm_run_host_fpu` 支持 XMM 全量进出 |
| FPU 跨 VM-exit | 含「浮点参数 / XMM 返回」的外部调用编译期打 `BC_FLAG_FPU_EXIT` + `BC_FLAG_NEED_FPU`；只能经 `csvm_run_host_fpu` 执行（额外搬运 XMM0-7/0-3 与 XMM0 返回），其它入口运行期明确拒绝，**不会静默算错**（修掉了 `pow(2,3)+1` 得 3.0 这个 bug） |
| 填充 | `NOP` `66 90` `0F 1F` `F3 0F 1E FA` |

**v3.3.5 新增 `IR_ATOMIC`**：32/64 位 LOCK `CMPXCHG` / `XADD` / `XCHG`、
LOCK ALU（ADD/OR/AND/SUB/XOR）、`BTS/BTR/BTC`、`INC/DEC/NOT/NEG`，用单次
`__atomic_*` RMW 实现（宿主模式对真实地址原子）。8/16 位、带 index 寻址、
非对齐地址与自定义内存回调明确 TRAP。**明确仍不支持**：packed 逐 lane 浮点
算术 / AVX、`BSF/BSR`、系统调用、TEB / 回调。遇到不支持指令会带字节偏移
报错，不静默吞掉。

## 5. 验证结果

`python selftest_codevm.py`（10/10）、`python selftest_integration.py`（**19 项：12 通过 / 7 跳过**，
Linux + gcc 13.3 + clang/lld Windows 交叉）、`python selftest_vmp.py`（25/25）：

- 内核：从真实 `gcc -O2 -fPIC` 编出的 `.so` 抽函数机器码，**35 组参数**与 CPU
  原生逐字节一致；**40 个种子**产生 40 份互异字节码
- 宿主内存模式 **20/20**（DIV/IDIV/MUL/IMUL/CQO/RIP 相对）与 CPU 一致
- ELF 函数头 5 字节 `E9` 改写 → 冷启动 **8/8** 与原生一致（`VM_CALLS=8`）
- 真实 PE32+ 改写 2048B → 5632B，新增 `.csvm` 节区，节表 / 导入表 / IAT /
  函数头 `E9` / `CSVM` 魔数 / DLL 名静态校验全过（体积随 seed 变化）
- 集成器产出的 Windows x64 stub 字节在真实 CPU 上执行 **8/8** 与参考一致
- **L2 `exit_demo`**：两个 gcc `-O2` 真实函数（6 参数全寄存器 / 8 参数含栈参数）
  各 **7/7** 与原生一致，反汇编含 `CALLEXT`，外部函数被**真实调用 14 次**
- **第七批 `coverage_demo`**（4 个 gcc `-O2` 真实函数，全部与原生逐位比对）：
  - `FF/4` 尾调用 `jmp reg`（函数外目标 → VM-exit）：**PASS 6/6**
  - `FF/4` switch 跳转表（函数内目标 → VM 内闭环，8 个 case 全覆盖）：**PASS 15/15**
  - 标量 SSE double / float：**PASS 7/7 逐位一致**
- **第八批 `v5_demo`**：浮点跨 VM-exit `pow(2,3)+1 == 9`（非 3.0）且非 fpu 入口明确
  拒绝；`TAILEXIT` / 多段 `CFG` 各 **7/7**；`REP movsb/stosq` 正确；**v5 变长加密
  容器**随 seed 变长 + meta 密文 + 头/记录篡改分别被 `hdr_mac`/`rec_mac` 拒绝 + 旧 v4 拒绝
- **多函数批量 + SDK 标注**：2 个真实函数共享 1 个 `.csvm` 节区（节区 2→3）与 1 个
  IAT，两处 `E9` 各指向独立 stub，SDK 标注清单已入报告
- **PE CheckSum** 重算非 0 且与 `CheckSumMappedFile` 等价算法一致；report 同步输出
- 交叉编译 `CyrilShield.CodeVM.dll` 导出 **8 个运行入口**（去 `compile/disasm/stats/
  run/run_regs` 等分析接口）；静态 dump 者拿不到自带反编译器，仅依赖系统 `msvcrt.dll`
- 回归 `selftest_vmp.py` 25/25；Python 侧源码扫描确认无内核逻辑

> 这些数字只说明**被测的 4 类函数形态跑通了**，不代表覆盖率测量。用户曾预估补上
> 第 1、2 项后覆盖率约 80%，本项目**未做完整函数样本基准**，不宣称具体覆盖率。

## 6. 边界与真实差距（务必看清）

第五批把内核从「独立翻译器」推进到「**翻译器 + 最小可用集成层**」（PE 函数头
改写、新节区、导入表、Windows x64 上下文切换，接进 `vmgen.build()`）；第六批补上
**L2 VM-exit 桥**；第七批补上 **`FF /4` 间接跳转与标量 SSE 基础子集**；第八批补齐
**VM-exit 浮点参数搬运**、**CFG 多段闭包**、**`rep movsb/stos` 字符串指令**、
**多函数批量 + SDK 标注**，以及**抗提取层的第一块拼图**（v5 变长加密容器 + 发布
DLL 导出收敛）。**但这仍不是 VMP**，按影响排剩余差距：

1. **仍需显式指定目标函数**。第八批已支持 `protect_pe_batch`：一次批量改写 N 个
   函数、共享 1 个 `.csvm` 节区 + 1 个 IAT、可附 `sdk.protection_manifest` 标注清单；
   但仍**没有自动挑函数 / 没有全量函数虚拟化 / 默认关闭**。未启用时产物仍是
   「引导链 VM + 抽取式加固」，解密后的原始 PE 仍会明文落盘再拉起。
2. **指令子集仍受限，但已补上字符串指令**。已补 `MUL/IMUL/DIV/IDIV/CQO`、RIP
   相对寻址、宿主真实内存、累加器短格式 ALU、长模式 `PUSH/POP` 64 位宽度、
   Windows x64 调用约定、**`FF /4` 间接跳转（尾调用 + 跳转表）**、**标量 SSE 基础
   子集**、**`rep movsb/stosq` 字符串指令**、**直接 `jmp rel32` 跨段尾调用（CFG 闭包）**。
   第六批实测的 `rep movsb` 失败**已在第八批解决**；v3.3.5 补 LOCK 原子子集
   （见上表）。**仍缺**：packed 逐 lane 浮点算术 / AVX、`BSF/BSR`、系统调用。
3. **L2 VM-exit 已实现且浮点参数已打通**。已做：VM 栈↔宿主栈切换、Windows x64 32B
   影子空间 + 16B 对齐、nonvolatile GPR（`RBX/RBP/RDI/RSI/R12-R15`）与 `XMM6-15`
   保存恢复、整数寄存器参数（SysV ≤6 / Win ≤4）+ 栈参数搬运、`RAX/RDX` 返回值
   回写；第八批新增 `csvm_default_exit_fpu` / `csvm_run_host_fpu`：**VM-exit 跨
   浮点参数由 XMM0-7 / 0-3 搬运、XMM0 返回回读**，并修掉了「静默算错」Bug
   （`pow(2,3)+1` 之前得 3.0、正确应为 9.0，现由 `BC_FLAG_NEED_FPU` 在编译期 /
   运行期拒绝非 fpu 入口，不会静默错）。**v3.3.5 已补 stub 的 UNWIND_INFO / .pdata
   元数据**（见第 6 节与 VMP-EXE-PARITY.md 第十二批对照）。**仍未做**：异常穿透
   VM 帧被原函数 handler 捕获（带 EH/链式展开的函数直接跳过虚拟化）、主动伪造
   TEB / SEH 链、C++ 异常共存。
4. **抗提取层有进展但仍不完整（诚实标注）**。第八批完成两块：
   - **v5 变长加密字节码容器**：逐条（逐块）按需解密、对称 keystream 混淆
     （`CSVM_CONST_*`，非密码学保密）、`hdr_mac` + `rec_mac` 头/记录篡改分别被拒、
     随 seed 变长（不再是定长明文）、旧 v4 按魔数拒绝；
   - **发布 DLL 导出收敛**：只留 8 个运行入口，去掉 `compile/disasm/stats/run/
     run_regs` 等分析接口，静态 dump 者拿不到自带反编译器。
   **v3.2.4 进展（handler 变异强化）**：每个受变异逻辑 op 由 seed 逐 op 选
   「标准 + 3 套噪声变体」共 4 套等价 handler 之一（每 op 2 bit 选择子，见
   `csvm_dispatch_mask`），噪声体为与 VM 状态无关的不透明计算；配合已有的
   逐 build 操作码排列 / GPR 槽位置换 / 立即数掩码 / 垃圾指令，每 build 的
   解释器代码集合均不同。**v3.3.5 已做 computed-goto 间接分派**：case 体抽到
   `native/src/codevm_ops.inc` 由两种分派共享，GNU/clang 下 `goto *enc[lop]`
   消灭中心 switch，**运行时**分派副本按 per-run key 逐 op 异或（MSVC 回退
   switch）。**第十三批实测修正**：静态 `cg_plain[]` 标签数组仍整表留在
   `.rdata`（46 个连续明文代码指针），此前「`.rdata` 无明文地址表」不成立；
   且 `seed`/`salt` 明文存于容器文件头、`CSVM_KS_CONST` 随源码公开，
   `tools/parity_audit.py` 已实证**仅凭 blob 离线还原 7/7 条指令**。
   **仍未做**：逐 handler 等价指令重写（恒真谓词 / 指令替换）、按 pc 逐条
   独立密钥、counterfeit 控制流。IR 定义与 opcode 映射算法随仓库公开，
   整段拷贝型提取仍可行。
5. **其它工程缺口**：完整链式异常展开、TLS、性能优化（解释执行约 10–50x 慢）、
   标志位仍为即时全算（非按需延迟 + 随机存放）、懒标志 + 超指令融合、
   handler 逐体重写（见第 4 项）。v3.3.3 起运行内核已内嵌进单文件成品，
   **不再需要同目录 DLL**；v3.3.5 起字节码魔数 `CSVM\x06` / ABI 4
   （新增 IR_ATOMIC），旧字节码按魔数拒绝（容器格式仍是 v5 变长加密）。
6. **验证边界**：沙箱是 Linux，没有 Windows 加载器，**未在 Windows 真机冷启动
   改写后的 PE**。`native/tools/win_coldboot_verify.ps1` 已提供真机验证脚本
   （LoadLibrary 冷启动 + 原生/VM 结果逐项比对 + `.csvm`/导入表/去导出复核），
   沙箱无真机，本项只验证脚本齐备，真机执行需用户在本机运行。已做到的是：
   stub 字节在真实 CPU 上执行 8/8、PE 静态结构全过、ELF 冷启动 8/8、L2 `exit_demo`
   两个真实函数各 7/7 且外部函数真调 14 次、第七批 `coverage_demo` 4 类函数 35 组
   逐位比对、`v5_demo` 5 组端到端、PE CheckSum 自洽、交叉编译出真实 DLL（8 导出）。
   真机验证需 Windows + 同目录部署该 DLL。

一句话：**从「带 L2 VM-exit + 标量 SSE 的集成原型」推进到「浮点跨 VM-exit 不静默错 +
CFG 多段闭包 + 字符串指令 + 多函数批量 + v5 加密容器 + 发布 DLL 导出收敛」的可运行
集成原型，但 handler 变异 / Windows SEH 异常穿透 / packed SIMD 全量 / 真机冷启动仍缺，不是
VMP 成品。** 请勿把自检全绿理解成「已对标 VMProtect」。

## 7. 构建与使用

Linux / macOS（开发、自检）：

```bash
cd native && ./build.sh
# 10 项产物：libcyrilshield_native.so / libcyrilshield_codevm.so / csvm /
#           peintegrate / hotpatch_demo / pe_stub_verify / exit_demo /
#           coverage_demo / v5_demo / win_multi.*
cd .. && python selftest_integration.py    # 19 项集成自检（12 通过 / 7 跳过）
python selftest_codevm.py                  # 10 项 C 内核自检
python selftest_vmp.py                     # 25 项能力层自检
```

`build.sh` 固定 `-std=c11`，源码内已定义 `_GNU_SOURCE`、CFLAGS 再加
`-D_GNU_SOURCE`：`MAP_ANONYMOUS` / `mmap` 在严格 C11 + glibc 下不再报错。
`coverage_demo.c` 的 `sqrtss` / `sqrtsd` 用内联 SSE 指令实现，**不依赖 `-lm`**；
Windows COFF 目标下 `codevm.c` 自带 `_fltused` 定义，无需 CRT 浮点初始化。

Windows 产物（可在 Linux 上交叉编译，需 clang / lld-link / llvm-lib）：

```bash
cd native && ./build-win.sh
# out/CyrilShield.CodeVM.dll  内核 DLL，只导出 8 个运行入口（csvm_enter /
#                            csvm_run_host / csvm_run_host_ex / csvm_run_host_fpu /
#                            csvm_host_mem_direct / csvm_free / csvm_abi_version /
#                            csvm_version_string），仅依赖系统 msvcrt.dll
# out/win_target.dll          PE 集成器的目标样本
# out/win_multi.dll           双函数批量改写样本（verify 用）
```

Windows 原生构建：`native\build.bat`，产出 4 项（含 `peintegrate.exe`，纯标准
C11）。**只走 MinGW-w64 gcc**：`codevm.c` 的 128 位乘除用 `__int128`、开方用
GNU 内联 asm，`exit_trampoline.c` 是文件级 GNU asm，原版 MSVC `cl` 三者都不
支持，**无法编译本内核**（此前「`cl` 回落为纯 C 降级桩」的说法只针对
`exit_trampoline.c` 单文件，不代表完整内核可用，本轮已删除该误导）。
`build.bat` 已把 `exit_trampoline.c` 编进 DLL 与 `csvm.exe`（`codevm.c` 强引用
`csvm_default_exit`，漏编必然链接失败），且不带 `CSVM_NO_CRT`（MinGW 链接完整
CRT，`_fltused` 由 CRT 提供，避免重复定义）。**该脚本未在 Linux 沙箱实测**
（沙箱无 MinGW 工具链），仅做工具链与源码一致性校准；纯 MSVC COFF 产物请用
上面的 `build-win.sh`（已实测）。`重建EXE.bat` 已把 DLL 打进单文件 EXE。

启用目标代码虚拟化（构建期；Python 只做参数传递，不含内核逻辑）：

```python
from cyrilshield.vmp.integration import protect_pe
new_pe, report = protect_pe(pe_bytes, func_rva=0x1000, func_size=73, seed=123)
# report: section / stub_rva / patched_head / bc_bytes / ir_listing / checksum
```

> 第八批字节码是 **v5 变长加密容器 / ABI 3**。如果手上还有第五、六、七批生成的
> `.csvm` 字节码，必须用本版 `csvm compile` / `csvm_compile_cfg` 或 `protect_pe()`
> **重新生成**；旧字节码会因魔数不匹配被直接拒绝，不要试图直接复用。

Web 界面：VM 虚拟壳 → 「目标代码虚拟化（C 内核 · PE 集成）」卡片，勾选并填
函数 RVA（十六进制）与长度（字节），或填「多函数清单」一次批量改写多个函数
（`RVA十六进制:长度十进制`，逗号分隔，共享 1 个 `.csvm` 节区 + 1 个 IAT，可附
SDK 标注清单）。`vmgen.build()` 在加密打包前完成改写。

运行期：`CyrilShield.CodeVM.dll` 必须与成品同目录，改写后的 PE 通过导入表
加载它。该文件由 `vmgen._deploy_runtime_kernel()` 在构建结束时**自动部署**
（优先 `CyrilShield.CodeVM.runtime.dll` 发布版 8 导出，缺则退回构建版）。CLI 调试：`csvm disasm / compile / run / stats`。缺内核或集成器时
明确抛 `CodeVMUnavailable` / `IntegrationUnavailable`，不用 Python 假 VM 兜底。

## 8. 立场

面向使用者**自己拥有合法权利**的程序，提高逆向门槛。本内核不含 AMSI/ETW
补丁、进程注入、内核驱动、致盲或绕过 EDR 等主动规避手段；相关边界见
[AV-COMPATIBILITY.md](AV-COMPATIBILITY.md) 与 [RED-TEAM-ROE.md](RED-TEAM-ROE.md)。


## 9. 第九批：多线程 VM 上下文（Linux/POSIX 实测）

多线程跑同一套 VM 原来有三个真实竞态，本轮全部修掉：

1. **分派表去全局**：旧实现把「哪些逻辑 op 走噪声等价 handler」写进进程级
   `g_handlers[]`，每次 run 用 blob 的 `seed` 重建 —— 两线程跑不同 seed 时
   函数指针被并发改写。现改为纯函数 `csvm_dispatch_mask(seed)` 算 32 位掩码，
   掩码只放本次 run 的栈帧，任何线程都不写共享状态（同一 seed 选出同一组，
   与旧实现逐位等价）。
2. **安全网改为 run 级 + 每线程 frame 栈**：旧实现每次 VM-exit 做 8 次
   `sigaction` 安装/还原，`csvm_old_sa[]` 还是进程级静态，两线程并发安装互相覆盖；
   现改为互斥 + 引用计数（进程内 0→1 装、1→0 还原），每线程一个 frame 栈，
   支持 VM → 宿主函数 → VM 的嵌套；`sigsetjmp` 收进独立 noinline 包裹函数，
   不再依赖被 longjmp 打断的局部变量（旧写法实测会拿到信号号走错分支）。
3. **每线程 VM 上下文池**：`vm_t` 原来每 run `calloc/free` 一次（含 64KB 沙箱内存），
   高频调用是 malloc 风暴。现在每线程借用/归还（最多缓存 4 个），嵌套 run
   自动再借一个，线程退出由 `pthread_key` 析构回收；归还只擦寄存器与 XMM，
   64KB `mem[]` 留给下次 run 覆写（全量 memset 会让短函数调用反而变慢）。

**实测（`native/out/thread_demo`，8 线程，Linux 真并发）**：

| 项 | 结果 |
|---|---|
| 并发基础（两 seed 交替） | 16000 次，结果与原生逐位一致，0 错误 |
| 并发 VM-exit（调 strlen） | 3200 次，全部正确 |
| 可重入（外层 VM → 宿主 → 内层 VM） | 2400 次嵌套，全部正确 |
| 故障隔离 | 1 线程宿主回调触发 SIGSEGV → 本线程捕获为 TRAP，其余 7 线程照常完成，进程存活 |
| 并发编译 | 8 线程同时编译同一机器码，均成功且长度一致 |
| VM-exit 吞吐（单线程） | **~17.7 万 ops/s**（旧实现 ~15.2 万 ops/s，+16%） |

**旧实现同场景对照**：8 线程跑同一组用例直接 `*** stack smashing detected ***` 崩溃
（全局分派表 + 进程级 `csvm_old_sa` + longjmp 局部变量 UB 三者叠加），新实现 6/6 通过。
ThreadSanitizer（`-DCSVM_NO_SIGNAL_GUARD` 专测竞争）**未报告任何 data race**。

诚实边界（v3.2.4 已收口一半）：Windows 侧多线程 VM 上下文已在真机
（zig cc / MinGW CRT，FLS 池 + VEH→SEH 安全网）实测 4/4 PASS —— 池复用
2000 次、8 线程 × 2000 次两 seed 交替、8 线程并发 VM-exit 3200 次（宿主
函数真实调用 3200 次且返回值回填校验）、单线程 VM-exit 里 AV 被
`__try/__except` 安全网捕获为 TRAP 且其余线程不受影响。真机冷启动多线程
场景与异常展开（unwind info）仍未覆盖，见 `win_coldboot_verify.ps1`。


## 第十批补充：SIB「无基址」寻址与 Linux ELF 入口

## 10. v3.2.4：handler 变异强化 + Windows 真机闭环

### handler 变异（每逻辑 op 4 套等价体）

- 受变异面不变：整数 / 逻辑类 op（`IR_ADD..IR_IMUL3` 共 14 个）；控制流、
  内存、SSE、VM-exit 恒走标准实现。
- 选择子升级为**每 op 2 bit**（`csvm_dispatch_mask` 返回 64 位掩码，只驻留
  本次 run 的栈帧，多线程仍零共享写）；0=标准、1..3 = 三套噪声变体：
  ① 指针异或型 ② xorshift 游走型 ③ 乘加混合 + 位旋转型。噪声体全部
  `volatile`，读入参派生值、不触碰 VM 状态，语义逐位等价。
- 与既有「逐 build 操作码排列 + GPR 槽位置换 + 立即数掩码 + 垃圾指令 +
  v5 变长加密容器」叠加后，每个 build 的字节码与解释器代码集合均不同。

### Windows 真机（v3.2.4 实测）

| 项 | 结果 |
|---|---|
| `win_thread_demo`（zig cc，MinGW CRT，FLS 池 + SEH 安全网） | **4/4 PASS** |
| `win_coldboot_verify.ps1`（新内核改写 win_target.dll → 冷启动比对） | **8/8 PASS** |
| 运行 DLL 导出收敛 | runtime 8 导出 ✓ / 开发 14 导出 ✓ |

真机首跑修正的三处 demo bug（记录在 CHANGES v3.2.4）：v5 容器编译前置、
host 模式 RSP 必须传真实栈地址、参数寄存器按机器码字面（RDI/RSI）而非
Win64 ABI 传递。安全网由「VEH 手工改写 CONTEXT」重写为 `__try/__except`
（旧实现真机挂死，见 CHANGES）。

- **SIB 无基址**：`mod=00, rm=100(SIB), SIB.base=101` 在 x86-64 里表示「无基址 + disp32」。
  原实现把它当 `RBP` 基址，导致 gcc/clang `-O2` 生成的「大常量取模 `lea rax,[rdx*8+disp]`」
  把调用者的 `RBP` 漏进结果。现以哨兵 `base=255` 贯穿解码 → 编码 → `mem_addr()`（LEA 同路径）。
- **ELF 入口**：`cyrilshield/vmp/protect_elf.py` 解析 ELF64（PT_LOAD / `.symtab` / `endbr64`），
  调 `codevm.compile` 生成 `CSVMELF1` payload；`native/src/elf_hook.c` 用 `LD_PRELOAD` 在运行时
  把目标函数头改成 `E9 rel32` 指向近页 stub，stub 用 `r10/r11`（非参数寄存器）跳共享 trampoline，
  `csvm_run_host` 的 `runtime_base` 取函数真实地址。原文件不改一个字节。
  界面对应侧栏 **ELF 加固** 页（`/api/elf/inspect` 只读解析、`/api/elf/protect` 生成 payload），
  与 `main()` 共用 `inspect()` / `protect()`。符号清单会过滤 `st_shndx == 0` 的未定义导入，
  否则 `getenv@GLIBC_2.2.5` 这类条目会被误当成可保护函数。**逐函数编译**：某个函数命中
  未覆盖指令（如 `41 88` `mov r/m8, r8`、`9C` `pushfq`）时只跳过它并回报偏移与字节，
  其余函数仍写入 payload —— 整批失败会让入口完全不可用。
- **Windows**：`CSVM_WIN_TLS`（FLS 池）与 `CSVM_VEH_GUARD`（VEH + CONTEXT 改写）需真实 `windows.h`；
  `CSVM_NO_CRT` 的无 CRT 交叉产物仍走 calloc 直通 + 桩（边界见 `CHANGES-第十批`）。
