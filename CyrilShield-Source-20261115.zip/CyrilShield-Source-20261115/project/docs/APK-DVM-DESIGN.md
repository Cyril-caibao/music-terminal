# APK 全量 VMP 级虚拟化 —— 架构设计（v3.4.0 规划稿）

> 状态：**设计稿，未实施**。本文回答「把 APK 业务方法的 Dalvik 字节码也虚拟化」
> 该怎么做、分几期做、哪里是硬骨头、哪些事做不到。
> 与 `docs/APK-SECURITY-NOTES.md` 的关系：那份文档描述的是**已实现**的壳引导链
> 虚拟化（`dexvm.py`，虚拟化的是壳自己）；本文规划的是**业务方法级**虚拟化，
> 即 exe 侧 VM 虚拟壳在 Android 上的对等物。

---

## 0. 目标与非目标

**目标**：把选中的业务 Java/Kotlin 方法（method body）从标准 Dalvik 字节码
翻译为自定义指令集（自定义 ISA），原方法体替换为调用解释器的桩。反编译
加固后的 APK，看到的选中方法不再是可读的 Dalvik，而是一段 opaque 字节码 +
通用解释器；操作码数值、寄存器映射、常量池、垃圾指令每次构建随机
（复用 `dexvm.py` 已验证的多态编译器框架）。

**非目标（诚实边界，与 exe 侧同一口径）**：
- 不做资源/so 层保护（已有独立能力）；
- 不做反 Frida/反 root 的对抗升级（现有检测开关不变）；
- 不承诺对抗「运行时内存 dump + 主动调用」（任何 VMP 都做不到绝对防，
  只能抬高成本）；
- 不含任何规避杀软/免杀能力，仅用于保护自己有版权的应用。

---

## 1. 总体架构：构建期（PC）+ 运行期（设备）

```
┌────────────────── 构建期（Windows, Python + zig cc）──────────────────┐
│                                                                        │
│  classes*.dex ──► DEX 解析器 ──► 方法选中 ──► Dalvik 反汇编          │
│                    (code_item/      (P1 白名单+       (insn 数组 →     │
│                     map_list)        启发式)          IR 提升 lift)    │
│                                                                        │
│  IR ──► ISA 编译器（复用 dexvm.py 多态框架）──► VM 字节码 blob       │
│         · opcode 随机映射 · 寄存器置换 · 常量池掩码 · 垃圾指令        │
│                                                                        │
│  VM 字节码 ──► assets/ 随机路径分片存放（复用 apk.py 分片基础设施）   │
│  解释器 C 源 ──► zig cc / NDK ──► libcsvm_dvm.so（随 APK 打包）      │
│  原方法体 ──► 替换为桩（native 桩 / Java 桩，见 §5）                 │
│  重签名（复用现有 apksigner 流程）                                    │
└────────────────────────────────────────────────────────────────────────┘

┌────────────────── 运行期（Android, ART）──────────────────────────────┐
│                                                                        │
│  壳 Application 先于业务运行（复用现有壳引导链，解密+加载原 dex）    │
│  业务方法被调用 ──► 桩 ──► JNI ──► libcsvm_dvm.so 解释器             │
│  解释器逐条执行自定义 ISA：                                            │
│    · 算术/比较/跳转：纯 C，寄存器文件在 native 侧                    │
│    · 对象操作（new/invoke/getfield/…）：经 JNI 句柄表回调 ART        │
│    · 异常：解释器内模拟 try 范围表 + JNI ExceptionCheck               │
│    · monitor：JNI MonitorEnter/Exit                                   │
└────────────────────────────────────────────────────────────────────────┘
```

关键决策：**解释器用 C（JNI .so）而不是 Java**。理由：① 与 exe 侧 v3.3.0
C 外壳同一套安全哲学（宿主语言解释器易被逆向，C 产物逆向成本高一个量级）；
② Java 层解释器每条指令都要经过 ART 的 JIT/GC 边界，性能更差；③ 可复用
`native/src/` 已有的 SHA-256/SHAKE256/迷你 VM 骨架。

---

## 2. 构建期组件

### 2.1 DEX 解析器（新建 `dvdex.py`）

需要的能力（不必解析全部 dex 结构，只取方法级所需）：
- `map_list` 定位 `TYPE_CODE_ITEM` 段；
- `code_item`：`registers_size / ins_size / outs_size / tries / insns / debug_info_off`；
- `insn` 流按 `dex` 规范变长解码（Dalvik 指令 1~5 个 16 位 code unit，
  含 `packed-switch-payload` / `sparse-switch-payload` / `fill-array-data-payload`
  三个对齐伪指令）；
- 字符串/类型/字段/方法/原型五个索引表的反查（把 `invoke-…` 的 method_idx
  还原成 `Lclass;→name(params)ret`）。

实现取舍：自研轻量解析（~800 行，只读不写）而非引依赖；写回用现成
`dexlib` 思路的**最小 patch**——只改 code_item 的 insns 与 registers_size，
不动其余结构，保证其余字节逐位不变（利于完整性校验与调试）。

### 2.2 方法选中策略

不是所有方法都值得虚拟化（见 §7 性能），选中策略分三档：
- **白名单**：用户在界面勾选类/方法（UI 已有逐函数勾选先例，exe 侧 ELF 入口
  同款交互）；
- **启发式**：自动选中含敏感操作的方法——密码学调用（`javax.crypto.*`）、
  License/签名校验、本地存储密钥相关、native 声明的包装方法；
- **排除**：入口类（Application/主 Activity 生命周期）、被反射按名字调用的
  方法（R8 混淆后难以静态判定时保守排除）、抽象/native/synchronized 包体
  专有（P1 期）。

### 2.3 Dalvik → IR → 自定义 ISA

三层转换，与 exe 侧 `vmgen.py` 的「源码 → IR → 字节码」同构：

1. **lift**：Dalvik insn → 线性 IR。要点：
   - Dalvik 是寄存器机（v0..vN，可复用），IR 保留其 SSA 无需化简——直接
     按「虚拟寄存器 → VM 寄存器槽位」置换即可（复用 dexvm.py 的槽位随机
     置换）；
   - `goto/if-…/switch` 目标从 insn 偏移改为 IR label；
   - `move-result` 与前驱 invoke 配对成一条复合 IR。
2. **编译**：IR → 自定义 ISA。指令编码沿用 dexvm.py 的
   `5×int（op dst a b imm）`定长格式，节省解释器复杂度；宽常量拆两条。
   新增 opcode 组（P2/P3 渐进引入，见 §6）：
   - `NEW / CHECKCAST / INSTANCEOF`（类型 idx 进常量池）
   - `GETF / PUTF`（field idx + 宽度标志）
   - `INVOKE_D / INVOKE_S / INVOKE_R`（direct/super/static/virtual/interface
     归并为 3 类 + kind 标志）
   - `ARR_L / ARR_S / ARR_LEN / FILLARR`
   - `STR_C / STR_L`（字符串常量池）
   - `MON_E / MON_X / THROW / CATCH_BEGIN / CATCH_END`
   - `MVR_W`（wide move，long/double）
3. **多态**：opcode 数值随机、槽位置换、常量池掩码、垃圾指令、
   解释器 C 源里 OPS 数组排列随机（全部复用 dexvm.py 已验证的机制，
   C 侧等价实现）。

### 2.4 字节码与解释器的部署

- VM 字节码 blob：走 apk.py 现有的「随机 assets 路径 + 分片 + 尾部 nonce/tag +
  壳引导链 VM 解密」管线，等于**免费获得与壳同级的存储防护**；
- `libcsvm_dvm.so`：构建期用 zig cc 交叉编译（`zig cc -target aarch64-linux-android`
  + `x86_64` 双架构，NDK 提供 libc 头）或直接调 NDK clang；so 内含解释器 +
  多态后的 opcode 表，构建后与字节码绑定校验（SHA-256 绑进引导链）。

---

## 3. 运行期解释器（`native/src/dvm_interp.c`，新建）

### 3.1 核心循环

与 `bootstub.c` 的 `cs_vm_run` 同骨架：寄存器文件（此处是 32 位 jobject/int
联合，而非 uint64）+ 反向查表 dispatch + 步数上限 + 完整性自检。差异点：
- **JNI 环境**：解释器持 `JNIEnv*`，所有对象操作走 JNI；
- **句柄表**：IR 层的「VM 寄存器」分两类——原始槽（int/float 直接存）与
  引用槽（存 `jobject`，进入时 `NewGlobalRef`，方法退出统一 `DeleteGlobalRef`，
  防 JNI 局部引用表溢出——这是头号工程坑，见 §7）；
- **帧栈**：invoke 会嵌套（被调方法也可能是虚拟化方法），需要 native 侧
  帧栈：`{ caller_regs, pc, catch_sp, ret_slot }`，深度上限（默认 64）。

### 3.2 对象模型（最难的部分，必须 JNI 直通）

**不自建对象系统**。所有引用一律是 JNI 句柄，语义直通 ART：
- `new-instance` → `NewObject`；`invoke-*` → `Call<Type>Method*` 系列；
  `get/put-field` → `Get<Type>Field/Set<Type>Field`（按字段描述符分派
  int/long/object…11 种）；
- 字符串：`NewStringUTF` / `GetStringUTFChars`（拷贝进 VM 常量池的字符串
  构建期已编码，运行期只读）；
- 数组：`GetArrayLength / GetObjectArrayElement / Set…`；
- 类解析：构建期把用到的 class/field/method idx 全量物化进「运行期符号表」
  （字节码尾部段），解释器启动时一次性 `FindClass/GetMethodID/GetFieldID`
  缓存成 ID 表——**FindClass 失败即终止**（防混淆改名导致的运行期爆炸，
  构建期已校验过一轮）。

### 3.3 异常与 monitor

- 构建期把 `code_item.tries`（try 范围 + handler）翻译成 ISA 侧的
  `CATCH_BEGIN/END` 包围 + handler label；
- 运行期每个可能抛异常的 JNI 调用后 `ExceptionCheck`；命中时沿当前帧的
  catch 表回溯，`ExceptionClear` 后跳 handler；无 handler 则
  `Throw`（保留原异常对象）并逐帧展开——语义等价 Dalvik 的异常展开；
- `monitor-enter/exit` → `MonitorEnter/MonitorExit`；解释器中途退出
  （异常展开）必须释放已持有的 monitor（帧栈记录持有计数）。

### 3.4 与壳引导链的衔接

壳 Application 现有流程不变（解密 dex → InMemoryDexClassLoader）。虚拟化
方法不依赖原 dex 的 code_item，因此**不需要**「先加载原 dex 再接管」这种
ART hack——桩方法直接是壳 dex 里的 native 方法，`System.loadLibrary` 后
由 JNI 分派。这是本设计相对「ART 层 inline-hook 解释器」方案的最大简化：
完全在公开 JNI 语义内工作，不碰 ART 内部结构，各 Android 版本兼容性好。

---

## 4. 方法体替换（桩）

对每个选中方法，在壳 dex（或 patch 原 dex）中：
- 方法修饰加 `native`，注册到 `libcsvm_dvm.so` 的 `JNI_OnLoad`
  `RegisterNatives` 表（方法名随机，表在 so 内多态存储）；
- 原 code_item 整体丢弃（不留在 dex 里），`registers_size/ins_size` 保持
  签名兼容；
- `abstract/synchronized` 方法不能加 native 的兼容处理：synchronized 语义
  移入 ISA 的 MON_E/X 包围（构建期自动改写）。

---

## 5. 分期路线（每期独立可用、独立可测）

| 期 | 覆盖 | 可虚拟化的方法画像 | 验收 |
| --- | --- | --- | --- |
| **P1 子集** | 算术/比较/跳转/常量/return、static 方法、int/long/float/double/String 常量 | 纯计算方法（校验和、混淆哈希、License 算法核心） | 与原方法输出逐位一致（差分测试：随机输入 1e4 组）；反编译看不到原 insn |
| **P2 对象与异常** | invoke 全族、字段、数组、字符串操作、try/catch/throw、instanceof/checkcast | 常规业务方法（不含 synchronized/native 交互） | 真机（API 24/28/33 各一）业务回归 + 异常路径单测 |
| **P3 收尾** | synchronized、wide 语义收尾、packed/sparse-switch、fill-array-data、接口默认方法 | 全指令集（除 VARHANDLE/JDK17+ 专有） | 全量差分 + 混淆（R8 full mode）输入验证 |

P1 期就对外可交付（用户可选「仅虚拟化选中的纯计算方法」），不是攒三年
才见人——这与 exe 侧「先跳过 UPX 壳输入、报告里如实标注」的诚实策略一致。

---

## 6. 风险与边界（写给未来的自己）

1. **性能**：解释开销实测预期 10–50×（exe 侧同量级）。选中方法必须避免
   放进热循环；UI 上明确提示「虚拟化方法不宜高频调用」。
2. **JNI 局部引用表**：解释器长循环里每条 invoke 产生局部引用，必须
   `PushLocalFrame/PopLocalFrame` + 引用槽用 GlobalRef（§3.1），否则
   引用表溢出直接崩进程（上限通常 512）。
3. **R8/ProGuard**：混淆改名会让构建期符号表与运行期 FindClass 不一致——
   管线必须吃**混淆后**的最终 dex（加固作为 release 构建最后一步，与
   现有 apk.py 顺序一致），并构建期全量预解析 FindClass 目标，宁可
   拒绝虚拟化（报告里列出并回退为不虚拟化）也不产出必崩产物。
4. **调试黑洞**：虚拟化方法崩在 VM 内部没有 Java 堆栈。解释器必须维护
   「VM pc → 原方法行号」映射表，崩溃时经 JNI `ThrowNew` 带行号信息抛出
   （exe 侧 CS_TRACE 的等价物，release 关闭）。
5. **多进程/多 dex**：方法属于哪个 classloader 就在哪个 classloader 里
   FindClass；壳用 InMemoryDexClassLoader 加载业务 dex 时，桩必须留在
   **壳 dex**（先加载的一侧），否则 RegisterNatives 找不到类。
6. **架构覆盖**：arm64-v8a + armeabi-v7a + x86_64 三份 so（zig cc 或
   NDK 各编一次），漏架构 = 该设备秒崩。
7. **明确不做**：Kotlin 协程 suspend 函数（状态机含 Continuation 透传，
   P3 后再评估）、VARHANDLE/MethodHandle 语义、GC 对 jweak 的特殊处理。

---

## 7. 与既有能力的关系

| 既有 | 本设计如何复用 |
| --- | --- |
| `dexvm.py` 多态编译器 | IR→ISA 的多态机制（opcode 映射/槽位/掩码/垃圾指令）整框架复用，新增 opcode 组按同一套 `LOGIC_OPS` 模式扩展 |
| `apk.py` 分片加密 + 壳引导链 | VM 字节码 blob 直接走现有 assets 分片管线；引导链 VM 顺带负责把符号表/行号表一并解密 |
| `native/src/bootstub.c` | SHA-256/SHAKE256、迷你 VM dispatch 骨架、完整性自检思路直接移植到 `dvm_interp.c` |
| exe 侧方法选中 UI（ELF 符号勾选） | P1 白名单 UI 同款交互（按类分组勾选方法） |
| `av_compat_audit` / 诚实边界文档体系 | Android 侧对应物：安装性验证（不触发 Play Protect 误报审计流程）+ 本文档边界声明 |

## 8. 第一步落地清单（P1，预计规模）

- [ ] `cyrilshield/dvdex.py`：dex 解析 + code_item 提取（~800 行）
- [ ] `cyrilshield/dvcompile.py`：lift + ISA 编译 + 多态（~1200 行，骨架抄 dexvm.py）
- [ ] `native/src/dvm_interp.c`：P1 opcode 解释器 + JNI 直通桩（~900 行）
- [ ] `apk.py` 接入：方法选中 UI 数据、桩替换、so 打包、重签名
- [ ] 差分测试 harness：随机输入 × 原方法 vs 虚拟化方法，真机 + 模拟器双跑
- [ ] 文档：`APK-SECURITY-NOTES.md` 补「业务方法虚拟化」章节，边界同步
