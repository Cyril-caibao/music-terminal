# 底层架构：原生侧载层接入 Python

> 本文件只描述 **EXE / Windows x64** 链路。安卓链路不在本文范围内。

## 1. 要解决的问题

CPython 运行在受保护的用户态解释层里，「直接操作硬件」在工程上不可行：

| 障碍 | 说明 |
|---|---|
| 特权级隔离 | 端口 I/O、MSR、MMIO、物理内存映射都要求 Ring 0，用户态代码执行即触发异常 |
| 无内联汇编 / 特权指令 | Python 字节码由解释器执行，无法发出 `rdmsr` / `in` / `out` / `cpuid` 这类指令 |
| GIL 与对象模型 | 精确时序、原始内存布局、中断/DMA 语义与被托管的对象模型不匹配 |
| 指纹不可靠 | 纯 Python 只能拿到 `uuid.getnode()`、`platform` 等易伪造值，做不了稳定的硬件绑定 |

结论不是「让 Python 提权」，而是**把硬件能力委托给一个受控的原生层**。

## 2. 四层架构

```
┌────────────────────────────────────────────────────────────┐
│ L3  Python 应用层      Web UI / 编排 / 保护策略 / 许可签发   │
│                        纯 Python，零硬件耦合                 │
├────────────────────────────────────────────────────────────┤
│ L2  桥接层              native_bridge.py                    │
│      · 能力门 CapabilityGate（最小权限，未声明即拒绝）       │
│      · ctypes C ABI 绑定、ABI 版本与能力位校验               │
│      · 侧载库自身 SHA-256 钉住（防同名替换）                 │
│      · 失败自动降级到 PurePythonBackend，绝不因缺件崩溃       │
├────────────────────────────────────────────────────────────┤
│ L1  原生侧载层          CyrilShield.Native.dll  (C11)        │
│      · 只读采集硬件指纹 / 单调时钟 / CPU 特性字              │
│      · 内嵌 SHA-256，零第三方依赖，可静态链接                │
│      · 稳定 C ABI，不依赖 CPython C-API（跨 Python 版本）    │
├────────────────────────────────────────────────────────────┤
│ L0  公开 OS 接口        Win32 / WMI / SetupAPI / sysfs       │
│      · 不装驱动、不提权、不访问其他进程地址空间              │
└────────────────────────────────────────────────────────────┘
```

**「侧载」的确切含义**：与应用同目录部署、由应用**显式 `LoadLibrary` / `dlopen`**、
加载后立即校验 ABI 与自身摘要的伴随库。加载路径固定、不依赖 DLL 搜索顺序、
不寄生于第三方进程。它**不是** DLL 侧加载劫持 / 白利用。

查找顺序（`NativeBackend.discover`）：`CYRILSHIELD_NATIVE` 环境变量 →
PyInstaller 的 `sys._MEIPASS` → 程序目录 → `native/out` → 包目录。

## 3. C ABI

| 函数 | 作用 |
|---|---|
| `csn_abi_version()` | ABI 版本，当前 1 |
| `csn_capabilities()` | 能力位掩码（HWID / TICKS / CPUID / SELFHASH / FILEHASH） |
| `csn_probe_hwid(csn_hwid*)` | 采集机器标识、卷序列号、CPU、OS、CPU 数、内存，并算 SHA-256 摘要 |
| `csn_ticks(uint64_t*)` | 高精度单调时钟（QPC / `CLOCK_MONOTONIC`） |
| `csn_cpu_features(uint32_t*)` | CPUID 特性字 |
| `csn_file_digest(path, out32)` | 文件 SHA-256，供完整性链与构建清单 |
| `csn_self_digest(out32)` | 侧载库自身 SHA-256，防替换 |
| `csn_last_error(buf, n)` | 最近一次错误文本 |

Python 侧：

```python
from cyrilshield import native_bridge as nb

b = nb.get_bridge(granted={"hwid", "file_digest"})
hw = b.hwid()                 # HardwareId(machine, volume, cpu, os, ...)
print(hw.short)               # 用于授权绑定的 32 hex
digest = b.file_digest("demo.exe")
# b.ticks()  → SidecarError: 能力未授权
```

## 4. 构建与部署（对应「打包成 EXE 无依赖」）

```bat
native\build.bat            :: MinGW-w64 gcc 编出 out\*.dll / csvm.exe / peintegrate.exe
copy /Y native\out\CyrilShield.Native.dll .
重建EXE.bat                 :: PyInstaller --add-binary 把 DLL 打进单文件 EXE
```

> 注：`build.bat` 现只走 MinGW-w64 gcc——`codevm.c` 用 `__int128` 与 GNU 内联
> asm、`exit_trampoline.c` 是文件级 GNU asm，原版 MSVC `cl` 无法编译本内核；
> 需要纯 MSVC COFF 产物请用 `native\build-win.sh`（Linux 交叉，已实测）。
> 详见 [CODE-VM.md](CODE-VM.md) 第 7 节。

`重建EXE.bat` 已加入：

```
--add-binary "CyrilShield.Native.dll;."
```

PyInstaller onefile 启动时把 DLL 解到 `sys._MEIPASS`，`discover()` 会优先命中，
因此最终 EXE **不需要目标机器安装 Python，也不需要额外携带 DLL**。
若 DLL 缺失，工具自动降级到纯 Python 后端，功能不中断（只是指纹强度下降）。

## 5. 安全边界

- 只读采集；不写系统状态、不改注册表、不申请管理员权限；
- 能力门白名单；侧载库摘要可钉住；
- **不实现**内核驱动、进程注入 / 镂空、DLL 劫持、AMSI/ETW 补丁、
  禁用安全产品、任何用于隐藏行为的手段。这与 `antitamper.py` 的既有边界一致。

## 6. 自检

```bash
native/build.sh                       # Linux 开发期编 .so
CYRILSHIELD_NATIVE=... python selftest_vmp.py
```

覆盖：原生后端加载、HWID 采集、能力门拦截、摘要钉住与替换拒绝、纯 Python 降级。
