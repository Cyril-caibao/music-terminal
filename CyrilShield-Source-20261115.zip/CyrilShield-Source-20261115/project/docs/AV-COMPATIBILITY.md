# 「免杀强度」的实现边界：降低误报与静态特征命中

> 本文件只讨论 **EXE / PE** 产物。

## 1. 定义

本项目中「增加壳的免杀强度」被明确界定为：

> **AV compatibility / false-positive reduction** —— 让受保护的**合法程序**
> 不被启发式引擎误判为恶意加壳程序，同时减少可被稳定指纹命中的静态特征。

这是商业壳同样必须解决的工程问题。带 VM 虚拟化、内存解密、反调试的程序
几乎必然命中「packed / suspicious」启发式；正版软件因此被 Defender / 360 /
火绒拦截，是加壳工具最真实的痛点。

**本项目不实现**：针对安全产品的主动规避、行为隐藏、检测绕过。

## 2. 误报从哪来

| 触发器 | 原因 |
|---|---|
| 空版本资源 | 无公司名 / 产品名 / 描述 / 版本，像「来路不明的加壳程序」 |
| 高熵节 | 整段压缩或加密，熵接近 8.0，是 packed 的经典判据 |
| 可疑节名 | `UPX0` / `.vmp0` / `.themida` 等被规则库直接标记 |
| W+X 节 | 可写且可执行，是运行时自改码的强特征 |
| RWX 内存 | 运行时申请可写可执行内存、写完跳进去执行 |
| 可疑导入组合 | 反调试 / 注入类 API 成组出现在静态导入表 |
| 无图标 / 时间戳为 0 | 缺少正常发布程序的元信息 |
| 稳定静态特征 | 每次构建字节相同，容易被按哈希入库 |

## 3. 本项目的手段

### 3.1 构建期写合法版本资源

`compat.version_file_source()` 生成 PyInstaller `--version-file` 源码，链接阶段
挂上 `RT_VERSION`：公司名、产品名、描述、原始文件名、文件/产品版本、版权、
`Translation`。这是**降误报最有效的一项**，且不改变程序行为。

`compat.version_info_bytes()` 另提供可直接嵌入 `.rsrc` 的 `VS_VERSION_INFO`
二进制块，供非 PyInstaller 的 PE 使用。

### 3.2 结构规范与审计

`compat.av_compat_audit(exe_bytes)` 返回 0–100 评分与 10 项逐条结论：

`pe_structure` / `version_resource` / `icon_resource` / `wx_section` /
`section_names` / `entropy` / `timestamp` / `mitigations`(ASLR+DEP) /
`overlay` / `reproducible`。

前端结果区展示评分与待优化项；分数不是「免杀能力」打分，而是**产物规范度**打分。

### 3.3 减少静态特征命中

- **多态**：opcode 映射、指令字段排列、角色寄存器、符号名、盐、载荷名、
  分块大小、编码串每次构建全随机；`polymorph.BuildFingerprint` 记录并自检互异。
- **常量加密**：stub 里的魔数、盐、程序名、字节码串全部变成加盐编码串，
  静态反编译看不到明文，也不会形成固定特征。
- **导入保护**：编码名 + `importlib` 延迟解析，避免可疑 API 组合扎堆出现。
- **沿用原图标**（`keepIcon`）：保留发布程序该有的资源。

### 3.4 可复现构建清单 / 误报申诉

`compat.build_manifest()` 生成 `cyrilshield.manifest/1`：每个产物的路径、体积、
SHA-256、熵，附用途声明（无联网、无注入、无驱动、无 AV 规避）。
`vmgen.build` 把水印、完整性链根、许可策略、混淆报告一起写进
`cs_manifest.json`，通过 `--add-data` 打进包，可直接提交安全厂商白名单申诉。

### 3.5 数字签名（顺序很重要）

```
水印 / 版本资源 / 清单  →  PyInstaller 编译  →  signtool 签名（含 RFC3161 时间戳）
```

`compat.signing_hint()` 给出命令。**签名必须是最后一步**：改动文件尾会破坏签名。
Authenticode 有效签名是消除「未知发布者」误报的关键。

## 4. 为什么不往 PyInstaller 产物尾部追加 overlay

`compat.overlay_append()` 与 `license.embed_watermark()` 保留给**普通 PE** 使用，
但 `vmgen.build` 不这么做：PyInstaller onefile 的 CArchive cookie 位于文件尾，
bootloader 从尾部定位归档；追加字节会让自解压失败。因此水印改由
`--add-data` 随包资源承载。这一约束是工程事实，不是能力取舍。

## 5. 明确不做（边界）

以下属于主动规避 / 行为隐藏，既非软件保护必要手段，也超出本项目支持范围，
与 `antitamper.py` 既有边界一致：

- AMSI / ETW 打补丁、直接系统调用绕过用户态钩子；
- 禁用、欺骗安全产品，或按「是否在分析环境」决定隐藏行为；
- 进程镂空 / 注入、DLL 侧加载劫持 / 白利用；
- 内核驱动、提权、签名伪造；
- 任何让恶意载荷躲过检测的用途。

## 6. 自检

```bash
python selftest_vmp.py
# 误报审计 / 版本资源 / version-file / overlay / 构建清单 / 多态指纹
```

`av_compat_audit` 对构造的 PE32+ 样本给出 70/100（缺版本资源、图标等），
启用 `--version-file` 并签名后分数会显著上升；这一步需要 Windows 构建环境验证。
