# -*- mode: python ; coding: utf-8 -*-


# 原生组件必须随 EXE 一起走：_MEIPASS/native/out 正是 codevm._candidates() /
# integration.default_candidates() 的搜索路径之一。缺了它们，界面上的
# 「目标代码虚拟化」在成品里会退化成「C 内核未构建」。
# libcsvm_elfhook.so 是 Linux 侧的 LD_PRELOAD 挂钩库：Windows 上跑不起来，
# 但要跟着 ELF 页的 payload 一起交给用户，否则用户还得自己在 Linux 上构建。
_NATIVE = [
    ('native/out/CyrilShield.CodeVM.dll', 'native/out'),
    ('native/out/CyrilShield.CodeVM.runtime.dll', 'native/out'),
    ('native/out/peintegrate.exe', 'native/out'),
    ('native/out/libcsvm_elfhook.so', 'native/out'),
    ('native/out/bootstub.exe', 'native/out'),
]

# PIL.ImageTk 只有装了 tkinter 才有意义（本程序走 Web UI，不用 TK）。
# 硬写进 hiddenimports 会在无 tkinter 的解释器上刷一堆「找不到模块」警告，
# 所以按可导入性决定要不要带。
_hidden = ['PIL.Image']
try:
    import tkinter  # noqa: F401
    _hidden.append('PIL.ImageTk')
except Exception:
    pass

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[('tools/upx.exe', 'tools')],
    datas=[('cyrilshield/web', 'cyrilshield/web'), ('assets/app.ico', 'assets')] + _NATIVE,
    hiddenimports=_hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='CyrilShield',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    version='cs_version.py',
    icon=['assets/app.ico'],
)
