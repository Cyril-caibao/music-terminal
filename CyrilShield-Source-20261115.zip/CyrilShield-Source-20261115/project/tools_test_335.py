# -*- coding: utf-8 -*-
"""v3.3.5 回归：computed-goto 分派对照 + LOCK 原子指令子集 + unwind 元数据。

用法：python tools_test_335.py [内核 DLL 路径]
不传路径时用默认构建期内核；传 /tmp 新编 DLL 可在覆盖正式产物前验证。
"""
from __future__ import annotations

import os
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
if len(sys.argv) > 1:
    os.environ["CYRILSHIELD_CODEVM"] = str(Path(sys.argv[1]).resolve())

from cyrilshield.vmp import codevm as cv  # noqa: E402

FAILS: list[str] = []


def check(tag: str, ok: bool, detail: str = "") -> None:
    print(("PASS " if ok else "FAIL ") + tag + ("  " + detail if detail else ""))
    if not ok:
        FAILS.append(tag)


vm = cv.get_codevm()

# ---------------------------------------------------------------- 1) CG 语义
# 这组向量覆盖算术/逻辑/乘除/移位/条件设置；CG 分派与旧 switch 内核的结果
# 由 tools_test_335_parity.py 单独对照，这里只确认「能跑且结果正确」。
CG_CASES = [
    ("48C7C02A000000C3", 42, "MOV imm + RET"),
    ("48C7C02A0000004883C00FC3", 57, "ADD imm"),
    ("48C7C0640000004883E80A48FFC8C3", 89, "SUB + DEC"),
    ("B80A00000083F00F83C805C3", 5, "XOR/OR 32bit"),
    ("48C7C00700000048F7E7C3", 0, "MUL rdi(=0)"),
    ("48C7C02000000048D1E048FFC8C3", 63, "SHL + DEC"),
    ("B80500000083F8000F94C00FB6C0C3", 0, "CMP + SETCC + MOVZX"),
]
for hx, want, tag in CG_CASES:
    try:
        got = vm.run(vm.compile(bytes.fromhex(hx), seed=0xC0FFEE))
        check("CG " + tag, got == want, f"got={got} want={want}")
    except cv.CodeVMError as exc:
        check("CG " + tag, False, str(exc)[:90])

# ---------------------------------------------------------------- 2) 原子子集
P = "48BB0010000000000000"  # mov rbx, 0x1000（VM 内存窗口内、8 字节对齐）
ATOM_CASES = [
    # (后续机器码, 期望 RAX, 说明)
    ("48C7030500000048C7C003000000F0480FC103488B03C3", 8,
     "LOCK XADD qword [rbx], rax"),
    ("48C7030500000048C7C00500000048C7C109000000F0480FB10B488B03C3", 9,
     "LOCK CMPXCHG 成功（相等置换）"),
    ("48C7030500000048C7C00400000048C7C109000000F0480FB10B488B03C3", 5,
     "LOCK CMPXCHG 失败（保持原值）"),
    ("48C7030A000000F048830305488B03C3", 15, "LOCK ADD imm"),
    ("48C7030A000000F048832B03488B03C3", 7, "LOCK SUB imm"),
    ("48C7030000000048C7C003000000F0480FAB03488B03C3", 8, "LOCK BTS"),
    ("48C7030700000048C7C02A000000F0488703488B03C3", 42, "LOCK XCHG"),
    ("48C7030A000000F048FF03488B03C3", 11, "LOCK INC qword [rbx]"),
]
for seq, want, tag in ATOM_CASES:
    code = bytes.fromhex(P + seq)
    try:
        bc = vm.compile(code, seed=0xA70C)
        listing = vm.disasm(code)
        got = vm.run(bc)
        check("ATOM " + tag, got == want and "ATOMIC" in listing,
              f"got={got} want={want} ir={'ATOMIC' in listing}")
    except cv.CodeVMError as exc:
        check("ATOM " + tag, False, str(exc)[:110])

# 明确拒绝：8 位 LOCK（子集外，运行期 TRAP 而非静默算错）
try:
    code = bytes.fromhex(P + "C6030AF0FE03488B03C3")
    bc = vm.compile(code, seed=7)
    try:
        vm.run(bc)
        check("ATOM 8 位明确拒绝", False, "应触发 TRAP")
    except cv.CodeVMError as exc:
        check("ATOM 8 位明确拒绝", "子集外" in str(exc), str(exc)[:90])
except cv.CodeVMError as exc:
    check("ATOM 8 位明确拒绝", True, "编译期即拒绝：" + str(exc)[:70])

# ---------------------------------------------------------------- 3) unwind
from cyrilshield.vmp import integration as it  # noqa: E402


def _dd_and_off(data: bytes, want_rva: int):
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    opt = pe + 24
    dd = opt + 112 + 3 * 8
    pdata_rva, pdata_size = struct.unpack_from("<II", data, dd)
    secs = it._sections(data)
    po = it._rva_to_off(data, pdata_rva, secs)
    return pdata_rva, pdata_size, po, it._rva_to_off(data, want_rva, secs), secs


target = ROOT / "native/out/hello42.exe"
data = target.read_bytes()
protected = it.pdata_protected_ranges(data)
check("UNW 精准跳过判定", not it._unwind_covers(protected, 0x1000),
      f"protected={len(protected)} 条，0x1000 未被误判")

vm2 = cv.get_codevm()
win = None
for off in range(0, 0x8000, 16):
    if it._unwind_covers(protected, 0x1000 + off):
        continue
    try:
        c = it.extract_pe_function(data, 0x1000 + off, 64)
        vm2.compile(c, seed=0x335)
        win = (0x1000 + off, 64)
        break
    except (cv.CodeVMError, it.IntegrationError):
        continue
check("UNW 找到可虚拟化窗口", win is not None,
      hex(win[0]) if win else "none")

if win:
    out_data, rep = it.protect_pe_batch(data, [win], seed=0x335)
    uw = rep.get("unwind", {})
    check("UNW 报告含 unwind 字段", uw.get("enabled") is True, str(uw)[:110])
    check("UNW 条目数 = 原表 + stub",
          uw.get("pdata_entries") == uw.get("original_entries", 0) + 1,
          f"entries={uw.get('pdata_entries')} orig={uw.get('original_entries')}")
    prva, psize, poff, uoff, secs = _dd_and_off(out_data,
                                                int(str(uw.get("unwind_rva", "0x0")), 16))
    check("UNW dd[3] 指向新表", poff is not None and psize == uw.get("pdata_entries", 0) * 12,
          f"rva=0x{prva:X} size={psize}")
    if poff is not None and uoff is not None:
        ui = out_data[uoff:uoff + 40]
        check("UNW UNWIND_INFO 头", ui[0] == 1 and ui[1] == 104 and ui[2] == 18,
              f"ver={ui[0]} prolog={ui[1]} codes={ui[2]}")
        check("UNW 末尾 ALLOC_LARGE", ui[36] == 7 and (ui[37] & 0xF) == 1
              and ui[38] == 25 and ui[39] == 0,
              f"tail={list(ui[36:40])}")
        ent = struct.unpack_from("<III", out_data, poff + (uw["pdata_entries"] - 1) * 12)
        check("UNW stub RUNTIME_FUNCTION", ent[2] == int(str(uw["unwind_rva"]), 16)
              and ent[1] > ent[0], f"{tuple(hex(x) for x in ent)}")
        begins = [struct.unpack_from("<I", out_data, poff + i * 12)[0]
                  for i in range(uw["pdata_entries"])]
        check("UNW 表按 BeginAddress 有序", begins == sorted(begins),
              f"n={len(begins)}")
    # 带 EH 的函数必须被跳过而不是改写
    if protected:
        b, e = protected[0]
        out2, rep2 = it.protect_pe_batch(data, [(b, min(64, e - b))], seed=1)
        check("UNW 带 EH 函数跳过", out2 == data and rep2.get("skipped") == "unwind",
              f"skipped={rep2.get('skipped')}")

print("-" * 60)
print("FAILS:", ", ".join(FAILS) if FAILS else "none")
raise SystemExit(1 if FAILS else 0)
