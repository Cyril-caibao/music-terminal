# CyrilShield 改动说明（云端交付，未推送 GitHub）

解压后可整体替换本地工作副本，或仅用「改动 / 新增」文件按相同路径覆盖。
本包包含**三批**改动：第一批补齐 EXE 侧运行时守卫，第二批加强 APK 侧的
虚拟化与加壳能力，第三批加入 EXE / APK 自定义图标。三批都已合入同一份代码。

---

## 未发版 · 第十三批对标审计（v3.3.5 之后，未 bump 版本号）

外部评审给出 4 条 VMP 差距，逐条对着代码与**实际交付的二进制**核验：
**2 条已过时、1 条方向对但描述失真、1 条属实**；核验过程中查出两处比评审
更严重的自报失真。动工前先生成 `D:\CyrilShield_backup_20261115_v335`
完整快照（源码 281 文件 + 两份成品 + 两处插件副本 + 7218 行 SHA256 清单
+ 389,527,604 B zip，CRC 全通过）。

### 1. 新增 `tools/parity_audit.py`：攻击者视角 Level-0 基线

刻意不 import 项目自身的 `cyrilshield` 包——攻击者拿到的是交付的 DLL 与 PE，
不是源码编排层。直接 `ctypes` 调 `csvm_compile` / `csvm_run`、自解析 PE
导出表与 `.pdata`；覆盖率放隔离子进程，内核若在真实片段崩溃不会带走主审计，
且崩溃本身记为一条发现。`python tools/parity_audit.py --json .lab/parity_audit.json`。

| 检查 | 结果 | 实测 |
| --- | --- | --- |
| A1 运行 DLL 导出白名单 | PASS | 8 个运行入口，无 `compile/disasm/stats/run` 等分析接口 |
| A2 `.rdata` 明文分派地址表 | **FAIL** | 113 个代码指针，其中 **46 个连续**（`.rdata+0x23b0`）＝ `codevm.c:1546` 的静态 `cg_plain[]`。computed-goto 只异或了运行时副本 `cg_enc[]` |
| A3 仅凭 blob 离线还原字节码 | **FAIL** | `seed`/`salt` 明文存于文件头、`CSVM_KS_CONST` 随源码公开 → 纯脚本解出 **7/7** 条指令 |
| A4 完整性链 | PASS | 头 / meta 索引表 / 指令记录体三处单字节翻转均被 `hdr_mac` / `rec_mac` 拒绝；未篡改探针 `RAX=42` |
| A5 临时释放姿态 | INFO | 载荷 EXE delete-on-close=True，**侧载 DLL=False**，常规回落=True，内存完整明文=True |
| A6 任意函数可虚拟化率 | INFO | `hello42.exe` 107/200 (53.5%)、`peintegrate.exe` 107/200 (53.5%)、`bootstub.exe` 105/200 (52.5%)；拒绝原因 Top：`0xDB`/`0x84`/`0F C5`/`F6 /0`/`0F 0B`/`0xCC` |

### 2. 评审 4 条逐条结论

1. **指令覆盖**：packed **整数** SSE2（`packedsimd_demo.c`）、**原子**（`IR_ATOMIC`）、
   异常展开**元数据**均已落地，这几项过时；仍缺 packed 逐 lane 浮点 /
   AVX-VEX / 完整异常穿透，「默认关闭、做不到全量虚拟化」属实。
2. **字节码形态**：属实。已有逐条按需解密 + 按 pc 绑定的 `rec_mac`，但加密
   是「同一条全局 keystream 按偏移切片」，不是每条独立密钥；handler 变体
   确实只是 `volatile` 前置不透明计算后调同一个 `exec_step`。
3. **抗 dump**：方向属实但「零成本」过时（主力路径 delete-on-close）；
   侧载 DLL 仍常规写盘、内存仍有完整明文。驱动 / 进程镂空 **明确不做**。
4. **无对抗积累**：属实，且代价已显现——第一次扫 DLL 就发现第十二批
   「`.rdata` 无明文地址表」是错的。

### 3. 文档失真修订（本批重点）

`docs/VMP-EXE-PARITY.md`（新增第十三批 + 修订第 0 节 / 能力矩阵 / 差距表 /
第十一批 / 第十二批）、`docs/CODE-VM.md`、`docs/SECURITY-NOTES.md`
（补版本校准：第 2/6 节的「目标代码虚拟化未实现」已过时）、
`docs/RED-TEAM-ROE.md`、`native/include/cs_codevm.h` 边界注释、
`cyrilshield/vmp/__init__.py` 能力矩阵文案、`cyrilshield/vmp/integration.py`
模块说明。后两个 `.py` 已同步到 `Terminal-Windows` 的 `components` 与
`dist/components` 两处插件副本，SHA256 一致。

### 4. 边界与后续

**本批不改 C 内核、不重编任何二进制**（避免源码与交付物漂移）；
`cs_version.py` 仍为 3.3.5。下一步优先级：去掉 `.rdata` 静态标签表 +
把 `seed` 移出明文头 → 补 A6 清单里的低成本指令 → 把 A1~A6 纳入每次构建
必跑项。A2/A3 的修复只抬高静态提取成本，**不宣称解决整段拷贝 / 内存 dump**。
驱动级 / 进程镂空 / EDR 对抗红线不变。

---

## v3.3.5：computed-goto 间接分派 + 原子指令子集 + 异常展开子集

用户要求把上一轮列出的两块差距「一起做」；实施前先生成了
`D://CyrilShield_backup_20261114_v334` 完整快照（源码 279 文件 + 两份成品 +
两处插件副本 + 7219 行 SHA256 清单 + 389,340,596 B zip，CRC 全通过）。

### 1. 抗提取层：computed-goto 间接分派（消灭中心 switch）

- 把 `codevm.c` 里 500 行的中心 `switch(lop)` **case 体抽出**到新增的
  `native/src/codevm_ops.inc`。GNU/clang（MinGW-w64 gcc、build-win.sh 的
  clang、zig cc 三条实际工具链都属此类）下 `CS_CASE(x)` 展开成具名标签
  `L_x:`，用 `goto *cg_target` 直接跳到对应 handler；**中心 switch 消失**。
  MSVC 等不支持 labels-as-values 的编译器自动回退中心 switch（诚实标注，
  可用 `-DCSVM_FORCE_SWITCH` 强制对照）。
- 分派表逐条随机化：`cg_enc[i] = plain[i] ^ mask(i, per-run key)`，key 由
  `imm_mask ^ seed ^ 实例地址` 每次 run 重算；`.rdata` 里不留明文 handler
  地址表，分派只做一次整数 mix。v3.2.4 的 4 选 1 handler 噪声变体保留。
- **一份语义源码两种分派**：只替换外层 case/default 行，case 体（含内层
  switch 的 break/return）逐行原样保留，不可能出现双实现漂移。CG 模式借
  `do{...}while(0)` 让外层 `break` 自然落到写回代码。
- 与旧 switch 内核在 9 组样本（算术/逻辑/乘除/移位/SETCC/错误路径）上
  **逐项结果一致**。

### 2. 原子指令子集（IR_ATOMIC）

- 新增 `IR_ATOMIC` + 子操作码：LOCK `CMPXCHG` / `XADD` / `XCHG`、
  LOCK ALU（`ADD/OR/AND/SUB/XOR` 的 imm 与 reg 形式）、LOCK `BTS/BTR/BTC`、
  LOCK `INC/DEC/NOT/NEG`。解码器记录 `F0` 前缀并扩充 ModRM 白名单。
- 运行期用 `__atomic_*` builtins 对**单次 RMW** 实现：宿主真实内存模式直接
  对进程地址原子操作（跨线程真原子），沙箱模式对 VM 内存窗口原子操作；
  自定义内存回调、8/16 位操作数、带 index 寻址、非对齐地址一律明确 TRAP，
  不退化成「读-改-写」两步、不静默算错。
- 修了一处自查发现的宽度 bug：字节形式（`F0 FE /0` 等）不带 REX.W 时
  `raw_t.width` 默认 32，会静默按 32 位破坏相邻字节；现按操作码精确判 8 位
  并在运行期拒绝。
- **ABI 破坏性变更**：IR 集合变化 → 魔数 `CSVM\x05` → `CSVM\x06`、
  `CSVM_ABI_VERSION 3 → 4`（含 `csvm_container.h` 的字面量与
  `vmp/codevm.py` 的 ABI 校验、`selftest_integration.py` 断言）。旧字节码按
  魔数明确拒绝，不会静默误读。

### 3. 异常展开（unwind）子集

- `peintegrate.c` 的 batch 路径现在为 `.csvm` 节区生成共享 `UNWIND_INFO`
  （Version=1 / SizeOfProlog=104 / 18 个 UNWIND_CODE：8 个非易失寄存器的
  `UWOP_SAVE_NONVOL` + `UWOP_ALLOC_LARGE sub rsp,200`），为每个 stub 追加
  `RUNTIME_FUNCTION`，**原 `.pdata` 整段保留**、按 BeginAddress 有序，
  `DataDirectory[3]` 改指向新表；报告带 `unwind` 明细。
- **精准跳过安全网**：Windows x64 几乎每个函数都有 `.pdata` 条目
  （hello42 498 条、87MB Portable 841 条），按「有条目就跳过」会全量禁用
  函数级虚拟化。因此只跳过 `UNW_FLAG_EHANDLER / UHANDLER / CHAININFO`
  的函数（hello42 1 条、Portable 302 条，用户常测的 `0x1000` 不在其中）。
  新增 `pdata_covered_ranges()` / `pdata_protected_ranges()`，自动发现与
  手填清单两条路径都过滤，跳过原因写进 `skipped_functions`。
- 单函数路径 `protect_pe()` 统一走 `protect_pe_batch(N=1)`，同样获得
  unwind 元数据与逐函数降级，不再走无元数据的旧 CLI 单模式。
- **诚实边界**：stub 在 call 前后各 `sub/add rsp,32`（影子空间），异常恰好
  发生在 call 内部时 RSP 比 unwind 描述少 32，链式展开仍不完美；因此带
  EH/链式展开的原函数一律跳过，不把可展开函数变成不可展开函数。

### 4. 产物与验证

- 重编三份原生产物：`CyrilShield.CodeVM.dll`（构建期 312,832 B）、
  `CyrilShield.CodeVM.runtime.dll`（发布版 312,832 B，**仍只导出 8 个运行
  入口**，用 `.def` 白名单；`-fms-extensions` 保留 v3.2.4 的 SEH 安全网）、
  `peintegrate.exe`（233,472 B）。
- `tools_test_335.py` 24 项全过：7 组 CG 语义、8 组 LOCK 原子真值
  （含 CMPXCHG 成功/失败、8 位拒绝）、9 组 unwind 结构（dd[3]、条目数、
  UNWIND_INFO 头、末尾 ALLOC_LARGE、表有序、EH 函数跳过）。
- 真机 E2E `tools_test_333.py` 10 项全过：内嵌新 runtime DLL 后产物 `rc=0`、
  无 err=126、marker `argc=3 / arg[1]=ARG1 / arg[2]=ARG TWO`、临时目录清理干净。
- 回归：vmp 25 / integration 21 / codevm 10 / `tools_test_331.py` /
  `tools_test_333.py` / `tools_test_334.py` 全 0 失败；双 EXE 冒烟见交付记录。

**仍缺**（未虚标）：packed SIMD / AVX、完整的异常链式展开、跨 handler
等价指令重写、PDB/符号表级函数边界解析。

---

## v3.3.4：VMP 对标第十一批 —— 自动函数发现 + 对标矩阵刷新 + 当前版本完整备份

### 1. 备份与清理（本轮前置）

- 新增 `tools/backup_snapshot.py`：一键生成可恢复快照，含源码树（排除 dist /
  build / `__pycache__` / 旧交付 zip）、两份成品 EXE、Terminal-Windows 两处插件
  副本、`SHA256SUMS.txt`（逐文件哈希 + 字节数）与 `README.md`，最后压成 zip 并
  逐条目 CRC 校验。支持「断点收尾」模式：复制成功但后续中断时跳过复制、只补
  清单与 zip；个别文件瞬时读取失败会如实记入 README 而不静默丢弃。
- 当前快照：`D:\CyrilShield_backup_20261114_v333\`（目录）与同名 `.zip`
  （389,317,642 字节 / 7220 条目 / 清单 7218 行，CRC 全过）。
- 经明确确认后永久删除 3 个旧备份目录：`D:\CyrilShield_backup_20261113\`、
  `D:\CyrilShield_backup_20261114\`、`D:\_cs_pre_vmp_backup_20261108_2112`。
  **保留**：`dist_portable\CyrilShield-Portable - 副本.exe`（用户测试输入）、
  项目内三个旧交付 zip、`D:\Terminal-Windows\_backup`（另一项目）。
  注：回收站 API 需运行时编译 .NET 被安全策略禁止，故按用户确认改为永久删除。

### 2. 自动函数发现（补齐第 4 节差距表里的「多函数自动选择」）

- `vmp/integration.py` 新增 `discover_pe_functions()`：
  ① 跳过 packed 节区（`SizeOfRawData=0`，UPX 壳无原始机器码）；
  ② 在 `.text` 前 1MB 内用 12 种典型 x86-64 函数序言匹配候选起点；
  ③ 从 16 字节起逐窗口增长，**每个窗口都由 C 内核 `csvm_compile` 验证**；
  ④ 末条 IR 必须是真正的函数出口（`RET` / `TAILEXIT` / `HALT`）才采纳——
     条件跳转 / `CALLEXT` 不算出口，避免把函数拦腰截断；
  ⑤ 候选不重叠、上限 1~64、试编译上限 160，扫描统计写进 `auto_discover` 报告。
- 接线：`VMOptions.vm_auto_discover / vm_auto_max` → `vmgen.build()` →
  `protect_pe_batch()`（复用 v3.3.2 尾部容错与 v3.3.1 逐函数降级，不额外放宽
  闸门）；`server.py` 传 `vmAutoFunc / vmAutoMax`，报告新增 `auto_discover`；
  Web UI 加「自动发现函数（不用手填清单）」勾选框与上限输入，结果卡展示
  扫描量 / 候选数 / 采纳数。手填清单优先，不被自动发现覆盖。
- 无候选时与压缩壳同策略：跳过函数级虚拟化、保留 VM 外壳，绝不整体失败。
- **实测闭环**：用户此前反复手填 `1000:49` 的 87MB Portable 输入，自动发现
  给出 `0x1000 / 47` —— 自动裁掉尾部 int3 填充与下一函数 REX 前缀，与
  v3.3.2 尾部容试算出的真实边界完全一致。hello42 / Portable 扫描均 ~0.01s。
- 修掉一个自测当场抓到的 bug：自动发现最初插在 `if/elif` 链里，命中后直接
  跳过批量改写（产物未虚拟化却报成功）。改为「填清单」与「执行改写」两条
  独立链，产物由 464,560B 变为 755,576B，报告 `auto_discover.accepted=3`。

### 3. 对标矩阵刷新（文档滞后修正）

`docs/VMP-EXE-PARITY.md` 仍把已实现项列为「未实现」，本轮按实际代码更正：

- v3.2.4 已完成 **4 选 1 handler 噪声变体、Windows `__try/__except` 安全网、
  8 线程真机实测 `RESULT=PASS`**，不再标注「handler 未变异 / SEH 仍缺 /
  冷启动未实跑」；
- 剩余真实差距收敛为：packed SIMD / AVX / 原子 / 异常展开、computed-goto
  间接分派、逐条随机化加密、真·不落地（后者明确不做）；
- 新增「第十一批对照：自动函数发现」能力表；
- `vmp/__init__.py` 能力清单同步补 v3.3.3 / v3.3.4 说明，并纠正把已支持的
  字符串指令误列为缺口。
- Web UI 两处过时文案（「DLL 需随成品同目录部署」）改为「运行内核已内嵌
  （单文件成品）」。

### 4. 验证与交付

`tools_test_334.py` 12 项全过（候选不重叠、每个结果可编译且以函数出口收尾、
Portable 自动定位 0x1000/47、完整构建、报告字段、单文件、真机 `rc=0`、
手填清单优先）；回归 vmp 25 / integration 21 / codevm 10 /
`tools_test_331.py` / `tools_test_333.py` 全 0 失败。

**诚实边界**：序言是启发式，不是符号表 / PDB 解析；自动发现把门槛从「会用
IDA 查 RVA」降到「勾一个框」，但不改变「默认关闭、受限指令子集、非 VMP 强度」
的定位。生产保护仍建议反汇编复核函数边界。

---

## v3.3.3：运行内核 DLL 内嵌，保护产物真正单文件（并修复虚拟化成品无法启动）

**先澄清一个容易混淆的点**：工具自身的 `CyrilShield.exe` / 便携版**早已把两个
内核 DLL 打进 PyInstaller 包**（`CyrilShield.spec` 的 `_NATIVE`、
`build_portable.py` 的 `--add-data`）。本次处理的是另一件事——用本工具生成的
**保护产物**旁边总跟着一份外部 `CyrilShield.CodeVM.dll`。

顺带查出一个真 bug：开启「目标代码虚拟化」时，`peintegrate` 会在载荷 PE 的
导入表写入 `CyrilShield.CodeVM.dll`，Windows 加载器只在 **EXE 自己所在目录**
找它。而两种外壳都把载荷释放到独立临时目录，`_deploy_runtime_kernel()` 却把
DLL 放在**输出目录**。结果是「C 外壳 / Python 外壳 + 函数级虚拟化」构建能成功，
运行必然以 err=126 起不来（构建期 E2E 只看产物大小，之前没覆盖运行）。

修复（DLL 字节嵌进外壳数据，运行时随载荷释放到同一临时目录）：

- **C 外壳**：overlay 升 v2，尾表原 `res` 字段复用为 `dll_len`；DLL 段紧随
  载荷之后、尾表之前，用独立的 `SHAKE256(nonce || "CS-DLL-v1")` 流混淆，
  每次构建随 nonce 多态。bootstub 在 `cs_spawn_payload()` 里把 DLL 写到
  最终确定的临时目录（secure / 常规回落两条路径都覆盖），cleanup 时一并删除；
  `version < 2` 的旧格式仍按无 DLL 段解析，保持兼容。
- **Python 外壳**：`vmgen` 编译 onefile stub 时加 `--add-data` 把运行内核打进去，
  `antitamper.SPAWN_SOURCE` 新增 `_at_side_dll_bytes()` /
  `_at_deploy_side_dll()`，从 `sys._MEIPASS` 取出并按 PE 导入名写到载荷同目录。
- 两处 `_deploy_runtime_kernel()` 改为**仅在内核文件找不到时**的回落，并明确
  警告；正常情况下输出目录不再产生外部 DLL，日志如实写「成品为单文件」。
- 顺手清掉 `bootstub.c` 里一处调试残留：每个解密分块都往 stderr 打印 16 字节
  hex，大载荷会白白拖慢运行（v3.3.0 调试 NATIVE 1 时留下，生产版未消除）。

**诚实边界**：这不是「内存加载 / 不落地」。运行期内 DLL 仍会短暂出现在载荷
同一临时目录（关闭 cleanup 时保留），只是**分发时只有一个 EXE**；导入表机制
未变，兼容性与误报面与原来的双文件形态一致。

改动文件：`cyrilshield/vmgen.py`、`cyrilshield/antitamper.py`、
`native/src/bootstub.c`（重编 `native/out/bootstub.exe` 239,104 字节）、
版本号 3.3.3、新增 `tools_test_333.py` 回归脚本。

验证：`tools_test_333.py` 10 项全过（overlay v2 尾表、dll_len 与源一致、
输出目录无外部 DLL、真机 `rc=0` 无 err=126、marker 参数透传、临时目录清理）；
Python 外壳单独取证，释放目录内 `CyrilShield.CodeVM.dll` 282,112 字节与源
逐字节一致；回归 vmp 25 / integration 21 / codevm 10 / `tools_test_331.py`
均 0 失败。

---

## v3.3.2：修复「清单 0x1000/49 尾部混入 int3 + 下一函数前缀」构建失败

真机使用（v3.3.1）：清单 `1000:49`（`.text` 起始 + 49 字节）仍报
`偏移 47：不支持的操作码 CC`。取证后看清区间的真实字节布局：

```
+00: 40 53 48 83 ec 20 ... 5b e9 31 3c 00 00 cc
+48: 48 8d 05 a1 ba 04 00 c3 cc cc cc ...
```

即 `[0..42] 真实函数（以 e9 jmp rel32 尾调用结束）[47] int3 填充
[48] 下一函数的 REX.W 前缀`。v3.3.1 只能剥「尾部连续 int3/nop」，
这里 int3 后面紧跟下一函数的 `48`，且该前缀孤立（无 opcode）会再报
「前缀后截断」——两种填充都不是区间最尾部的连续带，剥不掉。

修复（`integration.py` 新增 `_compile_with_tail_retry`）：编译失败且
**失败点靠近函数尾部**时，逐字节回退尾部并重试编译；三道安全闸门——
① 失败偏移必须落在尾部 16 字节窗口内；② 最多回退 16 字节；
③ 截断后编译成功、且最后一条 IR 是终止类指令（RET / TAILEXIT /
JMP / CALLEXT / HALT / TRAP）才采用。否则原样抛错，由 v3.3.1 的
逐函数降级接管，绝不悄悄丢掉函数体中部的真实指令。日志如实提示
「已自动截断函数尾部 N 字节」。

本例：`49 → 47 字节` 后编译成功，最后一条 IR 正是 `TAILEXIT`
（VM-exit 尾调用）——真实函数在 jmp 处已离开，丢掉的 `cc 48` 是
填充与下一函数首字节，语义完整。

**关于「不是有 VM-exit 和多线程上下文吗」**：VM-exit（L2 外部真实
函数调用、浮点/XMM 返回）与多线程 VM 上下文（TLS 池 / 8 线程并发 /
SEH 故障隔离）都是**运行期**能力；这次卡在**编译期**——字节码还没
生成，解码器在把原始机器码提升为 IR 时遇到填充字节就拒绝。两者
不在同一层。修法选择「构建期识别真实函数边界」而非把填充塞进 VM：
不重编内核 DLL，保留 v3.2.4 真机验证过的 MSVC SEH 安全网完整。

验证：用户同款清单 `1000:49` 批量虚拟化 PASS；用户同款完整构建
（87MB 输入 + 最强防护 + C 外壳 + 虚拟化）PASS，产物 88,188,646
字节，内核随成品部署；单测覆盖「剥填充 / 用户清单自动截断 / 部分
失败降级 / 全部失败报错」全过；vmp 25 项、integration 21 项、
codevm 10 项回归 0 失败。版本 3.3.2，插件三副本同步
（manifest 1.2.8）。

边界：函数体**中部**出现 int3（`__debugbreak`）或指令子集之外的
指令（AVX / packed SIMD / lock 前缀）时，该函数仍会跳过虚拟化并
保留原机器码；工具不会假装支持。界面清单建议用反汇编/符号表给出的
真实函数边界。

---

## v3.3.1：修复「多函数清单遇到 int3 填充导致整体编译失败」（逐函数降级）

真机使用（v3.3.0）：对 PyInstaller 打包的工具自身（87MB）启用函数级
虚拟化 + 多函数清单，构建失败：

```
CodeVMError: 编译失败(-3)：偏移 47：不支持的操作码 CC（字节 CC 00）
```

根因：`0xCC` 是 **int3 断点指令**——MinGW / MSVC 用它填充函数间隙与
尾部对齐。函数清单的区间一旦覆盖到这些填充字节（PyInstaller / gcc
产物几乎必然存在），C 内核解码器不认识就报错；而 `protect_pe_batch`
是「任一函数失败 → 整体失败」，一个坏区间拖垮整份清单。

修复（两层）：

1. `integration.py` 新增 `_strip_tail_padding()`：函数切片自动剥掉
   **尾部连续**的 int3（0xCC）/ nop（0x90）填充。语义安全——VM stub
   执行完是「恢复现场后 ret」直接回调用方（peintegrate.c），填充位于
   ret 之后永不执行。只剥尾部，函数体中部的 int3（如 `__debugbreak`）
   不动。
2. `protect_pe_batch` **逐函数降级**：单个函数编译失败（含内核不支持
   的指令）→ 跳过该函数、保留原机器码，日志与报告
   `skipped_functions` 如实注明；与压缩壳 skipped 同一诚实降级策略。
   清单全部失败才报错。

验证：用户同款输入（Portable 副本 87MB）3 函数清单完整批量链路
PASS（编译 + peintegrate 集成 + CheckSum 重算）；降级单测覆盖
「部分失败跳过 / 全部失败报错 / 剥填充 5 组断言」；vmp 25 项、
integration 21 项回归 0 失败。版本升至 3.3.1，插件三副本同步
（manifest 1.2.7）。

边界：函数体**中部**遇到内核指令子集之外的指令（AVX / lock 前缀等）
时该函数仍会跳过虚拟化（保留原样），属既定边界而非缺陷；界面多函数
清单建议选真实函数边界（可从符号表 / 反汇编取函数起始 RVA）。

---

## v3.3.0：C 语言外壳（引导器去 Python 化）+ APK 全量 VMP 架构设计

**动机**：用户提出「程序核心用 C 语言写，避开 Python」。此前 VM 外壳的
引导层是 Python 打包的 PyInstaller stub（~6MB Python 解释器随壳分发，
Python 源码经 VM 化但仍可被还原出较多语义）。v3.3.0 把**保护产物的外壳**
换成纯 C 引导器：产物里不再有 Python 解释器与 Python 字节码。

### 新增：C 引导器（`native/src/bootstub.c`，zig cc 编译，238KB）

- **预编译模板 + overlay 模式**：bootstub.exe 一次性编译后随工具分发，
  构建期无需编译器。每次构建在模板尾部追加 overlay：
  `[nonce 16B][加密配置][载荷][尾表 "CSOVLAY1"+版本+长度]`。
- 配置（守卫模式 / 临时目录策略 / 加密参数 / 迷你 VM 程序）用
  `SHAKE256(nonce‖"CS-CONFIG-v1")` 流混淆，每次构建 nonce 随机 →
  **每个产物外壳逐字节不同**。
- C 侧自实现 SHA-256 与 SHAKE256（Keccak-f1600），与 Python hashlib
  逐字节交叉验证（独立测试程序 `test_bootstub_crypto.c`）。
- C 迷你 VM：16×uint64 寄存器 + 22 操作码（与 Python VM 模板语义严格
  对称），负责「解密参数重构 → 分块流解密 → SHA-256 完整性 → 释放执行」
  这条最敏感的链；步数上限 50M。
- **释放两级回落**：secure 临时文件（delete-on-close）在写句柄打开期间
  CreateProcess 无法创建映像节 → 关句柄触发删除 → 回落常规临时目录
  （此前 Python 版的 secure 路径一直静默回落，行为不变但日志更诚实）。
- 守卫整名匹配逻辑（v3.2.7 修复）同步移植进 C；图标替换改为
  `UpdateResource` API（落盘模板 → 改资源 → 追加 overlay 的顺序）。
- 调试基建：`CS_CONSOLE_DEBUG` 宏（console main + stderr）与 CS_TRACE
  打点，生产编译自动消除。

### VM 虚拟壳新增「外壳类型」

- `VMOptions.shell = "c" | "python"`，**默认 c**。C 模式下不再注入
  Python VMP 源码层，函数虚拟化等能力不受影响；结果卡显示
  「C 引导器 · 无 Python 运行时」徽标。
- `_find_bootstub()` 支持 `CYRILSHIELD_BOOTSTUB` 环境变量覆盖模板路径。

### 验证（真机闭环）

- hello42.exe（写 marker 测试载荷）→ C 外壳保护（含图标 9 尺寸 + 最强
  防护守卫）→ 真机运行 → marker 内容与参数（含空格参数引号）全部正确，
  临时目录自动清理。
- 回归：selftest_vmp 25 项 0 失败；selftest_integration 21 项 0 失败。
- bootstub.exe 已打入 PyInstaller spec 与便携版（native/out）。

### APK：全量 VMP 级虚拟化架构设计（设计稿，未实施）

- 新增 `docs/APK-DVM-DESIGN.md`：业务方法级虚拟化的完整架构——
  dex code_item 解析 → 方法选中 → Dalvik→IR→自定义 ISA（复用 dexvm.py
  多态框架）→ C/JNI 解释器（对象走 JNI 直通、异常表翻译、monitor）→
  桩替换 + 重签名；P1 纯计算子集 → P2 对象+异常 → P3 全指令集路线；
  JNI 局部引用表 / R8 混淆 / 热循环性能等硬骨头逐一列明。

### 边界（诚实声明）

- C 外壳虚拟化的是**引导链与加密流程**，与 Python 版同等强度；外壳本身
  去除 Python 运行时是本次核心收益。业务 EXE 的机器码本体仍按原有
  函数虚拟化流程处理。
- APK 侧业务方法虚拟化为**设计稿**，实施按 APK-DVM-DESIGN.md 分期进行。

---

## v3.2.7：修复「最强防护」误伤本机常驻软件导致保护副本静默退出

真机使用（v3.2.6）：生成的 `WebTerm_upx_vm.exe` 双击后**一闪而过、无窗口、
无报错、退出码 0**。

根因：外壳 stub `main()` 开头 `if not _at_guard(): return` —— 命中反调试 /
反分析环境判定时**纯静默退出**。而反分析启发式 #1 用**子串包含**匹配进程名，
用户机器上 WorkBuddy 自带的 `sandbox-center.exe` / `sandbox-cli.exe` 常驻
后台，进程名含 "sandbox" 被误判为恶意分析沙箱 → 每次启动都被守卫拦杀，
且用户完全无从排查。

修复：

1. `antitamper.py`：进程名匹配改为**整名匹配**（`p == needle` /
   `p == needle + ".exe"`），不再子串误伤合法软件。启发式本来就是概率性
   防线，不为覆盖改名进程而牺牲可用性。
2. `vmgen.py` stub `main()`：命中守卫时**弹窗提示**（只说明"检查未通过，
   可关闭反调试/反分析选项重新生成"，不透露具体命中哪条），不再无声消失。
3. 前端「最强防护」预设说明补充误伤与弹窗行为说明。
4. 版本升至 3.2.7；插件三副本同步（vendor antitamper/vmgen/__init__、
   面板 app.js/index.html/manifest 1.2.5）。

真机闭环：以用户同款设置（最强防护 + 清单 1000:49）重新生成
`WebTerm_upx_vm.exe`（23s，虚拟化按预期跳过 UPX0），实跑 25s 存活且
成功派生载荷子进程。守卫单测：`_at_guard()` 在装有 sandbox-center 的
机器上返回放行。

## v3.2.6：UPX 等压缩壳输入的友好处理（不再整体失败）

真机使用（v3.2.5）暴露：对 **UPX 加壳后的程序**启用函数级虚拟化时，
`IntegrationError: 函数区间超出节区文件数据` 直接失败。

根因：UPX 的节区（UPX0 等）`VirtualSize>0` 但 `SizeOfRawData=0`——
代码在文件里根本不存在（运行时才解压），没有原始机器码可编译成字节码。
**压缩壳输入注定无法做函数级虚拟化，这是本质限制而非 bug。**

改进：

1. `vmp/integration.py` 新增 `packed_section_names()`：检测「虚拟尺寸>0
   且原始数据=0」的节区；`extract_pe_function()` 对 raw=0 与越界两种情况
   分别给出带节区名与数值的明确报错。
2. `vmgen.build()`：虚拟化前先检测壳节区，命中则**自动跳过函数级虚拟化
   （不再整体失败）**，VM 外壳保护照常生效，日志给出三行明确提示与建议
   （用未加壳原程序作输入）。
3. 报告新增 `virtualization.skipped / packed_sections`；前端结果卡显示
   「已跳过」及原因，而不是悄悄少一块。
4. 版本升至 3.2.6；双 EXE 重建冒烟通过；插件三副本 vendor 同步一致。

## v3.2.5：修复「多函数清单 → FileNotFoundError」与清单空格容错

真机使用（v3.2.4）暴露两个 bug，均已修复：

1. **填了多函数清单后必报 `FileNotFoundError: 请选择有效的输入 EXE`**
   （`server.py job_vm`）：构建 SDK 标注清单时把标注源码字符串直接覆盖进
   `src`（本应是待保护 EXE 的落盘路径），随后 `vmgen.build(src,…)` 拿字符串
   当文件路径。现改为独立变量 `marker_src`，`src` 保持不变。
2. **多函数清单冒号后带空格被误判格式错误**（`web/app.js`）：校验前先去除
   全部空白（`1000: 49` 与 `1000:49` 等价），并把规范化后的值回填输入框；
   报错文案补充示例。

- 版本号升至 3.2.5；dist/CyrilShield.exe 与 dist_portable 重建，双 EXE 冒烟
  通过；插件三副本 vendor（server.py / __init__.py）同步且哈希一致。

## v3.2.4：handler 变异强化 + Windows 多线程真机验证 + 新手预设

### C 内核（`native/src/codevm.c`）

- **handler 变异强化**：受变异逻辑 op 从「标准 / 噪声 2 选 1」升级为
  「标准 + 3 套噪声变体 4 选 1」——每逻辑 op 2 bit 选择子由 build 的 seed
  逐 op 随机（`csvm_dispatch_mask` 返回 64 位掩码），三套噪声体分别是
  指针异或、xorshift 游走、乘加混合 + 位旋转的不透明计算，volatile 保证
  不被优化删除；只读 pc/mask/指针派生值、绝不触碰 VM 状态，语义与标准体
  逐位等价。控制流 / 内存 / SSE / VM-exit 类 op 恒走标准实现。
- **Windows 异常安全网重写**：真机首跑发现旧 VEH「手工改写异常 CONTEXT 的
  Rip/Rsp」会挂死（Rsp 快照与编译器栈帧布局不对应 → 反复触发同一异常、
  100% CPU 假死）。现改为 SEH `__try/__except`（`csvm_seh_filter` 过滤
  AV / 非法指令 / 除零 / 特权指令），异常帧随调用栈由 OS 展开，天然线程
  局部、可嵌套可重入，VEH 安装 / 引用计数 / 帧栈全部删除。
- **`win_thread_demo.c` 真机首跑修正**（三项均为首跑当场暴露）：
  1. v5 起 `csvm_run_host` 只接受编译后的 v5 容器，旧 demo 把裸机器码塞进
     run 端，每项都报「字节码无效」→ 现预编译两 seed（A/B）容器 + 一份含
     `call rel32` 的 C 容器；
  2. host 模式 RSP 直通真实栈，旧版 regs_in 里 RSP=0，首个 `push rbp` 写
     [0-8] 段错误 → 现按 Linux 侧 thread_demo 同样传入真实栈地址；
  3. 机器码字面引用 RDI/RSI（`mov rax,rdi / xor rax,rsi`），参数须放
     regs 编号 7/6，旧版按 Win64 ABI 放 RCX/RDX 导致结果系统性错位；
  4. 旧版 ③④ 项是空转的（blob 无 call、worker_exit 只查 rc）→ 现验证
     宿主函数真实调用 3200 次且 RAX=target+1 回填正确，fault 回调由真实
     VM-exit 触发。
- **实测（本机，zig cc → x86_64-windows-gnu，MinGW CRT）**：
  `[win-thread] RESULT=PASS` —— 池复用 2000 次、8 线程 × 2000 次两 seed
  交替全对、8 线程并发 VM-exit 3200 次全对、故障隔离 8/8。
  `win_coldboot_verify.ps1` 重跑 **8/8 PASS**（新内核 + zig 产 win_target.dll
  → peintegrate 改写 → 真机 LoadLibrary 冷启动比对）。
- `selftest_integration.py` 第九批用例改为 Windows 上用 zig cc 实编实跑
  （原为无条件 SKIP）；内置导出表 / .pdata 解析的小工具
  `tools_win_protect_target.py` 保留。重建 `CyrilShield.CodeVM.dll`（14 导出）
  与 `CyrilShield.CodeVM.runtime.dll`（8 导出收敛，def 文件白名单）。

### 界面（新手预设）

- **主面板 VM 页**新增「一键预设」卡：新手推荐 / 均衡分发 / 最强防护，
  一键填好混淆强度、完整性校验、守卫开关、VMP 层开关，密码与输出等个性化
  项不动；说明文案随预设更新。
- **插件面板（组件 v1.2.4）**VM 标签同步预设下拉；「最强防护」在面板无
  反调试选项时给出指引提示。

### 文档

- `docs/CODE-VM.md`：开头结论、§6.4 抗提取差距、§9 多线程边界更新为
  v3.2.4 状态（handler 4 套等价体、Windows 真机 4/4、SEH 安全网）。
- 能力矩阵 `CAPABILITY_MATRIX[virtualization]` 同步。


## v3.2.3：补上 Linux ELF 入口的 UI 与 HTTP 接口

v3.2.2 合入 `vmp/protect_elf.py` 后，它只作为一个命令行模块存在：侧栏没有入口、
前端没有页面、后端没有接口，功能等于不可达。本次把整条链路接通。

### 新增

- **侧栏「ELF 加固」页**（`page-elf`）：拖入 ELF64 可执行文件或 `.so` → 自动扫描
  函数符号 → 勾选要虚拟化的函数 → 生成 `*.csvmpayload`，并可下载 / 打开所在目录。
  与 EXE 侧不同，这里**不改原文件一个字节**，产物靠运行时 `LD_PRELOAD` 挂钩。
- **后端接口**：`/api/elf/inspect`（只读解析，返回架构 / 类型 / 入口 / 符号表状态 /
  可保护函数清单）、`/api/elf/protect`（生成 payload）；任务复用现有 `Job` 日志框架。
- **`protect_elf.inspect()` / `protect()`**：UI 与 CLI 共用的高层入口，
  `main()` 改为调用它们，行为一致。
- **`/api/env` 增加 `elf` 字段**，侧栏显示「虚拟化内核 · ABI 3 · ELF 挂钩就绪」；
  「关于」页补「虚拟化内核」「ELF 挂钩库」两项。
  （上一轮 `/api/env` 已有 `codevm` 字段但没有任何 UI 消费，这次一并接上。）

### 修正

- **符号清单混入未定义导入**：`symbols()` 未区分 `st_shndx == 0`，把
  `getenv@GLIBC_2.2.5` 这类外部导入也当成函数列出来（55 个里 6 个是假目标）。
  新增 `symbols_ex()` 返回 `shndx`，`inspect()` 只保留本目标内定义的函数符号。
- **单个函数不支持即整批失败**：内核指令子集有限（例如 `41 88` =
  `mov r/m8, r8`、`9C` = `pushfq` 未覆盖），原实现遇到第一个失败就抛异常，整个
  payload 生不出来。改为**逐函数编译**：失败的单独跳过、记录原因（含偏移与字节），
  其余函数照常写入，结果区与日志分别列出「已虚拟化 / 跳过」。
- 前端文件选择器按页面切换 `accept`：Linux 可执行文件常无扩展名，ELF 页不做后缀
  过滤，改用 `\x7fELF` 魔数校验，并区分「不是 ELF」与「ELF32 / 大端不支持」。

### 验证（真机，Windows 侧生成 + Linux 样本）

用 `native/out/libcsvm_elfhook.so`（x86-64 ET_DYN）走完整 HTTP 链路：

| 步骤 | 结果 |
|---|---|
| `/api/elf/inspect` | `x86-64 · ET_DYN · 入口 0x0 · 符号表可用`，11 个函数符号 / 5 个可直接编译 |
| `/api/elf/protect`（2 符号 + 1 RVA） | `csvm_elf_fini` 191B → 6649B 字节码；`csvm_elf_init`、`rva_19f0` 因指令不支持被跳过并给出原因；payload 6677 字节 |

### 插件面板（WebTerm 组件）同步

- 面板（`components/cyrilshield`）新增 **ELF 标签页**，与应用内页面同一套后端：
  拖入 `.so` / ELF 自动扫描 → 勾选函数（或填符号名 / RVA:长度）→ 生成 payload，
  结果里直接给出 `LD_PRELOAD=… CSVM_ELF_PAYLOAD=… ./prog` 运行命令。
- `bridge.py`：`_load()` 增载 `vmp.protect_elf`；新增 `elf_info` / `elf` 两个工具
  分发与 ELF 扩展名校验（`.so/.elf/.out/.ko/.axf/.bin`）；`opts` 的 `symbols` /
  `ranges` 同时接受 JSON 数组与逗号分隔字符串（前端 `collect()` 传的是数组，
  首测踩过「把整个数组 repr 当成一个符号名」的坑）。
- 面板五件套（`bridge.py / app.js / index.html / style.css / manifest.json`，
  manifest 升 1.2.3）已同步 `components/`、`dist/components/`、`electron-dist/…/resources/components/`
  三处；实测 bridge 侧 `elf_info`（11 符号 / 5 可保护）与 `elf` 生成（1 入壳、
  2 按原因跳过）均通过。
| 浏览器全流程 | 上传 16.4KB → 扫描 11 行清单 → 勾选生成 → 结果区显示 payload 与运行命令，控制台 0 异常 |

内核覆盖率仍是硬约束：本次样本里 5 个可编译函数中只有部分能真正编译通过，
UI 如实展示跳过原因，不隐瞒。

---

## v3.2.2：合并第八/九/十批（批量虚拟化 + 多线程内核 + ELF 入口）

以 v3.2.1（图标 + CodeVM 单函数）为基底，合入 `CyrilShield-Full-v9-win-elf.zip`
的三批增量；图标能力全部保留。

### 新增能力

- **第八批：多函数批量虚拟化**。`VMOptions.vm_func_list` / `vm_sdk_manifest`、
  `integration.protect_pe_batch()`：一次改写 N 个函数，共享 1 个 `.csvm` 节区
  与 1 个 IAT，可附 SDK 标注清单（`sdk.protection_manifest`）。
  前端 VM 页新增「多函数清单」输入框（`1000:49,1010:18`，RVA 十六进制:长度十进制），
  填了就走批量、留空走单函数。`server.py` 加 `_parse_func_list()`。
- **第九批：内核多线程**。分派表去全局（`csvm_dispatch_mask` 纯函数）、
  VM-exit 异常安全网改为「每 run 装一次 + 每线程帧栈」、每线程 VM 上下文池
  （最多缓存 4 个，`pthread_key` 析构回收）。单线程 VM-exit 吞吐 15.2 万 → 17.7 万 ops/s。
- **第十批：Linux ELF 加固入口**。`vmp/protect_elf.py` + `native/src/elf_hook.c`：
  不改 ELF 程序头、不追加 PT_LOAD，走 `LD_PRELOAD` 运行时挂钩（原文件一字节不改）。
  CLI：`python -m cyrilshield.vmp.protect_elf ./prog --list`。
- **内核修复：SIB 无基址寻址**。`mod==0 && (s&7)==5` 曾按 `base=RBP` 解析，
  导致 `lea rax,[rdx*8+disp32]` 把调用者 RBP 漏进结果（ELF 入口首轮 `sum` 差 8）。
  现已按 x86-64 规则置哨兵槽位 255，运行期从 0 起算。

### 副作用修复

- `native_bridge.discover()` 增加**平台后缀过滤**：同一 `native/out` 里混放
  Windows `.dll` 与 Linux `.so` 时，Windows 不再把 `.so` 当候选而抛
  `WinError 193`，改为跳过并走纯 Python 降级（`selftest_vmp` 该项由 FAIL 恢复为 SKIP）。
- **`peintegrate` 改写后的 DLL 加载即崩（0xC0000005）**：新增的 `.csvm` 节区
  特性原为 `0x60000020`（可读+可执行），但本节区同时承载**本次新增的 IAT**
  （`FirstThunk` 落在节内）。Windows 加载器解析导入时要把真实函数地址写进
  IAT，写入不可写页直接触发访问冲突——表现为 `ctypes.CDLL()` 就 `exit=139`，
  连 DllMain 都进不去，很容易误判成 TLS / 重定位问题。
  定位方式：`LoadLibraryEx(…, 0x8)` 报
  `access violation writing 0x00007FFDD527C600`，而基址 `…27C000 + 0x600`
  正是 IAT 的 RVA。修复：节特性改 `0xE0000020`（加 `MEM_WRITE`），单函数与
  批量两条路径同时生效（`native/src/peintegrate.c` 的 `SCN_CODE`）。
- **`__declspec(thread)` 在 clang/MinGW 下被忽略**：改为 `CSVM_TLS` 宏
  （MSVC→`__declspec(thread)`，其余→`__thread`），否则 5 处线程局部变量
  会静默退化成全局，第九批的多线程隔离形同虚设。
- **`peintegrate` 的 `json_escape()` 未转义 Windows 路径反斜杠**，报告中
  `C:\...` 让 Python 侧 `json.loads` 抛 `Invalid \escape`；已按 JSON 规则转义。
- **导入表被整体替换导致 `WinError 1114`**：新节区只写了 CodeVM 一条描述符，
  把目标模块原有的导入全丢了。改为 `count_import_descs()` 统计原描述符后
  「原表 + CodeVM + 结束符」拼接，`IAT` 目录仅在原来为空时新建。

### 验证

- `selftest.py` 24/24 通过
- `selftest_vmp.py` 24 通过 / 1 跳过 / 0 失败（跳过项＝本机无 Windows 侧载 DLL）
- `selftest_codevm.py` 2 通过 / 8 跳过 / 0 失败（跳过项＝Linux ELF 样本）
- `selftest_integration.py` 5 通过 / 15 跳过 / 0 失败
- **Windows 真机端到端**（本轮实跑，非模拟）：
  - 单函数：`zig` 出的 `t.dll` 改写 `f_sum` 后 `LoadLibrary` 正常，`f_sum(3,5)=49` 与原生一致
  - 批量：`f_sum` + `f_mod` 共享 1 个 `.csvm`（`vsz=0x1304`）与 1 个 IAT，
    `f_mod(7,4)=2`、`f_mod(9,0)=0`（除零分支）均与原生一致
  - **`native/tools/win_coldboot_verify.ps1` 真机 8/8 PASS**（`RESULT=PASS`）：
    真实 `win_target.dll`（含 DIV / RIP 相对常量池 / 128 位乘法）改写后
    与原 DLL 逐项比对一致，用的是**发布版 8 导出运行时 DLL**
- Windows 上 `selftest_codevm.py` / `selftest_integration.py` 的 ELF 相关用例
  改为**如实 SKIP**：本机 PATH 里唯一的 `gcc` 是 Free Pascal 自带的
  i386-Win32 gcc 2.95，产不出可加载的 `.so`，此前表现为 7～10 项红色 FAIL，
  现已把「非 Linux 直接判缺工具链」写进 `_have()`，并补 `LinuxToolchainMissing`
  让 `Env.setup()` 的失败沿用例边界转成 SKIP（不连锁误报）。

### 打包遗漏修复

- **原生组件原本没进安装包**：`CyrilShield.spec` 的 `datas` 只有 web 与图标，
  成品 EXE 里既没有 `peintegrate.exe` 也没有内核 DLL，点「构建」只会得到
  「C 内核未构建」。现已把 `native/out` 的 3 个 Windows 文件按同一相对路径
  打进 onefile（`_MEIPASS/native/out` 正是 `codevm._candidates()` /
  `integration.default_candidates()` 的搜索路径），`build_portable.py` 同步补齐。
- **运行内核改为自动部署**：`vmgen._deploy_runtime_kernel()` 在构建结束时把
  内核复制到成品 EXE 同目录（优先 `CyrilShield.CodeVM.runtime.dll` 8 导出发布版，
  缺则退回构建版）。此前日志只说「运行需同目录部署」，用户漏放就 `err=126` 起不来。
- **`/api/env` 增加 `codevm` 字段**：直接显示内核/运行版文件名与是否 8 导出，
  缺件在侧栏就能看见，不必等构建时报错。
- 打包时按可导入性决定是否带 `PIL.ImageTk`（本机无 tkinter 时不再刷警告）。
- 三处插件组件（`components/`、`dist/components/`、`electron-dist/.../resources/components/`）
  已同步 4 个改动文件，并新增 `vendor/native/out/`（内核 + 发布版 + 集成器）。
  组件自带的 Python 实测可加载内核：`compile(b8 2a 00 00 00 c3)` → `run()=42`。
- `native/tools/`（`win_coldboot_verify.ps1`、`patch_multithread.py`）在合并 zip
  时整目录漏拷，导致 `selftest_integration` 的「Windows 真机冷启动验证链」报缺件；
  已补入。
- `win_coldboot_verify.ps1` 两处真机 bug 修复：
  1) 无 BOM 的 UTF-8 脚本被 PowerShell 5.1 按 ANSI 解析，中文注释打乱语法→
     已加 BOM；
  2) `LoadLibrary` 找不到同目录的 `CyrilShield.CodeVM.dll`（`err=126`）→
     改用 `LoadLibraryEx(…, LOAD_WITH_ALTERED_SEARCH_PATH)`；
  3) 用例里的 `0xDEADBEEF` / `0xFFFFFFFFFFFFFFFF` 被 PowerShell 解析成负
     `Int32`/溢出，转 `UInt64` 报错→改成十进制字符串 + `[uint64]::Parse`。

### DLL 策略（重要）

zip 里的 `CyrilShield.CodeVM.dll` 是**发布版**（第八批抗提取：只导出 8 个运行入口，
去掉 `csvm_compile/disasm/stats/run/run_regs`），ABI 3 / v5 容器。
本机原有那份是 ABI 2 的旧构建。两份都留：

| 文件 | ABI | 导出 | 用途 |
|---|---|---|---|
| `CyrilShield.CodeVM.dll` | 3 | 13 个 | **构建期**：Python 侧需要 `csvm_compile` 编译字节码 |
| `CyrilShield.CodeVM.runtime.dll` | 3 | 8 个 | **运行期**：随成品部署，不给静态 dump 留编译接口 |

---

## v3.2.1：合并原生 CodeVM 分支 + 图标链路补齐

- 以 v3.1.0（含 `vmp/codevm.py`、`vmp/integration.py`、`native/out/*.dll`）为基底，
  重新接回 v3.2 的图标能力，两条版本线合并，功能都不丢。
- 图标界面补齐：VM 页「自定义 EXE 图标」卡片、APK 页「替换 APK 图标」卡片
  （上传 / 预览 / 候选逐项勾选 / 填充方式）；此前只有旧版静态勾选框。
- 新增 `GET /api/apk/icon`：按 zip 路径回显候选图标缩略图；
  `icons.entry_preview_png()` 负责解码缩放，矢量条目回退为占位。
- 修复：`ApkOptions.level="compat"`（仅重签）时 `icon_report` 未初始化导致
  `UnboundLocalError`；图标替换改为与加固等级无关，兼容模式同样可换图标。
- 版本：`__version__ = 3.2.1`、EXE 版本资源 `3.2.1.0`、前端 `APP_VERSION = 3.2.1`、
  插件 `manifest.version = 1.2.1`；插件 vendor 同步至 3.2.1（含缺失的 codevm / integration）。
- 自检：`selftest.py` 24/24 通过；真实 EXE 端到端（图标预览 → APK 候选 → 缩略图 →
  带图标加固）通过；VM 构建自定义图标读回为 9 个尺寸且像素为新图。

---

## 第三批：EXE / APK 自定义图标（v3.2）

| 项 | 内容 |
| --- | --- |
| 新模块 | `cyrilshield/icons.py`：图片解码（PNG/ICO/PE 图标，标准库；装 Pillow 时支持 JPG/BMP/WEBP）、双线性缩放、PNG/ICO 编码、APK 图标资源定位与替换 |
| EXE | `VMOptions.icon_path`：把输入规范化成 16–256 共 9 种尺寸 ICO 传给 PyInstaller `--icon`；支持直接选另一个 EXE / DLL 提取图标；显式指定失败时中止构建，不静默退回旧图标 |
| APK | `ApkOptions.icon_path / icon_entries / icon_fit`：`AndroidManifest.xml` 的 icon / roundIcon → `resources.arsc` 各密度路径 → 自适应图标图层 → 名称兜底；保持 zip 路径与资源 ID 不变，只换内容，随后 zipalign + apksigner 重签 |
| 矢量图标 | `<vector>` 图层复用原 AXML 字符串池与 resource map，重建为 24×24 色块矢量，不需要 aapt2；`.9.png` 与容器 XML 不改 |
| 网页 | VM / APK 两页新增「自定义图标」卡片：上传、预览、启用开关；APK 页列出候选资源逐项勾选 + 填充方式；结果区回显替换数量 |
| 接口 | `GET /api/icon/preview`、`/api/env.icons`；`/api/apk/inspect` 回传 `icons` 候选；`/api/vm`、`/api/apk/protect` 接收 `iconFid` / `iconEntries` / `iconFit` |
| 插件 | `components/cyrilshield` 与打包版 resources 副本：bridge 映射 `iconFid`，简化面板支持上传图标并替换，vendor 同步 5 个模块 |
| 自检 | `selftest.py` 新增 5 项（PNG 往返、多尺寸 ICO、EXE 取图标、APK 按勾选替换、参数接线），29/29 通过 |
| 版本 | `__version__ = 3.2.0`，两个 EXE 版本资源 `3.2.0.0`，前端 `APP_VERSION = 3.2` |

边界不变：只处理自有程序；没有扩展任何杀软 / EDR 对抗、进程注入或驱动能力。

---

## 第一批：EXE 侧运行时守卫（对照差距表）

| 缺失能力 | 处理 | 落地情况 |
| --- | --- | --- |
| 反调试 / 反沙箱 | 新增 | 可选、默认关闭，命中则静默退出 |
| 外壳自身抗反编译 | 部分改善 | 守卫逻辑以 `zlib + base85 + 随机盐` 编码注入，静态反编译只见编码串；PyInstaller onefile 的 `.pyc` 仍可还原（打包方案固有限制） |
| 抗动态 dump（不落地） | 折中 | 加固临时释放：`FILE_FLAG_DELETE_ON_CLOSE` + 去固定特征，缩短明文驻留窗口。**非真·不落地**，原因见 `CyrilShield/docs/SECURITY-NOTES.md` |
| 目标代码虚拟化 | 未做 | 把任意 x86/x64 机器码翻译进自定义 VM 属编译器级工程；当前 VM 虚拟化的是壳自身引导逻辑 |

文件：`cyrilshield/antitamper.py`（新增）、`cyrilshield/vmgen.py`、`server.py`、
`web/app.js` / `index.html` / `app.css`、`selftest.py`、`docs/SECURITY-NOTES.md`、
两个 README。

---

## 第二批：APK 虚拟化与加壳能力加强（本次重点）

| 能力 | 之前 | 现在 | 默认 |
| --- | --- | --- | --- |
| 引导链虚拟化 | 无，壳里是直白的 `key()` / `sub()` / `unseal()` | 编译成自定义字节码，壳内通用 VM 解释执行 | 开 |
| 载荷组织 | 一个 dex → 一个 asset，顺序即 dex 顺序 | 拼流后跨文件乱序切片、每片独立 nonce + 子密钥，重排关系只写在 VM 立即数里 | 开 |
| 壳抗反编译 | 方法名固定、反射字符串明文 | 方法名每次随机、反射字符串 XOR 编码、常量掩码、垃圾指令与死分支 | 开 |
| 字节码多态 | 仅类名 / 路径随机 | 操作码数值、寄存器槽位、常量池顺序、掩码、垃圾指令、OPS 排列全随机 | 开 |
| 内存明文 | 解密后只置 `null`（字节仍在堆里） | direct buffer 交给 ART 后，分片 / 拼接缓冲 / dex 副本逐一律零 | 开 |
| 签名绑定（防重打包） | 无 | 从密钥库导出证书 SHA-256，运行时比对 | 关 |
| 反调试 / 反注入框架 | 无 | 调试器、`TracerPid`、Frida / Xposed 痕迹检测 | 关 |
| 反模拟器 | 无 | `Build.FINGERPRINT` / `MODEL` 启发式判断 | 关 |

### 关键边界（务必读）

**虚拟化的是壳自己的引导逻辑，不是业务 dex 的 Dalvik 字节码。**
把任意 APK 的业务代码整体接管需要完整反汇编器 + ART 侧解释器 + 全指令语义
覆盖，是 VMP 级工程，本项目不做。同样，**做不到「内存里不留完整 dex」**：
ART 加载 dex 必须有一份完整明文映像，擦除的只是我们自己的临时副本。
详见 `CyrilShield/docs/APK-SECURITY-NOTES.md`。

### 文件清单（第二批）

**新增**
- `CyrilShield/cyrilshield/dexvm.py` —— VM 字节码编译器、Python 参考解释器、纯 Java 解释器源码模板
- `CyrilShield/docs/APK-SECURITY-NOTES.md` —— 虚拟化边界、分片、抗 dump、误报与验证说明
- `CHANGES.md`（本文件，替代旧的中文名 `更新说明.md`）

**修改**
- `CyrilShield/cyrilshield/apk.py` —— 壳模板重写、分片交错、VM 接线、签名绑定、
  `_encode_literals` / `_rename_methods` / `_cert_sha256` / `render_stub_sources`、
  `ApkOptions` 新增 6 个开关、结果回传新状态字段
- `CyrilShield/cyrilshield/server.py` —— `job_apk_protect` 映射新参数、`_safe_shards`
- `CyrilShield/cyrilshield/web/index.html` —— APK 页「运行时加固」卡片、关于页说明
- `CyrilShield/cyrilshield/web/app.js` —— 收集新参数、结果区显示 VM / 分片 / 守卫状态
- `CyrilShield/selftest.py` —— 新增 4 项 APK VM 自检
- `README.md`、`CyrilShield/README.md` —— 功能表、步骤、自检、适用范围同步

**未改动**：`pe.py`、`axml.py`、`_stream.py`、`upx.py`、`main.py`、
`build_portable.py`、`tools/`、`assets/`、`tests/` 及所有二进制文件。

### 界面怎么用

APK 加固页新增「运行时加固」卡片：

- **解密后擦除 Java 堆明文**：默认开，纯改进，建议保留。
- **载荷分片数**：`0` = 自动（2–8 片，上限 12）；片越多启动解密次数越多，
  低端机不宜超过 8。
- **绑定签名证书**：默认关。开启后 APK 只能用同一密钥库升级，换密钥库 /
  渠道重签 / 商店二次签名都会导致拒绝加载。
- **反调试 / 反注入框架**、**反模拟器**：默认关。启发式判断，可能误伤云真机、
  调试环境、已 root 设备，分发前请用自己的样本在目标真机验证。

---

## 验证情况（Linux 沙箱实测）

```
全部 .py 语法编译                                     通过
selftest.py <样本>                                    18/22 通过（2 跳过）
  ├ APK 引导链 VM（编译/乱序还原/篡改拒绝/多态）      通过
  ├ APK VM 双端一致性（JDK 真编译运行 Java 解释器）   4 片哈希与 Python 逐字节一致
  ├ APK 壳源码生成与指纹消除                        通过
  └ APK 壳源码编译校验（伪 android 桩类）            4 组开关组合通过
壳 Java 源码 40 组开关组合 javac 编译                 全部通过
完整 _protect_inner 逻辑链（strong/standard/compat）  假工具链跑通，产物自检 6 项全过
```

标准 `selftest.py` 的 4 个 FAIL 均为**环境 / 样本**所致：假样本无图标资源、
Linux 无法执行 Windows 版 `upx.exe`、缺 PyInstaller 与 Android SDK，
与改动无关；在装有依赖的 Windows 上会正常通过。

### 仍需你在真机侧确认

沙箱没有 `d8` / `apksigner` / `zipalign`，**编不出真实 APK**。请用 Windows +
完整 Android 工具链跑一次 `selftest.py <样本.apk>`，安装产物后覆盖冷启动、
Application 委托、多 dex、Activity 跳转；特别测 `minSdk 21–25`（落盘
`DexClassLoader` 分支）与 API 29+。开启签名绑定 / 反调试后，另在换签名、
调试器附着、模拟器环境下确认行为。

> 本工具用于保护你拥有合法权利的程序；不含杀软 / EDR 对抗、AMSI 或 ETW
> 打补丁、进程注入、驱动与持久化等隐蔽或规避手段。

---

## 第三批：EXE 侧 VMP 全面对标 + 原生侧载底层架构（本次）

需求：写底层架构、侧载接入 Python 绕开「Python 不能直接操作硬件」、
除多平台外全面对标 VMP、增加壳的免杀强度；后续收敛为**先对标 EXE，别管安卓**。
**本次 `apk.py` / `axml.py` / `dexvm.py` 及 APK 文档一行未改。**

### 边界（先说清楚）

「免杀强度」实现为 **AV compatibility / 降低加壳产物误报与静态特征命中**：
合法 `VS_VERSION_INFO` 版本资源、图标沿用、熵与节名规范、W^X 审计、多态去特征、
可复现构建清单、Authenticode 签名提示。**不实现** AMSI/ETW 补丁、直接系统调用
绕过用户态钩子、禁用安全产品、进程镂空 / 注入、DLL 侧加载劫持 / 白利用、
内核驱动。详见 `docs/AV-COMPATIBILITY.md`。

### 底层架构：侧载接入

| 层 | 文件 | 作用 |
|---|---|---|
| L0 公开 OS 接口 | `native/src/sidecar.c` | Win32 / WMI / sysfs 只读采集，不装驱动 |
| L1 原生侧载层 | `native/include/cyrilshield_native.h` | 稳定 C ABI，内嵌 SHA-256，零第三方依赖 |
| L2 桥接层 | `cyrilshield/native_bridge.py` | 能力门、ABI 校验、自身摘要钉住、纯 Python 降级 |
| L3 Python 应用层 | `cyrilshield/vmp/*` | 保护能力矩阵与构建编排 |

「侧载」= 同目录部署、由应用**显式 LoadLibrary/dlopen**、加载后校验摘要的伴随库；
不是 DLL 劫持或白利用。`重建EXE.bat` 已加入 `--add-binary`，最终单文件 EXE
无需目标机装 Python，也无需额外携带 DLL；缺件自动降级。

### 对标矩阵（除多平台）

新增 `cyrilshield/vmp/`：`compat.py`（误报审计 / 版本资源 / 清单）、
`integrity.py`（双分块哈希链 + 壳内自校验）、`license.py`（HMAC 离线许可 / HWID /
水印）、`obfuscation.py`（常量加密 / 死块 / 整数分裂 / 动态解析）、
`memory.py`（分块解密 + 即时擦除）、`polymorph.py`（构建指纹）、
`sdk.py`（装饰器 + AST 扫描）、`__init__.py`（矩阵 / `VMPProfile`）。

`antitamper.py` 增强：新增硬件断点 Dr0–Dr3 检测、CPU 品牌与显示规格判据，
所有新探针失败一律放行、默认仍关闭。

`vmgen.py` 接入：`VMOptions.vmp_enabled / vmp_config`、`render_stub(vmp_ctx=...)`、
`_vmp_postprocess`、`_make_vmp_context`；构建时生成 `--version-file` 版本资源与
`cs_manifest.json`（`--add-data`），编译后跑误报风险审计，结果随 `VMResult.vmp` 返回。
**注意**：不往 PyInstaller onefile 尾部追加 overlay（会破坏 CArchive cookie），
水印改由 `--add-data` 承载。

`server.py` / `web/index.html` / `web/app.js`：VM 页新增「VMP 对标层（EXE）」卡片
（开关、产品/公司/版本、离线授权密钥/到期/目标 HWID、版本资源与清单开关），
结果区展示能力数、误报评分、加密处数、死块数、授权状态并可展开对标矩阵。

### 真实差距（不虚标）

- 任意函数级 x86/x64 虚拟化**未实现**：当前 VM 虚拟化的是壳引导链，把任意机器码
  做反汇编 + 语义提升 + 标志位建模进自定义 VM 是编译器级专项工程；
- 真·不落地 / 抗内核 dump **未实现**（需驱动级方案，边界外）；
- .NET / ARM64 / macOS / Linux 多平台矩阵**按用户要求排除**；
- VMP 是十余年商业产品，本轮做到**能力项齐全 + 架构可扩展 + 全部可自测**，
  不代表单点强度等价。

### 验证（Linux 沙箱实测）

```
native/build.sh                          编译 .so 通过，导出符号齐全
selftest_vmp.py                          25/25 全部通过
  ├ 原生后端加载 / HWID / 能力门 / 摘要钉住 / 纯 Python 降级     通过
  ├ VS_VERSION_INFO 回读 / PyInstaller version-file / 误报审计   通过
  ├ 双完整性链（篡改检出）/ 壳内自校验（正常通过 / 篡改退出）   通过
  ├ 离线许可签发 / 签名 / HWID / 到期 / 壳内校验 / 水印         通过
  ├ 分块内存保护 / 常量加密 / 死块 / 整数分裂 / 动态解析         通过
  ├ VMP stub 端到端 exec（11 项能力 + 完整性 + 许可校验）        通过
  └ 旧路径兼容 / 原 VM 字节码端到端自检                          通过
selftest.py tools/upx.exe                18/22（4 FAIL 均为环境：样本无图标、
                                          Linux 跑不了 upx.exe、缺 PyInstaller）
```

沙箱无 PyInstaller Windows 后端，未生成真实可安装 EXE。请在 Windows 跑
`native\build.bat` → `重建EXE.bat`，并用 `selftest_vmp.py` 与真机冷启动、
调试器附着、换签名、误报扫描（VirusTotal / Defender）各验一轮。
