# -*- coding: utf-8 -*-
"""v3.3.4 回归：自动函数发现（VMP 对标第十一批）。"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cyrilshield import vmgen                       # noqa: E402
from cyrilshield.vmp import codevm as cv           # noqa: E402
from cyrilshield.vmp import integration as it      # noqa: E402

HELLO = os.path.join("native", "out", "hello42.exe")
PORTABLE = os.path.join("dist_portable", "CyrilShield-Portable - 副本.exe")
MARKER = os.path.join(tempfile.gettempdir(), "hello42_marker.txt")
FAILS: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(("PASS " if ok else "FAIL ") + name + ("  " + detail if detail else ""))
    if not ok:
        FAILS.append(name)


def main() -> int:
    vm = cv.get_codevm()
    data = open(HELLO, "rb").read()
    funcs, info = it.discover_pe_functions(data, max_funcs=4)
    check("自动发现拿到函数清单", len(funcs) >= 2, f"n={len(funcs)}")
    check("候选起点互不重叠",
          all(funcs[i][0] + funcs[i][1] <= funcs[i + 1][0]
              for i in range(len(funcs) - 1)))
    ok_all = True
    for rva, size in funcs:
        try:
            code = it.extract_pe_function(data, rva, size)
            _bc, used = it._compile_with_tail_retry(vm, code, seed=None)
            if not it._ir_ends_with_terminator(vm, used):
                ok_all = False
        except Exception:
            ok_all = False
    check("每个发现结果都能编译且以函数出口收尾", ok_all,
          str([(hex(r), s) for r, s in funcs]))
    check("info 记录扫描统计", info["scanned_bytes"] > 0
          and info["candidates"] > 0 and info["accepted"] == len(funcs))

    if os.path.isfile(PORTABLE):
        pdata = open(PORTABLE, "rb").read()
        pfuncs, _pinfo = it.discover_pe_functions(pdata, max_funcs=4)
        check("用户 Portable 输入自动定位到 0x1000",
              bool(pfuncs) and pfuncs[0][0] == 0x1000,
              str([(hex(r), s) for r, s in pfuncs[:2]]))
        check("0x1000 自动裁到真实边界 47（非含填充的 49）",
              bool(pfuncs) and pfuncs[0][1] == 47,
              f"size={pfuncs[0][1] if pfuncs else '-'}")

    out = os.path.join(tempfile.gettempdir(), "cs334_auto.exe")
    side = os.path.join(os.path.dirname(out), "CyrilShield.CodeVM.dll")
    for p in (out, side, MARKER):
        if os.path.exists(p):
            os.remove(p)
    vo = vmgen.VMOptions(
        junk_level=1, verify=True, cleanup=True, forward_args=True,
        keep_icon=False, anti_debug=False, anti_sandbox=False,
        secure_temp=True, vmp_enabled=False, shell="c",
        virtualize=True, vm_auto_discover=True, vm_auto_max=3,
    )
    logs: list[str] = []
    r = vmgen.build(HELLO, out, vo, on_line=logs.append)
    vz = r.virtualization or {}
    auto = vz.get("auto_discover") or {}
    check("完整构建成功", os.path.isfile(out), f"{os.path.getsize(out):,}B")
    check("报告带 auto_discover", auto.get("accepted", 0) >= 1,
          f"accepted={auto.get('accepted')}")
    check("日志声明自动发现", any("自动函数发现" in s for s in logs))
    check("输出目录仍为单文件（无外部 DLL）", not os.path.exists(side))
    rc = -1
    try:
        rc = subprocess.run([out, "ARG1"], capture_output=True, timeout=60).returncode
    except subprocess.TimeoutExpired:
        rc = -998
    check("真机运行 rc=0", rc == 0, f"rc={rc}")

    # 手填清单优先于自动发现（不被悄悄覆盖）
    logs2: list[str] = []
    vo2 = vmgen.VMOptions(
        junk_level=1, verify=True, cleanup=True, forward_args=True,
        keep_icon=False, anti_debug=False, anti_sandbox=False,
        secure_temp=True, vmp_enabled=False, shell="c",
        virtualize=True, vm_auto_discover=True, vm_auto_max=3,
        vm_func_list=[(0x1008, 24)],
    )
    r2 = vmgen.build(HELLO, out, vo2, on_line=logs2.append)
    check("手填清单优先，不触发自动发现",
          not (r2.virtualization or {}).get("auto_discover")
          and not any("自动函数发现" in s for s in logs2))

    for p in (out, MARKER):
        if os.path.exists(p):
            os.remove(p)
    print("-" * 60)
    print("FAILS: " + (", ".join(FAILS) if FAILS else "none"))
    return 1 if FAILS else 0


if __name__ == "__main__":
    raise SystemExit(main())
