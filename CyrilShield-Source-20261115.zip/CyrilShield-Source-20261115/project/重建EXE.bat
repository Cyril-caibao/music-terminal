@echo off
chcp 65001 >nul
setlocal
set "APP=%~dp0"
set "PY="

for %%P in (
  "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
  "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
  "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
) do (
  if not defined PY if exist %%P set "PY=%%~P"
)
if not defined PY set "PY=python"

pushd "%APP%"

echo 正在生成版本资源（RT_VERSION，用于降低误报）...
"%PY%" -c "from cyrilshield.vmp import compat; from cyrilshield import __version__; open('cs_version.py','w',encoding='utf-8').write(compat.version_file_source(company='CyrilShield',product='CyrilShield',description='Local EXE protection tool',original_filename='CyrilShield.exe',file_version=__version__+'.0'))"
if errorlevel 1 (
  echo 版本资源生成失败。
  popd
  goto :fail
)

echo 检查原生侧载层...
set "NATIVE=%APP%native\out\CyrilShield.Native.dll"
set "NATIVE_ARG="
if exist "%NATIVE%" (
  set NATIVE_ARG=--add-binary "%NATIVE%;."
  echo   已找到 CyrilShield.Native.dll，将打进单文件 EXE。
) else (
  echo   未找到侧载 DLL，工具会自动降级到纯 Python 后端。
  echo   如需完整硬件指纹能力，请先运行 native\build.bat。
)

echo 正在重新打包独立 EXE ...
"%PY%" -m PyInstaller --noconfirm --clean --onefile --windowed --noupx ^
  --log-level=WARN --name CyrilShield --icon "assets/app.ico" ^
  --version-file "cs_version.py" ^
  --add-binary "tools/upx.exe;tools" ^
  --add-data "cyrilshield/web;cyrilshield/web" ^
  --add-data "assets/app.ico;assets" ^
  --hidden-import=PIL.Image --hidden-import=PIL.ImageTk ^
  %NATIVE_ARG% ^
  --distpath dist --workpath .build --specpath . main.py
set "RC=%errorlevel%"
popd
if not "%RC%"=="0" goto :fail
echo 完成：%APP%dist\CyrilShield.exe
echo 目标机器无需安装 Python；侧载 DLL 已内嵌（若存在）。
goto :end

:fail
echo 打包失败，请确认已安装 PyInstaller ^(pip install pyinstaller^)。
pause
endlocal
exit /b 1

:end
pause
endlocal
