# -*- coding: utf-8 -*-
"""代码虚拟化 C 内核端到端自检。

判据不是「能生成字节码」，而是：**从真实 gcc 编译出的 x86-64 函数里抽出
机器码，翻译进私有 ISA 后由 C 解释器执行，结果必须与 CPU 原生执行逐字节一致。**

运行：
    python selftest_codevm.py
依赖：gcc / nm（Linux 自检）；缺则相关项 SKIP，不假装通过。
"""
from __future__ import annotations

import ctypes
import os
import random
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cyrilshield.vmp import codevm as cv

ROOT = os.path.dirname(os.path.abspath(__file__))
NATIVE = os.path.join(ROOT, "native")
SAMPLE_C = os.path.join(NATIVE, "samples", "reference.c")

TESTS = []


NAMES = {
    "t_kernel_build": "C 内核构建与 ABI",
    "t_real_machine_code": "真实机器码抽取",
    "t_disasm_no_trap": "IR 提升无 TRAP",
    "t_exec_matches_cpu": "VM 与 CPU 结果一致",
    "t_polymorphism": "多态与垃圾指令",
    "t_tamper_rejected": "字节码篡改拒绝",
    "t_trap_on_bad_code": "不支持指令显式报错",
    "t_build_report": "UI 构建报告",
    "t_missing_kernel_degrades": "缺内核明确降级",
    "t_no_python_vm_logic": "Python 侧无内核逻辑",
}


def test(fn):
    TESTS.append((fn, NAMES.get(fn.__name__, fn.__name__)))
    return fn


# 必须先用 CPU 原生跑一遍、或从 ELF 抽字节码的用例（依赖 Env.setup 的样本）
NEEDS_ENV = {
    "t_real_machine_code", "t_disasm_no_trap", "t_exec_matches_cpu",
    "t_polymorphism", "t_tamper_rejected", "t_trap_on_bad_code",
    "t_build_report",
}


def _have(*tools):
    return all(subprocess.run(["which", t], capture_output=True).returncode == 0 for t in tools)


class LinuxToolchainMissing(Exception):
    """样本函数必须从 Linux x86-64 ELF 里抽，缺该工具链时整组用例 SKIP。"""


class Env:
    def __init__(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="csvm_selftest_")
        self.d = self.tmp.name
        self.so = os.path.join(self.d, "libsample.so")
        self.code = {}
        self.vm = None
        self.native = None
        self.ready = False
        self.skip_reason = ""

    def setup(self):
        if sys.platform == "win32":
            # 本组样本用 -fPIC -shared 编 libsample.so 再用 nm 取符号，目标是
            # Linux x86-64 ELF。Windows 上即便 PATH 里有 gcc（例如 Free Pascal
            # 自带的 i386-Win32 gcc 2.95）也不是同一 ABI：产物无法加载，
            # 只会抛 WinError 193。这里显式 SKIP，不伪装成通过，也不误报失败。
            self.skip_reason = ("Windows 无 Linux x86-64 工具链：本组用例依赖 "
                                "ELF 样本（-fPIC -shared + nm），改由 Linux 侧跑")
            raise LinuxToolchainMissing(self.skip_reason)
        subprocess.run([os.path.join(NATIVE, "build.sh")], check=True,
                       capture_output=True, text=True)
        subprocess.run(["gcc", "-O2", "-fPIC", "-shared", "-fcf-protection=none",
                        "-o", self.so, SAMPLE_C], check=True, capture_output=True, text=True)
        for s in ("f_fib", "f_mix", "f_branch"):
            self.code[s] = cv.extract_elf_function(self.so, s)
        self.vm = cv.get_codevm()
        self.native = ctypes.CDLL(self.so)
        self.ready = True

    def close(self):
        self.tmp.cleanup()


E = Env()


@test
def t_kernel_build():
    if not _have("gcc"):
        return "SKIP", "缺 gcc"
    try:
        E.setup()
    except LinuxToolchainMissing as exc:
        return "SKIP", str(exc)
    assert E.vm is not None
    assert os.path.basename(E.vm.path).startswith(("libcyrilshield_codevm", "CyrilShield.CodeVM"))
    return f"已加载 {os.path.basename(E.vm.path)}（C ABI v1）"


@test
def t_real_machine_code():
    assert set(E.code) == {"f_fib", "f_mix", "f_branch"}
    head = E.code["f_mix"][:4].hex()
    assert E.code["f_mix"][0] in (0x48, 0x55, 0x41)  # 真实 x86-64 字节，不是构造的序列
    return "从 ELF .text 抽取 3 个函数，" + ", ".join(
        f"{k}={len(v)}B" for k, v in E.code.items()) + f"（f_mix 头 {head}）"


@test
def t_disasm_no_trap():
    for name, code in E.code.items():
        listing = E.vm.disasm(code)
        assert "TRAP" not in listing, f"{name} 出现不支持指令:\n{listing}"
        assert "MOV" in listing and "RET" in listing
    return "3 个函数的 IR 清单无 TRAP，C 内核覆盖其全部指令"


def _native(name, args, signed=False):
    fn = getattr(E.native, name)
    fn.restype = ctypes.c_int64 if signed else ctypes.c_uint64
    fn.argtypes = [ctypes.c_int64 if signed else ctypes.c_uint64] * len(args)
    return fn(*args) & ((1 << 64) - 1)


@test
def t_exec_matches_cpu():
    cases = [
        ("f_fib", [0], False), ("f_fib", [1], False), ("f_fib", [10], False),
        ("f_fib", [30], False), ("f_fib", [50], False), ("f_fib", [80], False),
        ("f_mix", [1, 2], False),
        ("f_mix", [0x123456789ABCDEF, 0xFF], False),
        ("f_mix", [0, 0], False),
        ("f_mix", [0xFFFFFFFFFFFFFFFF, 0x1234], False),
        ("f_branch", [3, 4], True), ("f_branch", [9, 9], True),
        ("f_branch", [100, 7], True), ("f_branch", [7, 100], True),
        ("f_branch", [-5, 5], True),
    ]
    rng = random.Random(20261109)
    for _ in range(12):
        cases.append(("f_mix", [rng.getrandbits(64), rng.getrandbits(64)], False))
    for _ in range(8):
        cases.append(("f_branch", [rng.randint(-10**6, 10**6),
                                   rng.randint(-10**6, 10**6)], True))
    checked = 0
    for name, args, signed in cases:
        bc = E.vm.compile(E.code[name], seed=0xC0FFEE)
        got = E.vm.run(bc, [a & ((1 << 64) - 1) for a in args])
        want = _native(name, args, signed)
        assert got == want, f"{name}{args}: VM=0x{got:016x} CPU=0x{want:016x}"
        checked += 1
    return f"{checked} 组参数，VM 执行结果与 CPU 原生执行逐字节一致"


@test
def t_polymorphism():
    digests, results = set(), set()
    for seed in range(1, 41):
        bc = E.vm.compile(E.code["f_mix"], seed=seed)
        digests.add(bytes(bc))
        results.add(E.vm.run(bc, [1, 2]))
    assert len(digests) == 40, f"只有 {len(digests)}/40 种不同字节码"
    assert len(results) == 1, "多态改变了语义"
    st = E.vm.stats(E.vm.compile(E.code["f_mix"], seed=1))
    assert st["junk_insns"] > 0 and st["ir_insns"] > 0
    return (f"40/40 字节码互异、结果唯一；IR={st['ir_insns']} "
            f"BC={st['bc_insns']} 垃圾指令={st['junk_insns']}")


@test
def t_tamper_rejected():
    bc = bytearray(E.vm.compile(E.code["f_mix"], seed=7))
    bc[600] ^= 0x01
    try:
        E.vm.run(bytes(bc), [1, 2])
    except cv.CodeVMError as exc:
        assert "篡改" in str(exc) or "完整性" in str(exc), str(exc)
        return "翻转字节码 1 字节 -> CRC 拒绝执行"
    raise AssertionError("篡改未被拒绝")


@test
def t_trap_on_bad_code():
    # 0x0F 0x0B 是 UD2，不在支持子集内；必须明确报错而不是静默通过
    try:
        E.vm.compile(b"\x0f\x0b\xc3", seed=1)
    except cv.CodeVMError as exc:
        assert "不支持" in str(exc), str(exc)
        return "不支持指令返回带偏移的错误，不静默吞掉"
    raise AssertionError("不支持指令被静默接受")


@test
def t_build_report():
    r = cv.build_report(E.code["f_fib"], seed=99)
    assert r.available and r.error == ""
    assert r.bc_bytes > 0 and r.ir_insns > 0 and r.seed == 99
    d = r.as_dict()
    assert d["engine"].startswith("C11")
    return (f"UI 报告可用：IR={r.ir_insns} BC={r.bc_insns} "
            f"字节码={r.bc_bytes}B engine={r.engine}")


@test
def t_missing_kernel_degrades():
    try:
        cv.CodeVM("/definitely/not/here/libcodevm.so")
    except cv.CodeVMUnavailable:
        return "缺 C 内核时明确报错（不静默用 Python 假 VM 兜底）"
    raise AssertionError("缺库未报错")


@test
def t_no_python_vm_logic():
    # 编排层不得含有解释器 / 反汇编逻辑
    src = open(cv.__file__, encoding="utf-8").read()
    for banned in ("eval_cc", "decode_one", "lift_one", "run_blob", "opcode 表"):
        assert banned not in src, f"Python 侧出现了内核逻辑: {banned}"
    return "Python 侧只有 ABI 封装与报告，无反汇编/IR/解释器逻辑"


def main():
    ok = skip = fail = 0
    width = max(len(n) for _, n in TESTS)
    print("=" * 78)
    print("CyrilShield 代码虚拟化 C 内核 — 端到端自检")
    print("=" * 78)
    try:
        for fn, name in TESTS:
            try:
                # 依赖 ELF 样本的用例：环境准备不上就统一 SKIP，避免连锁误报
                needs_env = fn.__name__ != "t_kernel_build" and fn.__name__ in NEEDS_ENV
                if needs_env and not E.ready:
                    skip += 1
                    print(f"[SKIP] {name.ljust(width)}  {E.skip_reason or '样本环境未就绪'}")
                    continue
                r = fn()
                if isinstance(r, tuple) and r[0] == "SKIP":
                    skip += 1
                    print(f"[SKIP] {name.ljust(width)}  {r[1]}")
                else:
                    ok += 1
                    print(f"[ OK ] {name.ljust(width)}  {r}")
            except Exception as exc:
                fail += 1
                print(f"[FAIL] {name.ljust(width)}  {type(exc).__name__}: {exc}")
    finally:
        E.close()
    print("-" * 78)
    print(f"合计 {len(TESTS)} 项：通过 {ok}，跳过 {skip}，失败 {fail}")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
