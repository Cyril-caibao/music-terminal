# CyrilShield 第九批（多线程上下文）改动说明

本轮只改 EXE 侧原生内核 + 自检，不动 APK 侧。目标：把「多线程挑不出问题」从
「文档里写着缺」变成「有实现、有实测、有对照」。

## 一、改了哪三处（内核 `native/src/codevm.c`）

### 1. handler 分派表去全局
- 旧：进程级 `static csvm_hfn g_handlers[IR_COUNT+1]`，每次 `run_blob` 调
  `csvm_dispatch_ensure(seed)` 用当前 blob 的 seed 重建整张表。
  两个线程跑不同 seed 的字节码时，函数指针被并发改写（数据竞争，形式上是 UB）。
- 新：`csvm_dispatch_mask(seed)` 纯函数算 32 位掩码，掩码只放在 `run_blob` 的栈帧。
  同一 seed 选出的 handler 组合与旧实现逐位等价，但**没有共享可写状态**。

### 2. VM-exit 异常安全网：从「每次 exit 装 8 次」改为「每 run 装一次」
- 旧：每次 VM-exit 做 4 装 + 4 还原共 8 次 `sigaction`；`csvm_old_sa[4]` 是进程级
  静态，两线程并发安装会互相覆盖「旧处理器」；`csvm_in_exit` 无线程 frame 栈，
  嵌套（VM → 宿主函数 → VM）时内层直接跳过安全网。
- 新：
  - 互斥 + 引用计数：进程内 0→1 安装、1→0 还原；
  - 每线程一个 `csvm_guard_frame_t` 栈，故障只 longjmp 到本线程栈顶，天然支持嵌套；
  - `sigsetjmp` 收进独立 `noinline` 包裹函数 `csvm_call_exit_gpr/_fpu`。
    **这一步是修 bug**：旧写法把 `sigsetjmp` 与调用方局部变量（`rc`/`fault`）混在一起，
    longjmp 之后这些局部变量按 C 标准不确定，实测拿到信号号 11 并走错分支
    （表现为「原生调用失败」而不是「宿主异常」）。
  - 本线程不在安全网内时，链回安装前保存的处理器；没有则恢复默认并重新递送，
    不吞别的线程或宿主自己的异常。

### 3. 每线程 VM 上下文池
- 旧：每次 run `calloc(1, sizeof(vm_t))`（含 64KB 沙箱内存）+ `free`。
- 新：每线程借用/归还，最多缓存 4 个；嵌套 run 自动再借一个；线程退出由
  `pthread_key` 析构回收；归还只擦通用寄存器与 XMM，64KB `mem[]` 留给下次 run 覆写。
- 注意：一开始做的是「归还时全量 `csvm_sec_zero`」，实测把单线程 VM-exit 吞吐从
  15.2 万拖到 4.9 万 ops/s（每次多两次 64KB memset）。改成只擦小块后回到 17.7 万。

## 二、实测数据（`native/out/thread_demo`，8 线程，Linux 真并发）

| 用例 | 规模 | 结果 |
|---|---|---|
| 并发基础（两 seed 交替） | 8 线程 × 2000 = 16000 次 | 与原生逐位一致，0 错误 |
| 并发 VM-exit（调 strlen） | 8 线程 × 400 = 3200 次 | 全部正确 |
| 可重入（外层 VM→宿主→内层 VM） | 8 线程 × 300 = 2400 次 | 全部正确 |
| 故障隔离（1 线程宿主回调 SIGSEGV） | 1 故障线程 + 7 正常线程 | 故障线程被捕获为 TRAP，其余 7 线程照常完成，进程存活 |
| 并发编译同一机器码 | 8 线程 | 全部成功且长度一致 |
| 单线程 VM-exit 吞吐 | 20000 次 | **17.7 万 ops/s** |

### 新旧对照
- 旧实现（原 `codevm.c`）：同场景 8 线程直接 `*** stack smashing detected ***` 崩溃
  （全局分派表 + 进程级 `csvm_old_sa` + longjmp 局部变量 UB 三者叠加）。
- 新实现：6/6 通过，`[thread] RESULT=PASS`。
- 单线程吞吐：旧 15.2 万 → 新 17.7 万 ops/s（约 +16%）。

### 竞争检测
- ThreadSanitizer 构建（关掉信号安全网以隔离竞争检测）：
  8 线程跑并发基础 / 并发 VM-exit / 可重入 / 并发编译，**未报告任何 data race**。
- 开了信号安全网的 TSan 运行只报「signal handler 里做了非异步信号安全调用」的提示
  （`siglongjmp` 出去之后继续跑正常代码造成的误判），不报竞争，功能用例全过。

## 三、集成自检
- `python3 selftest_integration.py`：**19 项 → 12 通过 / 7 跳过 / 0 失败**
  （7 跳过仍全是「无 Windows 交叉工具链」或「无真机」）。
- 新增项 `t_thread_ctx` 直接调用 `thread_demo` 并断言 6 个 PASS 标记。

## 四、诚实边界 / 下一轮

1. **Windows DLL 未重建**：本沙箱没有 clang / lld-link / mingw，`native/out/CyrilShield.CodeVM.dll`
   仍是上一版产物。请在你机器上跑 `native\build-win.sh` 或 `build.bat` 重新出 DLL；
   Windows 侧的改动是纯 C 的（去全局表 + 引用计数 + calloc 直通上下文），应当可编译，
   但我**没有实测过**，不能说已验证。
2. **Windows 无异常穿透**：安全网在 `_WIN32` 下是桩，SEH 未接；Windows 多线程
   目前是「安全但无池化、无故障捕获」。
3. **`.cold` 在主线之前（负 RVA）仍不支持**：`csvm_compile_cfg` 的坐标空间是
   uint32 正偏移，gcc 把 `.text.unlikely` 放在 `.text` 前面时仍会报
   「段 1 的 RVA 超出 32 位坐标空间」。下一轮把坐标原点改成「所有段的最小 RVA」，
   同时把 `src_off` 的基准一并改掉（涉及 IR_JMPI 的闭包判定，不能只改编译侧）。
4. **真机多线程冷启动**：`win_coldboot_verify.ps1` 目前是单线程，需扩成多线程版本。
