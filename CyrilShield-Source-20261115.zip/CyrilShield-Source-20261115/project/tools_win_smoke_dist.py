# -*- coding: utf-8 -*-
"""成品冒烟：起 dist 两份 EXE → /api/env 与 / 预设卡检查。"""
import json
import subprocess
import sys
import time
import urllib.request

TARGETS = [
    (r"D:\Cyril-Shield\dist\CyrilShield.exe", 18701),
    (r"D:\Cyril-Shield\dist_portable\CyrilShield-Portable.exe", 18702),
]
procs = []
try:
    for exe, port in TARGETS:
        procs.append(subprocess.Popen([exe, "--port=%d" % port, "--no-browser"]))
    time.sleep(15)
    ok = True
    for _exe, port in TARGETS:
        print("== port", port, "==")
        try:
            h = urllib.request.urlopen("http://127.0.0.1:%d/" % port, timeout=8).read().decode("utf-8", "replace")
            print("  preset card=%s radio=%s hint=%s" % (
                "vmPreset" in h, "vmpreset" in h, "vmPresetHint" in h))
            import re
            m = re.search(r'name="token" content="([A-Za-z0-9_\-]+)"', h)
            tok = m.group(1) if m else ""
            req = urllib.request.Request(
                "http://127.0.0.1:%d/api/env" % port, headers={"X-Token": tok})
            d = json.load(urllib.request.urlopen(req, timeout=8))
            cvd = d.get("codevm") or {}
            elf = d.get("elf") or {}
            ico = d.get("icons") or {}
            print("  codevm.ok=%s runtime=%s | elf.ok=%s hook=%s | pillow=%s | android.bundled=%s" % (
                cvd.get("ok"), cvd.get("runtime_release"), elf.get("ok"),
                elf.get("hook_found"), ico.get("pillow"),
                (d.get("android") or {}).get("bundled")))
        except Exception as exc:
            ok = False
            print("  FAIL:", exc)
    sys.exit(0 if ok else 1)
finally:
    for p in procs:
        p.terminate()
