# -*- coding: utf-8 -*-
"""EXE / VMP 对标层自检（不依赖 PyInstaller、不需要 Windows、不碰安卓链路）。

用法：python selftest_vmp.py
覆盖：原生侧载桥接、能力矩阵、误报审计、完整性链、离线授权、内存保护、
      壳源码混淆与多态、SDK 标记，以及 vmgen.render_stub 的端到端集成。
"""
from __future__ import annotations

import hashlib
import os
import random
import struct
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cyrilshield import native_bridge as nb
from cyrilshield import vmgen
from cyrilshield.vmp import (VMPProfile, parity_report, profile_from_dict,
                             excluded_capabilities)
from cyrilshield.vmp import compat, integrity, license as lic, memory
from cyrilshield.vmp import obfuscation as obf, polymorph as poly, sdk

OK, FAIL, SKIP = "[ OK ]", "[FAIL]", "[SKIP]"
results: list[tuple[str, str, str]] = []


def check(name: str, fn):
    try:
        detail = fn()
        results.append((str(detail).startswith("SKIP:") and SKIP or OK,
                        name, str(detail or "")))
    except Exception as exc:
        results.append((FAIL, name, f"{type(exc).__name__}: {exc}"))


# ---------------------------------------------------------------- 侧载桥接
def t_native():
    b = nb.get_bridge()
    hw = b.hwid()
    assert len(hw.digest) == 32 and len(hw.machine) == 16
    assert b.ticks() > 0
    assert len(b.self_digest()) == 32
    return f"backend={b.kind}, hwid={hw.short}, caps={len(b.capabilities)}"


def t_pure_fallback():
    p = nb.PurePythonBackend()
    bridge = nb.Bridge(p, nb.CapabilityGate({"hwid", "ticks"}), "forced")
    hw = bridge.hwid()
    assert len(hw.digest) == 32 and bridge.ticks() > 0
    try:
        bridge.file_digest(__file__)
        raise AssertionError("能力门未拦截未授权调用")
    except nb.SidecarError:
        pass
    return f"纯 Python 回落 hwid={hw.short}，能力门拦截正常"


def t_selfhash_pin():
    path = nb.NativeBackend.discover()
    if not path:
        return "SKIP: 无侧载库（降级路径已覆盖）"
    digest = hashlib.sha256(open(path, "rb").read()).hexdigest()
    assert nb.NativeBackend(path, digest).hwid().digest
    try:
        nb.NativeBackend(path, "0" * 64)
        raise AssertionError("错误摘要未被拒绝")
    except nb.SidecarError:
        pass
    return "摘要钉住 + 同名替换拒绝正常"


# ---------------------------------------------------------------- 矩阵 / 配置
def t_matrix():
    m = VMPProfile()
    assert m.enabled_keys() and len(excluded_capabilities()) == 1
    assert excluded_capabilities()[0]["key"] == "multi_platform"
    txt = parity_report(m)
    assert "| VMP 能力项 |" in txt and "明确排除" in txt
    assert "virtualization" in txt and "av_compatibility" in txt
    return f"启用 {len(m.enabled_keys())} 项，多平台已排除"


def t_profile_validation():
    try:
        profile_from_dict({"mutation_level": 9})
        raise AssertionError("非法配置未被拒绝")
    except ValueError:
        pass
    p = profile_from_dict({"mutation_level": 3, "license_features": ["a", "b"]})
    assert p.mutation_level == 3 and p.license_features == ("a", "b")
    return "类型收敛与越界校验正常"


# ---------------------------------------------------------------- 误报 / PE
def fake_pe() -> bytes:
    b = bytearray(b"MZ" + b"\x00" * 0x3A + struct.pack("<I", 0x40))
    b += b"\x00" * (0x40 - len(b))
    b += b"PE\x00\x00"
    size_opt = 240
    b += struct.pack("<HHIIIHH", 0x8664, 2, 0x5F000000, 0, 0, size_opt, 0x0022)
    opt = bytearray(size_opt)
    struct.pack_into("<H", opt, 0, 0x20B)
    struct.pack_into("<I", opt, 64, 0x12345)
    struct.pack_into("<H", opt, 70, 0x0140)     # ASLR | DEP
    b += opt
    for name, va, vs, ro, rs, ch in (
        (b".text", 0x1000, 0x200, 0x200, 0x200, 0x60000020),
        (b".rdata", 0x2000, 0x100, 0x400, 0x100, 0x40000040),
    ):
        b += name.ljust(8, b"\x00")
        b += struct.pack("<IIII", vs, va, rs, ro)
        b += b"\x00" * 12
        b += struct.pack("<I", ch)
    b += bytes((i * 37) & 0xFF for i in range(0x500))
    return bytes(b)


def t_pe_parse():
    pe = compat.parse_pe(fake_pe())
    assert pe.valid and len(pe.sections) == 2
    assert pe.sections[0].name == ".text" and pe.timestamp != 0
    assert all(0 <= s.entropy <= 8 for s in pe.sections)
    return f"PE32+ / {len(pe.sections)} 节 / 熵 {pe.sections[0].entropy:.2f}"


def t_av_audit():
    r = compat.av_compat_audit(fake_pe())
    assert 0 <= r["score"] <= 100 and r["findings"]
    assert any(f["key"] == "wx_section" for f in r["findings"])
    assert r["sha256"]
    return f"评分 {r['score']}/100，{len(r['findings'])} 项检查，W^X 通过"


def t_version_resource():
    blob = compat.version_info_bytes(
        company="CyrilShield", product="Demo", description="Protected build",
        original_filename="demo.exe", file_version="1.2.3.4")
    assert len(blob) > 100 and blob[:2] == struct.pack("<H", len(blob))
    fields = compat.version_info_fields(blob)
    assert fields.get("CompanyName") == "CyrilShield", fields
    assert fields.get("FileVersion") == "1.2.3.4", fields
    return f"VS_VERSION_INFO {len(blob)} 字节，字段回读 {len(fields)} 项"


def t_version_file():
    src = compat.version_file_source(
        company="CyrilShield", product="Demo", description="Protected build",
        original_filename="demo.exe", file_version="1.2.3.4")
    compile(src, "cs_version.py", "exec")
    assert "VSVersionInfo" in src and "1, 2, 3, 4" in src
    assert "CompanyName" in src
    assert compat.signing_hint("demo.exe").startswith("signtool sign")
    return "PyInstaller --version-file 源码语法与字段正常"


def t_overlay_manifest():
    data = fake_pe()
    marked = compat.overlay_append(data, b"WM-001")
    got = compat.overlay_read(marked)
    assert got == b"WM-001"
    assert len(marked) > len(data)
    m = compat.build_manifest([("a.bin", b"abc"), ("b.bin", b"def")])
    assert len(m["files"]) == 2 and m["schema"].endswith("/1")
    return "overlay 水印回读 + 可复现构建清单正常"


# ---------------------------------------------------------------- 完整性
def t_integrity():
    blob = bytes(random.Random(1).randbytes(5000))
    plan = integrity.make_plan(blob)
    assert integrity.verify_chain(blob, plan.salt, plan.roots, plan.blocks)
    bad = bytearray(blob)
    bad[3000] ^= 1
    assert not integrity.verify_chain(bytes(bad), plan.salt, plan.roots, plan.blocks)
    return f"双链 {plan.blocks}，篡改第 3000 字节被检出，root={plan.root_hex[:12]}"


def t_integrity_runtime():
    blob = b"PROGRAM-BYTES" * 40
    plan = integrity.make_plan(blob)
    src = integrity.runtime_check_source("PROG", plan)
    ns = {"PROG": blob}
    exec(compile(src, "<integrity>", "exec"), ns)
    ns2 = {"PROG": blob[:-1] + b"X"}
    try:
        exec(compile(src, "<integrity>", "exec"), ns2)
        raise AssertionError("运行时校验未拦截篡改")
    except SystemExit:
        pass
    return "壳内自校验源码：正常通过 / 篡改即退出"


# ---------------------------------------------------------------- 授权
def t_license():
    secret = "unit-test-secret"
    hw = lic.shell_hwid()
    pol = lic.LicensePolicy(serial="SN-001", features=("vm", "mutation"),
                            expires_days=30, hwid_bound=True)
    token = lic.issue(pol, hw, secret)
    assert lic.verify(token, secret, hw).ok
    assert lic.verify(token, "wrong", hw).reason == "bad_signature"
    assert lic.verify(token, secret, "0" * 32).reason == "hwid_mismatch"
    body = token.split(".", 1)[0]
    assert lic.verify(body + "." + "0" * 32, secret, hw).reason == "bad_signature"
    return "签发/签名/HWID/篡改 4 类校验正常"


def t_license_expired():
    secret = "s"
    pol = lic.LicensePolicy(hwid_bound=False)
    token = lic.issue(pol, "", secret)
    now = 2 ** 40
    assert lic.verify(token, secret, "", now=now).ok
    # 构造过期令牌
    import base64, json, hmac
    payload = json.loads(base64.urlsafe_b64decode(
        token.split(".")[0] + "=" * (-len(token.split(".")[0]) % 4)))
    payload["exp"] = 1
    canon = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    sig = hmac.new(secret.encode(), canon, hashlib.sha256).hexdigest()[:32]
    bad = base64.urlsafe_b64encode(canon).decode().rstrip("=") + "." + sig
    assert lic.verify(bad, secret, "", now=now).reason == "expired"
    return "永不过期 / 到期拒绝正常"


def t_license_runtime():
    secret = "runtime-secret"
    token = lic.issue(lic.LicensePolicy(hwid_bound=False), "", secret)
    ns = {}
    exec(compile(lic.runtime_license_source(token, secret), "<lic>", "exec"), ns)
    ns2 = {}
    try:
        exec(compile(lic.runtime_license_source(token, "BAD"), "<lic>", "exec"), ns2)
        raise AssertionError("壳内许可校验未拒绝错误密钥")
    except SystemExit:
        pass
    return "壳内离线校验：正确密钥放行 / 错误密钥退出"


def t_watermark():
    data = fake_pe()
    marked = lic.embed_watermark(data, "SN-007", "abc123")
    rec = lic.extract_watermark(marked)
    assert rec and rec["serial"] == "SN-007" and rec["hwid"] == "abc123"
    assert rec["vendor"] == "CyrilShield"
    return "PE overlay 水印写入与提取正常"


# ---------------------------------------------------------------- 内存
def t_memory():
    buf = bytearray(b"SECRET" * 100)
    memory.wipe(buf)
    assert len(buf) == 0
    master = b"M" * 32
    plain = bytes(random.Random(9).randbytes(3000))
    chunks = memory.seal_chunks(plain, master, 512)
    snapshot = list(chunks)          # release() 会清空原 list
    dec = memory.ChunkedDecoder(chunks, master)
    assert bytes(dec.read_all()) == plain
    dec.release()
    ns = {}
    exec(compile(memory.runtime_memory_guard_source(), "<mem>", "exec"), ns)
    c = ns["_cm_read"](snapshot[0], master, 0)
    assert bytes(c) == plain[:512]
    ns["_cm_wipe"](c)
    assert len(c) == 0
    return f"分块 {len(snapshot)} 块，即时擦除与壳内片段正常"


# ---------------------------------------------------------------- 混淆
def t_seal():
    rng = random.Random(3)
    for value in (b"\x00\x01binary\xff", "中文字符串 / literal", b"", ""):
        expr = obf.seal(value, b"LABEL", rng)
        assert obf.verify_seal(expr, value), value
    repl = {"__MAGIC__": repr(b"abc"), "__APP_TITLE__": repr("Demo")}
    sealed, done = obf.seal_replacements(repl, rng)
    assert set(done) == {"__MAGIC__", "__APP_TITLE__"}
    return "字面量编码/还原、占位符 seal 正常"


def t_obf_parts():
    rng = random.Random(5)
    dead = obf.dead_code_source(rng, 2)
    compile(dead, "<dead>", "exec")
    src = "A = 123456\nB = 7\nC = (1 << 64) - 1\n"
    out, n = obf.obfuscate_int_literals(src, rng, 2)
    compile(out, "<int>", "exec")
    ns = {}
    exec(out, ns)
    assert ns["A"] == 123456 and ns["B"] == 7
    dyn = obf.dynamic_import_source([("hashlib", "sha256")], rng)
    compile(dyn, "<dyn>", "exec")
    ns2 = {}
    exec(dyn, ns2)
    assert ns2["_cd_resolve"](0)(b"x").digest()
    return f"死块/整数分裂({n})/动态解析 均可编译且语义不变"


def t_obf_stub():
    rng = random.Random(11)
    src = ("# -*- coding: utf-8 -*-\nimport base64\n"
           "MAGIC = __MAGIC__\nLEN = __LEN__\n"
           "def go():\n    return MAGIC\n"
           "if __name__ == \"__main__\":\n    go()\n")
    repl = {"__MAGIC__": repr(b"secret-magic"), "__LEN__": "1024"}
    out, rep = obf.obfuscate_stub(src, repl, 2, rng,
                                  extra_imports=[("hashlib", "sha256")])
    ns = {"__name__": "obf_test"}
    exec(compile(out, "boot.py", "exec"), ns)
    assert ns["MAGIC"] == b"secret-magic" and ns["LEN"] == 1024
    assert rep.sealed == ["__MAGIC__"] and rep.split_ints >= 1
    return f"整 stub 变换后可运行：seal={rep.sealed}, split={rep.split_ints}, dead={rep.dead_blocks}"


# ---------------------------------------------------------------- 多态 / SDK
def t_polymorph():
    rng = random.Random(13)
    fps = []
    for _ in range(3):
        plan = vmgen.make_plan(rng)
        program, ops, plan = vmgen.make_program(rng.randbytes(32), 1, rng, plan)
        fps.append(poly.collect(ops=ops, plan=plan, profile=VMPProfile(),
                                integrity_root="x"))
    assert poly.assert_distinct(fps, min_changes=3)
    assert poly.diff(fps[0], fps[1])
    return f"3 次构建指纹互异，差异分量 {len(poly.diff(fps[0], fps[1]))} 项"


def t_sdk():
    src = '''
from cyrilshield.vmp.sdk import protect

@protect(scope="vm", mutation=3, note="核心校验")
def alpha():
    pass

@protect
def beta():
    pass

def gamma():
    pass
'''
    markers = sdk.scan_markers(src, "demo.py")
    assert len(markers) == 2, markers
    assert markers[0].name == "alpha" and markers[0].mutation == 3
    m = sdk.protection_manifest(markers)
    assert m["count"] == 2 and m["max_mutation"] == 3
    ns = {}
    exec(sdk.runtime_marker_source(markers), ns)
    assert "_CS_SCOPE" in ns
    return "装饰器标记扫描 / 保护清单 / 壳内常量注入正常"


# ---------------------------------------------------------------- 端到端集成
def _new_program(seed: int):
    rng = random.Random(seed)
    plan = vmgen.make_plan(rng)
    key = rng.randbytes(32)
    program, ops, plan = vmgen.make_program(key, 1, rng, plan)
    return program, ops, plan, rng, key


def t_render_vmp():
    program, ops, plan, rng, _key = _new_program(21)
    profile = VMPProfile(licensing=True, license_secret="e2e-secret")
    ctx = vmgen._make_vmp_context(profile, program, plan, rng, vmgen.VMOptions())
    stub = vmgen.render_stub(program, ops, "demo", plan, vmp_ctx=ctx)
    ns = {"__name__": "vmp_e2e", "__file__": "boot.py"}
    exec(compile(stub.source, "boot.py", "exec"), ns)
    assert ctx["report"]["enabled"]
    return (f"VMP stub 可执行：{len(ctx['report']['enabled'])} 项能力，"
            f"integrity/许可校验通过，源码 {len(stub.source):,} 字符")


def t_render_original():
    program, ops, plan, rng, _key = _new_program(22)
    stub = vmgen.render_stub(program, ops, "demo", plan)
    ns = {"__name__": "orig_e2e", "__file__": "boot.py"}
    exec(compile(stub.source, "boot.py", "exec"), ns)
    return "旧路径（vmp_ctx=None）完全兼容"


def t_original_selftest():
    program, ops, plan, rng, key = _new_program(23)
    with tempfile.TemporaryDirectory(prefix="vmp_selftest_") as d:
        payload = os.path.join(d, plan.payload_name)
        plain = b"MZ" + os.urandom(4096)
        with open(payload, "wb") as f:
            f.write(vmgen.pack_payload(plain, key, 0, "x.exe", "", plan))
        assert vmgen.selftest(program, ops, plan, payload, d)
    return "原 VM 字节码端到端自检仍通过"


def main() -> int:
    tests = [
        ("原生侧载桥接", t_native),
        ("纯 Python 降级 + 能力门", t_pure_fallback),
        ("侧载库摘要钉住", t_selfhash_pin),
        ("VMP 能力矩阵 / 排除多平台", t_matrix),
        ("配置校验与类型收敛", t_profile_validation),
        ("PE 布局解析", t_pe_parse),
        ("误报风险审计", t_av_audit),
        ("VS_VERSION_INFO 版本资源", t_version_resource),
        ("PyInstaller version-file", t_version_file),
        ("overlay 水印 + 构建清单", t_overlay_manifest),
        ("分块完整性链", t_integrity),
        ("壳内完整性自校验", t_integrity_runtime),
        ("离线许可签发/校验", t_license),
        ("许可到期判定", t_license_expired),
        ("壳内许可校验", t_license_runtime),
        ("PE 水印写入/提取", t_watermark),
        ("分块内存保护", t_memory),
        ("字面量加密还原", t_seal),
        ("死块/整数分裂/动态解析", t_obf_parts),
        ("壳源码整体混淆", t_obf_stub),
        ("多态构建指纹", t_polymorph),
        ("SDK 标记扫描", t_sdk),
        ("VMP stub 端到端执行", t_render_vmp),
        ("旧路径兼容性", t_render_original),
        ("原 VM 端到端自检", t_original_selftest),
    ]
    for name, fn in tests:
        check(name, fn)
    width = max(len(n) for n, _ in tests)
    for status, name, detail in results:
        print(f"{status} {name.ljust(width)}  {detail}")
    bad = [r for r in results if r[0] == FAIL]
    skip = [r for r in results if r[0] == SKIP]
    print("-" * 78)
    print(f"合计 {len(results)} 项：通过 {len(results) - len(bad) - len(skip)}，"
          f"跳过 {len(skip)}，失败 {len(bad)}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
