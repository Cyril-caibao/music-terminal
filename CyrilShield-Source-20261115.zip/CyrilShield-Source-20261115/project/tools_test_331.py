# -*- coding: utf-8 -*-
"""v3.3.1 修复验证：剥尾部 padding + protect_pe_batch 逐函数降级。

用法：python tools_test_331.py   （在项目根目录）
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) or ".")

from cyrilshield.vmp import integration as it
from cyrilshield.vmp import codevm as cv

fails = []

def check(name, cond, detail=""):
    print(("[ OK ] " if cond else "[FAIL] ") + name + ("  " + detail if detail else ""))
    if not cond:
        fails.append(name)

# 1) 剥尾部填充
assert it._strip_tail_padding(b"\x50\xC3") == b"\x50\xC3"
assert it._strip_tail_padding(b"\x50\xC3\xCC\xCC") == b"\x50\xC3"
assert it._strip_tail_padding(b"\x50\x90\x90") == b"\x50"
assert it._strip_tail_padding(b"\x50\xCC\x50\xCC") == b"\x50\xCC\x50"
assert it._strip_tail_padding(b"\xCC\xCC") == b""
check("strip_tail_padding 5 组断言", True)

# 2) 用户真实输入（Portable 副本）里带 int3 填充的区间：剥掉后不再报 CC
data = open(r"dist_portable/CyrilShield-Portable - 副本.exe", "rb").read()
import struct
pe = struct.unpack_from("<I", data, 0x3C)[0]
nsec = struct.unpack_from("<H", data, pe + 6)[0]
opt = struct.unpack_from("<H", data, pe + 20)[0]
sec = pe + 24 + opt
text_va = None
for i in range(nsec):
    o = sec + i * 40
    nm = data[o:o+8].rstrip(b"\x00").decode("ascii", "replace")
    vs, va, rs, ro = struct.unpack_from("<IIII", data, o + 8)
    if nm == ".text" and rs > 0:
        blob = data[ro:ro+rs]; text_va = va
        break
# 构造一个覆盖 [真实代码..C3..CC 填充] 的区间（模拟用户清单含填充）
idx = blob.find(b"\xC3\xCC\xCC\xCC")
rva_padded = text_va + idx - 40
size_padded = 44
code = it.extract_pe_function(data, rva_padded, size_padded)
check("剥尾部 int3 填充（用户输入）", not code.endswith(b"\xCC") or b"\xC3" in code,
      f"{size_padded}->{len(code)}B tail={code[-3:].hex()}")

# 2b) v3.3.2 用户真实清单 1000:49：尾部 = int3 + 下一函数 REX 前缀
real_vm = cv.get_codevm()
raw = it.extract_pe_function(data, 0x1000, 49)
tlogs = []
bc, used = it._compile_with_tail_retry(real_vm, raw, seed=123,
                                       on_line=tlogs.append)
check("用户清单 1000:49 自动截断后编译成功",
      len(bc) > 0 and len(used) == 47 and tlogs,
      f"49->{len(used)}B bc={len(bc)}B")

# 3) protect_pe_batch 降级：一个函数编译失败 → 跳过且其余成功
vm = cv.get_codevm()
orig_get = cv.get_codevm

class FlakyVM:
    """把指定字节数的输入变成 CodeVMError，其余转发真 VM。"""
    def __init__(self, real, bad_len):
        self.real, self.bad_len = real, bad_len
        self.disasm = real.disasm
        self.stats = real.stats
    def compile(self, code, seed=None):
        if len(code) == self.bad_len:
            # 失败点在函数中部 → 尾部重试不适用，应走逐函数降级
            raise cv.CodeVMError(
                "编译失败(-3): 偏移 5: 不支持的 0F B1 指令(SSE 子集外)")
        return self.real.compile(code, seed=seed)

class FlakyVM2(FlakyVM):
    def compile(self, code, seed=None):
        if len(code) == 48:
            # 中部失败：不触发尾部重试
            raise cv.CodeVMError("编译失败(-3): 偏移 5: 不支持的 0F B1 指令")
        return self.real.compile(code, seed=seed)

data2 = open(r"native/out/hello42.exe", "rb").read()
pe = struct.unpack_from("<I", data2, 0x3C)[0]
nsec = struct.unpack_from("<H", data2, pe + 6)[0]
opt = struct.unpack_from("<H", data2, pe + 20)[0]
sec = pe + 24 + opt
for i in range(nsec):
    o = sec + i * 40
    nm = data2[o:o+8].rstrip(b"\x00").decode("ascii", "replace")
    vs, va, rs, ro = struct.unpack_from("<IIII", data2, o + 8)
    if nm == ".text" and rs > 0:
        blob2 = data2[ro:ro+rs]; va2 = va
        break

# 3a) 全部失败 → IntegrationError
f1 = (va2, 48)
f2 = (va2 + 64, 48)
cv.get_codevm = lambda: FlakyVM(vm, 48)
logs = []
try:
    it.protect_pe_batch(data2, [f1, f2], seed=7, on_line=lambda s: logs.append(s))
    check("全部失败应抛 IntegrationError", False, "竟然成功了")
except it.IntegrationError as e:
    check("全部失败应抛 IntegrationError", "全部无法虚拟化" in str(e), str(e)[:80])

# 3b) 部分失败 → 跳过失败函数，其余照常
f2b = None
for p in range(0, len(blob2) - 72, 16):
    cand = it.extract_pe_function(data2, va2 + p, 72)
    try:
        vm.compile(cand, seed=7)
        f2b = (va2 + p, 72)
        break
    except cv.CodeVMError:
        continue
check("找到可编译对照窗口", f2b is not None)

f1b = (va2, 48)
cv.get_codevm = lambda: FlakyVM2(vm, 48)
logs = []
try:
    out, rep = it.protect_pe_batch(data2, [f1b, f2b], seed=7,
                                   on_line=lambda s: logs.append(s))
    nskip = len(rep.get("skipped_functions", []))
    ok_n = len(rep.get("per_function", []))
    check("部分失败逐函数降级", nskip == 1 and ok_n == 1,
          f"skipped={nskip} ok={ok_n}")
    check("降级后 PE 仍被改写", len(out) != len(data2) or rep.get("checksum"),
          f"out={len(out)}B")
except it.IntegrationError as e:
    check("部分失败逐函数降级", False, "不应整体失败: " + str(e)[:100])
finally:
    cv.get_codevm = orig_get

print("-" * 40)
print("FAILS:", fails if fails else "none")
sys.exit(1 if fails else 0)
