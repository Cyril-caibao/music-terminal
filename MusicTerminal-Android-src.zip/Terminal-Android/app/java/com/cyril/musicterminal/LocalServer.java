package com.cyril.musicterminal;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Base64;
import android.util.Log;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * 只跑在 127.0.0.1 上的极简静态资源服务器。
 *
 * 存在的意义：WebView 里用 file:// 读取 index.html 会让 IndexedDB 变成
 * opaque origin（音乐库/壁纸缓存全部失效）。给页面一个稳定的 http origin
 * （http://127.0.0.1:8765/）之后，localStorage / IndexedDB / Audio blob URL
 * 才能像正常网页一样持久化。
 *
 * 另外两个接口是原版前端必需的：/api/me（登录态）与 /api/sysinfo（系统采样）。
 * 安卓上没有 PC 后端，这里返回"本机已登录"的等价结构，让 UI 直接进主界面。
 */
public class LocalServer {

    private static final String TAG = "MusicTerminal";
    private static final String WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    private final Context ctx;
    private ServerSocket serverSocket;
    private int port = 8765;
    private volatile boolean running = false;

    public LocalServer(Context context) {
        this.ctx = context.getApplicationContext();
    }

    public int getPort() {
        return port;
    }

    public void start() {
        running = true;
        for (int p = 8765; p < 8775; p++) {
            try {
                serverSocket = new ServerSocket(p, 128, InetAddress.getByName("127.0.0.1"));
                port = p;
                break;
            } catch (IOException ignored) {
                // 端口占用则顺延
            }
        }
        if (serverSocket == null) {
            Log.e(TAG, "本地服务器启动失败：8765-8774 全部被占用");
            return;
        }
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                acceptLoop();
            }
        }, "mt-http-accept");
        t.setDaemon(true);
        t.start();
        Log.i(TAG, "本地服务器已启动 http://127.0.0.1:" + port + "/");
    }

    public void stop() {
        running = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignored) {
        }
    }

    private void acceptLoop() {
        while (running) {
            try {
                final Socket socket = serverSocket.accept();
                Thread worker = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        handle(socket);
                    }
                }, "mt-http-conn");
                worker.setDaemon(true);
                worker.start();
            } catch (IOException e) {
                if (!running) break;
            }
        }
    }

    private void handle(Socket socket) {
        try {
            socket.setSoTimeout(300000);
            InputStream raw = socket.getInputStream();
            OutputStream out = socket.getOutputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(raw, "UTF-8"));
            String requestLine = reader.readLine();
            if (requestLine == null) {
                socket.close();
                return;
            }

            String[] parts = requestLine.split(" ");
            if (parts.length < 2) {
                socket.close();
                return;
            }
            String method = parts[0];
            String path = parts[1];

            Map<String, String> headers = new HashMap<>();
            String line;
            while ((line = reader.readLine()) != null && !line.isEmpty()) {
                int colon = line.indexOf(':');
                if (colon > 0) {
                    headers.put(line.substring(0, colon).trim().toLowerCase(Locale.US),
                            line.substring(colon + 1).trim());
                }
            }

            if ("websocket".equalsIgnoreCase(headers.get("upgrade"))) {
                // 前端需要一个"连上了"的 WebSocket（状态灯 / 终端通道）。
                // 安卓版没有终端，这里只完成握手并保持连接，客户端发来的帧全部丢弃。
                handshakeWebSocket(socket, out, headers.get("sec-websocket-key"));
                return;
            }

            serve(method, path, out);
            out.flush();
            socket.close();
        } catch (Exception e) {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private void handshakeWebSocket(Socket socket, OutputStream out, String clientKey) throws Exception {
        if (clientKey == null) {
            socket.close();
            return;
        }
        String accept = Base64.encodeToString(
                MessageDigest.getInstance("SHA-1").digest((clientKey + WS_GUID).getBytes("ISO-8859-1")),
                Base64.NO_WRAP);
        String response = "HTTP/1.1 101 Switching Protocols\r\n"
                + "Upgrade: websocket\r\n"
                + "Connection: Upgrade\r\n"
                + "Sec-WebSocket-Accept: " + accept + "\r\n"
                + "\r\n";
        out.write(response.getBytes("UTF-8"));
        out.flush();

        // 保持连接存活，吞掉客户端所有数据（收到关闭帧或断链即退出）
        InputStream in = socket.getInputStream();
        byte[] buf = new byte[8192];
        while (true) {
            int n = in.read(buf);
            if (n < 0) break;
        }
        socket.close();
    }

    private void serve(String method, String path, OutputStream out) throws IOException {
        String p = path;
        int q = p.indexOf('?');
        if (q >= 0) p = p.substring(0, q);

        byte[] body;
        String ctype;
        int code = 200;

        if ("/api/me".equals(p)) {
            // 安卓版没有 PC 后端：直接返回"本机管理员已登录"，跳过登录页
            body = ("{\"ok\":true,\"authed\":true,\"user\":\"local\",\"admin\":true,"
                    + "\"local\":true,\"remote_mode\":false}").getBytes("UTF-8");
            ctype = "application/json; charset=utf-8";
        } else if ("/api/sysinfo".equals(p)) {
            // 系统采样面板在安卓版被隐藏，返回空对象避免前端报错
            body = "{\"ok\":true,\"data\":{}}".getBytes("UTF-8");
            ctype = "application/json; charset=utf-8";
        } else if ("/api/users".equals(p)) {
            body = "{\"ok\":true,\"users\":[]}".getBytes("UTF-8");
            ctype = "application/json; charset=utf-8";
        } else if ("/favicon.ico".equals(p)) {
            out.write("HTTP/1.1 204 No Content\r\nConnection: close\r\n\r\n".getBytes("UTF-8"));
            return;
        } else {
            String assetPath;
            if ("/".equals(p) || "/index.html".equals(p)) {
                assetPath = "web/index.html";
            } else if (p.startsWith("/web/")) {
                assetPath = p.substring(1);
            } else {
                assetPath = "web" + p;
            }
            body = readAsset(assetPath);
            if (body == null) {
                code = 404;
                body = "not found".getBytes("UTF-8");
                ctype = "text/plain; charset=utf-8";
            } else {
                ctype = mimeOf(assetPath);
            }
        }

        StringBuilder head = new StringBuilder();
        head.append("HTTP/1.1 ").append(code == 200 ? "200 OK" : "404 Not Found").append("\r\n");
        head.append("Content-Type: ").append(ctype).append("\r\n");
        head.append("Content-Length: ").append(body.length).append("\r\n");
        head.append("Cache-Control: no-store\r\n");
        head.append("Connection: close\r\n");
        head.append("\r\n");
        out.write(head.toString().getBytes("UTF-8"));
        if (!"HEAD".equalsIgnoreCase(method)) {
            out.write(body);
        }
    }

    private byte[] readAsset(String assetPath) {
        AssetManager am = ctx.getAssets();
        InputStream in = null;
        try {
            in = am.open(assetPath);
            ByteArrayOutputStream bos = new ByteArrayOutputStream(64 * 1024);
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toByteArray();
        } catch (IOException e) {
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private static String mimeOf(String name) {
        String lower = name.toLowerCase(Locale.US);
        if (lower.endsWith(".html") || lower.endsWith(".htm")) return "text/html; charset=utf-8";
        if (lower.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (lower.endsWith(".css")) return "text/css; charset=utf-8";
        if (lower.endsWith(".json")) return "application/json; charset=utf-8";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".bmp")) return "image/bmp";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".ico")) return "image/x-icon";
        if (lower.endsWith(".mp4") || lower.endsWith(".m4v") || lower.endsWith(".mov")) return "video/mp4";
        if (lower.endsWith(".webm")) return "video/webm";
        if (lower.endsWith(".ogv")) return "video/ogg";
        if (lower.endsWith(".mp3")) return "audio/mpeg";
        if (lower.endsWith(".wav")) return "audio/wav";
        if (lower.endsWith(".m4a")) return "audio/mp4";
        if (lower.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }
}
