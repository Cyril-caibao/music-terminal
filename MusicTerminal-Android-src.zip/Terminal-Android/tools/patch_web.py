#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""对原版 index.html 打安卓补丁：隐藏终端/服务端面板、控制栏铺满、自动进音乐模式。"""
import io, sys, os

SRC = sys.argv[1]

CSS_BLOCK = """
<!-- ================= Android 触屏版覆盖（自动生成，勿手改） ================= -->
<style id="android-touch-overrides">
  html, body { overscroll-behavior: none; -webkit-tap-highlight-color: transparent; }

  /* 顶栏常显：安卓没有鼠标 hover，交给 CSS 强制显示 */
  header { opacity: 1 !important; transform: none !important; pointer-events: auto !important; }

  /* 顶栏只保留「外观 / 音乐 / 电台导入」 */
  #btnTree, #btnHelp, #btnComp, #btnUsers, #btnAI, #btnSettings { display: none !important; }

  /* 终端区与所有依赖 PC 服务端的面板全部隐藏 */
  #workArea, #leftRail, #railHint,
  #aiPanel, #usersPanel, #compPanel, #settingsPanel, #helpPanel, #imgPanel { display: none !important; }

  /* 音乐控制栏：常显 + 可点 + 铺满宽度 + 底部安全距。
     关键：原版 body.bars-ready:not(.ctrl-on) #radio-controls 会把胶囊设成
     pointer-events:none（鼠标移开就"穿透"），触屏没有 mousemove 触发 ctrl-on，
     于是整条控制栏永远点不动 —— 这里必须强制 auto。 */
  #radio-controls {
    pointer-events: auto !important;
    display: flex !important;
    left: 6px !important; right: 6px !important; bottom: 8px !important;
    width: auto !important; min-width: 0 !important; max-width: none !important;
    transform: none !important; opacity: 1 !important;
    border-radius: 22px !important;
    padding: 4px 10px 10px !important;
  }

  /* 无终端 → 去掉为控制栏预留的底部内边距 */
  body.radio-on main { padding-bottom: 0 !important; }

  /* 浮层：改为接近全屏的抽屉，触屏好操作 */
  #radio-queue, #radio-lyrics, #radio-eq {
    pointer-events: auto !important;
    position: fixed !important;
    left: 4px !important; right: 4px !important;
    top: 54px !important; bottom: 128px !important;
    width: auto !important; max-width: none !important; max-height: none !important;
  }
  #appearancePanel, #importPanel {
    position: fixed !important;
    left: 4px !important; right: 4px !important;
    top: 54px !important;
    width: auto !important; max-width: none !important;
    max-height: 74vh !important;
    border-radius: 16px !important;
  }

  /* 顶栏压缩，给手机腾空间 */
  header { height: 46px !important; padding: 0 8px !important; }
  header .subtitle { display: none !important; }
  header .dot { display: none !important; }
  header .controls { gap: 4px !important; margin-left: auto !important; }
  header .btn { font-size: 11px !important; padding: 4px 9px !important; }

  /* WebView 不支持 webkitdirectory，隐藏「选择文件夹」 */
  #ipPickDir { display: none !important; }

  /* 触屏没有 hover / mousemove：强制任何"按边缘显隐"的状态为已显示 */
  body:not(.ctrl-on) #radio-controls { opacity: 1 !important; transform: none !important; pointer-events: auto !important; }
  header, #appearancePanel, #importPanel, #radio-queue, #radio-lyrics, #radio-eq {
    pointer-events: auto !important;
  }

  #radio-controls, #radio-queue, #radio-lyrics, #radio-eq,
  #appearancePanel, #importPanel { -webkit-overflow-scrolling: touch; }

  /* backdrop-filter 是每帧重算的，安卓 GPU 顶不住 blur(12px)+saturate+brightness，
     而它底下正好是一直在动的绘光/音域画布 —— 降到 6px 纯模糊，掉帧明显改善 */
  header, #radio-controls, #radio-queue, #radio-lyrics, #radio-eq,
  #appearancePanel, #importPanel {
    -webkit-backdrop-filter: blur(6px) !important;
    backdrop-filter: blur(6px) !important;
  }

  /* 大屏上的中文译文：绘光画布只画原文（改运行时风险太大），译文用 DOM 叠一层字幕 */
  #android-sub-lyric {
    position: fixed; left: 16px; right: 16px; bottom: 134px; z-index: 20;
    text-align: center; pointer-events: none;
    font-size: 15px; line-height: 1.45; letter-spacing: 0.5px;
    color: #ffe9c2; opacity: 0;
    text-shadow: 0 0 12px rgba(255, 214, 140, 0.6), 0 1px 2px rgba(0, 0, 0, 0.65);
    transition: opacity 0.3s ease;
  }
  #android-sub-lyric.on { opacity: 0.94; }

  /* 双语歌词：原文下面挂一行小字译文 */
  #radio-lyrics-body .l-trans {
    font-size: 11px;
    font-weight: normal;
    opacity: 0.62;
    line-height: 1.4;
    margin-top: 1px;
    color: inherit;
  }
  /* 横屏：控制栏居中收窄（横屏铺满整条会像根扁担），浮层跟着收。
     放在 style 最末尾 + 选择器带 body:not(.ctrl-on)：上面那条
     "强制 transform:none" 的规则 specificity 是 (1,1,1)，必须用同级别且更靠后才能压住。 */
  @media (orientation: landscape) {
    header { height: 42px !important; }
    #radio-controls, body:not(.ctrl-on) #radio-controls, body.ctrl-on #radio-controls {
      left: 50% !important; right: auto !important;
      width: min(760px, calc(100vw - 28px)) !important;
      transform: translateX(-50%) !important;
      bottom: 6px !important;
    }
    #radio-queue, #radio-lyrics, #radio-eq {
      left: 50% !important; right: auto !important;
      width: min(720px, calc(100vw - 24px)) !important;
      transform: translateX(-50%) !important;
      top: 48px !important; bottom: 134px !important;
    }
    #appearancePanel, #importPanel {
      left: 50% !important; right: auto !important;
      width: min(560px, calc(100vw - 24px)) !important;
      transform: translateX(-50%) !important;
      top: 48px !important;
      max-height: 78vh !important;
    }
    /* 横屏竖向空间只有 400 多像素：把控制栏压扁（隐藏标题行、缩小封面） */
    #radio-controls-head { display: none !important; }
    #radio-controls { padding: 6px 16px 8px !important; border-radius: 20px !important; }
    #radio-cover { width: 34px !important; height: 34px !important; }
    #radio-now { margin-bottom: 2px !important; }
    #radio-seekrow { gap: 6px !important; }
    #android-sub-lyric { bottom: 128px; font-size: 16px; left: 40px; right: 40px; }
  }
</style>
"""

DPR_SCRIPT = """
<!-- 安卓：把 devicePixelRatio 钳到 1.5。Pixi/THREE 的渲染分辨率直接由它决定，
     3x 屏会开 9 倍像素，正是掉帧的主因；放在所有脚本之前执行才生效 -->
<script id="android-dpr-cap">
(function () {
  try {
    var raw = window.devicePixelRatio || 1;
    if (raw > 1.5) {
      Object.defineProperty(window, 'devicePixelRatio', {
        configurable: true,
        get: function () { return 1.5; }
      });
    }
  } catch (e) {}
})();
</script>
"""

JS_BLOCK = """
<!-- ================= Android 启动补丁（自动生成） ================= -->
<script>
(function () {
  window.__ANDROID_APP__ = true;
  function boot() {
    /* 0) 中文译文字幕层（绘光大屏只画英文原文） */
    try {
      if (!document.getElementById('android-sub-lyric')) {
        var _sub = document.createElement('div');
        _sub.id = 'android-sub-lyric';
        document.body.appendChild(_sub);
      }
    } catch (e) {}

    /* 1) 去掉「选择文件夹」：安卓 WebView 忽略 webkitdirectory */
    try {
      var db = document.getElementById('ipPickDir');
      if (db) db.style.display = 'none';
      var di = document.getElementById('radio-dir');
      if (di) { di.removeAttribute('webkitdirectory'); di.removeAttribute('directory'); }
    } catch (e) {}

    /* 2) 自动进入音乐模式：终端已移除，控制栏要 radio-on 才出现。
          直接调 enterRadio 而不是点 btnMusic —— 后者会顺手把播放队列弹出来，
          启动就盖住整屏；队列留给用户点右下角按钮时再开。 */
    try {
      if (window.__cyrilEnterRadio) window.__cyrilEnterRadio('sonic');
      else {
        var bm = document.getElementById('btnMusic');
        if (bm) bm.click();
      }
    } catch (e) {}

    /* 3) 屏宽尺寸变化（键盘弹出/旋转）后刷新终端尺寸与玻璃折射贴图 */
    try {
      window.addEventListener('resize', function () {
        setTimeout(function () {
          if (window.__cyrilGlassUpdate) { try { window.__cyrilGlassUpdate(); } catch (e) {} }
        }, 60);
      });
    } catch (e) {}
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 80); });
  } else {
    setTimeout(boot, 80);
  }
})();
</script>
"""


def main():
    with io.open(SRC, 'r', encoding='utf-8') as f:
        html = f.read()

    if 'android-touch-overrides' in html:
        print('已打过补丁，跳过')
        return

    assert html.count('</head>') == 1, 'head 标记异常'
    assert html.count('</body>') == 1, 'body 标记异常'

    anchor = 'window.__cyrilClearRadio = exitRadio;'
    assert anchor in html, '找不到 exitRadio 导出锚点'
    if 'window.__cyrilEnterRadio' not in html:
        html = html.replace(anchor,
                            anchor + '\n  window.__cyrilEnterRadio = enterRadio;   // 安卓补丁：直接进电台', 1)

    html = html.replace('</head>', DPR_SCRIPT + CSS_BLOCK + '</head>', 1)
    # 4) 双语 LRC 合并：原文与译文同一时间戳时不再互相盖住
    old_sort = """    lines.sort(function (a, b) { return a.t - b.t; });
    return lines;"""
    new_sort = """    lines.sort(function (a, b) { return a.t - b.t; });
    /* 双语 LRC：英文原句和中文翻译常是同一时间戳的两行，原样喂给播放器会同时起播、
       互相盖住（大屏上只剩中文，看起来"英文没渲染"）。这里把「纯拉丁行 + 纯中文行
       且间隔 ≤0.35s」的配对合并成一条：text = 英文原文，trans = 中文译文。 */
    var CJK_RE = /[\\u3400-\\u9fff\\uf900-\\ufaff]/, LAT_RE = /[A-Za-z]/;
    var merged = [];
    for (var i = 0; i < lines.length; i++) {
      var a = lines[i], b = lines[i + 1];
      if (b && Math.abs(b.t - a.t) <= 0.35) {
        var aCJK = CJK_RE.test(a.text), aLat = LAT_RE.test(a.text);
        var bCJK = CJK_RE.test(b.text), bLat = LAT_RE.test(b.text);
        if (aLat && !aCJK && bCJK && !bLat) { merged.push({ t: a.t, text: a.text, trans: b.text }); i++; continue; }
        if (aCJK && !aLat && bLat && !bCJK) { merged.push({ t: b.t, text: b.text, trans: a.text }); i++; continue; }
      }
      merged.push(a);
    }
    return merged;"""
    assert old_sort in html, '找不到 parseLrc 排序锚点'
    html = html.replace(old_sort, new_sort, 1)

    # 5) 歌词面板：原文下面挂译文
    old_line = """      d.textContent = ln.text;
      d.setAttribute('data-lidx', i);"""
    new_line = """      d.textContent = ln.text;
      if (ln.trans) {
        var tr = document.createElement('div');
        tr.className = 'l-trans';
        tr.textContent = ln.trans;
        d.appendChild(tr);
      }
      d.setAttribute('data-lidx', i);"""
    assert old_line in html, '找不到歌词行渲染锚点'
    html = html.replace(old_line, new_line, 1)

    # 6) dbMerge 兜底：旧记录不存在时 merged 没有 keyPath，put() 会抛 DataError
    #    （表现为页面顶部弹红色脚本错误条）。把 key 直接带上，找不到旧记录也能新建。
    old_merge = """        var old = req.result || {};
        var merged = {};
        for (var k in old) merged[k] = old[k];"""
    new_merge = """        var old = req.result || {};
        var merged = { key: key };
        for (var k in old) merged[k] = old[k];"""
    assert old_merge in html, '找不到 dbMerge 锚点'
    html = html.replace(old_merge, new_merge, 1)

    # 7) 歌词高亮时同步中文译文字幕
    old_hl = """    if (idx >= 0) {
      var cur = elLyricsBody.querySelector('.l-line[data-lidx="' + idx + '"]');"""
    new_hl = """    /* 中文译文同步到大屏字幕层 */
    var _subEl = document.getElementById('android-sub-lyric');
    if (_subEl) {
      var _line = (idx >= 0) ? curLrc[idx] : null;
      var _tr = (_line && _line.trans) ? _line.trans : '';
      if (_subEl.textContent !== _tr) {
        _subEl.textContent = _tr;
        _subEl.classList.toggle('on', !!_tr);
      }
    }
    if (idx >= 0) {
      var cur = elLyricsBody.querySelector('.l-line[data-lidx="' + idx + '"]');"""
    assert old_hl in html, '找不到歌词高亮锚点'
    html = html.replace(old_hl, new_hl, 1)

    html = html.replace('</body>', JS_BLOCK + '</body>', 1)

    with io.open(SRC, 'w', encoding='utf-8') as f:
        f.write(html)
    print('补丁完成：', SRC, len(html), 'bytes')


if __name__ == '__main__':
    main()
