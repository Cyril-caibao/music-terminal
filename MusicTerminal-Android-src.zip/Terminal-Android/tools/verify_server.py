#!/usr/bin/env python3
"""本地验证用：镜像 LocalServer.java 的 HTTP/WS 行为，托管 app/assets/web。
用法: python3 tools/verify_server.py app/assets/web 8765
"""
import base64, hashlib, os, socket, sys, threading

ROOT = sys.argv[1]
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8765
GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

MIME = {'.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
        '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml',
        '.mp4': 'video/mp4', '.webm': 'video/webm', '.woff2': 'font/woff2'}


def handle(conn):
    try:
        conn.settimeout(300)
        data = b''
        while b'\r\n\r\n' not in data:
            chunk = conn.recv(4096)
            if not chunk:
                return
            data += chunk
        head = data.partition(b'\r\n\r\n')[0]
        lines = head.decode('latin-1').split('\r\n')
        parts = lines[0].split(' ')
        method, path = parts[0], parts[1]
        headers = {}
        for l in lines[1:]:
            if ':' in l:
                k, v = l.split(':', 1)
                headers[k.strip().lower()] = v.strip()

        if headers.get('upgrade', '').lower() == 'websocket':
            key = headers['sec-websocket-key'].encode()
            accept = base64.b64encode(hashlib.sha1(key + GUID).digest()).decode()
            conn.sendall(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\n"
                          "Connection: Upgrade\r\nSec-WebSocket-Accept: %s\r\n\r\n" % accept).encode())
            while True:
                if not conn.recv(8192):
                    break
            return

        p = path.split('?')[0]
        if p == '/api/me':
            body, ctype = b'{"ok":true,"authed":true,"user":"local","admin":true,"local":true,"remote_mode":false}', MIME['.json']
        elif p == '/api/sysinfo':
            body, ctype = b'{"ok":true,"data":{}}', MIME['.json']
        elif p == '/api/users':
            body, ctype = b'{"ok":true,"users":[]}', MIME['.json']
        else:
            if p in ('/', '/index.html'):
                fp = os.path.join(ROOT, 'index.html')
            elif p.startswith('/web/'):
                fp = os.path.join(ROOT, p[5:])
            else:
                fp = os.path.join(ROOT, p.lstrip('/'))
            if not os.path.isfile(fp):
                conn.sendall(b'HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: 9\r\nConnection: close\r\n\r\nnot found')
                return
            body = open(fp, 'rb').read()
            ctype = MIME.get(os.path.splitext(fp)[1].lower(), 'application/octet-stream')
        head = ("HTTP/1.1 200 OK\r\nContent-Type: %s\r\nContent-Length: %d\r\n"
                "Cache-Control: no-store\r\nConnection: close\r\n\r\n" % (ctype, len(body))).encode()
        conn.sendall(head if method == 'HEAD' else head + body)
    except Exception as e:
        sys.stderr.write('conn error: %r\n' % e)
    finally:
        try:
            conn.close()
        except Exception:
            pass


srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(('127.0.0.1', PORT))
srv.listen(128)
print('serving', ROOT, 'on', PORT, flush=True)
while True:
    c, _ = srv.accept()
    threading.Thread(target=handle, args=(c,), daemon=True).start()
