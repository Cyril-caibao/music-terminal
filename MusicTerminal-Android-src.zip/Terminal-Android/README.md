# Music Terminal · Android 版

原项目 [music-terminal](https://github.com/Cyril-caibao/music-terminal) 的安卓移植版。

## 改了什么

原项目的终端后端是 `server.py` + **ConPTY（pywinpty）**，Windows 专有，安卓无法运行。
因此本版本去掉终端以及所有依赖 PC 服务端的面板，保留：

- 音乐播放器（本地导入、播放队列、进度/音量、随机/循环）
- 歌词（.lrc 同名自动匹配）、播放队列、均衡器（多段 + Q）、混响、环绕
- 视觉背景：默认壁纸 / 音域回响（THREE 地形）/ 绘光（Folia Lumiere）
- 主题（黑/白）、背景透明度、自定义图片/视频壁纸
- 曲库持久化：音频 Blob + 封面 + 歌词存在 WebView 的 IndexedDB 里，关掉 App 也不会丢

## 关键技术点

- 页面通过**内置本地 HTTP 服务**（`LocalServer.java`，仅监听 127.0.0.1）托管，而不是 `file://`。
  这样页面有稳定 origin，IndexedDB / localStorage / Blob 才能正常持久化。
- `/api/me` 返回"本机已登录"，`/api/sysinfo` 返回空对象，跳过登录页。
- WebSocket 只做握手并保持连接（吞掉所有帧），前端状态灯显示 connected，不再无限重连。
- `tools/patch_web.py` 对原版 `index.html` 做幂等补丁：隐藏终端/服务端面板、
  控制栏铺满、浮层改全屏抽屉、启动直接进音乐模式（不借道 `btnMusic`，避免自动弹出队列）。

## 构建

```bash
export ANDROID_HOME=/home/user/android-sdk
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
./build.sh
# 产物: dist/MusicTerminal-1.0.0.apk
```

构建链：aapt2 → javac → d8 → zipalign → apksigner（不依赖 Gradle）。

## 已知限制

- 文件夹批量导入（`webkitdirectory`）在 WebView 不可用，已隐藏该入口；改用「选择文件」多选。
- 曲库存在 App 私有数据里，卸载 App 会清空。

## 版本记录

### 1.3.0
- 大屏中文译文：绘光运行时只画 `line.fullText`（英文原文），没有副行槽位，
  `folia-adapter.js`（2.7MB）改动风险太大，改为 DOM 叠一层字幕 `#android-sub-lyric`，
  跟着 `updateLrcHighlight()` 的当前行同步译文，暖白 + 发光，0.3s 淡入淡出。
- 横屏适配：`@media (orientation: landscape)` —— 控制栏居中收窄到 760px、隐藏标题行、
  封面 34px（高度从 131px 压到 106px）；歌词/队列/EQ 抽屉与外观/导入面板同样居中收窄。
  注意这条必须在样式表末尾、且选择器带 `body:not(.ctrl-on)`，否则会被
  "强制 transform:none" 那条规则压住（同 `!important` 时比特异性）。

### 1.2.0
- 双语歌词：同一时间戳的「英文原句 + 中文译文」合并成一条，大屏显示原文，歌词面板显示原文 + 小字译文。
  （此前两行同时起播互相盖住，看起来只有中文）
- 流畅度：`devicePixelRatio` 钳到 1.5（Pixi/THREE 渲染分辨率随之下降，3x 屏省掉约 44% 像素）；
  玻璃材质 `backdrop-filter` 由 `blur(12px)+saturate+brightness` 降为 `blur(6px)`。
- 修复：曲目记录缺失时 `dbMerge` 的 `put()` 抛 `DataError`（页面顶部会弹红色脚本错误条）。

### 1.1.0
- 修复底部控制栏无法点击：原版 `body.bars-ready:not(.ctrl-on)` 把胶囊设成 `pointer-events:none`，
  触屏没有 mousemove 触发 `ctrl-on`，整条栏永远穿透。
