#!/usr/bin/env bash
# Music Terminal · 安卓 APK 构建（aapt2 + javac + d8 + apksigner，无需 Gradle）
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK="${ANDROID_HOME:-/home/user/android-sdk}"
BT="$SDK/build-tools/34.0.0"
PLATFORM="$SDK/platforms/android-34/android.jar"
export JAVA_HOME="${JAVA_HOME:-/home/user/jdk/jdk-17.0.21+9}"
PATH="$JAVA_HOME/bin:$BT:$PATH"

APP="$ROOT/app"
BUILD="$ROOT/build"
DIST="$ROOT/dist"
NAME="MusicTerminal-1.3.0"

rm -rf "$BUILD"
mkdir -p "$BUILD/gen" "$BUILD/classes" "$BUILD/dex" "$DIST"

echo "==> 1/6 编译资源"
aapt2 compile --dir "$APP/res" -o "$BUILD/res.zip"

echo "==> 2/6 链接资源与清单"
aapt2 link \
  -o "$BUILD/base.apk" \
  -I "$PLATFORM" \
  --manifest "$APP/AndroidManifest.xml" \
  -A "$APP/assets" \
  --java "$BUILD/gen" \
  --min-sdk-version 21 \
  --target-sdk-version 34 \
  --version-code 4 \
  --version-name 1.3.0 \
  --auto-add-overlay \
  "$BUILD/res.zip"

echo "==> 3/6 编译 Java"
javac -source 8 -target 8 -encoding UTF-8 -Xlint:-options \
  -bootclasspath "$PLATFORM" \
  -d "$BUILD/classes" \
  $(find "$APP/java" "$BUILD/gen" -name '*.java')

echo "==> 4/6 dex"
d8 --lib "$PLATFORM" --min-api 21 --output "$BUILD/dex" \
  $(find "$BUILD/classes" -name '*.class')

echo "==> 5/6 组装 + 对齐"
cp "$BUILD/base.apk" "$BUILD/unaligned.apk"
( cd "$BUILD/dex" && zip -q "$BUILD/unaligned.apk" classes.dex )
zipalign -f -p 4 "$BUILD/unaligned.apk" "$BUILD/aligned.apk"

echo "==> 6/6 签名"
KS="$ROOT/debug.keystore"
if [ ! -f "$KS" ]; then
  keytool -genkeypair -v -keystore "$KS" -alias androiddebugkey \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass android -keypass android \
    -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1
fi
apksigner sign --ks "$KS" --ks-pass pass:android --key-pass pass:android \
  --v1-signing-enabled true --v2-signing-enabled true \
  --out "$DIST/$NAME.apk" "$BUILD/aligned.apk"

apksigner verify --verbose "$DIST/$NAME.apk" | head -6
echo
echo "✅ 产物: $DIST/$NAME.apk  ($(du -h "$DIST/$NAME.apk" | cut -f1))"
