"""从 assets/cyril/ 里的三款 Cyril 图标中选一款，生成安装包用的 app.ico。

用法：python mkico.py [--variant square|shield|terminal]
默认 terminal（终端窗口外框）。三款 ico 都是 9 尺寸（16~256）多帧文件，
直接复制原文件，不做重采样，避免小尺寸字形被二次插值糊掉。
"""
import argparse
import os
import shutil

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "assets")
CYRIL = os.path.join(ASSETS, "cyril")
VARIANTS = ("square", "shield", "terminal")

parser = argparse.ArgumentParser(description="选择 Cyril 应用图标")
parser.add_argument("--variant", choices=VARIANTS, default="terminal")
args = parser.parse_args()

src = os.path.join(CYRIL, "cyril-" + args.variant + ".ico")
if not os.path.isfile(src):
    raise SystemExit("找不到图标素材: " + src)

out = os.path.join(ASSETS, "app.ico")
shutil.copyfile(src, out)

frame = os.path.join(CYRIL, "frames", args.variant + "-256.png")
if os.path.isfile(frame):
    Image.open(frame).convert("RGBA").save(os.path.join(ASSETS, "app-256.png"))

print("variant :", args.variant)
print("ico     :", out, os.path.getsize(out), "bytes")
print("ico尺寸 :", sorted(Image.open(out).ico.sizes()))
