"""三种外框（圆角方形 / 盾牌 / 终端窗口），无描边、框外全透明，可打包成多尺寸 ICO。"""
import cv2, numpy as np, os
from PIL import Image
import build_icon as B

POLY, GW, GH = B.POLY, B.GW, B.GH

def shield_pts(n=80):
    top, side_x, r, shoulder, tip = 0.085, 0.135, 0.045, 0.46, 0.945
    right = [(0.5, top), (1-side_x-r, top)]
    cx, cy = 1-side_x-r, top+r
    for a in np.linspace(-np.pi/2, 0, n):
        right.append((cx + r*np.cos(a), cy + r*np.sin(a)))
    for t in np.linspace(0, 1, n):
        right.append((1-side_x, (top+r) + t*(shoulder-top-r)))
    P0=np.array([1-side_x, shoulder]); P1=np.array([1-side_x-0.01, 0.70])
    P2=np.array([0.73, 0.885]); P3=np.array([0.5, tip])
    for t in np.linspace(0, 1, n):
        right.append(tuple((1-t)**3*P0 + 3*(1-t)**2*t*P1 + 3*(1-t)*t*t*P2 + t**3*P3))
    left = [(1-x, y) for (x, y) in reversed(right)]
    return np.array(right + left[1:-1], np.float32)

def glyph_ratio(frame, size):
    if frame == "square":
        return 0.94 if size <= 24 else (0.84 if size <= 48 else (0.80 if size <= 96 else 0.72))
    if frame == "shield":
        return 0.64 if size <= 24 else (0.54 if size <= 48 else (0.48 if size <= 96 else 0.44))
    return 0.60 if size <= 24 else (0.50 if size <= 48 else (0.44 if size <= 96 else 0.40))

def render(size, frame):
    hard = size <= 32                    # 小尺寸硬边，避免灰糊
    SS = 16 if hard else 8
    S = size * SS
    img = np.full((S, S, 3), 255, np.uint8)
    cover = np.zeros((S, S), np.uint8)

    if frame == "square":
        rad = (0.18 if hard else 0.235) * S
        yy, xx = np.mgrid[0:S,0:S].astype(np.float32); c=(S-1)/2.0
        dx=np.abs(xx-c)-(S/2.0-rad); dy=np.abs(yy-c)-(S/2.0-rad)
        q=np.sqrt(np.maximum(dx,0)**2+np.maximum(dy,0)**2)+np.minimum(np.maximum(dx,dy),0)-rad
        cover = (np.clip(0.5-q,0,1)*255).astype(np.uint8)
        gcx, gcy = 0.5, 0.5

    elif frame == "shield":
        pts = (shield_pts()*S).astype(np.int32)
        cv2.fillPoly(cover, [pts], 255)
        gcx, gcy = 0.5, 0.48

    else:  # terminal
        x0, y0 = int(0.035*S), int(0.17*S)
        x1, y1 = int(0.965*S), int(0.83*S)
        r = int(0.075*S)
        cv2.rectangle(cover, (x0+r,y0), (x1-r,y1), 255, -1)
        cv2.rectangle(cover, (x0,y0+r), (x1,y1-r), 255, -1)
        for cx, cy in ((x0+r,y0+r),(x1-r,y0+r),(x0+r,y1-r),(x1-r,y1-r)):
            cv2.circle(cover,(cx,cy),r,255,-1)
        tb = y0 + int(0.14*(y1-y0))
        gcx, gcy = 0.5, (tb/S + y1/S)/2.0 + 0.01
        if size > 32:   # 小尺寸省略圆点，避免糊成一团
            for k in range(3):
                cv2.circle(img,(x0+int((0.045+0.05*k)*S), y0+int(0.07*(y1-y0))),
                           max(1,int(0.018*S)), (0,0,0), -1, cv2.LINE_AA)
            img[cover<128] = 255

    # 字形
    gh = glyph_ratio(frame, size) * S
    sc = gh / GH
    gp = POLY*sc + np.array([gcx*S - (GW*sc)/2.0, gcy*S - gh/2.0], np.float32)
    gm = np.zeros((S,S), np.uint8)
    cv2.fillPoly(gm, [np.round(gp).astype(np.int32)], 255)
    img[gm>127] = (0,0,0)
    img[cover<128] = 255          # 框外不参与颜色（透明）

    img_s = cv2.resize(img,(size,size),interpolation=cv2.INTER_AREA)
    alpha = cv2.resize(cover,(size,size),interpolation=cv2.INTER_AREA).astype(np.float32)/255.0
    if hard:
        alpha = (alpha>0.4).astype(np.float32)
        img_s = np.where(img_s < 128, 0, 255).astype(np.uint8)
    rgba = np.dstack([img_s[:,:,2], img_s[:,:,1], img_s[:,:,0], (alpha*255).astype(np.uint8)])
    return Image.fromarray(np.ascontiguousarray(rgba), "RGBA")

ICO = [(256,256),(128,128),(64,64),(48,48),(40,40),(32,32),(24,24),(20,20),(16,16)]
if __name__ == "__main__":
    os.makedirs("frames", exist_ok=True)
    for frame, fname in (("square","cyril-square.ico"), ("shield","cyril-shield.ico"), ("terminal","cyril-terminal.ico")):
        imgs = {s: render(s, frame) for s in (16,20,24,32,40,48,64,96,128,192,256)}
        for s, im in imgs.items():
            im.save(f"frames/{frame}-{s}.png")
        imgs[256].save(fname, format="ICO", sizes=ICO,
                       append_images=[imgs[s] for s in (128,64,48,40,32,24,20,16)])
        print(fname, os.path.getsize(fname), "B")
