/* 只替换 exe 的图标资源，不重建整个 Electron app 目录。
 *
 * 用法：node set-icon.mjs [exe路径] [ico路径]
 * 默认：electron-dist/WebTerm-Electron-win32-x64/WebTerm-Electron.exe + assets/app.ico
 * 产物写到 <exe>.new，由调用方改名替换；脚本不覆盖、不删除任何现有文件。
 */
import { Data, NtExecutable, NtExecutableResource, Resource } from 'resedit';
import { readFile, writeFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const exePath = process.argv[2]
  || path.join(root, 'electron-dist', 'WebTerm-Electron-win32-x64', 'WebTerm-Electron.exe');
const iconPath = process.argv[3] || path.join(here, 'assets', 'app.ico');

const [exeBuf, icoBuf] = await Promise.all([readFile(exePath), readFile(iconPath)]);
const exe = NtExecutable.from(exeBuf);
const res = NtExecutableResource.from(exe);
const groups = Resource.IconGroupEntry.fromEntries(res.entries);
if (groups.length !== 1) {
  throw new Error(`预期 1 个图标组，实际 ${groups.length} 个`);
}
const ico = Data.IconFile.from(icoBuf);
if (!ico.icons.length) throw new Error('ico 文件没有可用图标帧');

Resource.IconGroupEntry.replaceIconsForResource(
  res.entries, groups[0].id, groups[0].lang, ico.icons.map((i) => i.data)
);
res.outputResource(exe);

const outPath = exePath + '.new';
await writeFile(outPath, Buffer.from(exe.generate()));
const st = await stat(outPath);
console.log('源 exe   :', exePath, exeBuf.length, 'bytes');
console.log('图标     :', iconPath, ico.icons.length, '帧');
console.log('已生成   :', outPath, st.size, 'bytes');
