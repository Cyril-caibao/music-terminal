'use strict';
/* 把已经打包好的 electron-dist/WebTerm-Electron-win32-x64 做成 Windows 安装包。
 * 用 electron-winstaller（Squirrel.Windows）：生成 setup.exe + 自动安装到
 * %LOCALAPPDATA%、创建开始菜单 / 桌面快捷方式、写入“程序和功能”卸载项。
 * 不走 usePackageJson（dist 根没有 package.json），所有元数据显式给出。 */
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { createWindowsInstaller } = require('electron-winstaller');

const ROOT = path.resolve(__dirname, '..');
const appDir = path.join(ROOT, 'electron-dist', 'WebTerm-Electron-win32-x64');
const outDir = path.join(ROOT, 'installer');
const ICON = path.join(__dirname, 'assets', 'app.ico');

if (!fs.existsSync(appDir)) {
  console.error('appDirectory 不存在:', appDir);
  process.exit(1);
}

/* 打包源不直接用 appDir：它下面混着运行时可写数据（users.json 的真实账号哈希、
   Settings.json 的本机面板坐标、components/ 里 300MB+ 的用户插件工具链、
   lxmusic-data/ 音乐缓存）和历次 exe 备份 *.prev*。
   NuGet <file exclude> / 精确 <file> 清单都不生效：Squirrel 的 --releasify 会
   把 appDirectory 整个 resources 目录收进 full 包。
   这里用硬链接构造一个只含程序文件的 staging 目录：不复制数据、不改动原目录、
   不占用额外磁盘。打包后 staging 保留供下次复用。 */
const STAGING = path.join(ROOT, 'electron-dist', '_staging');
const SKIP_NAMES = new Set(['components', 'lxmusic-data', 'Settings.json', 'users.json']);
function buildStaging() {
  fs.mkdirSync(STAGING, { recursive: true });
  let linked = 0, reused = 0;
  function walk(srcDir, relDir) {
    for (const ent of fs.readdirSync(srcDir, { withFileTypes: true })) {
      const name = ent.name;
      if (SKIP_NAMES.has(name) || /\.prev\d*$/.test(name) ||
          name.endsWith('.pack-tmp') || name.endsWith('.new') ||
          name === 'Cyril-Terminal.lnk') continue;
      const src = path.join(srcDir, name);
      const dst = path.join(STAGING, relDir, name);
      if (ent.isDirectory()) {
        fs.mkdirSync(dst, { recursive: true });
        walk(src, path.join(relDir, name));
      } else if (ent.isFile()) {
        const st = fs.statSync(src);
        let need = true;
        try {
          const d = fs.statSync(dst);
          need = d.size !== st.size || Math.abs(d.mtimeMs - st.mtimeMs) > 1;
        } catch (e) { need = true; }
        if (need) {
          if (fs.existsSync(dst)) fs.unlinkSync(dst);
          fs.linkSync(src, dst);
          linked++;
        } else reused++;
      }
    }
  }
  walk(appDir, '');
  console.log('staging     :', STAGING);
  console.log('硬链接      : 新增/更新', linked, '复用', reused);
  return STAGING;
}

const staging = buildStaging();

const opts = {
  appDirectory: staging,
  outputDirectory: outDir,
  usePackageJson: false,
  name: 'WebTerm',
  title: 'Cyril Web Terminal',
  version: '1.0.3',
  authors: 'Cyril',
  description: 'Cyril - Web Terminal for Windows',
  exe: 'WebTerm-Electron.exe',
  /* electron-winstaller 默认把 iconUrl 硬编码成 GitHub raw 的 electron.ico，
     Squirrel 安装时会拿 WebClient 去下（写「程序和功能」里的图标）。国内连
     GitHub raw 会卡到 56 秒才超时 —— 安装动画就一直挂着，看着像卡死/残留。
     改成本地 file:// 路径：本机安装能直接读到（图标正常），换到别的机器上
     文件不存在则立即失败（只是没图标），绝不再等网络超时。 */
  iconUrl: pathToFileURL(ICON).href,
  setupIcon: ICON,
  /* 自定义 nuspec：resources/ 精确列出两个程序文件，配合 staging 双保险。 */
  nuspecTemplate: path.join(__dirname, 'installer.nuspectemplate'),
  noMsi: true,        // 只出 setup.exe，不要 MSI
  noDelta: true,      // 首次发布不需要 delta 增量包
  setupExe: 'WebTerm-Electron-Setup-1.0.3.exe'
};

console.log('== 构建安装包 ==');
console.log('appDirectory :', appDir);
console.log('output       :', outDir);
console.log('options      :', JSON.stringify(opts, null, 2));

createWindowsInstaller(opts)
  .then(() => {
    console.log('\n✅ 安装包构建完成，输出目录:', outDir);
    console.log('内容:');
    for (const f of fs.readdirSync(outDir)) {
      const st = fs.statSync(path.join(outDir, f));
      console.log('  ', f, (st.size / 1048576).toFixed(1) + ' MB');
    }
  })
  .catch((e) => {
    console.error('\n❌ 安装包构建失败:');
    console.error(e && e.stack ? e.stack : e);
    process.exit(1);
  });
